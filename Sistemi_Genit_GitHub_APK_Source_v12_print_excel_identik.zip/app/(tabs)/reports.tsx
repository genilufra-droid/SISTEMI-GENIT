import React from "react";
import { Alert, FlatList, Platform, Pressable, ScrollView, Switch, Text, TextInput, View } from "react-native";
import { useLocalSearchParams } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { Badge, Btn, Header } from "@/components/ui-kit";
import { useStore, allSalesmen } from "@/lib/store";
import {
  REPORT_CATALOG,
  ReportFilter,
  ReportType,
  buildReport,
  renderReportHtml,
} from "@/lib/reports";
import { exportReportToExcel } from "@/lib/excel";
import { buildSqliteReport } from "@/lib/sqlite-reports";
import * as Print from "expo-print";
import * as Sharing from "expo-sharing";

type ParamShape = { type?: string; client?: string; supplier?: string; product?: string };

const GROUP_ORDER = ["Shitje", "Blerje", "Stoku", "Manaxher", "Detyrime", "Shpenzime", "Shitës / GPS"];
type MultiKind = "clients" | "suppliers" | "products" | "stores" | "salesmen" | "categories";

export default function ReportsScreen() {
  const colors = useColors();
  const { db, setDB } = useStore();
  const params = useLocalSearchParams<ParamShape>();

  const [type, setType] = React.useState<ReportType>(
    (params.type as ReportType) || "salesSummary",
  );
  const [filters, setFilters] = React.useState<ReportFilter>({
    clients: typeof params.client === "string" && params.client ? [params.client] : [],
    suppliers: typeof params.supplier === "string" && params.supplier ? [params.supplier] : [],
    products: typeof params.product === "string" && params.product ? [params.product] : [],
    stores: [],
    units: [],
    from: "",
    to: "",
  });

  const [pickerOpen, setPickerOpen] = React.useState(false);
  const [searchPicker, setSearchPicker] = React.useState("");
  const [multiPicker, setMultiPicker] = React.useState<null | MultiKind>(null);
  const [partySearch, setPartySearch] = React.useState("");
  const [pdfOpen, setPdfOpen] = React.useState(false);
  const [pdfOpts, setPdfOpts] = React.useState({ showCompany: true, showFilters: true, showSummary: true, zebra: true });
  const [rowSearch, setRowSearch] = React.useState("");

  // Reset the live result search whenever the report type changes
  React.useEffect(() => { setRowSearch(""); }, [type]);

  // Sync the report type with incoming navigation params. The Reports tab stays
  // mounted, so a fresh `params.type` (e.g. tapping a different report link from
  // the menu) must update state — otherwise the previously opened report stays
  // on screen. We validate against the catalog so an unknown value is ignored.
  React.useEffect(() => {
    const t = params.type;
    if (typeof t === "string" && t && REPORT_CATALOG.some((r) => r.value === t) && t !== type) {
      setType(t as ReportType);
    }
  }, [params.type]);

  // Keep the single-value filters in sync when navigating with a target party /
  // product (e.g. "Kartela e Artikullit" opened from the product screen).
  React.useEffect(() => {
    setFilters((f) => ({
      ...f,
      products: typeof params.product === "string" && params.product ? [params.product] : f.products,
      clients: typeof params.client === "string" && params.client ? [params.client] : f.clients,
      suppliers: typeof params.supplier === "string" && params.supplier ? [params.supplier] : f.suppliers,
    }));
  }, [params.product, params.client, params.supplier]);

  const favorites = db.settings.favoriteReports || [];
  const isFavorite = favorites.includes(type);
  const toggleFavorite = (t: ReportType) => {
    setDB((prev) => {
      const cur = prev.settings.favoriteReports || [];
      const next = cur.includes(t) ? cur.filter((x) => x !== t) : [...cur, t];
      return { ...prev, settings: { ...prev.settings, favoriteReports: next } };
    });
  };

  const reportEntry = REPORT_CATALOG.find((r) => r.value === type) || REPORT_CATALOG[0];
  const memoryResult = React.useMemo(() => buildReport(type, db, filters), [type, db, filters]);
  const [sqliteResult, setSqliteResult] = React.useState<ReturnType<typeof buildReport> | null>(null);

  React.useEffect(() => {
    let alive = true;
    setSqliteResult(null);
    buildSqliteReport(type, filters)
      .then((r) => { if (alive) setSqliteResult(r); })
      .catch(() => { if (alive) setSqliteResult(null); });
    return () => { alive = false; };
  }, [type, filters]);

  const result = sqliteResult || memoryResult;

  // Fast client-side text search across all visible columns of the result rows
  const visibleRows = React.useMemo(() => {
    const q = rowSearch.trim().toLowerCase();
    if (!q) return result.rows;
    return result.rows.filter((r) =>
      result.columns.some((c) => String((r as any)[c.key] ?? "").toLowerCase().includes(q)),
    );
  }, [rowSearch, result]);

  const groupedCatalog = React.useMemo(() => {
    const norm = searchPicker.trim().toLowerCase();
    return GROUP_ORDER.map((g) => ({
      group: g,
      items: REPORT_CATALOG.filter(
        (r) => r.group === g && (!norm || r.label.toLowerCase().includes(norm)),
      ),
    })).filter((g) => g.items.length > 0);
  }, [searchPicker]);

  // Units available across all products (for the unit chips filter)
  const allUnits = React.useMemo(() => {
    const set: string[] = [];
    db.products.forEach((p) => (p.units || []).forEach((u) => {
      if (!set.some((x) => x.toLowerCase() === u.name.toLowerCase())) set.push(u.name);
    }));
    return set;
  }, [db.products]);

  const filtersText = React.useMemo(() => {
    const parts: string[] = [];
    if (filters.from || filters.to) parts.push(`${filters.from || "…"} → ${filters.to || "…"}`);
    if (filters.clients?.length) parts.push(`Klientë: ${filters.clients.join(", ")}`);
    if (filters.suppliers?.length) parts.push(`Furnitorë: ${filters.suppliers.join(", ")}`);
    if (filters.products?.length) parts.push(`Artikuj: ${filters.products.join(", ")}`);
    if (filters.stores?.length) parts.push(`Magazina: ${filters.stores.join(", ")}`);
    if (filters.units?.length) parts.push(`Njësi: ${filters.units.join(", ")}`);
    if (filters.salesmen?.length) parts.push(`Shitës: ${filters.salesmen.join(", ")}`);
    if (filters.categories?.length) parts.push(`Kategori: ${filters.categories.join(", ")}`);
    if (filters.txnType && filters.txnType !== "all") parts.push(`Lloji: ${filters.txnType === "cash" ? "Kesh" : "Kredi"}`);
    if (filters.payStatus && filters.payStatus !== "all") parts.push(`Statusi: ${filters.payStatus === "paid" ? "Paguar" : filters.payStatus === "partial" ? "Pjesërisht" : "Pa paguar"}`);
    return parts.join("  •  ");
  }, [filters]);

  // Build an export-ready result that respects the in-results text search.
  // When a row search is active we export only the visible rows and recompute
  // any numeric summary lines from those rows so totals match what is on screen.
  const exportResult = React.useMemo(() => {
    if (!rowSearch.trim() || visibleRows.length === result.rows.length) return result;
    const fmtMoney = (n: number) =>
      new Intl.NumberFormat("sq-AL", { maximumFractionDigits: 2 }).format(n);
    const recomputed = (result.summary || []).map((s) => {
      // Try to map a summary label to a money/qty column and re-sum visible rows.
      const col = result.columns.find(
        (c) => c.format === "money" && s.label.toLowerCase().includes(c.label.toLowerCase()),
      );
      if (col) {
        const sum = visibleRows.reduce((a, r) => a + Number((r as any)[col.key] || 0), 0);
        return { ...s, value: fmtMoney(sum) };
      }
      return s;
    });
    return {
      ...result,
      subtitle: result.subtitle
        ? `${result.subtitle}  •  Kërkim: “${rowSearch.trim()}”`
        : `Kërkim: “${rowSearch.trim()}”`,
      rows: visibleRows,
      summary: recomputed.length ? recomputed : result.summary,
    };
  }, [result, visibleRows, rowSearch]);

  const onShare = async () => {
    const html = renderReportHtml(exportResult, { companyName: db.company.name, filters, currency: db.company.currency });
    try {
      if (Platform.OS === "web") { await Print.printAsync({ html }); return; }
      const { uri } = await Print.printToFileAsync({ html });
      if (await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(uri, { mimeType: "application/pdf", dialogTitle: result.title });
      } else {
        await Print.printAsync({ html });
      }
    } catch (e: any) { Alert.alert("Gabim", String(e?.message || e)); }
  };

  const onPrint = async () => {
    const html = renderReportHtml(exportResult, { companyName: db.company.name, filters, currency: db.company.currency });
    try { await Print.printAsync({ html }); } catch (e: any) { Alert.alert("Gabim", String(e?.message || e)); }
  };

  const onExcel = async () => {
    try {
      const ft = rowSearch.trim() ? `${filtersText}${filtersText ? "  •  " : ""}Kërkim: “${rowSearch.trim()}”` : filtersText;
      await exportReportToExcel(exportResult, { companyName: db.company.name, filtersText: ft, currency: db.company.currency });
    } catch (e: any) {
      Alert.alert("Gabim Excel", String(e?.message || e));
    }
  };

  const setFilter = (patch: Partial<ReportFilter>) => setFilters((f) => ({ ...f, ...patch }));

  const toggleMulti = (kind: MultiKind, value: string) => {
    setFilters((f) => {
      const cur = (f[kind] as string[] | undefined) || [];
      const next = cur.some((x) => x.toLowerCase() === value.toLowerCase())
        ? cur.filter((x) => x.toLowerCase() !== value.toLowerCase())
        : [...cur, value];
      return { ...f, [kind]: next };
    });
  };

  const toggleUnit = (u: string) => {
    setFilters((f) => {
      const cur = f.units || [];
      const next = cur.some((x) => x.toLowerCase() === u.toLowerCase())
        ? cur.filter((x) => x.toLowerCase() !== u.toLowerCase())
        : [...cur, u];
      return { ...f, units: next };
    });
  };

  const optionList = React.useMemo(() => {
    const norm = partySearch.toLowerCase();
    let base: string[] = [];
    if (multiPicker === "clients") base = db.customers.map((c) => c.name);
    else if (multiPicker === "suppliers") base = db.suppliers.map((s) => s.name);
    else if (multiPicker === "products") base = db.products.map((p) => p.name);
    else if (multiPicker === "stores") base = db.stores;
    else if (multiPicker === "salesmen") base = allSalesmen(db);
    else if (multiPicker === "categories") {
      const set: string[] = [];
      db.products.forEach((p) => {
        if (p.category && !set.some((x) => x.toLowerCase() === p.category!.toLowerCase())) set.push(p.category);
      });
      base = set;
    }
    return base.filter((n) => !norm || n.toLowerCase().includes(norm));
  }, [multiPicker, partySearch, db]);

  const clearAll = () =>
    setFilters({ clients: [], suppliers: [], products: [], stores: [], units: [], salesmen: [], categories: [], from: "", to: "", txnType: "all", payStatus: "all" });

  return (
    <ScreenContainer>
      <Header title="Raporte" />
      <ScrollView contentContainerStyle={{ paddingBottom: 24 }}>
        {/* Report picker */}
        <View style={{ paddingHorizontal: 12, paddingTop: 12 }}>
          <Pressable
            onPress={() => setPickerOpen(true)}
            style={{ backgroundColor: colors.surface, borderRadius: 10, padding: 12, borderWidth: 1, borderColor: colors.border }}
          >
            <Text style={{ color: colors.muted, fontSize: 11 }}>Lloji i raportit • {reportEntry.group}</Text>
            <Text style={{ fontSize: 16, fontWeight: "800", color: colors.foreground, marginTop: 4 }}>{reportEntry.label}</Text>
          </Pressable>
        </View>

        {/* Dates */}
        <View style={{ flexDirection: "row", gap: 8, paddingHorizontal: 12, marginTop: 8 }}>
          <FilterField label="Nga" value={filters.from || ""} onChange={(v) => setFilter({ from: v })} placeholder="2026-01-01" />
          <FilterField label="Deri" value={filters.to || ""} onChange={(v) => setFilter({ to: v })} placeholder="2026-12-31" />
        </View>

        {/* Multi-select pickers */}
        <View style={{ flexDirection: "row", gap: 8, paddingHorizontal: 12, marginTop: 8, flexWrap: "wrap" }}>
          <MultiField label="Klientët" values={filters.clients} onOpen={() => { setMultiPicker("clients"); setPartySearch(""); }} onClear={() => setFilter({ clients: [] })} />
          <MultiField label="Furnitorët" values={filters.suppliers} onOpen={() => { setMultiPicker("suppliers"); setPartySearch(""); }} onClear={() => setFilter({ suppliers: [] })} />
          <MultiField label="Artikujt" values={filters.products} onOpen={() => { setMultiPicker("products"); setPartySearch(""); }} onClear={() => setFilter({ products: [] })} />
          <MultiField label="Magazinat" values={filters.stores} onOpen={() => { setMultiPicker("stores"); setPartySearch(""); }} onClear={() => setFilter({ stores: [] })} />
          <MultiField label="Shitësit" values={filters.salesmen} onOpen={() => { setMultiPicker("salesmen"); setPartySearch(""); }} onClear={() => setFilter({ salesmen: [] })} />
          <MultiField label="Kategoritë" values={filters.categories} onOpen={() => { setMultiPicker("categories"); setPartySearch(""); }} onClear={() => setFilter({ categories: [] })} />
        </View>

        {/* Unit chips */}
        {allUnits.length > 0 ? (
          <View style={{ paddingHorizontal: 12, marginTop: 10 }}>
            <Text style={{ color: colors.muted, fontSize: 11, fontWeight: "800", textTransform: "uppercase", marginBottom: 6 }}>Njësia</Text>
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6 }}>
              {allUnits.map((u) => {
                const active = (filters.units || []).some((x) => x.toLowerCase() === u.toLowerCase());
                return (
                  <Pressable
                    key={u}
                    onPress={() => toggleUnit(u)}
                    style={({ pressed }) => ({
                      paddingHorizontal: 12, paddingVertical: 7, borderRadius: 16,
                      backgroundColor: active ? colors.primary : colors.surface,
                      borderWidth: 1, borderColor: active ? colors.primary : colors.border,
                      opacity: pressed ? 0.8 : 1,
                    })}
                  >
                    <Text style={{ color: active ? "#fff" : colors.foreground, fontWeight: "700", fontSize: 12 }}>{u}</Text>
                  </Pressable>
                );
              })}
            </View>
          </View>
        ) : null}

        {/* Transaction type + payment status chips */}
        <View style={{ paddingHorizontal: 12, marginTop: 10 }}>
          <Text style={{ color: colors.muted, fontSize: 11, fontWeight: "800", textTransform: "uppercase", marginBottom: 6 }}>Lloji i transaksionit</Text>
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6 }}>
            {([["all", "Të gjitha"], ["cash", "Kesh"], ["credit", "Kredi"]] as const).map(([val, lbl]) => {
              const active = (filters.txnType || "all") === val;
              return (
                <Pressable key={val} onPress={() => setFilter({ txnType: val })}
                  style={({ pressed }) => ({ paddingHorizontal: 12, paddingVertical: 7, borderRadius: 16, backgroundColor: active ? colors.primary : colors.surface, borderWidth: 1, borderColor: active ? colors.primary : colors.border, opacity: pressed ? 0.8 : 1 })}>
                  <Text style={{ color: active ? "#fff" : colors.foreground, fontWeight: "700", fontSize: 12 }}>{lbl}</Text>
                </Pressable>
              );
            })}
          </View>
          <Text style={{ color: colors.muted, fontSize: 11, fontWeight: "800", textTransform: "uppercase", marginTop: 10, marginBottom: 6 }}>Statusi i pagesës</Text>
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6 }}>
            {([["all", "Të gjitha"], ["paid", "Paguar"], ["partial", "Pjesërisht"], ["unpaid", "Pa paguar"]] as const).map(([val, lbl]) => {
              const active = (filters.payStatus || "all") === val;
              return (
                <Pressable key={val} onPress={() => setFilter({ payStatus: val })}
                  style={({ pressed }) => ({ paddingHorizontal: 12, paddingVertical: 7, borderRadius: 16, backgroundColor: active ? colors.primary : colors.surface, borderWidth: 1, borderColor: active ? colors.primary : colors.border, opacity: pressed ? 0.8 : 1 })}>
                  <Text style={{ color: active ? "#fff" : colors.foreground, fontWeight: "700", fontSize: 12 }}>{lbl}</Text>
                </Pressable>
              );
            })}
          </View>
        </View>

        {/* Selected-filter chips (live) */}
        {filtersText ? (
          <View style={{ paddingHorizontal: 12, marginTop: 10 }}>
            <View style={{ backgroundColor: colors.surface, borderRadius: 8, borderWidth: 1, borderColor: colors.border, padding: 8 }}>
              <Text style={{ color: colors.muted, fontSize: 11 }} numberOfLines={3}>{filtersText}</Text>
            </View>
          </View>
        ) : null}

        {/* Actions */}
        <View style={{ flexDirection: "row", gap: 8, paddingHorizontal: 12, marginTop: 12, flexWrap: "wrap" }}>
          <Btn title="Excel" icon="square.and.arrow.up" onPress={onExcel} />
          <Btn title="Printo" icon="printer.fill" variant="soft" onPress={onPrint} />
          <Btn title="PDF" icon="square.and.arrow.up" variant="soft" onPress={() => setPdfOpen(true)} />
          <Btn title={isFavorite ? "★ Hiq" : "☆ Prefero"} icon="tag.fill" variant="ghost" onPress={() => toggleFavorite(type)} />
          <Btn title="Pastro" icon="xmark" variant="ghost" onPress={clearAll} />
        </View>

        {/* Favorites strip */}
        {favorites.length > 0 ? (
          <View style={{ paddingHorizontal: 12, marginTop: 12 }}>
            <Text style={{ color: colors.muted, fontSize: 11, fontWeight: "800", textTransform: "uppercase", marginBottom: 6 }}>Të preferuarat</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 6 }}>
              {favorites.map((f) => {
                const entry = REPORT_CATALOG.find((r) => r.value === f);
                if (!entry) return null;
                const active = entry.value === type;
                return (
                  <Pressable
                    key={f}
                    onPress={() => setType(entry.value)}
                    style={({ pressed }) => ({
                      paddingHorizontal: 12, paddingVertical: 8, borderRadius: 16,
                      backgroundColor: active ? colors.primary : colors.surface,
                      borderWidth: 1, borderColor: active ? colors.primary : colors.border, opacity: pressed ? 0.8 : 1,
                    })}
                  >
                    <Text style={{ color: active ? "#fff" : colors.foreground, fontWeight: "700", fontSize: 12 }}>{entry.label}</Text>
                  </Pressable>
                );
              })}
            </ScrollView>
          </View>
        ) : null}

        {/* Title */}
        <View style={{ paddingHorizontal: 12, marginTop: 14 }}>
          <Text style={{ fontSize: 18, fontWeight: "900", color: colors.foreground }}>{result.title}</Text>
          {result.subtitle ? <Text style={{ color: colors.muted, fontSize: 12, marginTop: 2 }}>{result.subtitle}</Text> : null}
        </View>

        {/* Summary */}
        {result.summary && result.summary.length > 0 ? (
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8, paddingHorizontal: 12, marginTop: 8 }}>
            {result.summary.map((s, i) => (
              <View key={i} style={{ backgroundColor: colors.surface, borderRadius: 8, borderWidth: 1, borderColor: colors.border, paddingHorizontal: 10, paddingVertical: 6, minWidth: 110 }}>
                <Text style={{ color: colors.muted, fontSize: 11 }}>{s.label}</Text>
                <Text style={{ color: colors.foreground, fontWeight: "800", fontSize: 14 }}>{s.value}</Text>
              </View>
            ))}
          </View>
        ) : null}

        {/* Fast live search across result rows */}
        {result.rows.length > 0 ? (
          <View style={{ paddingHorizontal: 12, marginTop: 12 }}>
            <View style={{ backgroundColor: colors.surface, borderRadius: 10, paddingHorizontal: 12, borderWidth: 1, borderColor: rowSearch ? colors.primary : colors.border, flexDirection: "row", alignItems: "center", gap: 8 }}>
              <Text style={{ color: colors.muted, fontSize: 15 }}>🔍</Text>
              <TextInput
                value={rowSearch}
                onChangeText={setRowSearch}
                placeholder="Kërko në rezultate…"
                placeholderTextColor={colors.muted}
                style={{ flex: 1, paddingVertical: 10, color: colors.foreground }}
              />
              {rowSearch ? (
                <Pressable onPress={() => setRowSearch("")} hitSlop={10}>
                  <Text style={{ color: colors.error, fontWeight: "900", fontSize: 16 }}>×</Text>
                </Pressable>
              ) : null}
            </View>
            <Text style={{ color: colors.muted, fontSize: 11, marginTop: 4 }}>
              {visibleRows.length} {visibleRows.length === 1 ? "rezultat" : "rezultate"}
              {rowSearch ? ` nga ${result.rows.length}` : ""}
            </Text>
          </View>
        ) : null}

        {/* Table */}
        <View style={{ paddingHorizontal: 12, marginTop: 12 }}>
          {result.rows.length === 0 ? (
            <View style={{ alignItems: "center", padding: 40 }}>
              <Text style={{ color: colors.muted }}>{result.emptyMessage || "Pa të dhëna në periudhën e zgjedhur"}</Text>
            </View>
          ) : visibleRows.length === 0 ? (
            <View style={{ alignItems: "center", padding: 40 }}>
              <Text style={{ color: colors.muted }}>Asnjë rresht nuk përputhet me “{rowSearch}”</Text>
            </View>
          ) : (
            <ScrollView horizontal>
              <View>
                <View style={{ flexDirection: "row", borderBottomWidth: 2, borderColor: colors.primary, paddingBottom: 6 }}>
                  {result.columns.map((c, i) => (
                    <Text key={i} style={{ minWidth: colWidth(c.format), textAlign: c.align || "left", fontWeight: "800", color: colors.primary, fontSize: 12, paddingHorizontal: 6 }}>
                      {c.label}
                    </Text>
                  ))}
                </View>
                {visibleRows.map((r, idx) => {
                  const isTotal = !!(r as any)._total;
                  return (
                    <View key={idx} style={{ flexDirection: "row", paddingVertical: 6, borderBottomWidth: 1, borderColor: colors.border, backgroundColor: isTotal ? "#16a34a" : idx % 2 === 0 ? colors.surface : "transparent" }}>
                      {result.columns.map((c, i) => (
                        <Text key={i} style={{ minWidth: colWidth(c.format), textAlign: c.align || "left", color: isTotal ? "#fff" : colors.foreground, fontWeight: isTotal ? "800" : "400", fontSize: 12, paddingHorizontal: 6 }}>
                          {formatValue((r as any)[c.key], c.format)}
                        </Text>
                      ))}
                    </View>
                  );
                })}
              </View>
            </ScrollView>
          )}
        </View>
      </ScrollView>

      {/* Report-type picker overlay */}
      {pickerOpen ? (
        <View style={overlayStyle}>
          <View style={{ backgroundColor: colors.background, borderRadius: 12, padding: 12, maxHeight: "85%" }}>
            <Text style={{ fontWeight: "900", fontSize: 16, color: colors.foreground, marginBottom: 8 }}>Zgjidh raportin</Text>
            <TextInput
              value={searchPicker}
              onChangeText={setSearchPicker}
              placeholder="Kërko raport…"
              placeholderTextColor={colors.muted}
              style={{ borderWidth: 1, borderColor: colors.border, borderRadius: 8, padding: 10, marginBottom: 8, color: colors.foreground, backgroundColor: colors.surface }}
            />
            <ScrollView>
              {groupedCatalog.map((g) => (
                <View key={g.group} style={{ marginBottom: 8 }}>
                  <Text style={{ fontSize: 11, fontWeight: "900", color: colors.muted, textTransform: "uppercase", marginVertical: 6 }}>{g.group}</Text>
                  {g.items.map((it) => {
                    const active = it.value === type;
                    return (
                      <Pressable
                        key={it.value}
                        onPress={() => { setType(it.value); setPickerOpen(false); setSearchPicker(""); }}
                        style={{ padding: 12, borderRadius: 8, backgroundColor: active ? colors.primary + "22" : colors.surface, borderWidth: 1, borderColor: active ? colors.primary : colors.border, marginBottom: 6, flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}
                      >
                        <Text style={{ color: colors.foreground, fontWeight: "700", flex: 1 }}>{it.label}</Text>
                        {active ? <Badge tone="paid">Aktiv</Badge> : null}
                      </Pressable>
                    );
                  })}
                </View>
              ))}
            </ScrollView>
            <Pressable onPress={() => setPickerOpen(false)} style={{ marginTop: 4, padding: 12, alignSelf: "flex-end" }}>
              <Text style={{ color: colors.primary, fontWeight: "800" }}>Mbyll</Text>
            </Pressable>
          </View>
        </View>
      ) : null}

      {/* PDF customize sheet */}
      {pdfOpen ? (
        <View style={overlayStyle}>
          <View style={{ backgroundColor: colors.background, borderRadius: 12, padding: 16, gap: 10 }}>
            <Text style={{ fontWeight: "900", fontSize: 16, color: colors.foreground }}>Personalizo PDF-në</Text>
            <Text style={{ fontSize: 12, color: colors.muted, marginBottom: 6 }}>Zgjidh çfarë të shfaqet në raportin e printuar.</Text>
            {([
              ["showCompany", "Trego të dhënat e biznesit"],
              ["showFilters", "Trego filtrat e zbatuar"],
              ["showSummary", "Trego përmbledhjen lart"],
              ["zebra", "Rreshta me ngjyrë alternative"],
            ] as const).map(([key, label]) => (
              <View key={key} style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingVertical: 6 }}>
                <Text style={{ color: colors.foreground, fontSize: 14 }}>{label}</Text>
                <Switch value={(pdfOpts as any)[key]} onValueChange={(v) => setPdfOpts((o) => ({ ...o, [key]: v }))} trackColor={{ true: colors.primary, false: colors.border }} />
              </View>
            ))}
            <View style={{ flexDirection: "row", gap: 8, marginTop: 6 }}>
              <View style={{ flex: 1 }}><Btn title="Anulo" variant="ghost" onPress={() => setPdfOpen(false)} /></View>
              <View style={{ flex: 1 }}><Btn title="Gjenero PDF" onPress={async () => { setPdfOpen(false); await onShare(); }} /></View>
            </View>
          </View>
        </View>
      ) : null}

      {/* Multi-select overlay */}
      {multiPicker ? (
        <View style={overlayStyle}>
          <View style={{ backgroundColor: colors.background, borderRadius: 12, padding: 12, maxHeight: "85%" }}>
            <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
              <Text style={{ fontWeight: "900", fontSize: 16, color: colors.foreground }}>
                Zgjidh {multiPicker === "clients" ? "klientët" : multiPicker === "suppliers" ? "furnitorët" : multiPicker === "products" ? "artikujt" : multiPicker === "stores" ? "magazinat" : multiPicker === "salesmen" ? "shitësit" : "kategoritë"}
              </Text>
              <View style={{ backgroundColor: colors.primary, borderRadius: 12, paddingHorizontal: 10, paddingVertical: 3 }}>
                <Text style={{ color: "#fff", fontWeight: "900", fontSize: 12 }}>
                  {((filters[multiPicker] as string[] | undefined) || []).length} të zgjedhur
                </Text>
              </View>
            </View>
            <Text style={{ color: colors.muted, fontSize: 11, marginBottom: 8 }}>Filtri aplikohet menjëherë — tabela rifreskohet live.</Text>
            <TextInput
              value={partySearch}
              onChangeText={setPartySearch}
              placeholder="Kërko…"
              placeholderTextColor={colors.muted}
              style={{ borderWidth: 1, borderColor: colors.border, borderRadius: 8, padding: 10, marginBottom: 8, color: colors.foreground, backgroundColor: colors.surface }}
            />
            <FlatList
              data={optionList}
              keyExtractor={(n) => n}
              renderItem={({ item }) => {
                const selected = ((filters[multiPicker] as string[] | undefined) || []).some((x) => x.toLowerCase() === item.toLowerCase());
                return (
                  <Pressable
                    onPress={() => toggleMulti(multiPicker, item)}
                    style={{ paddingVertical: 12, paddingHorizontal: 10, borderBottomWidth: 1, borderColor: colors.border, flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}
                  >
                    <Text style={{ color: colors.foreground, fontWeight: "700", flex: 1 }}>{item}</Text>
                    <View style={{ width: 22, height: 22, borderRadius: 6, borderWidth: 2, borderColor: selected ? colors.primary : colors.border, backgroundColor: selected ? colors.primary : "transparent", alignItems: "center", justifyContent: "center" }}>
                      {selected ? <Text style={{ color: "#fff", fontWeight: "900", fontSize: 13 }}>✓</Text> : null}
                    </View>
                  </Pressable>
                );
              }}
              ListEmptyComponent={<Text style={{ textAlign: "center", color: colors.muted, padding: 20 }}>Pa rezultate</Text>}
            />
            <View style={{ flexDirection: "row", gap: 8, marginTop: 8 }}>
              <View style={{ flex: 1 }}>
                <Btn title="Pastro" variant="ghost" onPress={() => setFilter({ [multiPicker]: [] } as Partial<ReportFilter>)} />
              </View>
              <View style={{ flex: 1 }}>
                <Btn title="Mbyll" onPress={() => { setMultiPicker(null); setPartySearch(""); }} />
              </View>
            </View>
          </View>
        </View>
      ) : null}
    </ScreenContainer>
  );
}

function colWidth(format?: string) {
  return format === "money" || format === "qty" || format === "pct" ? 110 : 130;
}

function formatValue(val: any, format?: "money" | "qty" | "pct" | "text") {
  if (val == null || val === "") return "";
  if (format === "money") return Number(val || 0).toLocaleString("sq-AL", { maximumFractionDigits: 2 });
  if (format === "qty") return Number(val || 0).toLocaleString("sq-AL", { maximumFractionDigits: 3 });
  if (format === "pct") return `${Number(val || 0).toFixed(1)}%`;
  return String(val);
}

function FilterField({ label, value, onChange, placeholder }: { label: string; value: string; onChange: (v: string) => void; placeholder?: string }) {
  const colors = useColors();
  return (
    <View style={{ flex: 1, backgroundColor: colors.surface, borderRadius: 10, paddingHorizontal: 10, borderWidth: 1, borderColor: colors.border }}>
      <Text style={{ color: colors.muted, fontSize: 11, marginTop: 6 }}>{label}</Text>
      <TextInput value={value} onChangeText={onChange} placeholder={placeholder} placeholderTextColor={colors.muted} style={{ paddingVertical: 8, color: colors.foreground }} />
    </View>
  );
}

function MultiField({ label, values, onOpen, onClear }: { label: string; values?: string[]; onOpen: () => void; onClear: () => void }) {
  const colors = useColors();
  const count = values?.length || 0;
  return (
    <View style={{ flexBasis: "48%", flexGrow: 1 }}>
      <Pressable onPress={onOpen} style={{ backgroundColor: colors.surface, borderRadius: 10, paddingHorizontal: 10, paddingVertical: 8, borderWidth: 1, borderColor: count ? colors.primary : colors.border }}>
        <Text style={{ color: colors.muted, fontSize: 11 }}>{label}</Text>
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
          <Text style={{ color: count ? colors.foreground : colors.muted, fontWeight: "700", fontSize: 14 }} numberOfLines={1}>
            {count === 0 ? "Të gjithë" : count === 1 ? values![0] : `${count} të zgjedhur`}
          </Text>
          {count ? (
            <Pressable onPress={onClear} hitSlop={10} style={{ paddingHorizontal: 4 }}>
              <Text style={{ color: colors.error, fontWeight: "900" }}>×</Text>
            </Pressable>
          ) : null}
        </View>
      </Pressable>
    </View>
  );
}

const overlayStyle = {
  position: "absolute" as const,
  top: 0, left: 0, right: 0, bottom: 0,
  backgroundColor: "rgba(0,0,0,0.45)",
  justifyContent: "center" as const,
  padding: 14,
};
