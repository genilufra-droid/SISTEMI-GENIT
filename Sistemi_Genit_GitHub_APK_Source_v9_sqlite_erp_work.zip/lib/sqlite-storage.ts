/**
 * Sistemi Genit SQLite persistence layer.
 *
 * This replaces the old AsyncStorage-only persistence with a real on-device
 * SQLite database. The app still keeps the rich in-memory DB object used by the
 * existing screens, but the durable storage is SQLite and, on every save, a
 * normalized shadow schema is refreshed so business data can be inspected,
 * exported and validated table-by-table.
 */
import AsyncStorage from "@react-native-async-storage/async-storage";
import type { DB, MultiDB, Product, Invoice, Purchase, Payment, StockMovement, AuditLog, InboundDoc, OutboundDoc, InventoryDoc } from "./store";

type SQLiteDatabase = any;

const SQLITE_DB_NAME = "sistemi_genit_erp.sqlite";
let dbPromise: Promise<SQLiteDatabase | null> | null = null;
let schemaReady = false;

function nowIso(): string {
  return new Date().toISOString();
}

function asJson(value: any): string {
  return JSON.stringify(value ?? null);
}

async function openDb(): Promise<SQLiteDatabase | null> {
  if (!dbPromise) {
    dbPromise = (async () => {
      try {
        // Dynamic require keeps Node/Vitest/web paths from crashing when the
        // native Expo module is unavailable. Native APK uses expo-sqlite.
        // eslint-disable-next-line @typescript-eslint/no-var-requires
        const SQLite = require("expo-sqlite");
        if (SQLite?.openDatabaseAsync) return await SQLite.openDatabaseAsync(SQLITE_DB_NAME);
      } catch (_) {}
      return null;
    })();
  }
  return dbPromise;
}

async function exec(db: SQLiteDatabase, sql: string): Promise<void> {
  await db.execAsync(sql);
}

async function run(db: SQLiteDatabase, sql: string, params: any[] = []): Promise<void> {
  await db.runAsync(sql, params);
}

async function getFirst<T = any>(db: SQLiteDatabase, sql: string, params: any[] = []): Promise<T | null> {
  return (await db.getFirstAsync(sql, params)) as T | null;
}

async function ensureSchema(): Promise<SQLiteDatabase | null> {
  const db = await openDb();
  if (!db) return null;
  if (schemaReady) return db;
  await exec(
    db,
    `PRAGMA journal_mode = WAL;
     PRAGMA foreign_keys = ON;

     CREATE TABLE IF NOT EXISTS kv_store (
       key TEXT PRIMARY KEY NOT NULL,
       value TEXT NOT NULL,
       updated_at TEXT NOT NULL
     );

     CREATE TABLE IF NOT EXISTS companies (
       company_id TEXT PRIMARY KEY NOT NULL,
       name TEXT NOT NULL,
       nipt TEXT,
       address TEXT,
       phone TEXT,
       email TEXT,
       currency TEXT,
       status TEXT,
       created_at TEXT,
       updated_at TEXT NOT NULL
     );

     CREATE TABLE IF NOT EXISTS products (
       company_id TEXT NOT NULL,
       product_id INTEGER NOT NULL,
       code TEXT,
       barcode TEXT,
       name TEXT NOT NULL,
       category TEXT,
       default_store TEXT,
       sale_piece REAL,
       buy_piece REAL,
       stock_base REAL,
       min_stock REAL,
       prices_json TEXT,
       units_json TEXT,
       stock_by_store_json TEXT,
       updated_at TEXT NOT NULL,
       PRIMARY KEY (company_id, product_id)
     );

     CREATE TABLE IF NOT EXISTS parties (
       company_id TEXT NOT NULL,
       party_type TEXT NOT NULL,
       party_id INTEGER NOT NULL,
       name TEXT NOT NULL,
       phone TEXT,
       nipt TEXT,
       city TEXT,
       address TEXT,
       opening_balance REAL,
       credit_limit REAL,
       default_price_list INTEGER,
       note TEXT,
       updated_at TEXT NOT NULL,
       PRIMARY KEY (company_id, party_type, party_id)
     );

     CREATE TABLE IF NOT EXISTS invoices (
       company_id TEXT NOT NULL,
       invoice_no INTEGER NOT NULL,
       date TEXT NOT NULL,
       time TEXT,
       customer TEXT,
       store TEXT,
       mode TEXT,
       subtotal REAL,
       round_off REAL,
       total REAL,
       paid REAL,
       due REAL,
       total_cost REAL,
       profit REAL,
       payment_type TEXT,
       salesman TEXT,
       gps_json TEXT,
       note TEXT,
       updated_at TEXT NOT NULL,
       PRIMARY KEY (company_id, invoice_no)
     );

     CREATE TABLE IF NOT EXISTS invoice_items (
       company_id TEXT NOT NULL,
       invoice_no INTEGER NOT NULL,
       line_no INTEGER NOT NULL,
       product_name TEXT NOT NULL,
       unit TEXT,
       qty REAL,
       free_qty REAL,
       rate REAL,
       buy_rate REAL,
       total REAL,
       cost REAL,
       price_list INTEGER,
       PRIMARY KEY (company_id, invoice_no, line_no)
     );

     CREATE TABLE IF NOT EXISTS purchases (
       company_id TEXT NOT NULL,
       purchase_no INTEGER NOT NULL,
       date TEXT NOT NULL,
       time TEXT,
       supplier TEXT,
       store TEXT,
       mode TEXT,
       subtotal REAL,
       round_off REAL,
       total REAL,
       paid REAL,
       due REAL,
       payment_type TEXT,
       note TEXT,
       updated_at TEXT NOT NULL,
       PRIMARY KEY (company_id, purchase_no)
     );

     CREATE TABLE IF NOT EXISTS purchase_items (
       company_id TEXT NOT NULL,
       purchase_no INTEGER NOT NULL,
       line_no INTEGER NOT NULL,
       product_name TEXT NOT NULL,
       unit TEXT,
       qty REAL,
       free_qty REAL,
       rate REAL,
       buy_rate REAL,
       total REAL,
       cost REAL,
       PRIMARY KEY (company_id, purchase_no, line_no)
     );

     CREATE TABLE IF NOT EXISTS payments (
       company_id TEXT NOT NULL,
       payment_id INTEGER NOT NULL,
       party_type TEXT,
       party TEXT,
       date TEXT,
       amount REAL,
       method TEXT,
       ref TEXT,
       note TEXT,
       updated_at TEXT NOT NULL,
       PRIMARY KEY (company_id, payment_id)
     );

     CREATE TABLE IF NOT EXISTS stock_movements (
       company_id TEXT NOT NULL,
       movement_id INTEGER NOT NULL,
       date TEXT,
       time TEXT,
       warehouse TEXT,
       product_name TEXT,
       doc_type TEXT,
       doc_no TEXT,
       in_base REAL,
       out_base REAL,
       balance_after REAL,
       note TEXT,
       created_at TEXT,
       PRIMARY KEY (company_id, movement_id)
     );

     CREATE TABLE IF NOT EXISTS warehouse_docs (
       company_id TEXT NOT NULL,
       doc_kind TEXT NOT NULL,
       doc_id INTEGER NOT NULL,
       doc_no TEXT,
       date TEXT,
       warehouse TEXT,
       party TEXT,
       destination_address TEXT,
       status TEXT,
       lines_json TEXT,
       total_qty REAL,
       total_value REAL,
       created_at TEXT,
       PRIMARY KEY (company_id, doc_kind, doc_id)
     );

     CREATE TABLE IF NOT EXISTS audit_logs (
       company_id TEXT NOT NULL,
       audit_id INTEGER NOT NULL,
       at TEXT,
       action TEXT,
       entity TEXT,
       entity_id TEXT,
       doc_no TEXT,
       party TEXT,
       total REAL,
       user TEXT,
       before_json TEXT,
       after_json TEXT,
       note TEXT,
       PRIMARY KEY (company_id, audit_id)
     );

     CREATE INDEX IF NOT EXISTS idx_products_name ON products(company_id, name);
     CREATE INDEX IF NOT EXISTS idx_invoices_date ON invoices(company_id, date);
     CREATE INDEX IF NOT EXISTS idx_purchases_date ON purchases(company_id, date);
     CREATE INDEX IF NOT EXISTS idx_stock_product_wh ON stock_movements(company_id, product_name, warehouse);
     CREATE INDEX IF NOT EXISTS idx_audit_action ON audit_logs(company_id, action, at);`,
  );
  schemaReady = true;
  return db;
}

function stockBase(p: Product): number {
  if (p.stockByStore && Object.keys(p.stockByStore).length) {
    return Object.values(p.stockByStore).reduce((sum, v) => sum + Number(v || 0), 0);
  }
  return Number(p.stock || 0);
}

async function clearCompanyShadow(db: SQLiteDatabase, companyId: string): Promise<void> {
  const tables = [
    "products",
    "parties",
    "invoices",
    "invoice_items",
    "purchases",
    "purchase_items",
    "payments",
    "stock_movements",
    "warehouse_docs",
    "audit_logs",
  ];
  for (const table of tables) await run(db, `DELETE FROM ${table} WHERE company_id = ?`, [companyId]);
}

async function insertProducts(db: SQLiteDatabase, companyId: string, slice: DB, updatedAt: string) {
  for (const p of slice.products || []) {
    await run(
      db,
      `INSERT OR REPLACE INTO products
       (company_id, product_id, code, barcode, name, category, default_store, sale_piece, buy_piece, stock_base, min_stock, prices_json, units_json, stock_by_store_json, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        companyId,
        Number(p.id || 0),
        p.code || "",
        p.barcode || "",
        p.name,
        p.category || "",
        p.store || "",
        Number(p.salePiece || 0),
        Number(p.buyPiece || 0),
        stockBase(p),
        Number(p.minStock || 0),
        asJson(p.prices || []),
        asJson(p.units || []),
        asJson(p.stockByStore || {}),
        updatedAt,
      ],
    );
  }
}

async function insertParties(db: SQLiteDatabase, companyId: string, slice: DB, updatedAt: string) {
  const all = [
    ...((slice.customers || []).map((p) => ({ ...p, type: "customer" as const }))),
    ...((slice.suppliers || []).map((p) => ({ ...p, type: "supplier" as const }))),
  ];
  for (const p of all) {
    await run(
      db,
      `INSERT OR REPLACE INTO parties
       (company_id, party_type, party_id, name, phone, nipt, city, address, opening_balance, credit_limit, default_price_list, note, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        companyId,
        p.type,
        Number(p.id || 0),
        p.name,
        p.phone || "",
        p.nipt || "",
        p.city || "",
        p.address || "",
        Number(p.openingBalance || 0),
        Number(p.limit || 0),
        p.defaultPriceList == null ? null : Number(p.defaultPriceList),
        p.note || "",
        updatedAt,
      ],
    );
  }
}

async function insertInvoices(db: SQLiteDatabase, companyId: string, slice: DB, updatedAt: string) {
  for (const inv of slice.invoices || []) {
    await run(
      db,
      `INSERT OR REPLACE INTO invoices
       (company_id, invoice_no, date, time, customer, store, mode, subtotal, round_off, total, paid, due, total_cost, profit, payment_type, salesman, gps_json, note, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        companyId,
        Number(inv.no || 0),
        inv.date,
        inv.time || "",
        inv.customer || "",
        inv.store || "",
        inv.mode || "",
        Number(inv.subtotal || 0),
        Number(inv.roundOff || 0),
        Number(inv.total || 0),
        Number(inv.paid || 0),
        Number(inv.due || 0),
        Number(inv.totalCost || 0),
        Number(inv.profit || 0),
        inv.paymentType || "",
        inv.salesmanName || inv.salesman || "",
        asJson(inv.geo || { lat: inv.latitude, lng: inv.longitude, accuracy: inv.locationAccuracy }),
        inv.note || "",
        updatedAt,
      ],
    );
    let lineNo = 1;
    for (const it of inv.items || []) {
      await run(
        db,
        `INSERT OR REPLACE INTO invoice_items
         (company_id, invoice_no, line_no, product_name, unit, qty, free_qty, rate, buy_rate, total, cost, price_list)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [companyId, Number(inv.no || 0), lineNo++, it.productName, it.unit, Number(it.qty || 0), Number(it.freeQty || 0), Number(it.rate || 0), Number(it.buyRate || 0), Number(it.total || 0), Number(it.cost || 0), it.priceList == null ? null : Number(it.priceList)],
      );
    }
  }
}

async function insertPurchases(db: SQLiteDatabase, companyId: string, slice: DB, updatedAt: string) {
  for (const pur of slice.purchases || []) {
    await run(
      db,
      `INSERT OR REPLACE INTO purchases
       (company_id, purchase_no, date, time, supplier, store, mode, subtotal, round_off, total, paid, due, payment_type, note, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [companyId, Number(pur.no || 0), pur.date, pur.time || "", pur.supplier || "", pur.store || "", pur.mode || "", Number(pur.subtotal || 0), Number(pur.roundOff || 0), Number(pur.total || 0), Number(pur.paid || 0), Number(pur.due || 0), pur.paymentType || "", pur.note || "", updatedAt],
    );
    let lineNo = 1;
    for (const it of pur.items || []) {
      await run(
        db,
        `INSERT OR REPLACE INTO purchase_items
         (company_id, purchase_no, line_no, product_name, unit, qty, free_qty, rate, buy_rate, total, cost)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [companyId, Number(pur.no || 0), lineNo++, it.productName, it.unit, Number(it.qty || 0), Number(it.freeQty || 0), Number(it.rate || 0), Number(it.buyRate || 0), Number(it.total || 0), Number(it.cost || 0)],
      );
    }
  }
}

async function insertPayments(db: SQLiteDatabase, companyId: string, rows: Payment[], updatedAt: string) {
  for (const p of rows) {
    await run(
      db,
      `INSERT OR REPLACE INTO payments
       (company_id, payment_id, party_type, party, date, amount, method, ref, note, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [companyId, Number(p.id || 0), p.partyType || "", p.party || "", p.date || "", Number(p.amount || 0), p.method || "", p.ref || "", p.note || "", updatedAt],
    );
  }
}

async function insertMovements(db: SQLiteDatabase, companyId: string, rows: StockMovement[] = []) {
  for (const m of rows) {
    await run(
      db,
      `INSERT OR REPLACE INTO stock_movements
       (company_id, movement_id, date, time, warehouse, product_name, doc_type, doc_no, in_base, out_base, balance_after, note, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [companyId, Number(m.id || 0), m.date || "", m.time || "", m.warehouse || "", m.productName || "", m.docType || "", String(m.docNo || ""), Number(m.inBase || 0), Number(m.outBase || 0), Number(m.balanceAfter || 0), m.note || "", m.createdAt || ""],
    );
  }
}

async function insertWarehouseDocs(db: SQLiteDatabase, companyId: string, rows: Array<InboundDoc | OutboundDoc | InventoryDoc>, kind: string) {
  for (const d of rows || []) {
    const lines = (d.lines || []) as any[];
    const totalQty = lines.reduce((s, l) => s + Number(l.qty || 0), 0);
    const totalValue = lines.reduce((s, l) => s + Number(l.value || 0), 0);
    await run(
      db,
      `INSERT OR REPLACE INTO warehouse_docs
       (company_id, doc_kind, doc_id, doc_no, date, warehouse, party, destination_address, status, lines_json, total_qty, total_value, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [companyId, kind, Number(d.id || 0), d.no || "", d.date || "", d.warehouse || "", (d as any).customerName || (d as any).supplierName || "", (d as any).destinationAddress || "", d.status || "", asJson(d.lines || []), totalQty, totalValue, d.createdAt || ""],
    );
  }
}

async function insertAudit(db: SQLiteDatabase, companyId: string, rows: AuditLog[] = []) {
  for (const a of rows) {
    await run(
      db,
      `INSERT OR REPLACE INTO audit_logs
       (company_id, audit_id, at, action, entity, entity_id, doc_no, party, total, user, before_json, after_json, note)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [companyId, Number(a.id || 0), a.at || "", a.action || "", a.entity || "", a.entityId || "", String(a.docNo || ""), a.party || "", Number(a.total || 0), a.user || "", asJson(a.before), asJson(a.after), a.note || ""],
    );
  }
}

async function syncShadowTables(db: SQLiteDatabase, mdb: MultiDB): Promise<void> {
  const updatedAt = nowIso();
  await exec(db, "BEGIN TRANSACTION;");
  try {
    await run(db, "DELETE FROM companies");
    for (const meta of mdb.companies || []) {
      await run(
        db,
        `INSERT OR REPLACE INTO companies
         (company_id, name, nipt, address, phone, email, currency, status, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [meta.id, meta.name, meta.nipt || "", meta.address || "", meta.phone || "", meta.email || "", meta.currency || "LEK", meta.status || "active", meta.createdAt || "", updatedAt],
      );
    }
    for (const [companyId, slice] of Object.entries(mdb.data || {})) {
      await clearCompanyShadow(db, companyId);
      await insertProducts(db, companyId, slice, updatedAt);
      await insertParties(db, companyId, slice, updatedAt);
      await insertInvoices(db, companyId, slice, updatedAt);
      await insertPurchases(db, companyId, slice, updatedAt);
      await insertPayments(db, companyId, slice.payments || [], updatedAt);
      await insertMovements(db, companyId, slice.stockMovements || []);
      await insertWarehouseDocs(db, companyId, slice.inboundDocs || [], "inbound");
      await insertWarehouseDocs(db, companyId, slice.outboundDocs || [], "outbound");
      await insertWarehouseDocs(db, companyId, slice.inventoryDocs || [], "inventory");
      await insertAudit(db, companyId, slice.auditLogs || []);
    }
    await exec(db, "COMMIT;");
  } catch (e) {
    try { await exec(db, "ROLLBACK;"); } catch (_) {}
    throw e;
  }
}

export async function readJsonValue<T>(key: string): Promise<T | null> {
  const db = await ensureSchema();
  if (db) {
    try {
      const row = await getFirst<{ value: string }>(db, "SELECT value FROM kv_store WHERE key = ?", [key]);
      if (row?.value) return JSON.parse(row.value) as T;
    } catch (_) {}
  }
  // Fallback + one-time migration from legacy AsyncStorage.
  try {
    const raw = await AsyncStorage.getItem(key);
    if (raw) {
      const parsed = JSON.parse(raw) as T;
      await writeJsonValue(key, parsed);
      return parsed;
    }
  } catch (_) {}
  return null;
}

export async function writeJsonValue<T>(key: string, value: T): Promise<void> {
  const db = await ensureSchema();
  const raw = JSON.stringify(value);
  if (db) {
    await run(db, "INSERT OR REPLACE INTO kv_store(key, value, updated_at) VALUES (?, ?, ?)", [key, raw, nowIso()]);
    if ((value as any)?.schema === 2 && (value as any)?.data) {
      await syncShadowTables(db, value as any as MultiDB);
    }
  }
  // Keep a legacy mirror for emergency restore / older APK downgrade.
  try { await AsyncStorage.setItem(key, raw); } catch (_) {}
}

export async function resetSqliteMirror(): Promise<void> {
  const db = await ensureSchema();
  if (!db) return;
  await exec(
    db,
    `DELETE FROM kv_store;
     DELETE FROM companies;
     DELETE FROM products;
     DELETE FROM parties;
     DELETE FROM invoices;
     DELETE FROM invoice_items;
     DELETE FROM purchases;
     DELETE FROM purchase_items;
     DELETE FROM payments;
     DELETE FROM stock_movements;
     DELETE FROM warehouse_docs;
     DELETE FROM audit_logs;`,
  );
}

export async function sqliteHealthCheck(): Promise<{ ok: boolean; message: string; counts?: Record<string, number> }> {
  const db = await ensureSchema();
  if (!db) return { ok: false, message: "expo-sqlite nuk është aktiv; po përdoret fallback." };
  const tables = ["companies", "products", "parties", "invoices", "invoice_items", "purchases", "purchase_items", "payments", "stock_movements", "warehouse_docs", "audit_logs"];
  const counts: Record<string, number> = {};
  for (const t of tables) {
    const row = await getFirst<{ c: number }>(db, `SELECT COUNT(*) AS c FROM ${t}`);
    counts[t] = Number(row?.c || 0);
  }
  return { ok: true, message: "SQLite aktive me tabela reale ERP.", counts };
}
