/**
 * Shared form for Fletë Hyrje (inbound) and Fletë Dalje (outbound).
 * v7: the entry screen now uses a paper-like warehouse document layout:
 * header/details + a fixed goods table with Nr, Emërtimi, Njësia, Sasia,
 * Çmimi and Vlefta. The table is visible even before items are added, so the
 * form mirrors the physical Fletë Dalje block instead of hiding the line area.
 */
import { useMemo, useState } from "react";
import { Alert, Pressable, ScrollView, Text, TextInput, View } from "react-native";
import { Stack, useRouter } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { Btn, Card } from "@/components/ui-kit";
import { useColors } from "@/hooks/use-colors";
import {
  createInboundDoc,
  createOutboundDoc,
  fmt,
  makeDocNoFrom,
  num,
  stockInStore,
  todayStr,
  unitCoef,
  useStore,
  type Product,
  type WarehouseDocLineInput,
} from "@/lib/store";

type LineDraft = WarehouseDocLineInput & { _k: string };

type TableRow = LineDraft | null;

const MIN_VISIBLE_ROWS = 21;

export function WarehouseDocForm({ kind }: { kind: "inbound" | "outbound" }) {
  const router = useRouter();
  const colors = useColors();
  const { db, setDB } = useStore();

  const title = kind === "inbound" ? "Fletë Hyrje" : "Fletë Dalje";
  const titleUpper = kind === "inbound" ? "FLETË HYRJE" : "FLETË DALJE";

  const activeWarehouses = useMemo(
    () => (db.warehouses || []).filter((w) => w.status === "active"),
    [db.warehouses],
  );

  const [date] = useState(todayStr());
  const [warehouse, setWarehouse] = useState(activeWarehouses[0]?.name || db.stores?.[0] || "");
  const [reason, setReason] = useState("");
  const [partyName, setPartyName] = useState("");
  const [destinationAddress, setDestinationAddress] = useState("");
  const [authorizedPerson, setAuthorizedPerson] = useState("");
  const [vehicle, setVehicle] = useState("");
  const [serialNo, setSerialNo] = useState("");
  const [lines, setLines] = useState<LineDraft[]>([]);
  const [search, setSearch] = useState("");
  const [saving, setSaving] = useState(false);

  const docNoPreview = useMemo(() => {
    const existing = kind === "inbound" ? db.inboundDocs || [] : db.outboundDocs || [];
    return makeDocNoFrom(existing, kind === "inbound" ? "FH" : "FD", date);
  }, [date, db.inboundDocs, db.outboundDocs, kind]);

  const productResults = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return [] as Product[];
    return db.products
      .filter((p) => p.name.toLowerCase().includes(q) || (p.code || "").toLowerCase().includes(q))
      .slice(0, 10);
  }, [db.products, search]);

  const productOf = (name: string) => db.products.find((p) => p.name.toLowerCase() === name.toLowerCase());

  const selectedRows: TableRow[] = useMemo(() => {
    const blankCount = Math.max(0, MIN_VISIBLE_ROWS - lines.length);
    return [...lines, ...Array(blankCount).fill(null)];
  }, [lines]);

  const addLine = (p: Product) => {
    const defaultUnit = p.units?.[1]?.name || p.units?.[0]?.name || "Copë";
    setLines((prev) => [
      ...prev,
      {
        _k: `${p.id}-${Date.now()}`,
        productName: p.name,
        unit: defaultUnit,
        qty: 1,
        price: 0,
      },
    ]);
    setSearch("");
  };

  const updateLine = (k: string, patch: Partial<LineDraft>) =>
    setLines((prev) => prev.map((l) => (l._k === k ? { ...l, ...patch } : l)));

  const removeLine = (k: string) => setLines((prev) => prev.filter((l) => l._k !== k));

  const cycleUnit = (line: LineDraft) => {
    const p = productOf(line.productName);
    const units = p?.units?.length ? p.units.map((u) => u.name) : ["Copë"];
    const idx = Math.max(0, units.findIndex((u) => u === line.unit));
    const next = units[(idx + 1) % units.length] || line.unit;
    updateLine(line._k, { unit: next });
  };

  const validLines = useMemo(() => lines.filter((l) => num(l.qty) > 0), [lines]);
  const totalValue = useMemo(() => validLines.reduce((s, l) => s + num(l.qty) * num(l.price), 0), [validLines]);
  const totalBaseQty = useMemo(() => {
    return validLines.reduce((s, l) => {
      const p = productOf(l.productName);
      return s + num(l.qty) * unitCoef(p, l.unit);
    }, 0);
  }, [validLines, db.products]);

  const save = async () => {
    if (!warehouse) {
      Alert.alert("Gabim", "Zgjidh magazinën.");
      return;
    }
    const cleanLines = validLines;
    if (!cleanLines.length) {
      Alert.alert("Gabim", "Shto të paktën një artikull me sasi.");
      return;
    }
    setSaving(true);
    try {
      let result;
      const input = {
        date,
        warehouse,
        reason: reason.trim() || undefined,
        customerName: kind === "outbound" ? partyName.trim() || undefined : undefined,
        supplierName: kind === "inbound" ? partyName.trim() || undefined : undefined,
        destinationAddress: destinationAddress.trim() || undefined,
        authorizedPerson: authorizedPerson.trim() || undefined,
        vehicle: vehicle.trim() || undefined,
        serialNo: serialNo.trim() || undefined,
        lines: cleanLines.map((l) => ({
          productName: l.productName,
          unit: l.unit,
          qty: num(l.qty),
          price: num(l.price),
        })),
      };
      if (kind === "inbound") {
        result = createInboundDoc(db, input);
      } else {
        result = createOutboundDoc(db, input);
      }
      if (result.error) {
        Alert.alert("Nuk u ruajt dot", result.error);
        setSaving(false);
        return;
      }
      await setDB(result.db);
      Alert.alert("U ruajt", `${title} ${result.doc?.no} u ruajt me sukses.`, [
        { text: "OK", onPress: () => router.back() },
      ]);
    } catch (e: any) {
      Alert.alert("Gabim", e?.message || String(e));
    } finally {
      setSaving(false);
    }
  };

  const inputStyle = {
    color: colors.foreground,
    fontSize: 14,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 8,
    backgroundColor: "#fff",
  } as const;

  const headerCell = (label: string, width: number) => (
    <View
      style={{
        width,
        borderRightWidth: 1,
        borderBottomWidth: 1,
        borderColor: "#222",
        paddingVertical: 7,
        paddingHorizontal: 5,
        backgroundColor: "#e9eef4",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <Text style={{ color: "#111827", fontWeight: "900", fontSize: 12, textAlign: "center" }}>{label}</Text>
    </View>
  );

  const cellStyle = (width: number, extra?: object) => ({
    width,
    minHeight: 42,
    borderRightWidth: 1,
    borderBottomWidth: 1,
    borderColor: "#222",
    paddingHorizontal: 5,
    justifyContent: "center" as const,
    backgroundColor: "#fff",
    ...extra,
  });

  return (
    <>
      <Stack.Screen
        options={{ title, headerStyle: { backgroundColor: colors.primary }, headerTintColor: "#fff" }}
      />
      <ScreenContainer>
        <ScrollView contentContainerStyle={{ padding: 10, gap: 10, paddingBottom: 120 }} keyboardShouldPersistTaps="handled">
          <Card style={{ gap: 8, backgroundColor: "#fff" }}>
            <Text style={{ color: "#111827", fontWeight: "900", fontSize: 24, textAlign: "center", letterSpacing: 0.5 }}>
              {titleUpper}
            </Text>
            <View style={{ borderWidth: 1, borderColor: "#222", borderBottomWidth: 0 }}>
              <View style={{ flexDirection: "row" }}>
                <View style={{ flex: 1, borderRightWidth: 1, borderBottomWidth: 1, borderColor: "#222", padding: 7 }}>
                  <Text style={{ color: "#4b5563", fontSize: 11, fontWeight: "700" }}>Nr.</Text>
                  <Text style={{ color: "#111827", fontWeight: "800" }}>{docNoPreview}</Text>
                </View>
                <View style={{ flex: 1, borderRightWidth: 1, borderBottomWidth: 1, borderColor: "#222", padding: 7 }}>
                  <Text style={{ color: "#4b5563", fontSize: 11, fontWeight: "700" }}>Dt.</Text>
                  <Text style={{ color: "#111827", fontWeight: "800" }}>{date}</Text>
                </View>
                <View style={{ flex: 1.45, borderBottomWidth: 1, borderColor: "#222", padding: 7 }}>
                  <Text style={{ color: "#4b5563", fontSize: 11, fontWeight: "700" }}>Adresa ku shkon malli</Text>
                  <Text style={{ color: "#111827", fontWeight: "700" }} numberOfLines={1}>{destinationAddress || "—"}</Text>
                </View>
              </View>
              <View style={{ flexDirection: "row" }}>
                <View style={{ flex: 1.15, borderRightWidth: 1, borderBottomWidth: 1, borderColor: "#222", padding: 7 }}>
                  <Text style={{ color: "#4b5563", fontSize: 11, fontWeight: "700" }}>{kind === "inbound" ? "Furnitori" : "Marrësi"}</Text>
                  <Text style={{ color: "#111827", fontWeight: "700" }} numberOfLines={1}>{partyName || "—"}</Text>
                </View>
                <View style={{ flex: 1.15, borderRightWidth: 1, borderBottomWidth: 1, borderColor: "#222", padding: 7 }}>
                  <Text style={{ color: "#4b5563", fontSize: 11, fontWeight: "700" }}>Person i autorizuar</Text>
                  <Text style={{ color: "#111827", fontWeight: "700" }} numberOfLines={1}>{authorizedPerson || "—"}</Text>
                </View>
                <View style={{ flex: 1.15, borderBottomWidth: 1, borderColor: "#222", padding: 7 }}>
                  <Text style={{ color: "#4b5563", fontSize: 11, fontWeight: "700" }}>Mjeti transportit</Text>
                  <Text style={{ color: "#111827", fontWeight: "700" }} numberOfLines={1}>{vehicle || "—"}</Text>
                </View>
              </View>
            </View>
          </Card>

          <Card style={{ gap: 10 }}>
            <Text style={{ color: colors.foreground, fontWeight: "900", fontSize: 16 }}>Detaje Dokumenti</Text>

            <View style={{ gap: 4 }}>
              <Text style={{ color: colors.muted, fontSize: 12 }}>Magazina</Text>
              <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6 }}>
                {activeWarehouses.map((w) => {
                  const active = warehouse === w.name;
                  return (
                    <Pressable
                      key={w.id}
                      onPress={() => setWarehouse(w.name)}
                      style={{
                        paddingHorizontal: 12,
                        paddingVertical: 8,
                        borderRadius: 999,
                        borderWidth: 1,
                        borderColor: active ? colors.primary : colors.border,
                        backgroundColor: active ? colors.primary : "transparent",
                      }}
                    >
                      <Text style={{ color: active ? "#fff" : colors.foreground, fontWeight: "700", fontSize: 13 }}>
                        {w.name}
                      </Text>
                    </Pressable>
                  );
                })}
              </View>
            </View>

            <View style={{ gap: 4 }}>
              <Text style={{ color: colors.muted, fontSize: 12 }}>{kind === "inbound" ? "Furnitori" : "Marrësi"}</Text>
              <TextInput
                value={partyName}
                onChangeText={setPartyName}
                placeholder={kind === "inbound" ? "Emri i furnitorit..." : "Emri i marrësit..."}
                placeholderTextColor={colors.muted}
                style={inputStyle}
              />
            </View>

            <View style={{ gap: 4 }}>
              <Text style={{ color: colors.muted, fontSize: 12 }}>Adresa ku shkon malli</Text>
              <TextInput
                value={destinationAddress}
                onChangeText={setDestinationAddress}
                placeholder="Adresa e destinacionit..."
                placeholderTextColor={colors.muted}
                style={inputStyle}
              />
            </View>

            <View style={{ flexDirection: "row", gap: 8 }}>
              <View style={{ flex: 1, gap: 4 }}>
                <Text style={{ color: colors.muted, fontSize: 12 }}>Personi i Autorizuar</Text>
                <TextInput value={authorizedPerson} onChangeText={setAuthorizedPerson} placeholder="Emri..." placeholderTextColor={colors.muted} style={inputStyle} />
              </View>
              <View style={{ flex: 1, gap: 4 }}>
                <Text style={{ color: colors.muted, fontSize: 12 }}>Mjeti</Text>
                <TextInput value={vehicle} onChangeText={setVehicle} placeholder="Targa..." placeholderTextColor={colors.muted} style={inputStyle} />
              </View>
            </View>

            <View style={{ flexDirection: "row", gap: 8 }}>
              <View style={{ flex: 1, gap: 4 }}>
                <Text style={{ color: colors.muted, fontSize: 12 }}>Nr. Reference / Seria</Text>
                <TextInput value={serialNo} onChangeText={setSerialNo} placeholder="0017680..." placeholderTextColor={colors.muted} style={inputStyle} />
              </View>
              <View style={{ flex: 1, gap: 4 }}>
                <Text style={{ color: colors.muted, fontSize: 12 }}>Arsyeja / Shënim</Text>
                <TextInput
                  value={reason}
                  onChangeText={setReason}
                  placeholder={kind === "inbound" ? "Furnizim..." : "Dalje malli..."}
                  placeholderTextColor={colors.muted}
                  style={inputStyle}
                />
              </View>
            </View>
          </Card>

          <Card style={{ gap: 8 }}>
            <Text style={{ color: colors.foreground, fontWeight: "900", fontSize: 16 }}>Shto artikull</Text>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                gap: 8,
                backgroundColor: colors.background,
                borderWidth: 1,
                borderColor: colors.border,
                borderRadius: 10,
                paddingHorizontal: 12,
              }}
            >
              <IconSymbol name="magnifyingglass" size={16} color={colors.muted} />
              <TextInput
                value={search}
                onChangeText={setSearch}
                placeholder="Kërko artikull..."
                placeholderTextColor={colors.muted}
                style={{ flex: 1, color: colors.foreground, paddingVertical: 10 }}
              />
            </View>
            {productResults.map((p) => (
              <Pressable
                key={p.id}
                onPress={() => addLine(p)}
                style={{ paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: colors.border }}
              >
                <Text style={{ color: colors.foreground, fontWeight: "700" }}>{p.name}</Text>
                <Text style={{ color: colors.muted, fontSize: 12 }}>
                  Stok në {warehouse || "—"}: {fmt(stockInStore(p, warehouse))} copë
                </Text>
              </Pressable>
            ))}
          </Card>

          <Card style={{ gap: 8, backgroundColor: "#fff" }}>
            <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 8 }}>
              <Text style={{ color: "#111827", fontWeight: "900", fontSize: 16 }}>Artikujt e dokumentit</Text>
              {lines.length > 0 ? (
                <Pressable onPress={() => setLines([])} style={{ paddingHorizontal: 10, paddingVertical: 6 }}>
                  <Text style={{ color: colors.error, fontWeight: "700" }}>Pastro</Text>
                </Pressable>
              ) : null}
            </View>

            <ScrollView horizontal showsHorizontalScrollIndicator>
              <View style={{ borderLeftWidth: 1, borderTopWidth: 1, borderColor: "#222", width: 630 }}>
                <View style={{ flexDirection: "row" }}>
                  {headerCell("Nr", 36)}
                  {headerCell("Emërtimi i mallit", 210)}
                  {headerCell("Njësia", 74)}
                  {headerCell("Sasia", 74)}
                  {headerCell("Çmimi", 86)}
                  {headerCell("Vlefta", 96)}
                  {headerCell("", 54)}
                </View>

                {selectedRows.map((l, idx) => {
                  if (!l) {
                    return (
                      <View key={`blank-${idx}`} style={{ flexDirection: "row" }}>
                        <View style={cellStyle(36, { alignItems: "center" })}><Text style={{ color: "#6b7280" }}>{idx + 1}</Text></View>
                        <View style={cellStyle(210)} />
                        <View style={cellStyle(74)} />
                        <View style={cellStyle(74)} />
                        <View style={cellStyle(86)} />
                        <View style={cellStyle(96)} />
                        <View style={cellStyle(54)} />
                      </View>
                    );
                  }
                  const p = productOf(l.productName);
                  const coef = unitCoef(p, l.unit);
                  const base = num(l.qty) * coef;
                  const avail = p ? stockInStore(p, warehouse) : 0;
                  const insufficient = kind === "outbound" && base > avail + 0.0001;
                  const value = num(l.qty) * num(l.price);
                  return (
                    <View key={l._k} style={{ flexDirection: "row" }}>
                      <View style={cellStyle(36, { alignItems: "center", backgroundColor: insufficient ? "#fff1f2" : "#fff" })}>
                        <Text style={{ color: "#111827", fontWeight: "800" }}>{idx + 1}</Text>
                      </View>
                      <View style={cellStyle(210, { backgroundColor: insufficient ? "#fff1f2" : "#fff" })}>
                        <Text style={{ color: "#111827", fontWeight: "800", fontSize: 12 }}>{l.productName}</Text>
                        <Text style={{ color: insufficient ? colors.error : "#6b7280", fontSize: 10 }}>
                          {num(l.qty)} {l.unit} = {fmt(base)} copë{kind === "outbound" ? ` · Stok: ${fmt(avail)} copë` : ""}
                        </Text>
                      </View>
                      <Pressable onPress={() => cycleUnit(l)} style={cellStyle(74, { alignItems: "center", backgroundColor: insufficient ? "#fff1f2" : "#fff" })}>
                        <Text style={{ color: colors.primary, fontWeight: "900", fontSize: 12 }}>{l.unit}</Text>
                        <Text style={{ color: "#6b7280", fontSize: 9 }}>ndrysho</Text>
                      </Pressable>
                      <View style={cellStyle(74, { backgroundColor: insufficient ? "#fff1f2" : "#fff" })}>
                        <TextInput
                          value={String(l.qty)}
                          onChangeText={(v) => updateLine(l._k, { qty: num(v) })}
                          keyboardType="numeric"
                          selectTextOnFocus
                          style={{ color: "#111827", fontWeight: "800", padding: 0, textAlign: "center" }}
                        />
                      </View>
                      <View style={cellStyle(86, { backgroundColor: insufficient ? "#fff1f2" : "#fff" })}>
                        <TextInput
                          value={num(l.price) ? String(l.price) : ""}
                          onChangeText={(v) => updateLine(l._k, { price: num(v) })}
                          keyboardType="numeric"
                          placeholder="0"
                          placeholderTextColor="#9ca3af"
                          selectTextOnFocus
                          style={{ color: "#111827", fontWeight: "800", padding: 0, textAlign: "right" }}
                        />
                      </View>
                      <View style={cellStyle(96, { alignItems: "flex-end", backgroundColor: insufficient ? "#fff1f2" : "#fff" })}>
                        <Text style={{ color: "#111827", fontWeight: "800" }}>{num(value) ? fmt(value) : ""}</Text>
                      </View>
                      <View style={cellStyle(54, { alignItems: "center", backgroundColor: insufficient ? "#fff1f2" : "#fff" })}>
                        <Pressable onPress={() => removeLine(l._k)} hitSlop={8}>
                          <IconSymbol name="trash" size={18} color={colors.error} />
                        </Pressable>
                      </View>
                    </View>
                  );
                })}

                <View style={{ flexDirection: "row" }}>
                  <View style={cellStyle(36, { backgroundColor: "#e9eef4" })} />
                  <View style={cellStyle(210, { backgroundColor: "#e9eef4", alignItems: "flex-end" })}>
                    <Text style={{ color: "#111827", fontWeight: "900" }}>TOTALI</Text>
                  </View>
                  <View style={cellStyle(74, { backgroundColor: "#e9eef4" })} />
                  <View style={cellStyle(74, { backgroundColor: "#e9eef4", alignItems: "center" })}>
                    <Text style={{ color: "#111827", fontWeight: "900" }}>{fmt(totalBaseQty)}</Text>
                    <Text style={{ color: "#6b7280", fontSize: 9 }}>copë</Text>
                  </View>
                  <View style={cellStyle(86, { backgroundColor: "#e9eef4" })} />
                  <View style={cellStyle(96, { backgroundColor: "#e9eef4", alignItems: "flex-end" })}>
                    <Text style={{ color: "#111827", fontWeight: "900" }}>{num(totalValue) ? fmt(totalValue) : ""}</Text>
                  </View>
                  <View style={cellStyle(54, { backgroundColor: "#e9eef4" })} />
                </View>
              </View>
            </ScrollView>

            <Text style={{ color: colors.muted, fontSize: 11 }}>
              Shtyp njësinë për ta ndryshuar. Rreshtat bosh janë vetëm pamje si formulari; ruhen vetëm rreshtat me artikuj.
            </Text>
          </Card>

          <Btn title={saving ? "Duke ruajtur..." : `Ruaj ${title}`} icon="checkmark" onPress={save} fullWidth />
        </ScrollView>
      </ScreenContainer>
    </>
  );
}
