import React from "react";
import { FlatList, Modal, Pressable, Text, TextInput, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { IconSymbol } from "@/components/ui/icon-symbol";
import {
  useStore,
  useCompanies,
  money,
  fmt,
  paymentStatusesOf,
  unifiedDocuments,
  filterUnifiedDocs,
  type UnifiedDoc,
} from "@/lib/store";
import { FilterModal, type FilterModalValue } from "@/components/filter-modal";
import { router } from "expo-router";

export default function HomeScreen() {
  const colors = useColors();
  const { db, ready } = useStore();
  const { companies, activeCompanyId, switchCompany } = useCompanies();
  const [search, setSearch] = React.useState("");
  const [tab, setTab] = React.useState<"docs" | "parties">("docs");
  const [companyPickerOpen, setCompanyPickerOpen] = React.useState(false);
  const activeWarehouses = React.useMemo(
    () => (db.warehouses || []).filter((w) => w.status === "active"),
    [db.warehouses],
  );
  const [filterOpen, setFilterOpen] = React.useState(false);
  const [docFilter, setDocFilter] = React.useState<FilterModalValue>({ types: [], statuses: [] });

  const activeFilterCount = docFilter.types.length + docFilter.statuses.length;

  const filtered = React.useMemo(() => {
    const q = search.trim().toLowerCase();
    const docs = unifiedDocuments(db);
    const byFilter = filterUnifiedDocs(docs, docFilter.types, docFilter.statuses);
    if (!q) return byFilter;
    return byFilter.filter(
      (d) =>
        d.party.toLowerCase().includes(q) ||
        String(d.no).toLowerCase().includes(q) ||
        d.date.includes(q),
    );
  }, [db, search, docFilter]);

  const filteredParties = React.useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return db.customers;
    return db.customers.filter((c) => c.name.toLowerCase().includes(q));
  }, [db.customers, search]);

  return (
    <ScreenContainer>
      {/* Top brand */}
      <View
        style={{
          backgroundColor: colors.surface,
          paddingHorizontal: 16,
          paddingTop: 14,
          paddingBottom: 10,
          borderBottomWidth: 1,
          borderBottomColor: colors.border,
        }}
      >
        <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
          <View
            style={{
              width: 44,
              height: 44,
              borderRadius: 22,
              backgroundColor: "#0a66aa",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Text style={{ color: "#fff", fontWeight: "900", fontSize: 14 }}>SG</Text>
          </View>
          <Pressable
            onPress={() => setCompanyPickerOpen(true)}
            style={{ flex: 1, flexDirection: "row", alignItems: "center", gap: 6 }}
          >
            <View style={{ flex: 1 }}>
              <Text
                style={{ fontWeight: "900", fontSize: 19, color: colors.foreground, letterSpacing: 0.5 }}
                numberOfLines={1}
              >
                {db.company.name}
              </Text>
              <Text style={{ color: colors.muted, fontSize: 11 }} numberOfLines={1}>
                {activeWarehouses.length} magazina · trokit për të ndërruar kompaninë
              </Text>
            </View>
            <IconSymbol name="chevron.down" size={16} color={colors.muted} />
          </Pressable>
          <IconSymbol name="bell.fill" size={22} color={colors.muted} />
        </View>

        {/* Company switcher modal */}
        <Modal
          visible={companyPickerOpen}
          transparent
          animationType="fade"
          onRequestClose={() => setCompanyPickerOpen(false)}
        >
          <Pressable
            onPress={() => setCompanyPickerOpen(false)}
            style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.4)", justifyContent: "center", padding: 24 }}
          >
            <Pressable
              onPress={() => {}}
              style={{ backgroundColor: colors.surface, borderRadius: 14, padding: 16, gap: 8 }}
            >
              <Text style={{ color: colors.foreground, fontWeight: "900", fontSize: 16, marginBottom: 4 }}>
                Zgjidh kompaninë
              </Text>
              {companies.map((c) => {
                const active = c.id === activeCompanyId;
                const disabled = c.status !== "active";
                return (
                  <Pressable
                    key={c.id}
                    onPress={async () => {
                      if (disabled) return;
                      await switchCompany(c.id);
                      setCompanyPickerOpen(false);
                    }}
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      gap: 10,
                      padding: 12,
                      borderRadius: 10,
                      borderWidth: 1,
                      borderColor: active ? colors.primary : colors.border,
                      backgroundColor: active ? "#dceffd" : "transparent",
                      opacity: disabled ? 0.4 : 1,
                    }}
                  >
                    <IconSymbol
                      name={active ? "checkmark.circle.fill" : "building.2.fill"}
                      size={20}
                      color={active ? colors.primary : colors.muted}
                    />
                    <View style={{ flex: 1 }}>
                      <Text style={{ color: colors.foreground, fontWeight: "700" }}>{c.name}</Text>
                      {c.nipt ? <Text style={{ color: colors.muted, fontSize: 11 }}>NIPT: {c.nipt}</Text> : null}
                      {disabled ? <Text style={{ color: colors.error, fontSize: 11 }}>Joaktive</Text> : null}
                    </View>
                  </Pressable>
                );
              })}
              <Pressable
                onPress={() => {
                  setCompanyPickerOpen(false);
                  router.push("/companies" as any);
                }}
                style={{ paddingVertical: 12, alignItems: "center", marginTop: 4 }}
              >
                <Text style={{ color: colors.primary, fontWeight: "800" }}>Menaxho kompanitë →</Text>
              </Pressable>
            </Pressable>
          </Pressable>
        </Modal>

        {/* Tabs */}
        <View style={{ flexDirection: "row", gap: 14, marginTop: 14 }}>
          <Pressable
            onPress={() => setTab("docs")}
            style={{
              flex: 1,
              borderWidth: 1,
              borderColor: tab === "docs" ? colors.error : colors.border,
              borderRadius: 28,
              paddingVertical: 10,
              alignItems: "center",
            }}
          >
            <Text style={{ fontWeight: "800", color: tab === "docs" ? colors.error : colors.muted }}>Dokumentet</Text>
          </Pressable>
          <Pressable
            onPress={() => setTab("parties")}
            style={{
              flex: 1,
              borderWidth: 1,
              borderColor: tab === "parties" ? colors.error : colors.border,
              borderRadius: 28,
              paddingVertical: 10,
              alignItems: "center",
            }}
          >
            <Text style={{ fontWeight: "800", color: tab === "parties" ? colors.error : colors.muted }}>Klientët</Text>
          </Pressable>
        </View>
      </View>

      {/* Quick links */}
      <View
        style={{
          backgroundColor: colors.surface,
          marginHorizontal: 12,
          marginTop: 10,
          borderRadius: 10,
          padding: 14,
          borderWidth: 1,
          borderColor: colors.border,
        }}
      >
        <Text style={{ color: colors.muted, fontSize: 14, fontWeight: "800", marginBottom: 12 }}>Lidhje të shpejta</Text>
        <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
          <QuickLink icon="doc.text.fill" label="Shto Dok." onPress={() => router.push("/sale" as any)} />
          <QuickLink icon="cart.fill" label="Shto Blerje" onPress={() => router.push("/purchase" as any)} />
          <QuickLink icon="chart.bar.fill" label="Raporte" onPress={() => router.push("/(tabs)/reports" as any)} />
          <QuickLink icon="gearshape.fill" label="Cilësime" onPress={() => router.push("/txn-settings" as any)} />
        </View>
      </View>

      {/* Search + Filter */}
      <View style={{ flexDirection: "row", alignItems: "center", gap: 8, marginHorizontal: 12, marginTop: 8 }}>
        <View
          style={{
            flex: 1,
            backgroundColor: colors.surface,
            borderRadius: 10,
            paddingHorizontal: 12,
            flexDirection: "row",
            alignItems: "center",
            gap: 8,
            borderWidth: 1,
            borderColor: colors.border,
          }}
        >
          <IconSymbol name="magnifyingglass" size={20} color={colors.primary} />
          <TextInput
            placeholder={tab === "docs" ? "Kërko dokument" : "Kërko klient"}
            placeholderTextColor={colors.muted}
            value={search}
            onChangeText={setSearch}
            style={{ flex: 1, paddingVertical: 12, color: colors.foreground, fontSize: 15 }}
          />
        </View>

        {tab === "docs" ? (
          <Pressable
            onPress={() => setFilterOpen(true)}
            style={({ pressed }) => ({
              backgroundColor: activeFilterCount > 0 ? colors.error : colors.surface,
              borderWidth: 1,
              borderColor: activeFilterCount > 0 ? colors.error : colors.border,
              borderRadius: 10,
              paddingHorizontal: 14,
              paddingVertical: 12,
              flexDirection: "row",
              alignItems: "center",
              gap: 6,
              opacity: pressed ? 0.85 : 1,
            })}
          >
            <IconSymbol
              name="line.3.horizontal.decrease"
              size={20}
              color={activeFilterCount > 0 ? "#fff" : colors.foreground}
            />
            <Text style={{ fontWeight: "800", color: activeFilterCount > 0 ? "#fff" : colors.foreground, fontSize: 14 }}>
              Filter{activeFilterCount > 0 ? ` (${activeFilterCount})` : ""}
            </Text>
          </Pressable>
        ) : null}
      </View>

      <FilterModal
        visible={filterOpen}
        initial={docFilter}
        onClose={() => setFilterOpen(false)}
        onApply={(v) => setDocFilter(v)}
      />

      {/* List */}
      {tab === "docs" ? (
        <FlatList
          data={filtered}
          keyExtractor={(item) => item.key}
          contentContainerStyle={{ paddingTop: 6, paddingBottom: 120 }}
          ListEmptyComponent={
            <Text style={{ textAlign: "center", color: colors.muted, marginTop: 40 }}>
              {ready
                ? activeFilterCount > 0
                  ? "Asnjë dokument nuk përputhet me filtrat."
                  : "Asnjë dokument ende. Krijo një faturë të re."
                : "Duke ngarkuar..."}
            </Text>
          }
          renderItem={({ item }) => <DocCard doc={item} currency={db.company.currency} />}
        />
      ) : (
        <FlatList
          data={filteredParties}
          keyExtractor={(item) => String(item.id)}
          contentContainerStyle={{ paddingTop: 6, paddingBottom: 120 }}
          renderItem={({ item }) => (
            <Pressable
              onPress={() => router.push({ pathname: "/party/[name]", params: { name: item.name } } as any)}
              style={{
                backgroundColor: colors.surface,
                marginHorizontal: 12,
                marginVertical: 5,
                borderRadius: 8,
                padding: 14,
                borderWidth: 1,
                borderColor: colors.border,
              }}
            >
              <Text style={{ fontWeight: "800", color: colors.foreground, fontSize: 15 }}>{item.name}</Text>
              {item.phone ? <Text style={{ color: colors.muted, marginTop: 4 }}>{item.phone}</Text> : null}
            </Pressable>
          )}
        />
      )}

      {/* FAB */}
      <Pressable
        onPress={() => router.push("/sale" as any)}
        style={({ pressed }) => ({
          position: "absolute",
          bottom: 20,
          alignSelf: "center",
          backgroundColor: colors.error,
          paddingHorizontal: 24,
          paddingVertical: 14,
          borderRadius: 32,
          flexDirection: "row",
          alignItems: "center",
          gap: 8,
          opacity: pressed ? 0.85 : 1,
          shadowColor: colors.error,
          shadowOpacity: 0.3,
          shadowRadius: 8,
          shadowOffset: { width: 0, height: 4 },
          elevation: 6,
        })}
      >
        <IconSymbol name="plus" size={20} color="#fff" />
        <Text style={{ color: "#fff", fontWeight: "900", fontSize: 15 }}>Faturë e re shitje</Text>
      </Pressable>
    </ScreenContainer>
  );
}

/** A unified document card (sale / purchase / warehouse transfer) for the home list. */
function DocCard({ doc, currency }: { doc: UnifiedDoc; currency: string }) {
  const colors = useColors();
  const open = () => {
    if (doc.kind === "sale") {
      router.push({ pathname: "/invoice/[no]", params: { no: String(doc.no) } } as any);
    } else if (doc.kind === "purchase") {
      router.push({ pathname: "/purchase/[no]", params: { no: String(doc.no) } } as any);
    } else {
      router.push("/store-transfer" as any);
    }
  };
  return (
    <Pressable
      onPress={open}
      style={{
        backgroundColor: colors.surface,
        marginHorizontal: 12,
        marginVertical: 5,
        borderRadius: 8,
        padding: 14,
        borderWidth: 1,
        borderColor: colors.border,
      }}
    >
      <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
        <Text style={{ fontWeight: "900", fontSize: 16, color: colors.foreground, flex: 1 }} numberOfLines={1}>
          {doc.party}
        </Text>
        <Text style={{ color: colors.muted }}>#{doc.no}</Text>
      </View>
      <View style={{ marginTop: 6, flexDirection: "row", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
        <DocTypePill kind={doc.kind} />
        {doc.kind !== "transfer" ? <StatusPill total={doc.total} paid={doc.paid} /> : null}
      </View>
      {doc.kind === "transfer" ? (
        <View style={{ flexDirection: "row", justifyContent: "space-between", marginTop: 10 }}>
          <View>
            <Text style={{ color: colors.muted, fontSize: 12 }}>Data</Text>
            <Text style={{ fontWeight: "800", color: colors.foreground }}>{doc.date}</Text>
          </View>
          <View>
            <Text style={{ color: colors.muted, fontSize: 12 }}>Kodi</Text>
            <Text style={{ fontWeight: "800", color: colors.foreground }}>{String(doc.no)}</Text>
          </View>
        </View>
      ) : (
        <View style={{ flexDirection: "row", justifyContent: "space-between", marginTop: 10 }}>
          <View>
            <Text style={{ color: colors.muted, fontSize: 12 }}>Data</Text>
            <Text style={{ fontWeight: "800", color: colors.foreground }}>{doc.date}</Text>
          </View>
          <View>
            <Text style={{ color: colors.muted, fontSize: 12 }}>Totali</Text>
            <Text style={{ fontWeight: "800", color: colors.foreground }}>{money(doc.total, currency)}</Text>
          </View>
          <View>
            <Text style={{ color: colors.muted, fontSize: 12 }}>Paguar</Text>
            <Text style={{ fontWeight: "800", color: colors.foreground }}>{fmt(doc.paid)}</Text>
          </View>
          <View>
            <Text style={{ color: colors.muted, fontSize: 12 }}>Detyrimi</Text>
            <Text style={{ fontWeight: "800", color: doc.due > 0 ? colors.error : colors.success }}>
              {fmt(doc.due)}
            </Text>
          </View>
        </View>
      )}
    </Pressable>
  );
}

/** A small colored pill identifying the document type. */
function DocTypePill({ kind }: { kind: UnifiedDoc["kind"] }) {
  let label = "Shitje";
  let bg = "#dceffd";
  let fg = "#0a66aa";
  if (kind === "purchase") {
    label = "Blerje";
    bg = "#ede9fe";
    fg = "#6d28d9";
  } else if (kind === "transfer") {
    label = "Transfertë";
    bg = "#fef3c7";
    fg = "#b45309";
  }
  return (
    <View style={{ backgroundColor: bg, borderRadius: 999, paddingHorizontal: 10, paddingVertical: 3, alignSelf: "flex-start" }}>
      <Text style={{ color: fg, fontWeight: "800", fontSize: 12 }}>{label}</Text>
    </View>
  );
}

/** Colored payment-status pill: green = Paguar, orange = Pjesërisht, red = Pa paguar. */
function StatusPill({ total, paid }: { total: number; paid: number }) {
  const statuses = paymentStatusesOf({ total, paid });
  let label = "Pa paguar";
  let bg = "#fde2e1";
  let fg = "#c2362f";
  if (statuses.includes("paid")) {
    label = "Paguar";
    bg = "#d9f8ee";
    fg = "#0a9b6d";
  } else if (statuses.includes("partial")) {
    label = "Pjesërisht";
    bg = "#ffe7c2";
    fg = "#b5640a";
  }
  return (
    <View style={{ backgroundColor: bg, borderRadius: 999, paddingHorizontal: 10, paddingVertical: 3, alignSelf: "flex-start" }}>
      <Text style={{ color: fg, fontWeight: "800", fontSize: 12 }}>{label}</Text>
    </View>
  );
}

function QuickLink({ icon, label, onPress }: { icon: string; label: string; onPress: () => void }) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => ({
        width: "25%",
        alignItems: "center",
        paddingVertical: 4,
        opacity: pressed ? 0.6 : 1,
      })}
    >
      <View
        style={{
          width: 52,
          height: 52,
          borderRadius: 12,
          backgroundColor: "#dceffd",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <IconSymbol name={icon as any} size={26} color={colors.primary} />
      </View>
      <Text style={{ fontSize: 12, color: colors.foreground, marginTop: 6, fontWeight: "600" }} numberOfLines={1}>
        {label}
      </Text>
    </Pressable>
  );
}
