import React from "react";
import { 
  ActivityIndicator, 
  Alert, 
  FlatList, 
  Platform, 
  Pressable, 
  ScrollView, 
  Text, 
  View, 
  Modal, 
  Dimensions 
} from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useStore, allSalesmen } from "@/lib/store";
import {
  REPORT_CATALOG,
  ReportFilter,
  ReportType,
  type ReportResult,
  renderReportHtml,
} from "@/lib/reports";
import { exportReportToExcel } from "@/lib/excel";
import { buildSqliteReport } from "@/lib/sqlite-reports";
import * as Print from "expo-print";
import * as Sharing from "expo-sharing";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";

const { height: SCREEN_HEIGHT } = Dimensions.get("window");

type ParamShape = { type?: string };
type ReportFilterTab = "salesman" | "txn" | "party" | "status" | "products" | "unit" | "price" | "store";

const EMPTY_FILTERS: ReportFilter = {
  clients: [],
  suppliers: [],
  products: [],
  stores: [],
  units: [],
  salesmen: [],
  categories: [],
  from: "",
  to: "",
  price: "",
  reportUnit: "",
  txnType: "all",
  payStatus: "all",
};

function pad2(n: number) { return String(n).padStart(2, "0"); }
function isoDate(d: Date) { return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`; }
function startOfMonth(d: Date) { return new Date(d.getFullYear(), d.getMonth(), 1); }
function endOfMonth(d: Date) { return new Date(d.getFullYear(), d.getMonth() + 1, 0); }
function addDays(d: Date, n: number) { const x = new Date(d); x.setDate(x.getDate() + n); return x; }

export default function ReportsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { db } = useStore();
  const params = useLocalSearchParams<ParamShape>();

  const [type, setType] = React.useState<ReportType>((params.type as ReportType) || "salesSummary");
  const [filters, setFilters] = React.useState<ReportFilter>(() => {
    const now = new Date();
    return {
      ...EMPTY_FILTERS,
      from: isoDate(startOfMonth(now)),
      to: isoDate(endOfMonth(now)),
    };
  });
  
  const [reportResult, setReportResult] = React.useState<ReportResult | null>(null);
  const [loading, setLoading] = React.useState(false);
  const [filterSheetOpen, setFilterSheetOpen] = React.useState(false);
  const [filterTab, setFilterTab] = React.useState<ReportFilterTab>("salesman");
  const [reportPickerOpen, setReportPickerOpen] = React.useState(false);
  const [periodPickerOpen, setPeriodPickerOpen] = React.useState(false);
  const [exportMenuOpen, setExportMenuOpen] = React.useState<{ type: 'pdf' | 'xls' } | null>(null);

  const reportEntry = REPORT_CATALOG.find(r => r.value === type) || REPORT_CATALOG[0];

  const loadReport = React.useCallback(async () => {
    setLoading(true);
    // Clear previous rows/columns immediately to avoid ghosting (PDF Page 3 requirement)
    setReportResult(null);
    try {
      const res = await buildSqliteReport(type, filters);
      setReportResult(res);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [type, filters]);

  // Automatic refresh on type or filter change (PDF Page 1 requirement)
  React.useEffect(() => {
    loadReport();
  }, [loadReport]);

  const onExportPdf = async () => {
    if (!reportResult) return;
    const html = renderReportHtml(reportResult, { companyName: db.company.name, filters, currency: db.company.currency });
    try {
      if (Platform.OS === "web") {
        await Print.printAsync({ html });
      } else {
        const { uri } = await Print.printToFileAsync({ html });
        await Sharing.shareAsync(uri);
      }
    } catch (e) {
      Alert.alert("Gabim", "Dështoi gjenerimi i PDF.");
    }
    setExportMenuOpen(null);
  };

  const onExportExcel = async () => {
    if (!reportResult) return;
    try {
      await exportReportToExcel(reportResult, { companyName: db.company.name, filtersText: "", currency: db.company.currency });
    } catch (e) {
      Alert.alert("Gabim", "Dështoi gjenerimi i Excel.");
    }
    setExportMenuOpen(null);
  };

  const handleRowPress = (row: any) => {
    if (row._total || row._green || row._yellow) return;
    if (row.no) {
      const isSale = (db.invoices || []).some(i => String(i.no) === String(row.no));
      if (isSale) router.push(`/invoice/${row.no}`);
      else router.push(`/purchase/${row.no}`);
    } else if (row.party) {
      const isSupplier = (db.suppliers || []).some(s => s.name === row.party);
      if (isSupplier) router.push(`/supplier/${encodeURIComponent(row.party)}`);
      else router.push(`/party/${encodeURIComponent(row.party)}`);
    } else if (row.product || row.name) {
      const name = row.product || row.name;
      const prod = db.products.find(p => p.name === name);
      if (prod) router.push(`/product/${prod.id}`);
    }
  };

  const appliedChips = React.useMemo(() => {
    const chips = [];
    if (filters.txnType !== "all") chips.push(`Txns Type - ${filters.txnType === "cash" ? "Sale" : "Credit"}`);
    if (filters.payStatus !== "all") chips.push(`Status - ${filters.payStatus.toUpperCase()}`);
    if (filters.salesmen?.length) chips.push(`User - ${filters.salesmen.length} Selected`);
    if (filters.clients?.length) chips.push(`Party - ${filters.clients.length} Selected`);
    if (filters.products?.length) chips.push(`Item - ${filters.products.length} Selected`);
    return chips;
  }, [filters]);

  const renderFilterOptions = () => {
    let options: string[] = [];
    let key: keyof ReportFilter | null = null;

    if (filterTab === "salesman") { options = allSalesmen(db); key = "salesmen"; }
    else if (filterTab === "party") { options = [...db.customers.map(c => c.name), ...db.suppliers.map(s => s.name)]; key = "clients"; }
    else if (filterTab === "products") { options = db.products.map(p => p.name); key = "products"; }
    else if (filterTab === "store") { options = db.stores; key = "stores"; }
    else if (filterTab === "unit") { options = db.units; key = "units"; }

    if (filterTab === "txn") {
      return ["all", "cash", "credit"].map(t => (
        <Pressable key={t} onPress={() => setFilters(prev => ({ ...prev, txnType: t as any }))} style={{ paddingVertical: 15, flexDirection: "row", alignItems: "center" }}>
          <Ionicons name={filters.txnType === t ? "radio-button-on" : "radio-button-off"} size={22} color="#0b83d8" style={{ marginRight: 12 }} />
          <Text style={{ fontSize: 16, color: "#333" }}>{t === "all" ? "Sale & Cr. Note" : t.charAt(0).toUpperCase() + t.slice(1)}</Text>
        </Pressable>
      ));
    }

    if (filterTab === "status") {
      return ["all", "paid", "partial", "unpaid"].map(t => (
        <Pressable key={t} onPress={() => setFilters(prev => ({ ...prev, payStatus: t as any }))} style={{ paddingVertical: 15, flexDirection: "row", alignItems: "center" }}>
          <Ionicons name={filters.payStatus === t ? "radio-button-on" : "radio-button-off"} size={22} color="#0b83d8" style={{ marginRight: 12 }} />
          <Text style={{ fontSize: 16, color: "#333" }}>{t.charAt(0).toUpperCase() + t.slice(1)}</Text>
        </Pressable>
      ));
    }

    if (key && options.length) {
      return options.map(opt => {
        const isSelected = ((filters[key!] as string[]) || []).includes(opt);
        return (
          <Pressable key={opt} onPress={() => {
            setFilters(prev => {
              const cur = (prev[key!] as string[]) || [];
              const next = isSelected ? cur.filter(x => x !== opt) : [...cur, opt];
              return { ...prev, [key!]: next };
            });
          }} style={{ paddingVertical: 15, flexDirection: "row", alignItems: "center" }}>
            <Ionicons name={isSelected ? "checkbox" : "square-outline"} size={22} color="#0b83d8" style={{ marginRight: 12 }} />
            <Text style={{ fontSize: 16, color: "#333" }}>{opt}</Text>
          </Pressable>
        );
      });
    }

    return <Text style={{ color: "#999", marginTop: 20, textAlign: 'center' }}>Nuk ka opsione.</Text>;
  };

  const isTableReport = type === "shitjeSot" || type === "salesByProduct" || type === "salesAnalytic" || type === "stockSummary" || type === "stockByCompany" || type === "stockByWarehouse" || type === "kerkeseFurnizimi" || type === "supplyNeed" || type === "purchaseSuggestion";

  return (
    <ScreenContainer style={{ backgroundColor: "#f4f7f9" }}>
      {/* Header exactly like reference */}
      <View style={{ height: 60, flexDirection: "row", alignItems: "center", paddingHorizontal: 16, backgroundColor: "#fff", borderBottomWidth: 1, borderColor: "#e0e0e0" }}>
        <Pressable onPress={() => router.back()} style={{ paddingRight: 16 }}>
          <Ionicons name="arrow-back" size={24} color="#333" />
        </Pressable>
        <Pressable onPress={() => setReportPickerOpen(true)} style={{ flex: 1 }}>
          <Text style={{ fontSize: 18, fontWeight: "600", color: "#333" }} numberOfLines={1}>{reportEntry.label}</Text>
        </Pressable>
        <View style={{ flexDirection: 'row', gap: 12 }}>
          <Pressable onPress={() => setExportMenuOpen({ type: 'pdf' })} style={{ backgroundColor: "#fdecea", padding: 6, borderRadius: 4 }}>
             <Text style={{ color: "#e74c3c", fontWeight: "bold", fontSize: 12 }}>Pdf</Text>
          </Pressable>
          <Pressable onPress={() => setExportMenuOpen({ type: 'xls' })} style={{ backgroundColor: "#eafaf1", padding: 6, borderRadius: 4 }}>
            <Text style={{ color: "#27ae60", fontWeight: "bold", fontSize: 12 }}>xls</Text>
          </Pressable>
        </View>
      </View>

      {/* Date Bar with visible dates and refresh on change */}
      <View style={{ backgroundColor: "#fff", paddingVertical: 10, paddingHorizontal: 16, borderBottomWidth: 1, borderColor: "#e0e0e0", flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
        <Pressable onPress={() => setPeriodPickerOpen(true)} style={{ flexDirection: 'row', alignItems: 'center' }}>
          <Text style={{ fontSize: 14, color: "#555", marginRight: 4 }}>Select Period</Text>
          <Ionicons name="chevron-down" size={16} color="#555" />
        </Pressable>
        <View style={{ height: 20, width: 1, backgroundColor: '#ddd' }} />
        <Pressable style={{ flexDirection: 'row', alignItems: 'center', flex: 1, justifyContent: 'center' }}>
          <Ionicons name="calendar-outline" size={18} color="#0b83d8" style={{ marginRight: 8 }} />
          <Text style={{ fontSize: 13, color: "#333", fontWeight: '500' }}>{filters.from?.split('-').reverse().join('/')}  TO  {filters.to?.split('-').reverse().join('/')}</Text>
        </Pressable>
      </View>

      {/* Filters Applied row */}
      <View style={{ backgroundColor: "#fff", paddingVertical: 12, paddingLeft: 16, borderBottomWidth: 1, borderColor: "#e0e0e0" }}>
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 8, paddingRight: 16 }}>
          <Text style={{ fontSize: 13, color: "#666" }}>Filters Applied:</Text>
          <Pressable onPress={() => setFilterSheetOpen(true)} style={{ flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderColor: '#ddd', borderRadius: 20, paddingHorizontal: 10, paddingVertical: 4 }}>
            <Ionicons name="filter" size={14} color="#0b83d8" style={{ marginRight: 4 }} />
            <Text style={{ color: "#333", fontSize: 12, fontWeight: "500" }}>Filters</Text>
          </Pressable>
        </View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {appliedChips.length > 0 ? appliedChips.map((c, i) => (
            <View key={i} style={{ backgroundColor: "#f0f2f5", borderRadius: 20, paddingHorizontal: 12, paddingVertical: 6, marginRight: 8, borderWidth: 1, borderColor: '#e0e0e0' }}>
              <Text style={{ fontSize: 12, color: "#555" }}>{c}</Text>
            </View>
          )) : (
             <View style={{ backgroundColor: "#f0f2f5", borderRadius: 20, paddingHorizontal: 12, paddingVertical: 6, marginRight: 8, borderWidth: 1, borderColor: '#e0e0e0' }}>
              <Text style={{ fontSize: 12, color: "#555" }}>All Data</Text>
            </View>
          )}
        </ScrollView>
      </View>

      {/* Report Content */}
      {loading ? (
        <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
          <ActivityIndicator size="large" color="#0b83d8" />
        </View>
      ) : (
        <View style={{ flex: 1 }}>
          {!isTableReport && reportResult?.summary && (
            <View style={{ flexDirection: 'row', padding: 12, gap: 10 }}>
              {reportResult.summary.map((s, i) => (
                <View key={i} style={{ flex: 1, backgroundColor: '#fff', padding: 12, borderRadius: 8, elevation: 1, shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 2 }}>
                  <Text style={{ fontSize: 12, color: '#777', marginBottom: 4 }}>{s.label}</Text>
                  <Text style={{ fontSize: 15, fontWeight: 'bold', color: s.label.includes('Due') || s.label.includes('Detyrim') ? '#e74c3c' : '#333' }}>{s.value}</Text>
                </View>
              ))}
            </View>
          )}

          <FlatList
            data={reportResult?.rows || []}
            keyExtractor={(_, index) => index.toString()}
            contentContainerStyle={{ padding: 12, paddingBottom: insets.bottom + 20 }}
            ListEmptyComponent={<Text style={{ textAlign: 'center', marginTop: 40, color: '#999' }}>{reportResult?.emptyMessage || "Nuk ka të dhëna."}</Text>}
            renderItem={({ item }) => {
              if (item._total || item._green || item._yellow) {
                return (
                  <View style={{ 
                    backgroundColor: item._green ? "#a3cfbb" : item._yellow ? "#fff3cd" : "#eee",
                    padding: 12, marginVertical: 2, flexDirection: "row", justifyContent: "space-between",
                    borderWidth: 1, borderColor: item._green ? "#75b798" : item._yellow ? "#ffecb5" : "#ddd"
                  }}>
                    <Text style={{ fontWeight: "bold", flex: 2, color: "#333", textAlign: 'center' }}>{item.product || item.name || "Total"}</Text>
                    <Text style={{ fontWeight: "bold", flex: 1, textAlign: "right", color: "#333" }}>{item.value ? Number(item.value).toLocaleString() : ""}</Text>
                  </View>
                );
              }

              if (!isTableReport) {
                return (
                  <Pressable onPress={() => handleRowPress(item)} style={{ backgroundColor: "#fff", padding: 16, borderRadius: 8, marginBottom: 10, elevation: 1, shadowColor: "#000", shadowOpacity: 0.05, shadowRadius: 2 }}>
                    <View style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: 12 }}>
                      <Text style={{ fontSize: 16, fontWeight: "bold", color: '#333' }}>{item.party}</Text>
                      <View style={{ alignItems: 'flex-end' }}>
                         <Text style={{ fontSize: 11, color: "#999", textAlign: 'right' }}>{item.no ? `#${item.no}` : ''}</Text>
                         <Text style={{ fontSize: 11, color: "#999" }}>{item.date}</Text>
                      </View>
                    </View>
                    <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
                      <View>
                        <Text style={{ fontSize: 12, color: "#999", marginBottom: 2 }}>Vlera</Text>
                        <Text style={{ fontSize: 14, color: "#333", fontWeight: "500" }}>{Number(item.total || item.due).toLocaleString()}</Text>
                      </View>
                      {item.due !== undefined && item.total !== undefined && (
                        <View style={{ alignItems: 'center' }}>
                          <Text style={{ fontSize: 12, color: "#999", marginBottom: 2 }}>Detyrim</Text>
                          <Text style={{ fontSize: 14, color: "#e74c3c", fontWeight: "500" }}>{Number(item.due).toLocaleString()}</Text>
                        </View>
                      )}
                      <View style={{ width: 40 }} />
                    </View>
                  </Pressable>
                );
              }

              return (
                <Pressable onPress={() => handleRowPress(item)} style={{ flexDirection: "row", borderBottomWidth: 1, borderColor: "#eee", paddingVertical: 12, backgroundColor: '#fff' }}>
                  <Text style={{ flex: 2, fontSize: 12, color: '#333', paddingLeft: 4 }} numberOfLines={2}>{item.product}</Text>
                  <Text style={{ flex: 0.8, textAlign: "right", fontSize: 12, color: '#333' }}>{item.qty || item.stock}</Text>
                  <Text style={{ flex: 0.6, textAlign: "center", fontSize: 12, color: '#333' }}>{item.unit}</Text>
                  <Text style={{ flex: 1, textAlign: "right", fontSize: 12, color: '#333' }}>{Number(item.rate).toLocaleString()}</Text>
                  <Text style={{ flex: 1, textAlign: "right", fontSize: 12, color: '#333', paddingRight: 4 }}>{Number(item.value).toLocaleString()}</Text>
                </Pressable>
              );
            }}
            ListHeaderComponent={
              isTableReport ? (
                <View style={{ flexDirection: "row", backgroundColor: "#d1e7dd", paddingVertical: 10, borderBottomWidth: 1, borderColor: "#badbcc" }}>
                  <Text style={{ flex: 2, fontWeight: "bold", fontSize: 13, color: '#0f5132', paddingLeft: 4 }}>Item Name</Text>
                  <Text style={{ flex: 0.8, textAlign: "right", fontWeight: "bold", fontSize: 13, color: '#0f5132' }}>Sasi</Text>
                  <Text style={{ flex: 0.6, textAlign: "center", fontWeight: "bold", fontSize: 13, color: '#0f5132' }}>Njesi</Text>
                  <Text style={{ flex: 1, textAlign: "right", fontWeight: "bold", fontSize: 13, color: '#0f5132' }}>Cmimi</Text>
                  <Text style={{ flex: 1, textAlign: "right", fontWeight: "bold", fontSize: 13, color: '#0f5132', paddingRight: 4 }}>Vlere</Text>
                </View>
              ) : null
            }
          />
        </View>
      )}

      {/* Bottom-sheet has categories on the left and options on the right */}
      <Modal visible={filterSheetOpen} animationType="slide" transparent>
        <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.4)", justifyContent: "flex-end" }}>
          <View style={{ backgroundColor: "#fff", height: SCREEN_HEIGHT * 0.7, borderTopLeftRadius: 16, borderTopRightRadius: 16 }}>
            <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: 'center', padding: 16, borderBottomWidth: 1, borderColor: "#eee" }}>
              <Text style={{ fontSize: 18, fontWeight: "bold", color: '#333' }}>Filters</Text>
              <Pressable onPress={() => setFilterSheetOpen(false)}><Ionicons name="close" size={24} color="#666" /></Pressable>
            </View>
            <View style={{ flex: 1, flexDirection: "row" }}>
              <View style={{ width: 130, backgroundColor: "#f8f9fa", borderRightWidth: 1, borderColor: '#eee' }}>
                {[
                  ["salesman", "By User"],
                  ["txn", "By Txns Type"],
                  ["party", "By Party"],
                  ["status", "By Status"],
                  ["products", "By Item"],
                  ["unit", "By Unit"],
                  ["price", "By Price"],
                  ["store", "By Store"]
                ].map(([t, l]) => (
                  <Pressable 
                    key={t} 
                    onPress={() => setFilterTab(t as ReportFilterTab)} 
                    style={{ padding: 16, backgroundColor: filterTab === t ? "#fff" : "transparent", borderLeftWidth: filterTab === t ? 4 : 0, borderLeftColor: '#0b83d8' }}
                  >
                    <Text style={{ fontSize: 14, fontWeight: filterTab === t ? "bold" : "normal", color: filterTab === t ? "#0b83d8" : "#555" }}>{l}</Text>
                  </Pressable>
                ))}
              </View>
              <ScrollView style={{ flex: 1, padding: 16 }}>
                {renderFilterOptions()}
              </ScrollView>
            </View>
            {/* Reset and Apply buttons must always be visible above the Android navigation bar */}
            <View style={{ padding: 16, borderTopWidth: 1, borderColor: "#eee", flexDirection: "row", gap: 12, paddingBottom: Math.max(insets.bottom, 16) }}>
              <Pressable onPress={() => setFilters(EMPTY_FILTERS)} style={{ flex: 1, padding: 14, backgroundColor: "#f0f2f5", borderRadius: 25, alignItems: "center", borderWidth: 1, borderColor: '#ddd' }}>
                <Text style={{ fontWeight: "bold", color: '#555' }}>Reset</Text>
              </Pressable>
              <Pressable onPress={() => { setFilterSheetOpen(false); loadReport(); }} style={{ flex: 1, padding: 14, backgroundColor: "#e74c3c", borderRadius: 25, alignItems: "center" }}>
                <Text style={{ color: "#fff", fontWeight: "bold" }}>Apply</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>

      {/* Period Selector Modal */}
      <Modal visible={periodPickerOpen} animationType="fade" transparent>
         <Pressable style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "center", padding: 40 }} onPress={() => setPeriodPickerOpen(false)}>
            <View style={{ backgroundColor: "#fff", borderRadius: 8, padding: 8 }}>
               {["Today", "Yesterday", "This Week", "This Month", "This Quarter", "This Year", "Custom"].map(p => (
                 <Pressable key={p} onPress={() => {
                    const now = new Date();
                    let f = isoDate(now), t = isoDate(now);
                    if (p === "Yesterday") { f = isoDate(addDays(now, -1)); t = f; }
                    else if (p === "This Week") { f = isoDate(addDays(now, -now.getDay())); }
                    else if (p === "This Month") { f = isoDate(startOfMonth(now)); t = isoDate(endOfMonth(now)); }
                    else if (p === "This Year") { f = `${now.getFullYear()}-01-01`; t = `${now.getFullYear()}-12-31`; }
                    setFilters(prev => ({ ...prev, from: f, to: t }));
                    setPeriodPickerOpen(false);
                 }} style={{ padding: 16, borderBottomWidth: 1, borderColor: '#eee' }}>
                    <Text style={{ fontSize: 16, color: '#333' }}>{p}</Text>
                 </Pressable>
               ))}
            </View>
         </Pressable>
      </Modal>

      {/* Report Picker Modal */}
      <Modal visible={reportPickerOpen} animationType="fade" transparent>
        <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "center", padding: 20 }}>
          <View style={{ backgroundColor: "#fff", borderRadius: 12, maxHeight: "80%" }}>
            <View style={{ padding: 20, borderBottomWidth: 1, borderColor: "#eee", flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
               <Text style={{ fontSize: 18, fontWeight: "bold", color: '#333' }}>Select Report</Text>
               <Pressable onPress={() => setReportPickerOpen(false)}><Ionicons name="close" size={24} color="#666" /></Pressable>
            </View>
            <FlatList
              data={REPORT_CATALOG}
              renderItem={({ item }) => (
                <Pressable onPress={() => { setType(item.value); setReportPickerOpen(false); }} style={{ padding: 16, borderBottomWidth: 1, borderColor: "#eee", backgroundColor: type === item.value ? '#f0f7ff' : '#fff' }}>
                  <Text style={{ fontSize: 15, fontWeight: type === item.value ? "bold" : "400", color: type === item.value ? "#0b83d8" : "#333" }}>{item.label}</Text>
                </Pressable>
              )}
            />
          </View>
        </View>
      </Modal>

      {/* Export Menu Modal */}
      <Modal visible={!!exportMenuOpen} transparent animationType="fade">
        <Pressable style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.2)', justifyContent: 'center', alignItems: 'center' }} onPress={() => setExportMenuOpen(null)}>
          <View style={{ backgroundColor: '#fff', width: 200, borderRadius: 8, padding: 8, elevation: 5 }}>
            <Text style={{ padding: 12, fontWeight: 'bold', color: '#666', borderBottomWidth: 1, borderColor: '#eee' }}>{exportMenuOpen?.type.toUpperCase()} Options</Text>
            <Pressable onPress={exportMenuOpen?.type === 'pdf' ? onExportPdf : onExportExcel} style={{ padding: 16, borderBottomWidth: 1, borderColor: '#eee' }}>
              <Text style={{ color: '#333' }}>Open {exportMenuOpen?.type.toUpperCase()}</Text>
            </Pressable>
            <Pressable style={{ padding: 16, borderBottomWidth: 1, borderColor: '#eee' }}>
              <Text style={{ color: '#333' }}>Print {exportMenuOpen?.type.toUpperCase()}</Text>
            </Pressable>
            <Pressable style={{ padding: 16 }}>
              <Text style={{ color: '#333' }}>Share {exportMenuOpen?.type.toUpperCase()}</Text>
            </Pressable>
          </View>
        </Pressable>
      </Modal>
    </ScreenContainer>
  );
}
