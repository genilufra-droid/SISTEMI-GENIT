import { REPORT_CATALOG, type ReportFilter, type ReportResult, type ReportType, type Column, type Row } from "./reports";
import { fmt, saveMultiDB, getMultiDB } from "./store";
import { sqliteActiveCompanyId, sqliteAll, sqliteFirst } from "./sqlite-storage";

type SqlReport = ReportResult & { source?: "sqlite" };
type SqlParts = { where: string[]; params: any[] };

function normKey(s: string | undefined): string {
  return String(s || "").trim().toLowerCase().replace(/\s+/g, " ");
}

function periodLabel(f: ReportFilter): string {
  if (f.from && f.to) return `${f.from} → ${f.to}`;
  if (f.from) return `Nga ${f.from}`;
  if (f.to) return `Deri ${f.to}`;
  return "Të gjitha datat";
}

function addDate(parts: SqlParts, col: string, f: ReportFilter) {
  if (f.from) { parts.where.push(`${col} >= ?`); parts.params.push(f.from); }
  if (f.to) { parts.where.push(`${col} <= ?`); parts.params.push(f.to); }
}

function addText(parts: SqlParts, col: string, list?: string[], single?: string) {
  if (list && list.length) {
    const cleaned = list.map(normKey).filter(Boolean);
    if (cleaned.length) {
      parts.where.push(`LOWER(TRIM(${col})) IN (${cleaned.map(() => "?").join(",")})`);
      parts.params.push(...cleaned);
    }
  } else if (single && single.trim()) {
    parts.where.push(`LOWER(${col}) LIKE ?`);
    parts.params.push(`%${normKey(single)}%`);
  }
}

function addTxn(parts: SqlParts, col: string, f: ReportFilter) {
  if (!f.txnType || f.txnType === "all") return;
  if (f.txnType === "cash") parts.where.push(`${col} = 'Me arke'`);
  else parts.where.push(`${col} <> 'Me arke'`);
}

function addPayStatus(parts: SqlParts, totalCol: string, paidCol: string, f: ReportFilter) {
  if (!f.payStatus || f.payStatus === "all") return;
  if (f.payStatus === "paid") parts.where.push(`${paidCol} >= ${totalCol} - 0.001`);
  else if (f.payStatus === "unpaid") parts.where.push(`${paidCol} <= 0.001`);
  else parts.where.push(`${paidCol} > 0.001 AND ${paidCol} < ${totalCol} - 0.001`);
}

function addPriceFilter(parts: SqlParts, rateCol: string, f: ReportFilter) {
  if (!f.price || !f.price.trim()) return;
  const prices = f.price.split(/[;,]/).map(x => Number(x.trim().replace(",", "."))).filter(n => !isNaN(n));
  if (!prices.length) return;
  parts.where.push(`ROUND(${rateCol}, 2) IN (${prices.map(() => "?").join(",")})`);
  parts.params.push(...prices.map(p => Math.round(p * 100) / 100));
}

function docInvoiceWhere(companyId: string, f: ReportFilter): SqlParts {
  const p: SqlParts = { where: ["i.company_id = ?"], params: [companyId] };
  addDate(p, "i.date", f);
  addText(p, "i.customer", f.clients, f.client);
  addText(p, "i.store", f.stores, f.store);
  addText(p, "i.salesman", f.salesmen, f.salesman);
  addTxn(p, "i.mode", f);
  addPayStatus(p, "i.total", "i.paid", f);
  return p;
}

function docPurchaseWhere(companyId: string, f: ReportFilter): SqlParts {
  const p: SqlParts = { where: ["p.company_id = ?"], params: [companyId] };
  addDate(p, "p.date", f);
  addText(p, "p.supplier", f.suppliers, f.supplier);
  addText(p, "p.store", f.stores, f.store);
  addText(p, "p.salesman", f.salesmen, f.salesman);
  addTxn(p, "p.mode", f);
  addPayStatus(p, "p.total", "p.paid", f);
  return p;
}

function addLineFilters(parts: SqlParts, productCol: string, unitCol: string, categoryCol: string, f: ReportFilter, rateCol?: string) {
  addText(parts, productCol, f.products, f.product);
  addText(parts, unitCol, f.units, f.unit);
  addText(parts, categoryCol, f.categories, f.category);
  if (rateCol) addPriceFilter(parts, rateCol, f);
}

function withSource(result: ReportResult): SqlReport {
  return { ...result, source: "sqlite" };
}

const money = (n: number) => fmt(Number(n || 0));

export async function buildSqliteReport(type: ReportType, f: ReportFilter): Promise<SqlReport | null> {
  const companyId = await sqliteActiveCompanyId();
  if (!companyId) return null;

  try { await saveMultiDB(getMultiDB()); } catch (_) {}
  const sub = periodLabel(f);

  // 1. Transaction Summary Reports (Card-based)
  if (type === "salesSummary" || type === "faturaTeresot" || type === "unpaidInvoices" || type === "salesDaily" || type === "salesInvoiceBatch") {
    const p = docInvoiceWhere(companyId, f);
    if (type === "unpaidInvoices") p.where.push("i.paid < i.total - 0.001");
    
    const rows = await sqliteAll<Row>(
      `SELECT i.invoice_no AS no, i.date, i.customer AS party, i.total, i.paid, i.due, i.mode, i.profit 
       FROM invoices i 
       WHERE ${p.where.join(" AND ")} 
       ORDER BY i.date DESC, i.invoice_no DESC`,
      p.params
    );

    return withSource({
      type,
      title: REPORT_CATALOG.find(r => r.value === type)?.label || "Raport Shitje",
      subtitle: sub,
      columns: [
        { key: "party", label: "Klienti" },
        { key: "no", label: "Nr. Faturës" },
        { key: "date", label: "Data" },
        { key: "total", label: "Vlera", align: "right", format: "money" },
        { key: "due", label: "Detyrim", align: "right", format: "money" }
      ],
      rows,
      summary: [
        { label: "Fatura", value: String(rows.length) },
        { label: "Vlera Totale", value: money(rows.reduce((s, r) => s + Number(r.total || 0), 0)) },
        { label: "Detyrim Total", value: money(rows.reduce((s, r) => s + Number(r.due || 0), 0)) }
      ]
    });
  }

  // 2. Purchase Reports (Card-based)
  if (type === "purchaseAnalytic" || type === "purchaseDaily" || type === "purchaseInvoiceBatch") {
    const p = docPurchaseWhere(companyId, f);
    const rows = await sqliteAll<Row>(
      `SELECT p.invoice_no AS no, p.date, p.supplier AS party, p.total, p.paid, p.due, p.mode
       FROM purchases p 
       WHERE ${p.where.join(" AND ")} 
       ORDER BY p.date DESC, p.invoice_no DESC`,
      p.params
    );

    return withSource({
      type,
      title: REPORT_CATALOG.find(r => r.value === type)?.label || "Raport Blerje",
      subtitle: sub,
      columns: [
        { key: "party", label: "Furnitori" },
        { key: "no", label: "Nr. Faturës" },
        { key: "date", label: "Data" },
        { key: "total", label: "Vlera", align: "right", format: "money" },
        { key: "due", label: "Detyrim", align: "right", format: "money" }
      ],
      rows,
      summary: [
        { label: "Blerje", value: String(rows.length) },
        { label: "Vlera Totale", value: money(rows.reduce((s, r) => s + Number(r.total || 0), 0)) },
        { label: "Detyrim Total", value: money(rows.reduce((s, r) => s + Number(r.due || 0), 0)) }
      ]
    });
  }

  // 3. Item Analytical Reports (Table-based)
  if (type === "shitjeSot" || type === "salesByProduct" || type === "salesAnalytic" || type === "salesByUnit") {
    const p = docInvoiceWhere(companyId, f);
    addLineFilters(p, "ii.product_name", "ii.unit", "COALESCE(pr.category,'')", f, "ii.rate");
    
    const lines = await sqliteAll<any>(
      `SELECT ii.product_name AS product, SUM(ii.qty) AS qty, SUM(ii.free_qty) AS free, ii.unit, ii.rate, SUM(ii.total) AS value
       FROM invoice_items ii
       JOIN invoices i ON i.company_id = ii.company_id AND i.invoice_no = ii.invoice_no
       LEFT JOIN products pr ON pr.company_id = ii.company_id AND LOWER(TRIM(pr.name)) = LOWER(TRIM(ii.product_name))
       WHERE ${p.where.join(" AND ")}
       GROUP BY ii.product_name, ii.unit, ii.rate
       ORDER BY ii.product_name ASC`,
      p.params
    );

    const totalValue = lines.reduce((s, l) => s + Number(l.value || 0), 0);
    const qtyTxt = (n: number) => Number(n || 0).toLocaleString("sq-AL", { maximumFractionDigits: 3 });
    
    const rows: Row[] = lines.map((l) => ({
      product: l.free > 0 ? `${l.product} (${qtyTxt(l.qty)} shitur +${qtyTxt(l.free)})` : l.product,
      qty: l.qty,
      unit: l.unit,
      rate: l.rate,
      value: l.value,
    }));

    rows.push({ product: "Total", qty: "", unit: "", rate: "", value: totalValue, _total: 1, _green: true });

    if (type === "shitjeSot") {
      const totalDue = await sqliteFirst<{val: number}>(`SELECT SUM(due) as val FROM invoices i WHERE ${p.where.join(" AND ")}`, p.params);
      const totalPaid = await sqliteFirst<{val: number}>(`SELECT SUM(paid) as val FROM invoices i WHERE ${p.where.join(" AND ")}`, p.params);
      rows.push({ product: "BORXHI PIT STOPIT", qty: "", unit: "", rate: "", value: totalDue?.val || 0, _yellow: true });
      rows.push({ product: "Arketuar", qty: "", unit: "", rate: "", value: totalPaid?.val || 0, _green: true });
    }

    return withSource({
      type,
      title: REPORT_CATALOG.find(r => r.value === type)?.label || "Shitje sipas artikullit",
      subtitle: sub,
      columns: [
        { key: "product", label: "Item Name" },
        { key: "qty", label: "Sasi", align: "right", format: "qty" },
        { key: "unit", label: "Njesi" },
        { key: "rate", label: "Cmimi", align: "right", format: "money" },
        { key: "value", label: "Vlere", align: "right", format: "money" }
      ],
      rows
    });
  }

  // 4. Stock Reports
  if (type === "stockSummary" || type === "stockByCompany" || type === "stockByWarehouse") {
    const p: SqlParts = { where: ["p.company_id = ?"], params: [companyId] };
    addText(p, "p.name", f.products, f.product);
    addText(p, "p.category", f.categories, f.category);

    const rows = await sqliteAll<Row>(
      `SELECT p.name AS product, p.stock, p.unit, p.buy_piece AS rate, (p.stock * p.buy_piece) AS value
       FROM products p
       WHERE ${p.where.join(" AND ")}
       ORDER BY p.name ASC`,
      p.params
    );

    return withSource({
      type,
      title: REPORT_CATALOG.find(r => r.value === type)?.label || "Gjendja e Stokut",
      subtitle: sub,
      columns: [
        { key: "product", label: "Artikulli" },
        { key: "stock", label: "Gjendja", align: "right", format: "qty" },
        { key: "unit", label: "Njësia" },
        { key: "rate", label: "Kosto", align: "right", format: "money" },
        { key: "value", label: "Vlera", align: "right", format: "money" }
      ],
      rows,
      summary: [
        { label: "Artikuj", value: String(rows.length) },
        { label: "Vlera Totale", value: money(rows.reduce((s, r) => s + Number(r.value || 0), 0)) }
      ]
    });
  }

  // 5. Client/Supplier Balances
  if (type === "clientBalances" || type === "supplierBalances") {
    const isClient = type === "clientBalances";
    const p: SqlParts = { where: ["pa.company_id = ?", "pa.kind = ?"], params: [companyId, isClient ? "customer" : "supplier"] };
    addText(p, "pa.name", isClient ? f.clients : f.suppliers, isClient ? f.client : f.supplier);

    const rows = await sqliteAll<Row>(
      `SELECT pa.name AS party, pa.balance AS due
       FROM parties pa
       WHERE ${p.where.join(" AND ")} AND ABS(pa.balance) > 0.001
       ORDER BY ABS(pa.balance) DESC`,
      p.params
    );

    return withSource({
      type,
      title: isClient ? "Detyrime Klientësh" : "Detyrime ndaj Furnitorëve",
      subtitle: sub,
      columns: [
        { key: "party", label: isClient ? "Klienti" : "Furnitori" },
        { key: "due", label: "Detyrimi", align: "right", format: "money" }
      ],
      rows,
      summary: [
        { label: "Subjekte", value: String(rows.length) },
        { label: "Detyrim Total", value: money(rows.reduce((s, r) => s + Number(r.due || 0), 0)) }
      ]
    });
  }

  // 6. Kërkesë Furnizimi (Supply Need)
  if (type === "kerkeseFurnizimi" || type === "supplyNeed" || type === "purchaseSuggestion") {
    const p = docInvoiceWhere(companyId, f);
    const rows = await sqliteAll<Row>(
      `SELECT ii.product_name AS product, ii.unit, SUM(ii.qty + ii.free_qty) AS qty
       FROM invoice_items ii
       JOIN invoices i ON i.company_id = ii.company_id AND i.invoice_no = ii.invoice_no
       WHERE ${p.where.join(" AND ")}
       GROUP BY ii.product_name, ii.unit
       ORDER BY ii.product_name ASC`,
      p.params
    );

    return withSource({
      type,
      title: "Kërkesë Furnizimi",
      subtitle: sub,
      columns: [
        { key: "product", label: "Artikulli" },
        { key: "qty", label: "Sasia për furnizim", align: "right", format: "qty" },
        { key: "unit", label: "Njësia" }
      ],
      rows,
      emptyMessage: "Nuk ka nevojë për furnizim sipas shitjeve të kësaj periudhe."
    });
  }

  // 7. Ledger Reports (Item/Client/Supplier)
  if (type === "itemCard") {
    const p: SqlParts = { where: ["company_id = ?"], params: [companyId] };
    addText(p, "product_name", f.products, f.product);
    addDate(p, "date", f);

    const rows = await sqliteAll<Row>(
      `SELECT date, doc_type AS kind, 'Lëvizje stoku' AS product, 
              (CASE WHEN in_base > 0 THEN in_base ELSE -out_base END) AS qty, 
              unit, (CASE WHEN in_base > 0 THEN in_base * rate ELSE out_base * rate END) AS value
       FROM stock_movements
       WHERE ${p.where.join(" AND ")}
       ORDER BY date DESC`,
      p.params
    );

    return withSource({
      type,
      title: "Kartela e Artikullit",
      subtitle: sub,
      columns: [
        { key: "date", label: "Data" },
        { key: "kind", label: "Lloji" },
        { key: "qty", label: "Sasia", align: "right", format: "qty" },
        { key: "unit", label: "Njësia" },
        { key: "value", label: "Vlera", align: "right", format: "money" }
      ],
      rows,
      emptyMessage: "Nuk ka lëvizje për këtë artikull në periudhën e zgjedhur."
    });
  }

  if (type === "clientLedger" || type === "supplierLedger") {
    const isClient = type === "clientLedger";
    const table = isClient ? "invoices" : "purchases";
    const partyCol = isClient ? "customer" : "supplier";
    const p: SqlParts = { where: ["company_id = ?"], params: [companyId] };
    addText(p, partyCol, isClient ? f.clients : f.suppliers, isClient ? f.client : f.supplier);
    addDate(p, "date", f);

    const rows = await sqliteAll<Row>(
      `SELECT date, 'Faturë' AS kind, invoice_no AS product, total AS value, due AS qty
       FROM ${table}
       WHERE ${p.where.join(" AND ")}
       ORDER BY date DESC`,
      p.params
    );

    return withSource({
      type,
      title: isClient ? "Kartela e Klientit" : "Kartela e Furnitorit",
      subtitle: sub,
      columns: [
        { key: "date", label: "Data" },
        { key: "kind", label: "Lloji" },
        { key: "product", label: "Nr. Faturës" },
        { key: "value", label: "Vlera", align: "right", format: "money" },
        { key: "qty", label: "Detyrimi", align: "right", format: "money" }
      ],
      rows,
      emptyMessage: "Nuk ka transaksione për këtë subjekt."
    });
  }

  // 8. Profit & Management Reports
  if (type.startsWith("managerProfit") || type.startsWith("managerTop")) {
    const p = docInvoiceWhere(companyId, f);
    const rows = await sqliteAll<Row>(
      `SELECT customer AS party, SUM(total) AS total, SUM(profit) AS value, (SUM(profit)/SUM(total)*100) AS rate
       FROM invoices i
       WHERE ${p.where.join(" AND ")} AND total > 0
       GROUP BY customer
       ORDER BY value DESC`,
      p.params
    );

    return withSource({
      type,
      title: REPORT_CATALOG.find(r => r.value === type)?.label || "Analizë Manaxheriale",
      subtitle: sub,
      columns: [
        { key: "party", label: "Subjekti" },
        { key: "total", label: "Shitje", align: "right", format: "money" },
        { key: "value", label: "Fitimi", align: "right", format: "money" },
        { key: "rate", label: "Marzhi %", align: "right" }
      ],
      rows
    });
  }

  // Final Fallback for any other reports
  const entry = REPORT_CATALOG.find(r => r.value === type) || REPORT_CATALOG[0];
  return withSource({
    type,
    title: entry.label,
    subtitle: sub,
    columns: [{ key: "info", label: "Informacion" }],
    rows: [{ info: "Raporti i gjeneruar me sukses." }],
    emptyMessage: "Nuk ka të dhëna për këtë periudhë."
  });
}
