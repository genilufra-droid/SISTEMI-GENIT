/**
 * Excel (.xlsx) export for Sistemi Genit reports.
 * Builds a styled worksheet that mirrors the on-screen report table:
 * title row, optional company + filters rows, header row, data rows and a
 * summary block — then writes it to a temp file and opens the share sheet so
 * it can be saved/opened from any phone (WhatsApp, Drive, Excel, etc.).
 */
import * as XLSXStyle from "xlsx-js-style";
import * as FileSystem from "expo-file-system/legacy";
import * as Sharing from "expo-sharing";
import { Platform } from "react-native";
import type { ReportResult } from "./reports";
import type { Company } from "./store";
import type { PrintableDoc } from "./print-templates";
import { buildWarehouseDocWorkbook } from "./warehouse-excel";

export { buildWarehouseDocWorkbook } from "./warehouse-excel";

export type ExcelMeta = {
  companyName?: string;
  filtersText?: string;
  currency?: string;
};

function sanitizeFileName(name: string): string {
  return name.replace(/[^\p{L}\p{N}_-]+/gu, "_").replace(/_+/g, "_").slice(0, 60) || "raport";
}

/** Convert a report row value to a number when the column is numeric, else string. */
function cellValue(raw: any, format?: string): number | string {
  if (raw == null || raw === "") return "";
  if (format === "money" || format === "qty") {
    const n = Number(raw);
    return isFinite(n) ? n : String(raw);
  }
  if (format === "pct") {
    const n = Number(raw);
    return isFinite(n) ? n / 100 : String(raw);
  }
  return String(raw);
}

export async function exportReportToExcel(result: ReportResult, meta: ExcelMeta = {}): Promise<void> {
  const cols = result.columns;
  const NC = Math.max(1, cols.length);
  const lastCol = NC - 1;
  const B = { style: "thin", color: { rgb: "CBD5E1" } } as const;
  const allB = { top: B, bottom: B, left: B, right: B };
  const numFmt = (fmt?: string) =>
    fmt === "money" ? "#,##0.00" : fmt === "qty" ? "#,##0.###" : fmt === "pct" ? "0.0%" : undefined;
  const ws: any = {};
  const merges: any[] = [];
  let R = 0;
  const put = (c: number, v: string | number, s: any) => {
    ws[XLSXStyle.utils.encode_cell({ r: R, c })] = { v, t: typeof v === "number" ? "n" : "s", s };
  };
  const titleS = { font: { bold: true, sz: 16 }, alignment: { horizontal: "center" } };
  const metaS = { font: { sz: 10, color: { rgb: "475569" } }, alignment: { horizontal: "center" } };
  const thS = {
    font: { bold: true, sz: 11, color: { rgb: "0F172A" } },
    fill: { fgColor: { rgb: "E2E8F0" } },
    border: allB,
    alignment: { horizontal: "center", vertical: "center", wrapText: true },
  };
  const totFill = { rgb: "16A34A" };
  const mergeFull = () => merges.push({ s: { r: R, c: 0 }, e: { r: R, c: lastCol } });

  // Title + meta rows (each merged across all columns)
  put(0, result.title, titleS); mergeFull(); R++;
  if (meta.companyName) { put(0, meta.companyName, metaS); mergeFull(); R++; }
  if (result.subtitle) { put(0, result.subtitle, metaS); mergeFull(); R++; }
  if (meta.filtersText) { put(0, `Filtra: ${meta.filtersText}`, metaS); mergeFull(); R++; }
  R++; // spacer

  // Header row (bold, grey fill)
  cols.forEach((c, ci) => put(ci, c.label, thS));
  R++;

    // Data rows — styled based on _total, _green, _yellow markers.
    result.rows.forEach((r) => {
      const isGreen = !!(r as any)._green || !!(r as any)._total;
      const isYellow = !!(r as any)._yellow;
      cols.forEach((c, ci) => {
        const v = cellValue((r as any)[c.key], c.format);
        const base: any = {
          font: { sz: 10, bold: isGreen || isYellow },
          border: allB,
          alignment: { horizontal: c.align || "left" },
        };
        if (isGreen) base.fill = { fgColor: { rgb: "A3CFBB" } };
        else if (isYellow) base.fill = { fgColor: { rgb: "FFF3CD" } };
        
        const nf = numFmt(c.format);
        if (nf && typeof v === "number") base.numFmt = nf;
        put(ci, v, base);
      });
      R++;
    });

  // Summary block
  if (result.summary && result.summary.length) {
    R++;
    put(0, "Përmbledhje", { font: { bold: true, sz: 11 } }); R++;
    result.summary.forEach((s) => {
      put(0, s.label, { font: { sz: 10 } });
      put(1, s.value, { font: { bold: true, sz: 10 } });
      R++;
    });
  }

  ws["!ref"] = XLSXStyle.utils.encode_range({ s: { r: 0, c: 0 }, e: { r: Math.max(0, R - 1), c: lastCol } });
  ws["!cols"] = cols.map((c) => {
    let w = String(c.label).length;
    result.rows.forEach((r) => {
      const v = (r as any)[c.key];
      if (v != null) w = Math.max(w, String(v).length);
    });
    return { wch: Math.min(Math.max(w + 2, 10), 40) };
  });
  ws["!merges"] = merges;

  const wb = XLSXStyle.utils.book_new();
  const sheetName = (result.title || "Raport").slice(0, 28);
  XLSXStyle.utils.book_append_sheet(wb, ws, sheetName);

  const wbout: string = XLSXStyle.write(wb, { type: "base64", bookType: "xlsx" });
  const fileName = `${sanitizeFileName(result.title)}_${new Date().toISOString().slice(0, 10)}.xlsx`;
  const uri = `${FileSystem.cacheDirectory}${fileName}`;

  await FileSystem.writeAsStringAsync(uri, wbout, { encoding: FileSystem.EncodingType.Base64 });

  const mime = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
  if (Platform.OS !== "web" && (await Sharing.isAvailableAsync())) {
    await Sharing.shareAsync(uri, { mimeType: mime, dialogTitle: result.title, UTI: "org.openxmlformats.spreadsheetml.sheet" });
  } else if (Platform.OS === "web") {
    // Web fallback: trigger a download
    const link = document.createElement("a");
    link.href = `data:${mime};base64,${wbout}`;
    link.download = fileName;
    link.click();
  }
}


/**
 * Export a warehouse document (Fletë Dalje / Fletë Hyrje) as a REAL styled
 * .xlsx file (borders, merged title, fills, widths, totals, signatures) and
 * share it. Uses the pure {@link buildWarehouseDocWorkbook} builder.
 */
export async function exportWarehouseDocToExcel(
  doc: PrintableDoc,
  company: Company,
): Promise<void> {
  const wb = buildWarehouseDocWorkbook(doc, company);

  const wbout: string = XLSXStyle.write(wb, { type: "base64", bookType: "xlsx" });
  const safeTitle = sanitizeFileName(`${doc.title}_${doc.number}`);
  const fileName = `${safeTitle}.xlsx`;
  const uri = `${FileSystem.cacheDirectory}${fileName}`;
  await FileSystem.writeAsStringAsync(uri, wbout, { encoding: FileSystem.EncodingType.Base64 });

  const mime = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
  if (Platform.OS !== "web" && (await Sharing.isAvailableAsync())) {
    await Sharing.shareAsync(uri, { mimeType: mime, dialogTitle: `${doc.title} ${doc.number}`, UTI: "org.openxmlformats.spreadsheetml.sheet" });
  } else if (Platform.OS === "web") {
    const link = document.createElement("a");
    link.href = `data:${mime};base64,${wbout}`;
    link.download = fileName;
    link.click();
  }
}

/**
 * Batch export for all filtered Fletë Hyrje / Fletë Dalje documents.
 * Sheet 1 is a document summary; Sheet 2 contains every item line. This is the
 * right XLSX shape for business control: one file, all documents one after
 * another, filterable by date/document/product in Excel.
 */
export async function exportWarehouseDocsBatchToExcel(
  docs: PrintableDoc[],
  company: Company,
  opts: { title?: string } = {},
): Promise<void> {
  const title = opts.title || "Dokumente Magazine";
  const wb = XLSXStyle.utils.book_new();
  const B = { style: "thin", color: { rgb: "CBD5E1" } } as const;
  const allB = { top: B, bottom: B, left: B, right: B };
  const thS = {
    font: { bold: true, color: { rgb: "0F172A" } },
    fill: { fgColor: { rgb: "E2E8F0" } },
    border: allB,
    alignment: { horizontal: "center", vertical: "center", wrapText: true },
  };
  const tdS = { border: allB, alignment: { vertical: "center", wrapText: true } };
  const moneyS = { ...tdS, numFmt: "#,##0.00", alignment: { horizontal: "right" } };
  const qtyS = { ...tdS, numFmt: "#,##0.###", alignment: { horizontal: "right" } };
  const put = (ws: any, r: number, c: number, v: any, s: any = tdS) => {
    ws[XLSXStyle.utils.encode_cell({ r, c })] = { v: v ?? "", t: typeof v === "number" ? "n" : "s", s };
  };

  // Summary sheet
  const summaryHeaders = ["Lloji", "Nr.", "Data", "Magazina", "Palë", "Destinacion", "Artikuj", "Sasi", "Vlefta"];
  const ws1: any = {};
  summaryHeaders.forEach((h, c) => put(ws1, 0, c, h, thS));
  docs.forEach((d, i) => {
    const r = i + 1;
    const qty = d.lines.reduce((s, l) => s + Number(l.qty || 0), 0);
    put(ws1, r, 0, d.title);
    put(ws1, r, 1, d.number);
    put(ws1, r, 2, d.date);
    put(ws1, r, 3, d.warehouseName || d.businessUnit || "");
    put(ws1, r, 4, d.receiver || d.partyName || "");
    put(ws1, r, 5, d.destinationAddress || "");
    put(ws1, r, 6, d.lines.length, qtyS);
    put(ws1, r, 7, qty, qtyS);
    put(ws1, r, 8, Number(d.total || 0), moneyS);
  });
  ws1["!ref"] = XLSXStyle.utils.encode_range({ s: { r: 0, c: 0 }, e: { r: Math.max(0, docs.length), c: summaryHeaders.length - 1 } });
  ws1["!cols"] = [{ wch: 18 }, { wch: 14 }, { wch: 12 }, { wch: 18 }, { wch: 24 }, { wch: 28 }, { wch: 10 }, { wch: 12 }, { wch: 14 }];
  XLSXStyle.utils.book_append_sheet(wb, ws1, "Dokumente");

  // Lines sheet
  const lineHeaders = ["Lloji", "Nr.", "Data", "Magazina", "Artikulli", "Njësia", "Sasia", "Çmimi", "Vlefta"];
  const ws2: any = {};
  lineHeaders.forEach((h, c) => put(ws2, 0, c, h, thS));
  let r = 1;
  docs.forEach((d) => {
    d.lines.forEach((l) => {
      put(ws2, r, 0, d.title);
      put(ws2, r, 1, d.number);
      put(ws2, r, 2, d.date);
      put(ws2, r, 3, d.warehouseName || d.businessUnit || "");
      put(ws2, r, 4, l.name);
      put(ws2, r, 5, l.unit);
      put(ws2, r, 6, Number(l.qty || 0), qtyS);
      put(ws2, r, 7, Number(l.rate || 0), moneyS);
      put(ws2, r, 8, Number(l.total || 0), moneyS);
      r++;
    });
  });
  ws2["!ref"] = XLSXStyle.utils.encode_range({ s: { r: 0, c: 0 }, e: { r: Math.max(0, r - 1), c: lineHeaders.length - 1 } });
  ws2["!cols"] = [{ wch: 18 }, { wch: 14 }, { wch: 12 }, { wch: 18 }, { wch: 34 }, { wch: 10 }, { wch: 12 }, { wch: 12 }, { wch: 14 }];
  XLSXStyle.utils.book_append_sheet(wb, ws2, "Rreshtat");

  // Physical stacked sheet: every Fletë Hyrje / Fletë Dalje one after another,
  // using the same visible 6 columns as PDF/Print. This is the sheet intended
  // for printing from Excel when the user wants all documents in one file.
  const ws3: any = {};
  const merges3: any[] = [];
  const rows3: { hpt: number }[] = [];
  const put3 = (rr: number, cc: number, v: any, st: any = tdS) => {
    ws3[XLSXStyle.utils.encode_cell({ r: rr, c: cc })] = { v: v ?? "", t: typeof v === "number" ? "n" : "s", s: st };
  };
  const title3 = { font: { bold: true, sz: 18 }, alignment: { horizontal: "center" }, border: allB };
  const label3 = { font: { bold: true, sz: 10 }, fill: { fgColor: { rgb: "F0F0F0" } }, border: allB, alignment: { wrapText: true } };
  const right3 = { ...tdS, alignment: { horizontal: "right" } };
  const money3 = { ...right3, numFmt: "#,##0.00" };
  const qty3 = { ...right3, numFmt: "#,##0.###" };
  let rr = 0;
  docs.forEach((d, di) => {
    put3(rr, 0, d.title, title3); merges3.push({ s: { r: rr, c: 0 }, e: { r: rr, c: 5 } }); rows3[rr] = { hpt: 26 }; rr++;
    put3(rr, 0, `Nr. ${d.number || ""}`, label3); put3(rr, 2, `Dt. ${d.date || ""}`, label3); put3(rr, 4, "Adresa ku shkon malli", label3); put3(rr, 5, d.destinationAddress || "", tdS); rows3[rr] = { hpt: 20 }; rr++;
    put3(rr, 0, "Magazina", label3); put3(rr, 1, d.warehouseName || d.businessUnit || "", tdS); put3(rr, 3, d.warehouseKind === "inbound" ? "Furnitori" : "Marrësi", label3); put3(rr, 4, d.receiver || d.partyName || "", tdS); rows3[rr] = { hpt: 20 }; rr++;
    const headers = ["Nr", "Emërtimi i mallit", "Njësia", "Sasia", "Çmimi", "Vlefta"];
    headers.forEach((h, c) => put3(rr, c, h, thS)); rows3[rr] = { hpt: 22 }; rr++;
    const visible = [...d.lines];
    while (visible.length < 21) visible.push({ name: "", qty: 0, unit: "", rate: 0, total: 0 } as any);
    visible.forEach((l, i) => {
      const has = !!String(l.name || "").trim();
      put3(rr, 0, i + 1, tdS);
      put3(rr, 1, has ? l.name : "", tdS);
      put3(rr, 2, has ? l.unit : "", tdS);
      put3(rr, 3, has ? Number(l.qty || 0) : "", has ? qty3 : tdS);
      put3(rr, 4, has && Number(l.rate || 0) ? Number(l.rate || 0) : "", has ? money3 : tdS);
      put3(rr, 5, has && Number(l.total || 0) ? Number(l.total || 0) : "", has ? money3 : tdS);
      rows3[rr] = { hpt: 18 };
      rr++;
    });
    put3(rr, 0, "TOTALI", label3); merges3.push({ s: { r: rr, c: 0 }, e: { r: rr, c: 2 } });
    put3(rr, 3, d.lines.reduce((s, l) => s + Number(l.qty || 0), 0), qty3);
    put3(rr, 5, Number(d.total || 0), money3); rows3[rr] = { hpt: 20 }; rr++;
    rr += 3;
    if (di < docs.length - 1) rr += 2;
  });
  ws3["!ref"] = XLSXStyle.utils.encode_range({ s: { r: 0, c: 0 }, e: { r: Math.max(0, rr - 1), c: 5 } });
  ws3["!cols"] = [{ wch: 6 }, { wch: 38 }, { wch: 12 }, { wch: 12 }, { wch: 14 }, { wch: 14 }];
  ws3["!rows"] = rows3;
  ws3["!merges"] = merges3;
  XLSXStyle.utils.book_append_sheet(wb, ws3, "Fletet A4");

  const wbout: string = XLSXStyle.write(wb, { type: "base64", bookType: "xlsx" });
  const fileName = `${sanitizeFileName(title)}_${new Date().toISOString().slice(0, 10)}.xlsx`;
  const uri = `${FileSystem.cacheDirectory}${fileName}`;
  await FileSystem.writeAsStringAsync(uri, wbout, { encoding: FileSystem.EncodingType.Base64 });
  const mime = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
  if (Platform.OS !== "web" && (await Sharing.isAvailableAsync())) {
    await Sharing.shareAsync(uri, { mimeType: mime, dialogTitle: title, UTI: "org.openxmlformats.spreadsheetml.sheet" });
  } else if (Platform.OS === "web") {
    const link = document.createElement("a");
    link.href = `data:${mime};base64,${wbout}`;
    link.download = fileName;
    link.click();
  }
}
