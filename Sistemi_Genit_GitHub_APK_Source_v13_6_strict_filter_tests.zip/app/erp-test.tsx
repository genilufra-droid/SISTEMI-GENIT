import React from "react";
import { Alert, ScrollView, Text, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { Header, Btn } from "@/components/ui-kit";
import { router } from "expo-router";
import { useColors } from "@/hooks/use-colors";
import { runErpSelfTests, SelfTestRow, buildVerifiedDemoDb } from "@/lib/erp-self-test";
import { sqliteHealthCheck } from "@/lib/sqlite-storage";
import { sqliteReportsHealthCheck } from "@/lib/sqlite-reports";
import { useStore } from "@/lib/store";

export default function ErpTestScreen() {
  const colors = useColors();
  const { setDB } = useStore();
  const [rows, setRows] = React.useState<SelfTestRow[]>([]);
  const [sqliteInfo, setSqliteInfo] = React.useState<string>("Pa kontrolluar");

  const runTests = async () => {
    const result = runErpSelfTests();
    const health = await sqliteHealthCheck();
    const reportHealth = await sqliteReportsHealthCheck();
    const reportRows: SelfTestRow[] = (reportHealth.assertions || []).map((a) => ({
      name: a.name,
      status: a.status,
      details: a.details,
    }));
    setRows([...result, ...reportRows]);
    setSqliteInfo(`${health.ok ? "OK" : "KUJDES"}: ${health.message}${health.counts ? "\n" + Object.entries(health.counts).map(([k, v]) => `${k}: ${v}`).join(" • ") : ""}\n${reportHealth.ok ? "OK" : "KUJDES"}: ${reportHealth.message} ${Object.entries(reportHealth.reportCounts).map(([k, v]) => `${k}: ${v}`).join(" • ")}`);
  };

  const loadDemo = async () => {
    const { db, tests } = buildVerifiedDemoDb();
    await setDB(db);
    setRows(tests);
    Alert.alert("Demo u ngarkua", "U ngarkua databaza testuese me blerje, shitje, fletë hyrje/dalje, stok dhe audit log.");
  };

  const pass = rows.filter((r) => r.status === "PASS").length;
  const fail = rows.filter((r) => r.status === "FAIL").length;

  return (
    <ScreenContainer>
      <Header title="Test ERP / SQLite" back={() => router.back()} />
      <ScrollView contentContainerStyle={{ padding: 12, paddingBottom: 60 }}>
        <View style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 12, padding: 12, marginBottom: 10 }}>
          <Text style={{ color: colors.foreground, fontSize: 18, fontWeight: "900" }}>Kontroll real i transaksioneve</Text>
          <Text style={{ color: colors.muted, marginTop: 6, lineHeight: 20 }}>
            Teston blerje, shitje me dhuratë, fletë hyrje/dalje automatike, kthim stoku në fshirje, bllokim shitje pa stok, historik çmimesh, raporte dhe SQLite.
          </Text>
          <View style={{ flexDirection: "row", gap: 8, marginTop: 12, flexWrap: "wrap" }}>
            <Btn title="Run tests" onPress={runTests} />
            <Btn title="Ngarko demo reale" variant="soft" onPress={loadDemo} />
          </View>
        </View>

        <View style={{ backgroundColor: "#e8f5ff", borderRadius: 10, padding: 10, borderWidth: 1, borderColor: "#bfdbfe", marginBottom: 10 }}>
          <Text style={{ color: colors.primary, fontWeight: "900" }}>SQLite</Text>
          <Text style={{ color: colors.foreground, marginTop: 4, fontSize: 12 }}>{sqliteInfo}</Text>
        </View>

        {rows.length ? (
          <View style={{ flexDirection: "row", gap: 8, marginBottom: 10 }}>
            <Text style={{ color: "#047857", fontWeight: "900" }}>PASS: {pass}</Text>
            <Text style={{ color: "#b91c1c", fontWeight: "900" }}>FAIL: {fail}</Text>
          </View>
        ) : null}

        {rows.map((r, i) => (
          <View key={`${r.name}-${i}`} style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: r.status === "PASS" ? "#bbf7d0" : "#fecaca", borderRadius: 10, padding: 10, marginBottom: 8 }}>
            <Text style={{ color: r.status === "PASS" ? "#047857" : "#b91c1c", fontWeight: "900" }}>{r.status} — {r.name}</Text>
            <Text style={{ color: colors.muted, marginTop: 4, fontSize: 12 }}>{r.details}</Text>
          </View>
        ))}
      </ScrollView>
    </ScreenContainer>
  );
}
