import {
  DB,
  Invoice,
  InvoiceItem,
  Purchase,
  Product,
  commitPurchaseInvoice,
  commitSaleInvoice,
  deleteSaleInvoice,
  newCompanyDB,
  stockInStore,
} from "./store";
import { buildReport, renderReportHtml, ReportType } from "./reports";

export type SelfTestStatus = "PASS" | "FAIL";
export type SelfTestRow = {
  name: string;
  status: SelfTestStatus;
  details: string;
};

function ok(name: string, details: string): SelfTestRow {
  return { name, status: "PASS", details };
}
function fail(name: string, details: string): SelfTestRow {
  return { name, status: "FAIL", details };
}
function assertTest(name: string, condition: boolean, details: string): SelfTestRow {
  return condition ? ok(name, details) : fail(name, details);
}

function sampleProduct(): Product {
  return {
    id: 1,
    code: "RUG-05",
    barcode: "100000000001",
    name: "Ujë Rugove 0.5L",
    category: "Ujë",
    store: "Magazina Kryesore",
    salePiece: 25,
    buyPiece: 20,
    prices: [300, 290, 280, 270, 260, 250, 240, 230, 220, 210],
    stock: 0,
    stockByStore: { "Magazina Kryesore": 0 },
    minStock: 24,
    units: [
      { name: "Copë", coef: 1 },
      { name: "Koli", coef: 12 },
      { name: "Paletë", coef: 1368 },
    ],
  };
}

function sampleProduct2(): Product {
  return {
    id: 2,
    code: "PER-033",
    barcode: "100000000002",
    name: "PERONI SHISHE 0.33L",
    category: "Birra",
    store: "Magazina Kryesore",
    salePiece: 50,
    buyPiece: 35,
    prices: [1200, 1100, 1000, 950, 900],
    stock: 0,
    stockByStore: { "Magazina Kryesore": 0 },
    minStock: 24,
    units: [
      { name: "Copë", coef: 1 },
      { name: "Koli", coef: 24 },
      { name: "Paletë", coef: 960 },
    ],
  };
}

function sampleProduct3(): Product {
  return {
    id: 3,
    code: "ELB-033",
    barcode: "100000000003",
    name: "ELBAR KANAÇE 0.33L",
    category: "Birra",
    store: "Magazina Kryesore",
    salePiece: 40,
    buyPiece: 30,
    prices: [960, 900, 850, 800],
    stock: 0,
    stockByStore: { "Magazina Kryesore": 0 },
    minStock: 24,
    units: [
      { name: "Copë", coef: 1 },
      { name: "Koli", coef: 24 },
      { name: "Paletë", coef: 960 },
    ],
  };
}

function line(productName: string, qty: number, freeQty: number, unit: string, rate: number, buyRate: number): InvoiceItem {
  return {
    productName,
    qty,
    freeQty,
    unit,
    rate,
    buyRate,
    total: qty * rate,
    cost: (qty + freeQty) * buyRate,
    priceList: 0,
  };
}

function baseDb(): DB {
  const db = newCompanyDB({ name: "TEST ERP" });
  return {
    ...db,
    stores: ["Magazina Kryesore"],
    warehouses: [
      {
        id: 1,
        name: "Magazina Kryesore",
        type: "main",
        status: "active",
        createdAt: "2026-06-28T00:00:00.000Z",
        updatedAt: "2026-06-28T00:00:00.000Z",
      },
    ],
    products: [sampleProduct(), sampleProduct2(), sampleProduct3()],
    customers: [{ id: 1, name: "Market Test", defaultPriceList: 0 }],
    suppliers: [{ id: 1, name: "Furnitor Test" }],
    invoices: [],
    purchases: [],
    payments: [],
    stockMovements: [],
    inboundDocs: [],
    outboundDocs: [],
    auditLogs: [],
    nextInvoice: 1,
    nextPurchase: 1,
  };
}

export function buildVerifiedDemoDb(): { db: DB; tests: SelfTestRow[] } {
  const tests: SelfTestRow[] = [];
  let db = baseDb();
  const product = "Ujë Rugove 0.5L";
  const wh = "Magazina Kryesore";

  const purchase: Purchase = {
    no: 1,
    date: "2026-06-28",
    time: "08:00",
    supplier: "Furnitor Test",
    store: wh,
    mode: "Me arke",
    items: [line(product, 10, 1, "Koli", 240, 20)],
    subtotal: 2400,
    roundOff: 0,
    total: 2400,
    paid: 2400,
    due: 0,
    paymentType: "Cash",
    note: "Test blerje 10+1 koli",
  };
  const pr = commitPurchaseInvoice(db, purchase, { autoInbound: true });
  tests.push(assertTest("Blerje + Fletë Hyrje", !pr.error && !!pr.purchase.linkedInboundDocId, pr.error || "U krijua blerja dhe fletë hyrja automatike."));
  db = pr.db;
  const afterPurchase = stockInStore(db.products.find((p) => p.name === product), wh);
  tests.push(assertTest("Stok pas blerjes 10+1 koli", afterPurchase === 132, `Pritet 132 copë, doli ${afterPurchase}.`));

  const sale: Invoice = {
    no: 1,
    date: "2026-06-28",
    time: "09:00",
    customer: "Market Test",
    store: wh,
    mode: "Me arke",
    items: [line(product, 3, 1, "Koli", 300, 20)],
    subtotal: 900,
    roundOff: 0,
    total: 900,
    paid: 900,
    due: 0,
    paymentType: "Cash",
    totalCost: 960,
    profit: -60,
    note: "Test shitje 3+1 koli",
  };
  const sr = commitSaleInvoice(db, sale, { autoOutbound: true });
  tests.push(assertTest("Shitje + Fletë Dalje", !sr.error && !!sr.invoice.linkedOutboundDocId, sr.error || "U krijua shitja dhe fletë dalja automatike."));
  db = sr.db;
  const afterSale = stockInStore(db.products.find((p) => p.name === product), wh);
  tests.push(assertTest("Stok pas shitjes 3+1 koli", afterSale === 84, `Pritet 84 copë, doli ${afterSale}.`));

  const blocked = commitSaleInvoice(
    db,
    { ...sale, no: 2, items: [line(product, 999, 0, "Koli", 300, 20)], subtotal: 299700, total: 299700, paid: 0, due: 299700 },
    { autoOutbound: true },
  );
  tests.push(assertTest("Bllokim shitje pa stok", !!blocked.error, blocked.error || "Duhej të bllokohej, por nuk u bllokua."));

  const del = deleteSaleInvoice(db, 1);
  tests.push(assertTest("Fshirje fature rikthen stok", !del.error, del.error || "Fatura u fshi dhe lëvizja u kthye."));
  db = del.db;
  const afterDelete = stockInStore(db.products.find((p) => p.name === product), wh);
  tests.push(assertTest("Stok pas fshirjes së shitjes", afterDelete === 132, `Pritet 132 copë, doli ${afterDelete}.`));

  // Keep final sales in the demo database so the SQLite report tests can
  // verify real filters with multiple products, different units and prices.
  const filterPurchase: Purchase = {
    no: 2,
    date: "2026-06-28",
    time: "10:00",
    supplier: "Furnitor Test",
    store: wh,
    mode: "Me arke",
    items: [
      line(product, 5, 0, "Koli", 240, 20),
      line("PERONI SHISHE 0.33L", 3, 0, "Koli", 840, 35),
      line("ELBAR KANAÇE 0.33L", 3, 0, "Koli", 720, 30),
    ],
    subtotal: 5880,
    roundOff: 0,
    total: 5880,
    paid: 5880,
    due: 0,
    paymentType: "Cash",
    note: "Seed për teste filtrash SQLite",
  };
  const fpr = commitPurchaseInvoice(db, filterPurchase, { autoInbound: true });
  tests.push(assertTest("Seed filtra: blerje shumë artikuj", !fpr.error, fpr.error || "U shtua stok për teste filtrash."));
  db = fpr.db;

  const filterSale1: Invoice = {
    no: 3,
    date: "2026-06-28",
    time: "11:00",
    customer: "Market Test",
    store: wh,
    mode: "Me arke",
    items: [
      line(product, 2, 0, "Koli", 300, 20),
      line("PERONI SHISHE 0.33L", 1, 0, "Koli", 1200, 35),
    ],
    subtotal: 1800,
    roundOff: 0,
    total: 1800,
    paid: 1800,
    due: 0,
    paymentType: "Cash",
    totalCost: 1320,
    profit: 480,
    note: "Seed shitje Koli",
  };
  const fsr1 = commitSaleInvoice(db, filterSale1, { autoOutbound: true });
  tests.push(assertTest("Seed filtra: shitje shumë artikuj", !fsr1.error, fsr1.error || "U krijua shitje me dy artikuj."));
  db = fsr1.db;

  const filterSale2: Invoice = {
    no: 4,
    date: "2026-06-28",
    time: "11:30",
    customer: "Market Test",
    store: wh,
    mode: "Me arke",
    items: [
      line(product, 6, 0, "Copë", 25, 20),
      line("ELBAR KANAÇE 0.33L", 1, 0, "Koli", 960, 30),
    ],
    subtotal: 1110,
    roundOff: 0,
    total: 1110,
    paid: 1110,
    due: 0,
    paymentType: "Cash",
    totalCost: 840,
    profit: 270,
    note: "Seed shitje Copë + Koli",
  };
  const fsr2 = commitSaleInvoice(db, filterSale2, { autoOutbound: true });
  tests.push(assertTest("Seed filtra: shitje njësi/çmime", !fsr2.error, fsr2.error || "U krijua shitje me njësi dhe çmime të ndryshme."));
  db = fsr2.db;

  const history = db.clientPriceHistory?.["market test|ujë rugove 0.5l"] || [];
  tests.push(assertTest("5 çmimet e fundit të klientit", history.length >= 2 && history.some((h) => h.price === 300) && history.some((h) => h.price === 25), `Regjistrime: ${history.length}.`));

  const reports: ReportType[] = ["salesSummary", "purchaseAnalytic", "stockSummary", "stockMovement", "outboundDocsReport", "supplyNeed"];
  for (const r of reports) {
    try {
      const res = buildReport(r, db, { from: "2026-06-01", to: "2026-06-30" });
      const html = renderReportHtml(res, { companyName: db.company.name, filters: { from: "2026-06-01", to: "2026-06-30" } });
      const headersOk = res.columns.every((c) => html.includes(c.label));
      tests.push(assertTest(`Raport i kontrolluar: ${r}`, res.columns.length > 0 && headersOk, `${res.rows.length} rreshta, ${res.columns.length} kolona.`));
    } catch (e: any) {
      tests.push(fail(`Raport i kontrolluar: ${r}`, e?.message || String(e)));
    }
  }

  return { db, tests };
}

export function runErpSelfTests(): SelfTestRow[] {
  try {
    return buildVerifiedDemoDb().tests;
  } catch (e: any) {
    return [fail("Testimi i plotë ERP", e?.message || String(e))];
  }
}
