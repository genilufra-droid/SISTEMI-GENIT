import React from "react";
import { ActivityIndicator, Alert, FlatList, Platform, Pressable, ScrollView, Switch, Text, TextInput, View } from "react-native";
import { useLocalSearchParams } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { Badge, Btn, Header } from "@/components/ui-kit";
import { useStore, allSalesmen } from "@/lib/store";
import {
  REPORT_CATALOG,
  ReportFilter,
  ReportType,
  buildReport,
  renderReportHtml,
} from "@/lib/reports";
import { exportReportToExcel } from "@/lib/excel";
import { buildSqliteReport } from "@/lib/sqlite-reports";
import * as Print from "expo-print";
import * as Sharing from "expo-sharing";

type ParamShape = { type?: string; client?: string; supplier?: string; product?: string };

const GROUP_ORDER = ["Shitje", "Blerje", "Stoku", "Manaxher", "Detyrime", "Shpenzime", "Shitës / GPS"];
type MultiKind = "clients" | "suppliers" | "products" | "stores" | "salesmen" | "categories";


const EMPTY_FILTERS: ReportFilter = {
  clients: [],
  suppliers: [],
  products: [],
  stores: [],
  units: [],
  salesmen: [],
  categories: [],
  from: "",
  to: "",
  price: "",
  reportUnit: "",
  txnType: "all",
  payStatus: "all",
};

function normalizeFilter(f: ReportFilter): ReportFilter {
  return {
    ...EMPTY_FILTERS,
    ...f,
    clients: [...(f.clients || [])],
    suppliers: [...(f.suppliers || [])],
    products: [...(f.products || [])],
    stores: [...(f.stores || [])],
    units: [...(f.units || [])],
    salesmen: [...(f.salesmen || [])],
    categories: [...(f.categories || [])],
    from: f.from || "",
    to: f.to || "",
    price: f.price || "",
    reportUnit: f.reportUnit || "",
    txnType: f.txnType || "all",
    payStatus: f.payStatus || "all",
  };
}

function filterSignature(f: ReportFilter): string {
  const n = normalizeFilter(f);
  return JSON.stringify({
    ...n,
    clients: [...(n.clients || [])].sort(),
    suppliers: [...(n.suppliers || [])].sort(),
    products: [...(n.products || [])].sort(),
    stores: [...(n.stores || [])].sort(),
    units: [...(n.units || [])].sort(),
    salesmen: [...(n.salesmen || [])].sort(),
    categories: [...(n.categories || [])].sort(),
  });
}

function reportGroupOf(t: ReportType): string {
  return REPORT_CATALOG.find((r) => r.value === t)?.group || "";
}

function safeFiltersForReportSwitch(currentType: ReportType, nextType: ReportType, currentFilters: ReportFilter): ReportFilter {
  const f = normalizeFilter(currentFilters);

  // v14 Reports Rewrite: çdo raport duhet të hapet i pastër si në workflow-n
  // ERP të videos. Kur përdoruesi kalon nga një raport te tjetri, nuk duhet
  // të trashëgohen filtrat specifikë të raportit të mëparshëm (artikull,
  // klient, furnitor, çmim, njësi shitjeje, status pagese, kërkim rezultatesh),
  // sepse ato mund ta bëjnë raportin e ri të duket bosh ose me kolona/rreshta
  // të vjetër. Ruhen vetëm filtrat universalë që kanë kuptim në çdo raport:
  // periudha, magazina dhe njësia e raportimit.
  return normalizeFilter({
    from: f.from,
    to: f.to,
    stores: f.stores || [],
    reportUnit: f.reportUnit || "",
  });
}


function pad2(n: number) { return String(n).padStart(2, "0"); }
function isoDate(d: Date) { return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`; }
function parseIsoDate(v?: string): Date | null {
  if (!v || !/^\d{4}-\d{2}-\d{2}$/.test(v)) return null;
  const [y, m, d] = v.split("-").map(Number);
  const out = new Date(y, m - 1, d);
  return Number.isNaN(out.getTime()) ? null : out;
}
function addDays(d: Date, n: number) { const x = new Date(d); x.setDate(x.getDate() + n); return x; }
function addMonths(d: Date, n: number) { const x = new Date(d); x.setMonth(x.getMonth() + n); return x; }
function startOfMonth(d: Date) { return new Date(d.getFullYear(), d.getMonth(), 1); }
function endOfMonth(d: Date) { return new Date(d.getFullYear(), d.getMonth() + 1, 0); }
function startOfYear(d: Date) { return new Date(d.getFullYear(), 0, 1); }
function endOfYear(d: Date) { return new Date(d.getFullYear(), 11, 31); }
function monthTitle(d: Date) {
  return d.toLocaleDateString("sq-AL", { month: "long", year: "numeric" });
}
function prettyDate(v?: string) {
  const d = parseIsoDate(v);
  return d ? d.toLocaleDateString("sq-AL") : "Zgjidh";
}
function normalizeDatePatch(patch: Partial<Pick<ReportFilter, "from" | "to">>, base: ReportFilter) {
  let from = patch.from ?? base.from ?? "";
  let to = patch.to ?? base.to ?? "";
  if (from && to && from > to) {
    // Kur përdoruesi zgjedh datë fillimi më të madhe se data e fundit,
    // periudha kthehet në një datë të vetme që raporti të rifreskohet pa gabim.
    to = from;
  }
  return { from, to };
}
function calendarDays(cursor: Date) {
  const first = startOfMonth(cursor);
  const startOffset = (first.getDay() + 6) % 7; // Monday first
  const start = addDays(first, -startOffset);
  return Array.from({ length: 42 }, (_, i) => addDays(start, i));
}

function emptyReportFor(type: ReportType, filters: ReportFilter) {
  const entry = REPORT_CATALOG.find((r) => r.value === type) || REPORT_CATALOG[0];
  return {
    title: entry.label,
    subtitle: "Po ngarkohet raporti…",
    columns: [],
    rows: [],
    summary: [],
    emptyMessage: "Po ngarkohet raporti…",
    filter: filters,
  } as any;
}

export default function ReportsScreen() {
  const colors = useColors();
  const { db, setDB } = useStore();
  const params = useLocalSearchParams<ParamShape>();

  const [type, setType] = React.useState<ReportType>(
    (params.type as ReportType) || "salesSummary",
  );
  const initialFilters = React.useMemo<ReportFilter>(() => normalizeFilter({
    clients: typeof params.client === "string" && params.client ? [params.client] : [],
    suppliers: typeof params.supplier === "string" && params.supplier ? [params.supplier] : [],
    products: typeof params.product === "string" && params.product ? [params.product] : [],
  }), [params.client, params.supplier, params.product]);

  // Draft filters are edited freely. Applied filters are the only ones that
  // rebuild SQLite reports. This prevents slow reports from running on every
  // keystroke and makes combinations behave like a professional ERP: choose all
  // criteria first; v14.1 applies them automatically with a short debounce.
  const [filters, setFilters] = React.useState<ReportFilter>(initialFilters);
  const [appliedFilters, setAppliedFilters] = React.useState<ReportFilter>(initialFilters);
  const [refreshSeq, setRefreshSeq] = React.useState(0);
  const [filtersExpanded, setFiltersExpanded] = React.useState(false);

  const [pickerOpen, setPickerOpen] = React.useState(false);
  const [searchPicker, setSearchPicker] = React.useState("");
  const [multiPicker, setMultiPicker] = React.useState<null | MultiKind>(null);
  const [partySearch, setPartySearch] = React.useState("");
  const [pdfOpen, setPdfOpen] = React.useState(false);
  const [pdfOpts, setPdfOpts] = React.useState({ showCompany: true, showFilters: true, showSummary: true, zebra: true });
  const [rowSearch, setRowSearch] = React.useState("");
  const [reportTransitionSeq, setReportTransitionSeq] = React.useState(0);
  const [viewerRevision, setViewerRevision] = React.useState(0);
  const [datePickerOpen, setDatePickerOpen] = React.useState(false);
  const [activeDateField, setActiveDateField] = React.useState<"from" | "to">("from");
  const [dateCursor, setDateCursor] = React.useState(() => parseIsoDate(initialFilters.from || initialFilters.to) || new Date());

  // Sync the report type with incoming navigation params. The Reports tab stays
  // mounted, so a fresh `params.type` (e.g. tapping a different report link from
  // the menu) must update state — otherwise the previously opened report stays
  // on screen. We validate against the catalog so an unknown value is ignored.
  React.useEffect(() => {
    const t = params.type;
    if (typeof t === "string" && t && REPORT_CATALOG.some((r) => r.value === t) && t !== type) {
      // Global report switch path for navigation links. Clear result-search and
      // force a fresh SQLite run so every report type is loaded with its own
      // columns/rows instead of reusing the previous report view.
      const nextType = t as ReportType;
      const nextFilters = safeFiltersForReportSwitch(type, nextType, appliedFilters);
      setRowSearch("");
      setFilters(nextFilters);
      setAppliedFilters(nextFilters);
      setType(nextType);
      setReportTransitionSeq((x) => x + 1);
      setRefreshSeq((x) => x + 1);
    }
  }, [params.type]);

  // Keep the single-value filters in sync when navigating with a target party /
  // product (e.g. "Kartela e Artikullit" opened from the product screen).
  React.useEffect(() => {
    const patch: Partial<ReportFilter> = {
      products: typeof params.product === "string" && params.product ? [params.product] : undefined,
      clients: typeof params.client === "string" && params.client ? [params.client] : undefined,
      suppliers: typeof params.supplier === "string" && params.supplier ? [params.supplier] : undefined,
    };
    const cleaned = Object.fromEntries(Object.entries(patch).filter(([, v]) => v !== undefined)) as Partial<ReportFilter>;
    if (Object.keys(cleaned).length === 0) return;
    setFilters((f) => normalizeFilter({ ...f, ...cleaned }));
    setAppliedFilters((f) => normalizeFilter({ ...f, ...cleaned }));
  }, [params.product, params.client, params.supplier]);

  const favorites = db.settings.favoriteReports || [];
  const isFavorite = favorites.includes(type);
  const toggleFavorite = (t: ReportType) => {
    setDB((prev) => {
      const cur = prev.settings.favoriteReports || [];
      const next = cur.includes(t) ? cur.filter((x) => x !== t) : [...cur, t];
      return { ...prev, settings: { ...prev.settings, favoriteReports: next } };
    });
  };

  const reportEntry = REPORT_CATALOG.find((r) => r.value === type) || REPORT_CATALOG[0];
  const memoryResult = React.useMemo(() => buildReport(type, db, appliedFilters), [type, db, appliedFilters]);
  type ReportSnapshot = ReturnType<typeof buildReport>;
  const sqliteQueryKey = React.useMemo(
    () => `${type}|${filterSignature(appliedFilters)}|${refreshSeq}|${reportTransitionSeq}`,
    [type, appliedFilters, refreshSeq, reportTransitionSeq],
  );
  const [sqliteSnapshot, setSqliteSnapshot] = React.useState<{ key: string; result: ReportSnapshot | null } | null>(null);
  const [sqliteLoading, setSqliteLoading] = React.useState(false);

  // Reset the live result search and any previous SQL result whenever the
  // current report identity changes. This runs after the SQLite state exists
  // and is global for every report.
  React.useEffect(() => {
    setRowSearch("");
    setSqliteSnapshot(null);
    setViewerRevision((x) => x + 1);
  }, [type, appliedFilters]);

  // Progressive SQLite refresh with strict ownership by report+filter key.
  // The Reports tab remains mounted while the user changes report types. If an
  // older SQLite promise resolves after the type/filter changed, it must never
  // overwrite the new report. This fixes the visible issue where switching from
  // one report to another left the old rows/columns, or showed an empty table
  // until the user refreshed manually.
  React.useEffect(() => {
    let alive = true;
    const key = sqliteQueryKey;
    setSqliteSnapshot(null);
    setSqliteLoading(true);
    const timer = setTimeout(() => {
      buildSqliteReport(type, appliedFilters)
      .then((r) => {
        if (alive) setSqliteSnapshot({ key, result: r });
      })
      .catch(() => {
        if (alive) setSqliteSnapshot({ key, result: null });
      })
      .finally(() => {
        if (alive) setSqliteLoading(false);
      });
    }, 120);
    return () => { alive = false; clearTimeout(timer); };
  }, [sqliteQueryKey, type, appliedFilters, db]);

  const freshSqliteResult = sqliteSnapshot?.key === sqliteQueryKey ? sqliteSnapshot.result : null;
  const fallbackResult = memoryResult;
  const reportIsResolving = sqliteLoading && !freshSqliteResult;

  // v14: mos shfaq kurrë rezultat të raportit të mëparshëm gjatë ndërrimit.
  // Derisa SQLite të kthejë përgjigje për raportin+filtrat aktualë, tabela
  // tregon gjendje loading. Vetëm nëse SQLite mbaron pa rezultat përdorim
  // memory fallback të raportit aktual. Kjo eliminon rreshtat/kolonat e vjetra
  // që shfaqeshin në video.
  const result = freshSqliteResult || fallbackResult || emptyReportFor(type, appliedFilters);
  const tableResetKey = React.useMemo(
    () => `${type}|${filterSignature(appliedFilters)}|${reportTransitionSeq}|${viewerRevision}|${result.columns.map((c) => c.key).join(',')}`,
    [type, appliedFilters, reportTransitionSeq, viewerRevision, result.columns],
  );
  const filtersDirty = React.useMemo(
    () => filterSignature(filters) !== filterSignature(appliedFilters),
    [filters, appliedFilters],
  );

  // v14.1 Vyapar-style: filtrat kryesorë nuk presin më butonin "Apliko".
  // Përdoruesi zgjedh artikull/klient/njësi/çmim dhe raporti rifreskohet vetë
  // me një debounce të shkurtër për të mos bërë query në çdo tast.
  React.useEffect(() => {
    if (!filtersDirty) return;
    const timer = setTimeout(() => {
      setAppliedFilters(normalizeFilter(filters));
      setRowSearch("");
      setSqliteSnapshot(null);
      setViewerRevision((x) => x + 1);
      setRefreshSeq((x) => x + 1);
    }, 320);
    return () => clearTimeout(timer);
  }, [filters, filtersDirty]);

  const applyFilters = React.useCallback(() => {
    setAppliedFilters(normalizeFilter(filters));
    setRowSearch("");
    setSqliteSnapshot(null);
    setViewerRevision((x) => x + 1);
    setRefreshSeq((x) => x + 1);
  }, [filters]);
  const refreshSqliteReport = React.useCallback(() => {
    setRefreshSeq((x) => x + 1);
  }, []);

  const applyDatePatch = React.useCallback((patch: Partial<Pick<ReportFilter, "from" | "to">>) => {
    setFilters((f) => {
      const datePatch = normalizeDatePatch(patch, f);
      return normalizeFilter({ ...f, ...datePatch });
    });
    setAppliedFilters((f) => {
      const datePatch = normalizeDatePatch(patch, f);
      return normalizeFilter({ ...f, ...datePatch });
    });
    setRowSearch("");
    setSqliteSnapshot(null);
    setSqliteLoading(true);
    setViewerRevision((x) => x + 1);
    setRefreshSeq((x) => x + 1);
  }, []);

  const openDatePicker = React.useCallback((field: "from" | "to") => {
    setActiveDateField(field);
    const selected = parseIsoDate(field === "from" ? filters.from : filters.to) || parseIsoDate(filters.from || filters.to) || new Date();
    setDateCursor(startOfMonth(selected));
    setDatePickerOpen(true);
  }, [filters.from, filters.to]);

  const applyDatePreset = React.useCallback((kind: "today" | "yesterday" | "week" | "month" | "year") => {
    const now = new Date();
    if (kind === "today") applyDatePatch({ from: isoDate(now), to: isoDate(now) });
    if (kind === "yesterday") {
      const d = addDays(now, -1);
      applyDatePatch({ from: isoDate(d), to: isoDate(d) });
    }
    if (kind === "week") applyDatePatch({ from: isoDate(addDays(now, -6)), to: isoDate(now) });
    if (kind === "month") applyDatePatch({ from: isoDate(startOfMonth(now)), to: isoDate(endOfMonth(now)) });
    if (kind === "year") applyDatePatch({ from: isoDate(startOfYear(now)), to: isoDate(endOfYear(now)) });
  }, [applyDatePatch]);
  const activeDraftFilterCount = React.useMemo(() => {
    const f = normalizeFilter(filters);
    let n = 0;
    if (f.from || f.to) n += 1;
    if (f.price) n += 1;
    if (f.reportUnit) n += 1;
    ([f.clients, f.suppliers, f.products, f.stores, f.units, f.salesmen, f.categories] as string[][]).forEach((arr) => { if (arr.length) n += 1; });
    if (f.txnType && f.txnType !== "all") n += 1;
    if (f.payStatus && f.payStatus !== "all") n += 1;
    return n;
  }, [filters]);

  // Fast client-side text search across all visible columns of the result rows
  const visibleRows = React.useMemo(() => {
    const q = rowSearch.trim().toLowerCase();
    if (!q) return result.rows;
    return result.rows.filter((r) =>
      result.columns.some((c) => String((r as any)[c.key] ?? "").toLowerCase().includes(q)),
    );
  }, [rowSearch, result]);

  const groupedCatalog = React.useMemo(() => {
    const norm = searchPicker.trim().toLowerCase();
    return GROUP_ORDER.map((g) => ({
      group: g,
      items: REPORT_CATALOG.filter(
        (r) => r.group === g && (!norm || r.label.toLowerCase().includes(norm)),
      ),
    })).filter((g) => g.items.length > 0);
  }, [searchPicker]);

  // Units available across all products (for the unit chips filter)
  const allUnits = React.useMemo(() => {
    const set: string[] = [];
    db.products.forEach((p) => (p.units || []).forEach((u) => {
      if (!set.some((x) => x.toLowerCase() === u.name.toLowerCase())) set.push(u.name);
    }));
    return set;
  }, [db.products]);

  const makeFiltersText = React.useCallback((src: ReportFilter) => {
    const parts: string[] = [];
    if (src.from || src.to) parts.push(`${src.from || "…"} → ${src.to || "…"}`);
    if (src.clients?.length) parts.push(`Klientë: ${src.clients.join(", ")}`);
    if (src.suppliers?.length) parts.push(`Furnitorë: ${src.suppliers.join(", ")}`);
    if (src.products?.length) parts.push(`Artikuj: ${src.products.join(", ")}`);
    if (src.stores?.length) parts.push(`Magazina: ${src.stores.join(", ")}`);
    if (src.units?.length) parts.push(`Njësi shitje: ${src.units.join(", ")}`);
    if (src.reportUnit?.trim()) parts.push(`Njësi raporti: ${src.reportUnit.trim()}`);
    if (src.price?.trim()) parts.push(`Çmimi: ${src.price.trim()}`);
    if (src.salesmen?.length) parts.push(`Shitës: ${src.salesmen.join(", ")}`);
    if (src.categories?.length) parts.push(`Kategori: ${src.categories.join(", ")}`);
    if (src.txnType && src.txnType !== "all") parts.push(`Lloji: ${src.txnType === "cash" ? "Kesh" : "Kredi"}`);
    if (src.payStatus && src.payStatus !== "all") parts.push(`Statusi: ${src.payStatus === "paid" ? "Paguar" : src.payStatus === "partial" ? "Pjesërisht" : "Pa paguar"}`);
    return parts.join("  •  ");
  }, []);

  const filtersText = React.useMemo(() => makeFiltersText(appliedFilters), [makeFiltersText, appliedFilters]);
  const draftFiltersText = React.useMemo(() => makeFiltersText(filters), [makeFiltersText, filters]);

  // Build an export-ready result that respects the in-results text search.
  // When a row search is active we export only the visible rows and recompute
  // any numeric summary lines from those rows so totals match what is on screen.
  const exportResult = React.useMemo(() => {
    if (!rowSearch.trim() || visibleRows.length === result.rows.length) return result;
    const fmtMoney = (n: number) =>
      new Intl.NumberFormat("sq-AL", { maximumFractionDigits: 2 }).format(n);
    const recomputed = (result.summary || []).map((s) => {
      // Try to map a summary label to a money/qty column and re-sum visible rows.
      const col = result.columns.find(
        (c) => c.format === "money" && s.label.toLowerCase().includes(c.label.toLowerCase()),
      );
      if (col) {
        const sum = visibleRows.reduce((a, r) => a + Number((r as any)[col.key] || 0), 0);
        return { ...s, value: fmtMoney(sum) };
      }
      return s;
    });
    return {
      ...result,
      subtitle: result.subtitle
        ? `${result.subtitle}  •  Kërkim: “${rowSearch.trim()}”`
        : `Kërkim: “${rowSearch.trim()}”`,
      rows: visibleRows,
      summary: recomputed.length ? recomputed : result.summary,
    };
  }, [result, visibleRows, rowSearch]);

  const onShare = async () => {
    const html = renderReportHtml(exportResult, { companyName: db.company.name, filters: appliedFilters, currency: db.company.currency });
    try {
      if (Platform.OS === "web") { await Print.printAsync({ html }); return; }
      const { uri } = await Print.printToFileAsync({ html });
      if (await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(uri, { mimeType: "application/pdf", dialogTitle: result.title });
      } else {
        await Print.printAsync({ html });
      }
    } catch (e: any) { Alert.alert("Gabim", String(e?.message || e)); }
  };

  const onPrint = async () => {
    const html = renderReportHtml(exportResult, { companyName: db.company.name, filters: appliedFilters, currency: db.company.currency });
    try { await Print.printAsync({ html }); } catch (e: any) { Alert.alert("Gabim", String(e?.message || e)); }
  };

  const onExcel = async () => {
    try {
      const ft = rowSearch.trim() ? `${filtersText}${filtersText ? "  •  " : ""}Kërkim: “${rowSearch.trim()}”` : filtersText;
      await exportReportToExcel(exportResult, { companyName: db.company.name, filtersText: ft, currency: db.company.currency });
    } catch (e: any) {
      Alert.alert("Gabim Excel", String(e?.message || e));
    }
  };

  const setFilter = (patch: Partial<ReportFilter>) => setFilters((f) => normalizeFilter({ ...f, ...patch }));

  const toggleMulti = (kind: MultiKind, value: string) => {
    setFilters((f) => {
      const cur = (f[kind] as string[] | undefined) || [];
      const next = cur.some((x) => x.toLowerCase() === value.toLowerCase())
        ? cur.filter((x) => x.toLowerCase() !== value.toLowerCase())
        : [...cur, value];
      return { ...f, [kind]: next };
    });
  };

  const toggleUnit = (u: string) => {
    setFilters((f) => {
      const cur = f.units || [];
      const next = cur.some((x) => x.toLowerCase() === u.toLowerCase())
        ? cur.filter((x) => x.toLowerCase() !== u.toLowerCase())
        : [...cur, u];
      return { ...f, units: next };
    });
  };

  const selectReport = React.useCallback((next: ReportType) => {
    // Një rrugë e vetme globale për ndërrimin e çdo raporti. Kjo pastron
    // snapshot-in, kërkimin, tabelën, kolonat dhe filtrat që nuk kanë kuptim
    // në grupin e ri të raportit. Qëllimi: asnjë raport të mos trashëgojë
    // rreshta/kolona/filtra nga raporti paraardhës.
    const nextFilters = safeFiltersForReportSwitch(type, next, filtersDirty ? filters : appliedFilters);
    setPickerOpen(false);
    setSearchPicker("");
    setRowSearch("");
    setFilters(nextFilters);
    setAppliedFilters(nextFilters);
    setSqliteSnapshot(null);
    setSqliteLoading(true);
    setViewerRevision((x) => x + 1);
    setReportTransitionSeq((x) => x + 1);
    setType(next);
    setRefreshSeq((x) => x + 1);
  }, [type, filtersDirty, filters, appliedFilters]);

  const optionList = React.useMemo(() => {
    const norm = partySearch.toLowerCase();
    let base: string[] = [];
    if (multiPicker === "clients") base = db.customers.map((c) => c.name);
    else if (multiPicker === "suppliers") base = db.suppliers.map((s) => s.name);
    else if (multiPicker === "products") base = db.products.map((p) => p.name);
    else if (multiPicker === "stores") base = db.stores;
    else if (multiPicker === "salesmen") base = allSalesmen(db);
    else if (multiPicker === "categories") {
      const set: string[] = [];
      db.products.forEach((p) => {
        if (p.category && !set.some((x) => x.toLowerCase() === p.category!.toLowerCase())) set.push(p.category);
      });
      base = set;
    }
    return base.filter((n) => !norm || n.toLowerCase().includes(norm));
  }, [multiPicker, partySearch, db]);

  const clearAll = () => {
    setFilters(EMPTY_FILTERS);
    setAppliedFilters(EMPTY_FILTERS);
    setRowSearch("");
    setRefreshSeq((x) => x + 1);
  };

  return (
    <ScreenContainer>
      <Header title="Raporte" />
      <ScrollView contentContainerStyle={{ paddingBottom: 24 }}>
        {/* Report picker */}
        <View style={{ paddingHorizontal: 12, paddingTop: 12 }}>
          <Pressable
            onPress={() => setPickerOpen(true)}
            style={{ backgroundColor: colors.surface, borderRadius: 10, padding: 12, borderWidth: 1, borderColor: colors.border }}
          >
            <Text style={{ color: colors.muted, fontSize: 11 }}>Lloji i raportit • {reportEntry.group}</Text>
            <Text style={{ fontSize: 16, fontWeight: "800", color: colors.foreground, marginTop: 4 }}>{reportEntry.label}</Text>
          </Pressable>
        </View>

        {/* v14 Date Bar — gjithmonë e dukshme si në video. Ndryshimi i datës
            rifreskon raportin automatikisht pa pritur “Apliko filtrat”. */}
        <View style={{ paddingHorizontal: 12, marginTop: 10 }}>
          <Text style={{ color: colors.muted, fontSize: 11, fontWeight: "800", textTransform: "uppercase", marginBottom: 6 }}>Periudha</Text>
          <View style={{ flexDirection: "row", gap: 8 }}>
            <DateBox label="Nga" value={filters.from} onPress={() => openDatePicker("from")} />
            <DateBox label="Deri" value={filters.to} onPress={() => openDatePicker("to")} />
          </View>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 6, paddingTop: 8 }}>
            <DatePreset label="Sot" onPress={() => applyDatePreset("today")} />
            <DatePreset label="Dje" onPress={() => applyDatePreset("yesterday")} />
            <DatePreset label="7 ditë" onPress={() => applyDatePreset("week")} />
            <DatePreset label="Muaji" onPress={() => applyDatePreset("month")} />
            <DatePreset label="Viti" onPress={() => applyDatePreset("year")} />
          </ScrollView>
        </View>

        {/* v14.1 Vyapar-style filter chips: të dukshme, të qarta, auto-refresh. */}
        <View style={{ paddingHorizontal: 12, marginTop: 10 }}>
          <Text style={{ color: colors.muted, fontSize: 11, fontWeight: "900", textTransform: "uppercase", marginBottom: 6 }}>Filtra</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8, paddingRight: 12 }}>
            <QuickFilterChip label="Artikuj" value={(filters.products || []).length ? `${filters.products!.length} zgjedhur` : "Të gjithë"} active={!!filters.products?.length} onPress={() => { setMultiPicker("products"); setPartySearch(""); }} />
            <QuickFilterChip label="Klientë" value={(filters.clients || []).length ? `${filters.clients!.length} zgjedhur` : "Të gjithë"} active={!!filters.clients?.length} onPress={() => { setMultiPicker("clients"); setPartySearch(""); }} />
            <QuickFilterChip label="Furnitorë" value={(filters.suppliers || []).length ? `${filters.suppliers!.length} zgjedhur` : "Të gjithë"} active={!!filters.suppliers?.length} onPress={() => { setMultiPicker("suppliers"); setPartySearch(""); }} />
            <QuickFilterChip label="Magazina" value={(filters.stores || []).length ? `${filters.stores!.length} zgjedhur` : "Të gjitha"} active={!!filters.stores?.length} onPress={() => { setMultiPicker("stores"); setPartySearch(""); }} />
            <QuickFilterChip label="Njësi shitje" value={(filters.units || []).length ? filters.units!.join(", ") : "Të gjitha"} active={!!filters.units?.length} onPress={() => setFiltersExpanded((v) => !v)} />
            <QuickFilterChip label="Njësi raporti" value={filters.reportUnit || "Auto"} active={!!filters.reportUnit} onPress={() => setFiltersExpanded((v) => !v)} />
            <QuickFilterChip label="Çmim" value={filters.price || "Të gjithë"} active={!!filters.price} onPress={() => setFiltersExpanded((v) => !v)} />
            <QuickFilterChip label="Më shumë" value={filtersExpanded ? "Mbyll" : "Hap"} active={filtersExpanded} onPress={() => setFiltersExpanded((v) => !v)} />
          </ScrollView>
          {filtersDirty ? (
            <View style={{ flexDirection: "row", alignItems: "center", gap: 6, marginTop: 6 }}>
              <ActivityIndicator size="small" color={colors.primary} />
              <Text style={{ color: colors.muted, fontSize: 11 }}>Po aplikohen filtrat automatikisht…</Text>
            </View>
          ) : null}
        </View>

        {filtersExpanded ? (
          <>

        {/* Datat janë zhvendosur jashtë panelit të filtrave që të jenë gjithmonë të dukshme. */}

        {/* Price filter — critical for items sold at multiple prices (e.g. 300/240/250).
            Accepts one price or comma-separated exact prices: 300 or 300,240. */}
        <View style={{ flexDirection: "row", gap: 8, paddingHorizontal: 12, marginTop: 8 }}>
          <FilterField label="Çmimi shitjes" value={filters.price || ""} onChange={(v) => setFilter({ price: v })} placeholder="p.sh. 300 ose 300,240" />
        </View>

        {/* Multi-select pickers */}
        <View style={{ flexDirection: "row", gap: 8, paddingHorizontal: 12, marginTop: 8, flexWrap: "wrap" }}>
          <MultiField label="Klientët" values={filters.clients} onOpen={() => { setMultiPicker("clients"); setPartySearch(""); }} onClear={() => setFilter({ clients: [] })} />
          <MultiField label="Furnitorët" values={filters.suppliers} onOpen={() => { setMultiPicker("suppliers"); setPartySearch(""); }} onClear={() => setFilter({ suppliers: [] })} />
          <MultiField label="Artikujt" values={filters.products} onOpen={() => { setMultiPicker("products"); setPartySearch(""); }} onClear={() => setFilter({ products: [] })} />
          <MultiField label="Magazinat" values={filters.stores} onOpen={() => { setMultiPicker("stores"); setPartySearch(""); }} onClear={() => setFilter({ stores: [] })} />
          <MultiField label="Shitësit" values={filters.salesmen} onOpen={() => { setMultiPicker("salesmen"); setPartySearch(""); }} onClear={() => setFilter({ salesmen: [] })} />
          <MultiField label="Kategoritë" values={filters.categories} onOpen={() => { setMultiPicker("categories"); setPartySearch(""); }} onClear={() => setFilter({ categories: [] })} />
        </View>

        {/* Reporting unit chips: controls how quantities are displayed (Copë/Koli/Paletë). */}
        {allUnits.length > 0 ? (
          <View style={{ paddingHorizontal: 12, marginTop: 10 }}>
            <Text style={{ color: colors.muted, fontSize: 11, fontWeight: "800", textTransform: "uppercase", marginBottom: 6 }}>Njësia e raportit</Text>
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6 }}>
              {["Auto", ...allUnits].map((u) => {
                const val = u === "Auto" ? "" : u;
                const active = (filters.reportUnit || "") === val;
                return (
                  <Pressable
                    key={`report-${u}`}
                    onPress={() => setFilter({ reportUnit: val })}
                    style={({ pressed }) => ({
                      paddingHorizontal: 12, paddingVertical: 7, borderRadius: 16,
                      backgroundColor: active ? colors.primary : colors.surface,
                      borderWidth: 1, borderColor: active ? colors.primary : colors.border,
                      opacity: pressed ? 0.8 : 1,
                    })}
                  >
                    <Text style={{ color: active ? "#fff" : colors.foreground, fontWeight: "800", fontSize: 12 }}>{u}</Text>
                  </Pressable>
                );
              })}
            </View>
          </View>
        ) : null}

        {/* Exact sale-line unit chips: filters rows by the unit used in the invoice. */}
        {allUnits.length > 0 ? (
          <View style={{ paddingHorizontal: 12, marginTop: 10 }}>
            <Text style={{ color: colors.muted, fontSize: 11, fontWeight: "800", textTransform: "uppercase", marginBottom: 6 }}>Filtro njësinë e shitjes</Text>
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6 }}>
              {allUnits.map((u) => {
                const active = (filters.units || []).some((x) => x.toLowerCase() === u.toLowerCase());
                return (
                  <Pressable
                    key={u}
                    onPress={() => toggleUnit(u)}
                    style={({ pressed }) => ({
                      paddingHorizontal: 12, paddingVertical: 7, borderRadius: 16,
                      backgroundColor: active ? colors.primary : colors.surface,
                      borderWidth: 1, borderColor: active ? colors.primary : colors.border,
                      opacity: pressed ? 0.8 : 1,
                    })}
                  >
                    <Text style={{ color: active ? "#fff" : colors.foreground, fontWeight: "700", fontSize: 12 }}>{u}</Text>
                  </Pressable>
                );
              })}
            </View>
          </View>
        ) : null}

        {/* Transaction type + payment status chips */}
        <View style={{ paddingHorizontal: 12, marginTop: 10 }}>
          <Text style={{ color: colors.muted, fontSize: 11, fontWeight: "800", textTransform: "uppercase", marginBottom: 6 }}>Lloji i transaksionit</Text>
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6 }}>
            {([["all", "Të gjitha"], ["cash", "Kesh"], ["credit", "Kredi"]] as const).map(([val, lbl]) => {
              const active = (filters.txnType || "all") === val;
              return (
                <Pressable key={val} onPress={() => setFilter({ txnType: val })}
                  style={({ pressed }) => ({ paddingHorizontal: 12, paddingVertical: 7, borderRadius: 16, backgroundColor: active ? colors.primary : colors.surface, borderWidth: 1, borderColor: active ? colors.primary : colors.border, opacity: pressed ? 0.8 : 1 })}>
                  <Text style={{ color: active ? "#fff" : colors.foreground, fontWeight: "700", fontSize: 12 }}>{lbl}</Text>
                </Pressable>
              );
            })}
          </View>
          <Text style={{ color: colors.muted, fontSize: 11, fontWeight: "800", textTransform: "uppercase", marginTop: 10, marginBottom: 6 }}>Statusi i pagesës</Text>
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6 }}>
            {([["all", "Të gjitha"], ["paid", "Paguar"], ["partial", "Pjesërisht"], ["unpaid", "Pa paguar"]] as const).map(([val, lbl]) => {
              const active = (filters.payStatus || "all") === val;
              return (
                <Pressable key={val} onPress={() => setFilter({ payStatus: val })}
                  style={({ pressed }) => ({ paddingHorizontal: 12, paddingVertical: 7, borderRadius: 16, backgroundColor: active ? colors.primary : colors.surface, borderWidth: 1, borderColor: active ? colors.primary : colors.border, opacity: pressed ? 0.8 : 1 })}>
                  <Text style={{ color: active ? "#fff" : colors.foreground, fontWeight: "700", fontSize: 12 }}>{lbl}</Text>
                </Pressable>
              );
            })}
          </View>
        </View>

          </>
        ) : null}

        {/* Filtrat aktivë — pa komandë të detyrueshme “Apliko”. */}
        <View style={{ paddingHorizontal: 12, marginTop: 10 }}>
          <View style={{ backgroundColor: colors.surface, borderRadius: 8, borderWidth: 1, borderColor: colors.border, padding: 8 }}>
            <Text style={{ color: colors.muted, fontSize: 11, fontWeight: "800" }}>Filtrat aktivë</Text>
            <Text style={{ color: colors.muted, fontSize: 11, marginTop: 3 }} numberOfLines={4}>
              {(filtersDirty ? draftFiltersText : filtersText) || "Pa filtra"}
            </Text>
          </View>
        </View>

        {/* Actions */}
        <View style={{ flexDirection: "row", gap: 8, paddingHorizontal: 12, marginTop: 12, flexWrap: "wrap" }}>
          <Btn title="Rifresko" icon="arrow.clockwise" variant="soft" onPress={refreshSqliteReport} />
          <Btn title="Excel" icon="square.and.arrow.up" onPress={onExcel} />
          <Btn title="Printo" icon="printer.fill" variant="soft" onPress={onPrint} />
          <Btn title="PDF" icon="square.and.arrow.up" variant="soft" onPress={() => setPdfOpen(true)} />
          <Btn title={isFavorite ? "★ Hiq" : "☆ Prefero"} icon="tag.fill" variant="ghost" onPress={() => toggleFavorite(type)} />
          <Btn title="Pastro" icon="xmark" variant="ghost" onPress={clearAll} />
        </View>

        {/* Favorites strip */}
        {favorites.length > 0 ? (
          <View style={{ paddingHorizontal: 12, marginTop: 12 }}>
            <Text style={{ color: colors.muted, fontSize: 11, fontWeight: "800", textTransform: "uppercase", marginBottom: 6 }}>Të preferuarat</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 6 }}>
              {favorites.map((f) => {
                const entry = REPORT_CATALOG.find((r) => r.value === f);
                if (!entry) return null;
                const active = entry.value === type;
                return (
                  <Pressable
                    key={f}
                    onPress={() => selectReport(entry.value)}
                    style={({ pressed }) => ({
                      paddingHorizontal: 12, paddingVertical: 8, borderRadius: 16,
                      backgroundColor: active ? colors.primary : colors.surface,
                      borderWidth: 1, borderColor: active ? colors.primary : colors.border, opacity: pressed ? 0.8 : 1,
                    })}
                  >
                    <Text style={{ color: active ? "#fff" : colors.foreground, fontWeight: "700", fontSize: 12 }}>{entry.label}</Text>
                  </Pressable>
                );
              })}
            </ScrollView>
          </View>
        ) : null}

        {/* Title */}
        <View key={`title-${tableResetKey}`} style={{ paddingHorizontal: 12, marginTop: 14 }}>
          <Text style={{ fontSize: 18, fontWeight: "900", color: colors.foreground }}>{result.title}</Text>
          {result.subtitle ? <Text style={{ color: colors.muted, fontSize: 12, marginTop: 2 }}>{result.subtitle}</Text> : null}
          {sqliteLoading ? (
            <View style={{ flexDirection: "row", alignItems: "center", gap: 6, marginTop: 6 }}>
              <ActivityIndicator size="small" color={colors.primary} />
              <Text style={{ color: colors.muted, fontSize: 11 }}>Po rifreskohet SQLite në sfond… tabela nuk bllokohet.</Text>
            </View>
          ) : null}
        </View>

        {/* Summary */}
        {result.summary && result.summary.length > 0 ? (
          <View key={`summary-${tableResetKey}`} style={{ flexDirection: "row", flexWrap: "wrap", gap: 8, paddingHorizontal: 12, marginTop: 8 }}>
            {result.summary.map((s, i) => (
              <View key={i} style={{ backgroundColor: colors.surface, borderRadius: 8, borderWidth: 1, borderColor: colors.border, paddingHorizontal: 10, paddingVertical: 6, minWidth: 110 }}>
                <Text style={{ color: colors.muted, fontSize: 11 }}>{s.label}</Text>
                <Text style={{ color: colors.foreground, fontWeight: "800", fontSize: 14 }}>{s.value}</Text>
              </View>
            ))}
          </View>
        ) : null}

        {/* Fast live search across result rows */}
        {result.rows.length > 0 ? (
          <View style={{ paddingHorizontal: 12, marginTop: 12 }}>
            <View style={{ backgroundColor: colors.surface, borderRadius: 10, paddingHorizontal: 12, borderWidth: 1, borderColor: rowSearch ? colors.primary : colors.border, flexDirection: "row", alignItems: "center", gap: 8 }}>
              <Text style={{ color: colors.muted, fontSize: 15 }}>🔍</Text>
              <TextInput
                value={rowSearch}
                onChangeText={setRowSearch}
                placeholder="Kërko në rezultate…"
                placeholderTextColor={colors.muted}
                style={{ flex: 1, paddingVertical: 10, color: colors.foreground }}
              />
              {rowSearch ? (
                <Pressable onPress={() => setRowSearch("")} hitSlop={10}>
                  <Text style={{ color: colors.error, fontWeight: "900", fontSize: 16 }}>×</Text>
                </Pressable>
              ) : null}
            </View>
            <Text style={{ color: colors.muted, fontSize: 11, marginTop: 4 }}>
              {visibleRows.length} {visibleRows.length === 1 ? "rezultat" : "rezultate"}
              {rowSearch ? ` nga ${result.rows.length}` : ""}
            </Text>
          </View>
        ) : null}

        {/* Table */}
        <View key={`table-${tableResetKey}`} style={{ paddingHorizontal: 12, marginTop: 12 }}>
          {reportIsResolving && result.rows.length === 0 ? (
            <View style={{ alignItems: "center", padding: 40, gap: 8 }}>
              <ActivityIndicator size="small" color={colors.primary} />
              <Text style={{ color: colors.muted, textAlign: "center" }}>Po ngarkohet raporti…</Text>
              <Text style={{ color: colors.muted, textAlign: "center", fontSize: 11 }}>Raporti po rifreskohet automatikisht.</Text>
            </View>
          ) : result.rows.length === 0 ? (
            <View style={{ alignItems: "center", padding: 40 }}>
              <Text style={{ color: colors.muted }}>{result.emptyMessage || "Pa të dhëna në periudhën e zgjedhur"}</Text>
            </View>
          ) : visibleRows.length === 0 ? (
            <View style={{ alignItems: "center", padding: 40 }}>
              <Text style={{ color: colors.muted }}>Asnjë rresht nuk përputhet me “{rowSearch}”</Text>
            </View>
          ) : (
            <ScrollView horizontal key={tableResetKey}>
              <View>
                <View style={{ flexDirection: "row", borderBottomWidth: 2, borderColor: colors.primary, paddingBottom: 6 }}>
                  {result.columns.map((c, i) => (
                    <Text key={i} style={{ minWidth: colWidth(c), textAlign: c.align || "left", fontWeight: "800", color: colors.primary, fontSize: 12, paddingHorizontal: 6 }}>
                      {c.label}
                    </Text>
                  ))}
                </View>
                {visibleRows.map((r, idx) => {
                  const isTotal = !!(r as any)._total;
                  return (
                    <View key={idx} style={{ flexDirection: "row", paddingVertical: 6, borderBottomWidth: 1, borderColor: colors.border, backgroundColor: isTotal ? "#16a34a" : idx % 2 === 0 ? colors.surface : "transparent" }}>
                      {result.columns.map((c, i) => (
                        <Text key={i} style={{ minWidth: colWidth(c), textAlign: c.align || "left", color: isTotal ? "#fff" : colors.foreground, fontWeight: isTotal ? "800" : "400", fontSize: 12, paddingHorizontal: 6 }}>
                          {formatValue((r as any)[c.key], c.format)}
                        </Text>
                      ))}
                    </View>
                  );
                })}
              </View>
            </ScrollView>
          )}
        </View>
      </ScrollView>

      {/* Report-type picker overlay */}
      {pickerOpen ? (
        <View style={overlayStyle}>
          <View style={{ backgroundColor: colors.background, borderRadius: 12, padding: 12, maxHeight: "85%" }}>
            <Text style={{ fontWeight: "900", fontSize: 16, color: colors.foreground, marginBottom: 8 }}>Zgjidh raportin</Text>
            <TextInput
              value={searchPicker}
              onChangeText={setSearchPicker}
              placeholder="Kërko raport…"
              placeholderTextColor={colors.muted}
              style={{ borderWidth: 1, borderColor: colors.border, borderRadius: 8, padding: 10, marginBottom: 8, color: colors.foreground, backgroundColor: colors.surface }}
            />
            <ScrollView>
              {groupedCatalog.map((g) => (
                <View key={g.group} style={{ marginBottom: 8 }}>
                  <Text style={{ fontSize: 11, fontWeight: "900", color: colors.muted, textTransform: "uppercase", marginVertical: 6 }}>{g.group}</Text>
                  {g.items.map((it) => {
                    const active = it.value === type;
                    return (
                      <Pressable
                        key={it.value}
                        onPress={() => selectReport(it.value)}
                        style={{ padding: 12, borderRadius: 8, backgroundColor: active ? colors.primary + "22" : colors.surface, borderWidth: 1, borderColor: active ? colors.primary : colors.border, marginBottom: 6, flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}
                      >
                        <Text style={{ color: colors.foreground, fontWeight: "700", flex: 1 }}>{it.label}</Text>
                        {active ? <Badge tone="paid">Aktiv</Badge> : null}
                      </Pressable>
                    );
                  })}
                </View>
              ))}
            </ScrollView>
            <Pressable onPress={() => setPickerOpen(false)} style={{ marginTop: 4, padding: 12, alignSelf: "flex-end" }}>
              <Text style={{ color: colors.primary, fontWeight: "800" }}>Mbyll</Text>
            </Pressable>
          </View>
        </View>
      ) : null}

      {/* Calendar date picker — no native dependency, works offline and applies immediately. */}
      {datePickerOpen ? (
        <DateRangeModal
          cursor={dateCursor}
          setCursor={setDateCursor}
          from={filters.from || ""}
          to={filters.to || ""}
          activeField={activeDateField}
          setActiveField={setActiveDateField}
          onPick={(picked) => {
            if (activeDateField === "from") {
              applyDatePatch({ from: picked, to: filters.to || picked });
              setActiveDateField("to");
            } else {
              applyDatePatch({ from: filters.from || picked, to: picked });
            }
          }}
          onClose={() => setDatePickerOpen(false)}
        />
      ) : null}

      {/* PDF customize sheet */}
      {pdfOpen ? (
        <View style={overlayStyle}>
          <View style={{ backgroundColor: colors.background, borderRadius: 12, padding: 16, gap: 10 }}>
            <Text style={{ fontWeight: "900", fontSize: 16, color: colors.foreground }}>Personalizo PDF-në</Text>
            <Text style={{ fontSize: 12, color: colors.muted, marginBottom: 6 }}>Zgjidh çfarë të shfaqet në raportin e printuar.</Text>
            {([
              ["showCompany", "Trego të dhënat e biznesit"],
              ["showFilters", "Trego filtrat e zbatuar"],
              ["showSummary", "Trego përmbledhjen lart"],
              ["zebra", "Rreshta me ngjyrë alternative"],
            ] as const).map(([key, label]) => (
              <View key={key} style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingVertical: 6 }}>
                <Text style={{ color: colors.foreground, fontSize: 14 }}>{label}</Text>
                <Switch value={(pdfOpts as any)[key]} onValueChange={(v) => setPdfOpts((o) => ({ ...o, [key]: v }))} trackColor={{ true: colors.primary, false: colors.border }} />
              </View>
            ))}
            <View style={{ flexDirection: "row", gap: 8, marginTop: 6 }}>
              <View style={{ flex: 1 }}><Btn title="Anulo" variant="ghost" onPress={() => setPdfOpen(false)} /></View>
              <View style={{ flex: 1 }}><Btn title="Gjenero PDF" onPress={async () => { setPdfOpen(false); await onShare(); }} /></View>
            </View>
          </View>
        </View>
      ) : null}

      {/* Multi-select overlay */}
      {multiPicker ? (
        <View style={overlayStyle}>
          <View style={{ backgroundColor: colors.background, borderRadius: 12, padding: 12, maxHeight: "85%" }}>
            <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
              <Text style={{ fontWeight: "900", fontSize: 16, color: colors.foreground }}>
                Zgjidh {multiPicker === "clients" ? "klientët" : multiPicker === "suppliers" ? "furnitorët" : multiPicker === "products" ? "artikujt" : multiPicker === "stores" ? "magazinat" : multiPicker === "salesmen" ? "shitësit" : "kategoritë"}
              </Text>
              <View style={{ backgroundColor: colors.primary, borderRadius: 12, paddingHorizontal: 10, paddingVertical: 3 }}>
                <Text style={{ color: "#fff", fontWeight: "900", fontSize: 12 }}>
                  {((filters[multiPicker] as string[] | undefined) || []).length} të zgjedhur
                </Text>
              </View>
            </View>
            <Text style={{ color: colors.muted, fontSize: 11, marginBottom: 8 }}>Zgjidh vlerat. Raporti rifreskohet automatikisht pas zgjedhjes ose pas mbylljes së popup-it.</Text>
            <TextInput
              value={partySearch}
              onChangeText={setPartySearch}
              placeholder="Kërko…"
              placeholderTextColor={colors.muted}
              style={{ borderWidth: 1, borderColor: colors.border, borderRadius: 8, padding: 10, marginBottom: 8, color: colors.foreground, backgroundColor: colors.surface }}
            />
            <FlatList
              data={optionList}
              keyExtractor={(n) => n}
              renderItem={({ item }) => {
                const selected = ((filters[multiPicker] as string[] | undefined) || []).some((x) => x.toLowerCase() === item.toLowerCase());
                return (
                  <Pressable
                    onPress={() => toggleMulti(multiPicker, item)}
                    style={{ paddingVertical: 12, paddingHorizontal: 10, borderBottomWidth: 1, borderColor: colors.border, flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}
                  >
                    <Text style={{ color: colors.foreground, fontWeight: "700", flex: 1 }}>{item}</Text>
                    <View style={{ width: 22, height: 22, borderRadius: 6, borderWidth: 2, borderColor: selected ? colors.primary : colors.border, backgroundColor: selected ? colors.primary : "transparent", alignItems: "center", justifyContent: "center" }}>
                      {selected ? <Text style={{ color: "#fff", fontWeight: "900", fontSize: 13 }}>✓</Text> : null}
                    </View>
                  </Pressable>
                );
              }}
              ListEmptyComponent={<Text style={{ textAlign: "center", color: colors.muted, padding: 20 }}>Pa rezultate</Text>}
            />
            <View style={{ flexDirection: "row", gap: 8, marginTop: 8 }}>
              <View style={{ flex: 1 }}>
                <Btn title="Pastro" variant="ghost" onPress={() => setFilter({ [multiPicker]: [] } as Partial<ReportFilter>)} />
              </View>
              <View style={{ flex: 1 }}>
                <Btn title="Mbyll" onPress={() => { setMultiPicker(null); setPartySearch(""); }} />
              </View>
            </View>
          </View>
        </View>
      ) : null}
    </ScreenContainer>
  );
}

function colWidth(colOrFormat?: any) {
  const key = typeof colOrFormat === "object" ? String(colOrFormat.key || "") : "";
  const label = typeof colOrFormat === "object" ? String(colOrFormat.label || "") : "";
  const format = typeof colOrFormat === "object" ? colOrFormat.format : colOrFormat;
  if (["product", "name"].includes(key) || /artikull|emërtim/i.test(label)) return 190;
  if (["docs", "note", "destination"].includes(key) || /dokumente|shënim|destinacion/i.test(label)) return 220;
  if (["store", "warehouse"].includes(key) || /magazin/i.test(label)) return 150;
  if (["date"].includes(key) || /data/i.test(label)) return 95;
  if (format === "money" || format === "qty" || format === "pct") return 115;
  return 135;
}

function formatValue(val: any, format?: "money" | "qty" | "pct" | "text") {
  if (val == null || val === "") return "";
  if (format === "money") return Number(val || 0).toLocaleString("sq-AL", { maximumFractionDigits: 2 });
  if (format === "qty") return Number(val || 0).toLocaleString("sq-AL", { maximumFractionDigits: 3 });
  if (format === "pct") return `${Number(val || 0).toFixed(1)}%`;
  return String(val);
}


function QuickFilterChip({ label, value, active, onPress }: { label: string; value: string; active?: boolean; onPress: () => void }) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => ({
        minWidth: 104,
        borderRadius: 18,
        paddingHorizontal: 12,
        paddingVertical: 8,
        backgroundColor: active ? colors.primary : colors.surface,
        borderWidth: 1,
        borderColor: active ? colors.primary : colors.border,
        opacity: pressed ? 0.82 : 1,
      })}
    >
      <Text style={{ color: active ? "rgba(255,255,255,0.85)" : colors.muted, fontSize: 10, fontWeight: "800" }} numberOfLines={1}>{label}</Text>
      <Text style={{ color: active ? "#fff" : colors.foreground, fontSize: 12, fontWeight: "900", marginTop: 2 }} numberOfLines={1}>{value}</Text>
    </Pressable>
  );
}

function DateBox({ label, value, onPress }: { label: string; value?: string; onPress: () => void }) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => ({
        flex: 1,
        backgroundColor: colors.surface,
        borderRadius: 10,
        paddingHorizontal: 10,
        paddingVertical: 9,
        borderWidth: 1,
        borderColor: value ? colors.primary : colors.border,
        opacity: pressed ? 0.82 : 1,
      })}
    >
      <Text style={{ color: colors.muted, fontSize: 11 }}>{label}</Text>
      <Text style={{ color: colors.foreground, fontSize: 14, fontWeight: "900", marginTop: 2 }}>📅 {prettyDate(value)}</Text>
    </Pressable>
  );
}

function DatePreset({ label, onPress }: { label: string; onPress: () => void }) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => ({
        paddingHorizontal: 12,
        paddingVertical: 7,
        borderRadius: 16,
        backgroundColor: colors.surface,
        borderWidth: 1,
        borderColor: colors.border,
        opacity: pressed ? 0.8 : 1,
      })}
    >
      <Text style={{ color: colors.foreground, fontWeight: "800", fontSize: 12 }}>{label}</Text>
    </Pressable>
  );
}

function DateRangeModal({
  cursor,
  setCursor,
  from,
  to,
  activeField,
  setActiveField,
  onPick,
  onClose,
}: {
  cursor: Date;
  setCursor: (d: Date) => void;
  from: string;
  to: string;
  activeField: "from" | "to";
  setActiveField: (f: "from" | "to") => void;
  onPick: (iso: string) => void;
  onClose: () => void;
}) {
  const colors = useColors();
  const days = calendarDays(cursor);
  const today = isoDate(new Date());
  const fromD = from || "";
  const toD = to || "";
  return (
    <View style={overlayStyle}>
      <View style={{ backgroundColor: colors.background, borderRadius: 14, padding: 12, maxHeight: "88%" }}>
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
          <Text style={{ color: colors.foreground, fontSize: 17, fontWeight: "900" }}>Zgjidh periudhën</Text>
          <Pressable onPress={onClose} hitSlop={10}><Text style={{ color: colors.error, fontSize: 24, fontWeight: "900" }}>×</Text></Pressable>
        </View>
        <Text style={{ color: colors.muted, fontSize: 11, marginBottom: 8 }}>Datat aplikohen menjëherë dhe raporti rifreskohet automatikisht.</Text>
        <View style={{ flexDirection: "row", gap: 8, marginBottom: 10 }}>
          <Pressable onPress={() => setActiveField("from")} style={{ flex: 1, borderRadius: 10, borderWidth: 1, borderColor: activeField === "from" ? colors.primary : colors.border, backgroundColor: activeField === "from" ? colors.primary + "22" : colors.surface, padding: 10 }}>
            <Text style={{ color: colors.muted, fontSize: 11 }}>Nga</Text>
            <Text style={{ color: colors.foreground, fontWeight: "900" }}>{prettyDate(fromD)}</Text>
          </Pressable>
          <Pressable onPress={() => setActiveField("to")} style={{ flex: 1, borderRadius: 10, borderWidth: 1, borderColor: activeField === "to" ? colors.primary : colors.border, backgroundColor: activeField === "to" ? colors.primary + "22" : colors.surface, padding: 10 }}>
            <Text style={{ color: colors.muted, fontSize: 11 }}>Deri</Text>
            <Text style={{ color: colors.foreground, fontWeight: "900" }}>{prettyDate(toD)}</Text>
          </Pressable>
        </View>
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
          <Pressable onPress={() => setCursor(addMonths(cursor, -1))} style={{ padding: 10 }}><Text style={{ color: colors.primary, fontSize: 18, fontWeight: "900" }}>‹</Text></Pressable>
          <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: "900", textTransform: "capitalize" }}>{monthTitle(cursor)}</Text>
          <Pressable onPress={() => setCursor(addMonths(cursor, 1))} style={{ padding: 10 }}><Text style={{ color: colors.primary, fontSize: 18, fontWeight: "900" }}>›</Text></Pressable>
        </View>
        <View style={{ flexDirection: "row", marginBottom: 4 }}>
          {["H", "M", "M", "E", "P", "S", "D"].map((d, i) => (
            <Text key={`${d}-${i}`} style={{ flex: 1, textAlign: "center", color: colors.muted, fontSize: 11, fontWeight: "900" }}>{d}</Text>
          ))}
        </View>
        <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
          {days.map((d) => {
            const iso = isoDate(d);
            const inMonth = d.getMonth() === cursor.getMonth();
            const selected = iso === fromD || iso === toD;
            const inRange = !!fromD && !!toD && iso >= fromD && iso <= toD;
            const isToday = iso === today;
            return (
              <Pressable
                key={iso}
                onPress={() => onPick(iso)}
                style={({ pressed }) => ({
                  width: "14.285%",
                  paddingVertical: 8,
                  alignItems: "center",
                  opacity: pressed ? 0.7 : inMonth ? 1 : 0.35,
                })}
              >
                <View style={{
                  width: 34,
                  height: 34,
                  borderRadius: 17,
                  alignItems: "center",
                  justifyContent: "center",
                  backgroundColor: selected ? colors.primary : inRange ? colors.primary + "22" : "transparent",
                  borderWidth: isToday && !selected ? 1 : 0,
                  borderColor: colors.primary,
                }}>
                  <Text style={{ color: selected ? "#fff" : colors.foreground, fontWeight: selected ? "900" : "700", fontSize: 12 }}>{d.getDate()}</Text>
                </View>
              </Pressable>
            );
          })}
        </View>
        <View style={{ flexDirection: "row", gap: 8, marginTop: 10 }}>
          <View style={{ flex: 1 }}><Btn title="Sot" variant="soft" onPress={() => { const t = isoDate(new Date()); onPick(t); }} /></View>
          <View style={{ flex: 1 }}><Btn title="Mbyll" onPress={onClose} /></View>
        </View>
      </View>
    </View>
  );
}

function FilterField({ label, value, onChange, placeholder }: { label: string; value: string; onChange: (v: string) => void; placeholder?: string }) {
  const colors = useColors();
  return (
    <View style={{ flex: 1, backgroundColor: colors.surface, borderRadius: 10, paddingHorizontal: 10, borderWidth: 1, borderColor: colors.border }}>
      <Text style={{ color: colors.muted, fontSize: 11, marginTop: 6 }}>{label}</Text>
      <TextInput value={value} onChangeText={onChange} placeholder={placeholder} placeholderTextColor={colors.muted} style={{ paddingVertical: 8, color: colors.foreground }} />
    </View>
  );
}

function MultiField({ label, values, onOpen, onClear }: { label: string; values?: string[]; onOpen: () => void; onClear: () => void }) {
  const colors = useColors();
  const count = values?.length || 0;
  return (
    <View style={{ flexBasis: "48%", flexGrow: 1 }}>
      <Pressable onPress={onOpen} style={{ backgroundColor: colors.surface, borderRadius: 10, paddingHorizontal: 10, paddingVertical: 8, borderWidth: 1, borderColor: count ? colors.primary : colors.border }}>
        <Text style={{ color: colors.muted, fontSize: 11 }}>{label}</Text>
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
          <Text style={{ color: count ? colors.foreground : colors.muted, fontWeight: "700", fontSize: 14 }} numberOfLines={1}>
            {count === 0 ? "Të gjithë" : count === 1 ? values![0] : `${count} të zgjedhur`}
          </Text>
          {count ? (
            <Pressable onPress={onClear} hitSlop={10} style={{ paddingHorizontal: 4 }}>
              <Text style={{ color: colors.error, fontWeight: "900" }}>×</Text>
            </Pressable>
          ) : null}
        </View>
      </Pressable>
    </View>
  );
}

const overlayStyle = {
  position: "absolute" as const,
  top: 0, left: 0, right: 0, bottom: 0,
  backgroundColor: "rgba(0,0,0,0.45)",
  justifyContent: "center" as const,
  padding: 14,
};
