import React from "react";
import { ActivityIndicator, Alert, FlatList, Platform, Pressable, ScrollView, Switch, Text, TextInput, View } from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { Badge, Btn, Header } from "@/components/ui-kit";
import { useStore, allSalesmen, saveMultiDB } from "@/lib/store";
import {
  REPORT_CATALOG,
  ReportFilter,
  ReportType,
  type ReportResult,
  renderReportHtml,
} from "@/lib/reports";
import { exportReportToExcel } from "@/lib/excel";
import { buildSqliteReport } from "@/lib/sqlite-reports";
import * as Print from "expo-print";
import * as Sharing from "expo-sharing";
import { useSafeAreaInsets } from "react-native-safe-area-context";

type ParamShape = { type?: string; client?: string; supplier?: string; product?: string };

const GROUP_ORDER = ["Shitje", "Blerje", "Stoku", "Manaxher", "Detyrime", "Shpenzime", "Shitës / GPS"];
type MultiKind = "clients" | "suppliers" | "products" | "stores" | "salesmen" | "categories";
type ReportFilterTab = "salesman" | "txn" | "party" | "status" | "products" | "unit" | "price" | "store";


const EMPTY_FILTERS: ReportFilter = {
  clients: [],
  suppliers: [],
  products: [],
  stores: [],
  units: [],
  salesmen: [],
  categories: [],
  from: "",
  to: "",
  price: "",
  reportUnit: "",
  txnType: "all",
  payStatus: "all",
};

function normalizeFilter(f: ReportFilter): ReportFilter {
  return {
    ...EMPTY_FILTERS,
    ...f,
    clients: [...(f.clients || [])],
    suppliers: [...(f.suppliers || [])],
    products: [...(f.products || [])],
    stores: [...(f.stores || [])],
    units: [...(f.units || [])],
    salesmen: [...(f.salesmen || [])],
    categories: [...(f.categories || [])],
    from: f.from || "",
    to: f.to || "",
    price: f.price || "",
    reportUnit: f.reportUnit || "",
    txnType: f.txnType || "all",
    payStatus: f.payStatus || "all",
  };
}

function filterSignature(f: ReportFilter): string {
  const n = normalizeFilter(f);
  return JSON.stringify({
    ...n,
    clients: [...(n.clients || [])].sort(),
    suppliers: [...(n.suppliers || [])].sort(),
    products: [...(n.products || [])].sort(),
    stores: [...(n.stores || [])].sort(),
    units: [...(n.units || [])].sort(),
    salesmen: [...(n.salesmen || [])].sort(),
    categories: [...(n.categories || [])].sort(),
  });
}

function reportGroupOf(t: ReportType): string {
  return REPORT_CATALOG.find((r) => r.value === t)?.group || "";
}

function safeFiltersForReportSwitch(currentType: ReportType, nextType: ReportType, currentFilters: ReportFilter): ReportFilter {
  const f = normalizeFilter(currentFilters);

  // v14 Reports Rewrite: çdo raport duhet të hapet i pastër si në workflow-n
  // ERP të videos. Kur përdoruesi kalon nga një raport te tjetri, nuk duhet
  // të trashëgohen filtrat specifikë të raportit të mëparshëm (artikull,
  // klient, furnitor, çmim, njësi shitjeje, status pagese, kërkim rezultatesh),
  // sepse ato mund ta bëjnë raportin e ri të duket bosh ose me kolona/rreshta
  // të vjetër. Ruhen vetëm filtrat universalë që kanë kuptim në çdo raport:
  // periudha, magazina dhe njësia e raportimit.
  return normalizeFilter({
    from: f.from,
    to: f.to,
    stores: f.stores || [],
    reportUnit: f.reportUnit || "",
  });
}


function pad2(n: number) { return String(n).padStart(2, "0"); }
function isoDate(d: Date) { return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`; }
function parseIsoDate(v?: string): Date | null {
  if (!v || !/^\d{4}-\d{2}-\d{2}$/.test(v)) return null;
  const [y, m, d] = v.split("-").map(Number);
  const out = new Date(y, m - 1, d);
  return Number.isNaN(out.getTime()) ? null : out;
}
function addDays(d: Date, n: number) { const x = new Date(d); x.setDate(x.getDate() + n); return x; }
function addMonths(d: Date, n: number) { const x = new Date(d); x.setMonth(x.getMonth() + n); return x; }
function startOfMonth(d: Date) { return new Date(d.getFullYear(), d.getMonth(), 1); }
function endOfMonth(d: Date) { return new Date(d.getFullYear(), d.getMonth() + 1, 0); }
function startOfYear(d: Date) { return new Date(d.getFullYear(), 0, 1); }
function endOfYear(d: Date) { return new Date(d.getFullYear(), 11, 31); }
function monthTitle(d: Date) {
  return d.toLocaleDateString("sq-AL", { month: "long", year: "numeric" });
}
function prettyDate(v?: string) {
  const d = parseIsoDate(v);
  return d ? d.toLocaleDateString("sq-AL") : "Zgjidh";
}
function normalizeDatePatch(patch: Partial<Pick<ReportFilter, "from" | "to">>, base: ReportFilter) {
  let from = patch.from ?? base.from ?? "";
  let to = patch.to ?? base.to ?? "";
  if (from && to && from > to) {
    // Kur përdoruesi zgjedh datë fillimi më të madhe se data e fundit,
    // periudha kthehet në një datë të vetme që raporti të rifreskohet pa gabim.
    to = from;
  }
  return { from, to };
}
function calendarDays(cursor: Date) {
  const first = startOfMonth(cursor);
  const startOffset = (first.getDay() + 6) % 7; // Monday first
  const start = addDays(first, -startOffset);
  return Array.from({ length: 42 }, (_, i) => addDays(start, i));
}

function emptyReportFor(type: ReportType, filters: ReportFilter) {
  const entry = REPORT_CATALOG.find((r) => r.value === type) || REPORT_CATALOG[0];
  return {
    title: entry.label,
    subtitle: "Po ngarkohet raporti…",
    columns: [],
    rows: [],
    summary: [],
    emptyMessage: "Po ngarkohet raporti…",
    filter: filters,
  } as any;
}

export default function ReportsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { db, setDB, getMultiDB } = useStore();
  const params = useLocalSearchParams<ParamShape>();

  const [type, setType] = React.useState<ReportType>(
    (params.type as ReportType) || "salesSummary",
  );
  const initialFilters = React.useMemo<ReportFilter>(() => {
    const now = new Date();
    return normalizeFilter({
      from: isoDate(startOfMonth(now)),
      to: isoDate(endOfMonth(now)),
      clients: typeof params.client === "string" && params.client ? [params.client] : [],
      suppliers: typeof params.supplier === "string" && params.supplier ? [params.supplier] : [],
      products: typeof params.product === "string" && params.product ? [params.product] : [],
    });
  }, [params.client, params.supplier, params.product]);

  // Draft filters are edited freely. Applied filters are the only ones that
  // rebuild SQLite reports. This prevents slow reports from running on every
  // keystroke and makes combinations behave like a professional ERP: choose all
  // criteria first; v14.1 applies them automatically with a short debounce.
  const [filters, setFilters] = React.useState<ReportFilter>(initialFilters);
  const [appliedFilters, setAppliedFilters] = React.useState<ReportFilter>(initialFilters);
  const [refreshSeq, setRefreshSeq] = React.useState(0);
  const [filtersExpanded, setFiltersExpanded] = React.useState(false);
  const [filterSheetOpen, setFilterSheetOpen] = React.useState(false);
  const [filterSheetTab, setFilterSheetTab] = React.useState<ReportFilterTab>("salesman");

  const [pickerOpen, setPickerOpen] = React.useState(false);
  const [searchPicker, setSearchPicker] = React.useState("");
  const [multiPicker, setMultiPicker] = React.useState<null | MultiKind>(null);
  const [partySearch, setPartySearch] = React.useState("");
  const [pdfOpen, setPdfOpen] = React.useState(false);
  const [pdfOpts, setPdfOpts] = React.useState({ showCompany: true, showFilters: true, showSummary: true, zebra: true });
  const [rowSearch, setRowSearch] = React.useState("");
  const [reportTransitionSeq, setReportTransitionSeq] = React.useState(0);
  const [viewerRevision, setViewerRevision] = React.useState(0);
  const [datePickerOpen, setDatePickerOpen] = React.useState(false);
  const [activeDateField, setActiveDateField] = React.useState<"from" | "to">("from");
  const [dateCursor, setDateCursor] = React.useState(() => parseIsoDate(initialFilters.from || initialFilters.to) || new Date());

  // Sync the report type with incoming navigation params. The Reports tab stays
  // mounted, so a fresh `params.type` (e.g. tapping a different report link from
  // the menu) must update state — otherwise the previously opened report stays
  // on screen. We validate against the catalog so an unknown value is ignored.
  React.useEffect(() => {
    const t = params.type;
    if (typeof t === "string" && t && REPORT_CATALOG.some((r) => r.value === t) && t !== type) {
      // Global report switch path for navigation links. Clear result-search and
      // force a fresh SQLite run so every report type is loaded with its own
      // columns/rows instead of reusing the previous report view.
      const nextType = t as ReportType;
      const nextFilters = safeFiltersForReportSwitch(type, nextType, appliedFilters);
      setRowSearch("");
      setFilters(nextFilters);
      setAppliedFilters(nextFilters);
      setType(nextType);
      setReportTransitionSeq((x) => x + 1);
      setRefreshSeq((x) => x + 1);
    }
  }, [params.type]);

  // Keep the single-value filters in sync when navigating with a target party /
  // product (e.g. "Kartela e Artikullit" opened from the product screen).
  React.useEffect(() => {
    const patch: Partial<ReportFilter> = {
      products: typeof params.product === "string" && params.product ? [params.product] : undefined,
      clients: typeof params.client === "string" && params.client ? [params.client] : undefined,
      suppliers: typeof params.supplier === "string" && params.supplier ? [params.supplier] : undefined,
    };
    const cleaned = Object.fromEntries(Object.entries(patch).filter(([, v]) => v !== undefined)) as Partial<ReportFilter>;
    if (Object.keys(cleaned).length === 0) return;
    setFilters((f) => normalizeFilter({ ...f, ...cleaned }));
    setAppliedFilters((f) => normalizeFilter({ ...f, ...cleaned }));
  }, [params.product, params.client, params.supplier]);

  const favorites = db.settings.favoriteReports || [];
  const isFavorite = favorites.includes(type);
  const toggleFavorite = (t: ReportType) => {
    setDB((prev) => {
      const cur = prev.settings.favoriteReports || [];
      const next = cur.includes(t) ? cur.filter((x) => x !== t) : [...cur, t];
      return { ...prev, settings: { ...prev.settings, favoriteReports: next } };
    });
  };

  const reportEntry = REPORT_CATALOG.find((r) => r.value === type) || REPORT_CATALOG[0];
  type ReportSnapshot = ReportResult;
  const sqliteQueryKey = React.useMemo(
    () => `${type}|${filterSignature(appliedFilters)}|${refreshSeq}|${reportTransitionSeq}`,
    [type, appliedFilters, refreshSeq, reportTransitionSeq],
  );
  const [sqliteSnapshot, setSqliteSnapshot] = React.useState<{ key: string; result: ReportSnapshot | null } | null>(null);
  const [sqliteLoading, setSqliteLoading] = React.useState(false);

  // Reset the live result search and any previous SQL result whenever the
  // current report identity changes. This runs after the SQLite state exists
  // and is global for every report.
  React.useEffect(() => {
    setRowSearch("");
    setSqliteSnapshot(null);
    setViewerRevision((x) => x + 1);
  }, [type, appliedFilters]);

  // Progressive SQLite refresh with strict ownership by report+filter key.
  // The Reports tab remains mounted while the user changes report types. If an
  // older SQLite promise resolves after the type/filter changed, it must never
  // overwrite the new report. This fixes the visible issue where switching from
  // one report to another left the old rows/columns, or showed an empty table
  // until the user refreshed manually.
  React.useEffect(() => {
    let alive = true;
    const key = sqliteQueryKey;
    setSqliteSnapshot(null);
    setSqliteLoading(true);
    const timer = setTimeout(() => {
      (async () => {
        // v15.3: before any report query, force-sync the current multi-company
        // state into the SQLite shadow tables. This prevents the exact issue seen
        // in the video: the invoice header appears in one report, while
        // invoice_items are still stale/missing in line reports after a sale/date
        // change. Reports must read one fresh SQLite snapshot.
        try { await saveMultiDB(getMultiDB()); } catch (_) {}
        return await buildSqliteReport(type, appliedFilters);
      })()
      .then((r) => {
        if (alive) setSqliteSnapshot({ key, result: r });
      })
      .catch(() => {
        if (alive) setSqliteSnapshot({ key, result: null });
      })
      .finally(() => {
        if (alive) setSqliteLoading(false);
      });
    }, 120);
    return () => { alive = false; clearTimeout(timer); };
  }, [sqliteQueryKey, type, appliedFilters, db, getMultiDB]);

  const freshSqliteResult = sqliteSnapshot?.key === sqliteQueryKey ? sqliteSnapshot.result : null;
  const reportIsResolving = sqliteLoading && !freshSqliteResult;

  // v14.2: raportet nuk bëjnë më silent fallback te buildReport(memory).
  // Nëse një raport nuk është SQL-native, buildSqliteReport kthen raport diagnostik
  // në vend që UI të lexojë db state të ngadaltë dhe jo të sinkronizuar.
  const result = freshSqliteResult || emptyReportFor(type, appliedFilters);
  const tableResetKey = React.useMemo(
    () => `${type}|${filterSignature(appliedFilters)}|${reportTransitionSeq}|${viewerRevision}|${result.columns.map((c) => c.key).join(',')}`,
    [type, appliedFilters, reportTransitionSeq, viewerRevision, result.columns],
  );
  const filtersDirty = React.useMemo(
    () => filterSignature(filters) !== filterSignature(appliedFilters),
    [filters, appliedFilters],
  );

  // v14.1 Vyapar-style: filtrat kryesorë nuk presin më butonin "Apliko".
  // Përdoruesi zgjedh artikull/klient/njësi/çmim dhe raporti rifreskohet vetë
  // me një debounce të shkurtër për të mos bërë query në çdo tast.
  React.useEffect(() => {
    if (!filtersDirty) return;
    const timer = setTimeout(() => {
      setAppliedFilters(normalizeFilter(filters));
      setRowSearch("");
      setSqliteSnapshot(null);
      setViewerRevision((x) => x + 1);
      setRefreshSeq((x) => x + 1);
    }, 320);
    return () => clearTimeout(timer);
  }, [filters, filtersDirty]);

  const applyFilters = React.useCallback(() => {
    setAppliedFilters(normalizeFilter(filters));
    setRowSearch("");
    setSqliteSnapshot(null);
    setViewerRevision((x) => x + 1);
    setRefreshSeq((x) => x + 1);
  }, [filters]);
  const refreshSqliteReport = React.useCallback(() => {
    setRefreshSeq((x) => x + 1);
  }, []);

  const applyDatePatch = React.useCallback((patch: Partial<Pick<ReportFilter, "from" | "to">>) => {
    setFilters((f) => {
      const datePatch = normalizeDatePatch(patch, f);
      return normalizeFilter({ ...f, ...datePatch });
    });
    setAppliedFilters((f) => {
      const datePatch = normalizeDatePatch(patch, f);
      return normalizeFilter({ ...f, ...datePatch });
    });
    setRowSearch("");
    setSqliteSnapshot(null);
    setSqliteLoading(true);
    setViewerRevision((x) => x + 1);
    setRefreshSeq((x) => x + 1);
  }, []);

  const openDatePicker = React.useCallback((field: "from" | "to") => {
    setActiveDateField(field);
    const selected = parseIsoDate(field === "from" ? filters.from : filters.to) || parseIsoDate(filters.from || filters.to) || new Date();
    setDateCursor(startOfMonth(selected));
    setDatePickerOpen(true);
  }, [filters.from, filters.to]);

  const applyDatePreset = React.useCallback((kind: "today" | "yesterday" | "week" | "month" | "year") => {
    const now = new Date();
    if (kind === "today") applyDatePatch({ from: isoDate(now), to: isoDate(now) });
    if (kind === "yesterday") {
      const d = addDays(now, -1);
      applyDatePatch({ from: isoDate(d), to: isoDate(d) });
    }
    if (kind === "week") applyDatePatch({ from: isoDate(addDays(now, -6)), to: isoDate(now) });
    if (kind === "month") applyDatePatch({ from: isoDate(startOfMonth(now)), to: isoDate(endOfMonth(now)) });
    if (kind === "year") applyDatePatch({ from: isoDate(startOfYear(now)), to: isoDate(endOfYear(now)) });
  }, [applyDatePatch]);
  const activeDraftFilterCount = React.useMemo(() => {
    const f = normalizeFilter(filters);
    let n = 0;
    if (f.from || f.to) n += 1;
    if (f.price) n += 1;
    if (f.reportUnit) n += 1;
    ([f.clients, f.suppliers, f.products, f.stores, f.units, f.salesmen, f.categories] as string[][]).forEach((arr) => { if (arr.length) n += 1; });
    if (f.txnType && f.txnType !== "all") n += 1;
    if (f.payStatus && f.payStatus !== "all") n += 1;
    return n;
  }, [filters]);

  // Fast client-side text search across all visible columns of the result rows
  const visibleRows = React.useMemo(() => {
    const q = rowSearch.trim().toLowerCase();
    if (!q) return result.rows;
    return result.rows.filter((r) =>
      result.columns.some((c) => String((r as any)[c.key] ?? "").toLowerCase().includes(q)),
    );
  }, [rowSearch, result]);

  const groupedCatalog = React.useMemo(() => {
    const norm = searchPicker.trim().toLowerCase();
    return GROUP_ORDER.map((g) => ({
      group: g,
      items: REPORT_CATALOG.filter(
        (r) => r.group === g && (!norm || r.label.toLowerCase().includes(norm)),
      ),
    })).filter((g) => g.items.length > 0);
  }, [searchPicker]);

  // Units available across all products (for the unit chips filter)
  const allUnits = React.useMemo(() => {
    const set: string[] = [];
    db.products.forEach((p) => (p.units || []).forEach((u) => {
      if (!set.some((x) => x.toLowerCase() === u.name.toLowerCase())) set.push(u.name);
    }));
    return set;
  }, [db.products]);

  const makeFiltersText = React.useCallback((src: ReportFilter) => {
    const parts: string[] = [];
    if (src.from || src.to) parts.push(`${src.from || "…"} → ${src.to || "…"}`);
    if (src.clients?.length) parts.push(`Klientë: ${src.clients.join(", ")}`);
    if (src.suppliers?.length) parts.push(`Furnitorë: ${src.suppliers.join(", ")}`);
    if (src.products?.length) parts.push(`Artikuj: ${src.products.join(", ")}`);
    if (src.stores?.length) parts.push(`Magazina: ${src.stores.join(", ")}`);
    if (src.units?.length) parts.push(`Njësi shitje: ${src.units.join(", ")}`);
    if (src.reportUnit?.trim()) parts.push(`Njësi raporti: ${src.reportUnit.trim()}`);
    if (src.price?.trim()) parts.push(`Çmimi: ${src.price.trim()}`);
    if (src.salesmen?.length) parts.push(`Shitës: ${src.salesmen.join(", ")}`);
    if (src.categories?.length) parts.push(`Kategori: ${src.categories.join(", ")}`);
    if (src.txnType && src.txnType !== "all") parts.push(`Lloji: ${src.txnType === "cash" ? "Kesh" : "Kredi"}`);
    if (src.payStatus && src.payStatus !== "all") parts.push(`Statusi: ${src.payStatus === "paid" ? "Paguar" : src.payStatus === "partial" ? "Pjesërisht" : "Pa paguar"}`);
    return parts.join("  •  ");
  }, []);

  const filtersText = React.useMemo(() => makeFiltersText(appliedFilters), [makeFiltersText, appliedFilters]);
  const draftFiltersText = React.useMemo(() => makeFiltersText(filters), [makeFiltersText, filters]);

  const activePartyKind = React.useMemo<"clients" | "suppliers">(
    () => reportGroupOf(type) === "Blerje" ? "suppliers" : "clients",
    [type],
  );
  const priceOptions = React.useMemo(() => {
    const values = new Set<string>();
    (db.invoices || []).forEach((inv: any) => (inv.items || []).forEach((it: any) => {
      const n = Number(it.rate || 0);
      if (n > 0) values.add(String(Math.round(n * 100) / 100));
    }));
    (db.purchases || []).forEach((pur: any) => (pur.items || []).forEach((it: any) => {
      const n = Number(it.rate || it.buyRate || 0);
      if (n > 0) values.add(String(Math.round(n * 100) / 100));
    }));
    return Array.from(values).sort((a, b) => Number(a) - Number(b));
  }, [db.invoices, db.purchases]);
  const appliedChipLabels = React.useMemo(() => {
    const f = normalizeFilter(appliedFilters);
    const partyVals = activePartyKind === "suppliers" ? f.suppliers : f.clients;
    return [
      `Shitës - ${f.salesmen?.length ? `${f.salesmen.length} zgjedhur` : "Të gjithë"}`,
      `Lloj - ${f.txnType === "cash" ? "Kesh" : f.txnType === "credit" ? "Kredi" : "Të gjitha"}`,
      `Palë - ${partyVals?.length ? `${partyVals.length} zgjedhur` : "Të gjitha"}`,
      `Status - ${f.payStatus === "paid" ? "Paguar" : f.payStatus === "partial" ? "Pjesërisht" : f.payStatus === "unpaid" ? "Pa paguar" : "Të gjitha"}`,
      ...(f.products?.length ? [`Artikuj - ${f.products.length} zgjedhur`] : []),
      ...(f.units?.length ? [`Njësi - ${f.units.join(", ")}`] : []),
      ...(f.price ? [`Çmim - ${f.price}`] : []),
      ...(f.stores?.length ? [`Magazina - ${f.stores.length} zgjedhur`] : []),
    ];
  }, [appliedFilters, activePartyKind]);
  const visibleSummaryCards = React.useMemo(() => {
    const base = (result.summary || []).slice(0, 3).map((s) => ({ label: s.label, value: String(s.value) }));
    if (base.length) return base;
    return [
      { label: "Nr. rreshta", value: String(result.rows.length) },
      { label: "Rezultate", value: String(visibleRows.length) },
      { label: "Raporti", value: reportEntry.group || "ERP" },
    ];
  }, [result.summary, result.rows.length, visibleRows.length, reportEntry.group]);

  // Build an export-ready result that respects the in-results text search.
  // When a row search is active we export only the visible rows and recompute
  // any numeric summary lines from those rows so totals match what is on screen.
  const exportResult = React.useMemo(() => {
    if (!rowSearch.trim() || visibleRows.length === result.rows.length) return result;
    const fmtMoney = (n: number) =>
      new Intl.NumberFormat("sq-AL", { maximumFractionDigits: 2 }).format(n);
    const recomputed = (result.summary || []).map((s) => {
      // Try to map a summary label to a money/qty column and re-sum visible rows.
      const col = result.columns.find(
        (c) => c.format === "money" && s.label.toLowerCase().includes(c.label.toLowerCase()),
      );
      if (col) {
        const sum = visibleRows.reduce((a, r) => a + Number((r as any)[col.key] || 0), 0);
        return { ...s, value: fmtMoney(sum) };
      }
      return s;
    });
    return {
      ...result,
      subtitle: result.subtitle
        ? `${result.subtitle}  •  Kërkim: “${rowSearch.trim()}”`
        : `Kërkim: “${rowSearch.trim()}”`,
      rows: visibleRows,
      summary: recomputed.length ? recomputed : result.summary,
    };
  }, [result, visibleRows, rowSearch]);

  const onShare = async () => {
    const html = renderReportHtml(exportResult, { companyName: db.company.name, filters: appliedFilters, currency: db.company.currency });
    try {
      if (Platform.OS === "web") { await Print.printAsync({ html }); return; }
      const { uri } = await Print.printToFileAsync({ html });
      if (await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(uri, { mimeType: "application/pdf", dialogTitle: result.title });
      } else {
        await Print.printAsync({ html });
      }
    } catch (e: any) { Alert.alert("Gabim", String(e?.message || e)); }
  };

  const onPrint = async () => {
    const html = renderReportHtml(exportResult, { companyName: db.company.name, filters: appliedFilters, currency: db.company.currency });
    try { await Print.printAsync({ html }); } catch (e: any) { Alert.alert("Gabim", String(e?.message || e)); }
  };

  const onExcel = async () => {
    try {
      const ft = rowSearch.trim() ? `${filtersText}${filtersText ? "  •  " : ""}Kërkim: “${rowSearch.trim()}”` : filtersText;
      await exportReportToExcel(exportResult, { companyName: db.company.name, filtersText: ft, currency: db.company.currency });
    } catch (e: any) {
      Alert.alert("Gabim Excel", String(e?.message || e));
    }
  };

  const setFilter = (patch: Partial<ReportFilter>) => setFilters((f) => normalizeFilter({ ...f, ...patch }));

  const toggleMulti = (kind: MultiKind, value: string) => {
    setFilters((f) => {
      const cur = (f[kind] as string[] | undefined) || [];
      const next = cur.some((x) => x.toLowerCase() === value.toLowerCase())
        ? cur.filter((x) => x.toLowerCase() !== value.toLowerCase())
        : [...cur, value];
      return { ...f, [kind]: next };
    });
  };

  const toggleUnit = (u: string) => {
    setFilters((f) => {
      const cur = f.units || [];
      const next = cur.some((x) => x.toLowerCase() === u.toLowerCase())
        ? cur.filter((x) => x.toLowerCase() !== u.toLowerCase())
        : [...cur, u];
      return { ...f, units: next };
    });
  };

  const openReportRow = React.useCallback((row: any) => {
    if (!row || row._total) return;
    const pick = (...keys: string[]) => {
      for (const key of keys) {
        const value = row?.[key];
        if (value != null && String(value).trim()) return String(value).trim();
      }
      return "";
    };
    const no = pick("no", "invoiceNo", "invoice_no", "purchaseNo", "purchase_no", "docNo", "doc", "documentNo", "document_no");
    if (no) {
      const sale = (db.invoices || []).find((i: any) => String(i.no) === no);
      if (sale) {
        router.push(`/invoice/${encodeURIComponent(no)}` as any);
        return;
      }
      const purchase = (db.purchases || []).find((i: any) => String(i.no) === no);
      if (purchase) {
        router.push(`/purchase/${encodeURIComponent(no)}` as any);
        return;
      }
      if (/^(FD|FH|TR|IF|INV)-?/i.test(no)) {
        router.push({ pathname: "/warehouse-docs", params: { q: no } } as any);
        return;
      }
    }

    const productName = pick("product", "productName", "product_name", "Artikulli", "name");
    if (productName) {
      const product = (db.products || []).find((p: any) => String(p.name || "").toLowerCase() === productName.toLowerCase());
      if (product?.id != null) {
        router.push(`/product/${encodeURIComponent(String(product.id))}` as any);
        return;
      }
    }

    const party = pick("party", "client", "customer", "supplier", "Klienti", "Furnitori");
    if (party) {
      const customer = (db.customers || []).find((c: any) => String(c.name || "").toLowerCase() === party.toLowerCase());
      if (customer) {
        router.push(`/party/${encodeURIComponent(party)}` as any);
        return;
      }
      const supplier = (db.suppliers || []).find((s: any) => String(s.name || "").toLowerCase() === party.toLowerCase());
      if (supplier) {
        router.push(`/supplier/${encodeURIComponent(party)}` as any);
        return;
      }
    }

    Alert.alert("Raporti", "Ky rresht është përmbledhës dhe nuk ka dokument për hapje.");
  }, [db]);

  const selectReport = React.useCallback((next: ReportType) => {
    // Një rrugë e vetme globale për ndërrimin e çdo raporti. Kjo pastron
    // snapshot-in, kërkimin, tabelën, kolonat dhe filtrat që nuk kanë kuptim
    // në grupin e ri të raportit. Qëllimi: asnjë raport të mos trashëgojë
    // rreshta/kolona/filtra nga raporti paraardhës.
    const nextFilters = safeFiltersForReportSwitch(type, next, filtersDirty ? filters : appliedFilters);
    setPickerOpen(false);
    setSearchPicker("");
    setRowSearch("");
    setFilters(nextFilters);
    setAppliedFilters(nextFilters);
    setSqliteSnapshot(null);
    setSqliteLoading(true);
    setViewerRevision((x) => x + 1);
    setReportTransitionSeq((x) => x + 1);
    setType(next);
    setRefreshSeq((x) => x + 1);
  }, [type, filtersDirty, filters, appliedFilters]);

  const optionList = React.useMemo(() => {
    const norm = partySearch.toLowerCase();
    let base: string[] = [];
    if (multiPicker === "clients") base = db.customers.map((c) => c.name);
    else if (multiPicker === "suppliers") base = db.suppliers.map((s) => s.name);
    else if (multiPicker === "products") base = db.products.map((p) => p.name);
    else if (multiPicker === "stores") base = db.stores;
    else if (multiPicker === "salesmen") base = allSalesmen(db);
    else if (multiPicker === "categories") {
      const set: string[] = [];
      db.products.forEach((p) => {
        if (p.category && !set.some((x) => x.toLowerCase() === p.category!.toLowerCase())) set.push(p.category);
      });
      base = set;
    }
    return base.filter((n) => !norm || n.toLowerCase().includes(norm));
  }, [multiPicker, partySearch, db]);

  const clearAll = () => {
    setFilters(EMPTY_FILTERS);
    setAppliedFilters(EMPTY_FILTERS);
    setRowSearch("");
    setRefreshSeq((x) => x + 1);
  };

  return (
    <ScreenContainer>
      <View style={{ backgroundColor: colors.background, borderBottomWidth: 1, borderColor: colors.border, paddingTop: 8, paddingBottom: 10, paddingHorizontal: 12 }}>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
          <Pressable onPress={() => setPickerOpen(true)} hitSlop={10} style={({ pressed }) => ({ opacity: pressed ? 0.65 : 1 })}>
            <Text style={{ color: colors.foreground, fontSize: 32, lineHeight: 34 }}>‹</Text>
          </Pressable>
          <Pressable onPress={() => setPickerOpen(true)} style={{ flex: 1 }}>
            <Text style={{ color: colors.foreground, fontSize: 26, fontWeight: "900" }} numberOfLines={1}>{reportEntry.label}</Text>
          </Pressable>
          <Pressable onPress={() => setPdfOpen(true)} style={({ pressed }) => ({ width: 44, height: 44, borderRadius: 10, backgroundColor: "#ef4444", alignItems: "center", justifyContent: "center", opacity: pressed ? 0.8 : 1 })}>
            <Text style={{ color: "#fff", fontWeight: "900", fontSize: 13 }}>Pdf</Text>
          </Pressable>
          <Pressable onPress={onExcel} style={({ pressed }) => ({ width: 44, height: 44, borderRadius: 10, backgroundColor: "#16a34a", alignItems: "center", justifyContent: "center", opacity: pressed ? 0.8 : 1 })}>
            <Text style={{ color: "#fff", fontWeight: "900", fontSize: 13 }}>xls</Text>
          </Pressable>
        </View>
      </View>

      <ScrollView contentContainerStyle={{ paddingBottom: 30 }} style={{ backgroundColor: "#EAF8FF" }}>
        <View style={{ backgroundColor: colors.background, borderBottomWidth: 1, borderColor: colors.border }}>
          <View style={{ flexDirection: "row", alignItems: "center", paddingHorizontal: 14, paddingVertical: 12 }}>
            <Pressable onPress={() => applyDatePreset("month")} style={{ minWidth: 120, flexDirection: "row", alignItems: "center", gap: 8 }}>
              <Text style={{ color: colors.muted, fontSize: 17, fontWeight: "700" }}>Ky Muaj</Text>
              <Text style={{ color: colors.primary, fontSize: 22, fontWeight: "900" }}>⌄</Text>
            </Pressable>
            <View style={{ width: 1, height: 34, backgroundColor: colors.border, marginHorizontal: 10 }} />
            <Pressable onPress={() => openDatePicker("from")} hitSlop={8}>
              <Text style={{ color: colors.primary, fontSize: 22 }}>📅</Text>
            </Pressable>
            <Pressable onPress={() => openDatePicker("from")} style={{ paddingHorizontal: 12, paddingVertical: 4 }}>
              <Text style={{ color: colors.muted, fontSize: 16, fontWeight: "700" }}>{filters.from || "Nga"}</Text>
            </Pressable>
            <Text style={{ color: colors.foreground, fontSize: 15, fontWeight: "800" }}>TO</Text>
            <Pressable onPress={() => openDatePicker("to")} style={{ paddingHorizontal: 12, paddingVertical: 4 }}>
              <Text style={{ color: colors.muted, fontSize: 16, fontWeight: "700" }}>{filters.to || "Deri"}</Text>
            </Pressable>
          </View>
          <View style={{ paddingHorizontal: 14, paddingTop: 8, paddingBottom: 12 }}>
            <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
              <Text style={{ color: colors.foreground, fontSize: 18, fontWeight: "700" }}>Filtrat e aplikuar:</Text>
              <Pressable onPress={() => setFilterSheetOpen(true)} style={({ pressed }) => ({ flexDirection: "row", alignItems: "center", gap: 8, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 22, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surface, opacity: pressed ? 0.8 : 1 })}>
                <Text style={{ color: colors.primary, fontSize: 18 }}>▽</Text>
                <Text style={{ color: colors.muted, fontWeight: "800", fontSize: 15 }}>Filters</Text>
              </Pressable>
            </View>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 10, paddingRight: 16 }}>
              {appliedChipLabels.map((txt, idx) => (
                <View key={`${txt}-${idx}`} style={{ backgroundColor: "#F3F4F8", borderRadius: 22, paddingHorizontal: 16, paddingVertical: 9 }}>
                  <Text style={{ color: "#70778B", fontSize: 15, fontWeight: "800" }} numberOfLines={1}>{txt}</Text>
                </View>
              ))}
            </ScrollView>
          </View>
        </View>

        <View style={{ backgroundColor: "#7DD3FC", paddingHorizontal: 12, paddingVertical: 14 }}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 10, paddingRight: 14 }}>
            {visibleSummaryCards.map((s, idx) => (
              <View key={`${s.label}-${idx}`} style={{ backgroundColor: colors.surface, borderRadius: 6, minWidth: 150, paddingHorizontal: 14, paddingVertical: 12, shadowColor: "#000", shadowOpacity: 0.12, shadowRadius: 4, elevation: 2 }}>
                <Text style={{ color: colors.muted, fontSize: 15, fontWeight: "600" }}>{s.label}</Text>
                <Text style={{ color: idx === 2 ? "#10b981" : colors.foreground, fontWeight: "900", fontSize: 18, marginTop: 8 }} numberOfLines={1}>{s.value}</Text>
              </View>
            ))}
          </ScrollView>
        </View>

        {/* Fast live search across result rows */}
        {result.rows.length > 0 ? (
          <View style={{ paddingHorizontal: 12, marginTop: 12 }}>
            <View style={{ backgroundColor: colors.surface, borderRadius: 10, paddingHorizontal: 12, borderWidth: 1, borderColor: rowSearch ? colors.primary : colors.border, flexDirection: "row", alignItems: "center", gap: 8 }}>
              <Text style={{ color: colors.muted, fontSize: 15 }}>🔍</Text>
              <TextInput
                value={rowSearch}
                onChangeText={setRowSearch}
                placeholder="Kërko në rezultate…"
                placeholderTextColor={colors.muted}
                style={{ flex: 1, paddingVertical: 10, color: colors.foreground }}
              />
              {rowSearch ? (
                <Pressable onPress={() => setRowSearch("")} hitSlop={10}>
                  <Text style={{ color: colors.error, fontWeight: "900", fontSize: 16 }}>×</Text>
                </Pressable>
              ) : null}
            </View>
            <Text style={{ color: colors.muted, fontSize: 11, marginTop: 4 }}>
              {visibleRows.length} {visibleRows.length === 1 ? "rezultat" : "rezultate"}
              {rowSearch ? ` nga ${result.rows.length}` : ""}
            </Text>
          </View>
        ) : null}

        {/* Vyapar-style result cards */}
        <View key={`table-${tableResetKey}`} style={{ paddingHorizontal: 12, marginTop: 12 }}>
          {reportIsResolving && result.rows.length === 0 ? (
            <View style={{ alignItems: "center", padding: 40, gap: 8 }}>
              <ActivityIndicator size="small" color={colors.primary} />
              <Text style={{ color: colors.muted, textAlign: "center" }}>Po ngarkohet raporti…</Text>
            </View>
          ) : result.rows.length === 0 ? (
            <View style={{ alignItems: "center", padding: 40 }}>
              <Text style={{ color: colors.muted }}>{result.emptyMessage || "Pa të dhëna në periudhën e zgjedhur"}</Text>
            </View>
          ) : visibleRows.length === 0 ? (
            <View style={{ alignItems: "center", padding: 40 }}>
              <Text style={{ color: colors.muted }}>Asnjë rresht nuk përputhet me “{rowSearch}”</Text>
            </View>
          ) : (
            <View style={{ gap: 10 }}>
              {visibleRows.map((r, idx) => (
                <VyaparReportCard key={`${tableResetKey}-${idx}`} row={r} columns={result.columns as any[]} idx={idx} colors={colors} onPress={() => openReportRow(r)} />
              ))}
            </View>
          )}
        </View>
      </ScrollView>

      {/* Report-type picker overlay */}
      {pickerOpen ? (
        <View style={overlayStyle}>
          <View style={{ backgroundColor: colors.background, borderRadius: 12, padding: 12, maxHeight: "85%" }}>
            <Text style={{ fontWeight: "900", fontSize: 16, color: colors.foreground, marginBottom: 8 }}>Zgjidh raportin</Text>
            <TextInput
              value={searchPicker}
              onChangeText={setSearchPicker}
              placeholder="Kërko raport…"
              placeholderTextColor={colors.muted}
              style={{ borderWidth: 1, borderColor: colors.border, borderRadius: 8, padding: 10, marginBottom: 8, color: colors.foreground, backgroundColor: colors.surface }}
            />
            <ScrollView>
              {groupedCatalog.map((g) => (
                <View key={g.group} style={{ marginBottom: 8 }}>
                  <Text style={{ fontSize: 11, fontWeight: "900", color: colors.muted, textTransform: "uppercase", marginVertical: 6 }}>{g.group}</Text>
                  {g.items.map((it) => {
                    const active = it.value === type;
                    return (
                      <Pressable
                        key={it.value}
                        onPress={() => selectReport(it.value)}
                        style={{ padding: 12, borderRadius: 8, backgroundColor: active ? colors.primary + "22" : colors.surface, borderWidth: 1, borderColor: active ? colors.primary : colors.border, marginBottom: 6, flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}
                      >
                        <Text style={{ color: colors.foreground, fontWeight: "700", flex: 1 }}>{it.label}</Text>
                        {active ? <Badge tone="paid">Aktiv</Badge> : null}
                      </Pressable>
                    );
                  })}
                </View>
              ))}
            </ScrollView>
            <Pressable onPress={() => setPickerOpen(false)} style={{ marginTop: 4, padding: 12, alignSelf: "flex-end" }}>
              <Text style={{ color: colors.primary, fontWeight: "800" }}>Mbyll</Text>
            </Pressable>
          </View>
        </View>
      ) : null}

      {/* Calendar date picker — no native dependency, works offline and applies immediately. */}
      {datePickerOpen ? (
        <DateRangeModal
          cursor={dateCursor}
          setCursor={setDateCursor}
          from={filters.from || ""}
          to={filters.to || ""}
          activeField={activeDateField}
          setActiveField={setActiveDateField}
          onPick={(picked) => {
            if (activeDateField === "from") {
              applyDatePatch({ from: picked, to: filters.to || picked });
              setActiveDateField("to");
            } else {
              applyDatePatch({ from: filters.from || picked, to: picked });
              setDatePickerOpen(false);
            }
          }}
          onClose={() => setDatePickerOpen(false)}
        />
      ) : null}

      {/* Vyapar-style filter bottom sheet */}
      {filterSheetOpen ? (
        <View style={bottomOverlayStyle}>
          <View style={{ backgroundColor: colors.background, borderTopLeftRadius: 16, borderTopRightRadius: 16, height: "88%", maxHeight: 760, marginBottom: Math.max(insets.bottom, 0), overflow: "hidden" }}>
            <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 18, paddingVertical: 16, borderBottomWidth: 1, borderColor: colors.border }}>
              <Text style={{ color: colors.foreground, fontSize: 25, fontWeight: "900" }}>Filters</Text>
              <Pressable onPress={() => setFilterSheetOpen(false)} hitSlop={12}><Text style={{ color: colors.muted, fontSize: 30 }}>×</Text></Pressable>
            </View>
            <View style={{ flexDirection: "row", flex: 1, minHeight: 0 }}>
              <View style={{ width: 150, backgroundColor: "#F1F3F8" }}>
                {([
                  ["salesman", "By User"],
                  ["txn", "By Txns Type"],
                  ["party", "By Party"],
                  ["status", "By Status"],
                  ["products", "By Item"],
                  ["unit", "By Unit"],
                  ["price", "By Price"],
                  ["store", "By Store"],
                ] as [ReportFilterTab, string][]).map(([tab, label]) => {
                  const active = filterSheetTab === tab;
                  return (
                    <Pressable key={tab} onPress={() => setFilterSheetTab(tab)} style={{ paddingVertical: 17, paddingHorizontal: 16, backgroundColor: active ? colors.background : "transparent" }}>
                      <Text style={{ color: active ? colors.foreground : colors.muted, fontSize: 16, fontWeight: active ? "900" : "700" }}>{label}</Text>
                    </Pressable>
                  );
                })}
              </View>
              <View style={{ flex: 1, minHeight: 0 }}>
                <FilterSheetOptions
                  tab={filterSheetTab}
                  db={db}
                  allUnits={allUnits}
                  priceOptions={priceOptions}
                  filters={filters}
                  activePartyKind={activePartyKind}
                  setFilter={setFilter}
                  toggleUnit={toggleUnit}
                  toggleMulti={toggleMulti}
                  colors={colors}
                />
              </View>
            </View>
            <View style={{ flexDirection: "row", gap: 18, paddingHorizontal: 18, paddingTop: 16, paddingBottom: Math.max(insets.bottom + 14, 22), borderTopWidth: 1, borderColor: colors.border, backgroundColor: colors.background }}>
              <Pressable onPress={clearAll} style={({ pressed }) => ({ flex: 1, borderRadius: 28, backgroundColor: "#EEF0F5", paddingVertical: 16, alignItems: "center", opacity: pressed ? 0.8 : 1 })}>
                <Text style={{ color: colors.muted, fontWeight: "900", fontSize: 16 }}>Reset</Text>
              </Pressable>
              <Pressable onPress={() => { setFilterSheetOpen(false); applyFilters(); }} style={({ pressed }) => ({ flex: 1, borderRadius: 28, backgroundColor: "#F21446", paddingVertical: 16, alignItems: "center", opacity: pressed ? 0.8 : 1 })}>
                <Text style={{ color: "#fff", fontWeight: "900", fontSize: 16 }}>Apply</Text>
              </Pressable>
            </View>
          </View>
        </View>
      ) : null}

      {/* PDF customize sheet */}
      {pdfOpen ? (
        <View style={overlayStyle}>
          <View style={{ backgroundColor: colors.background, borderRadius: 12, padding: 16, gap: 10 }}>
            <Text style={{ fontWeight: "900", fontSize: 16, color: colors.foreground }}>Personalizo PDF-në</Text>
            <Text style={{ fontSize: 12, color: colors.muted, marginBottom: 6 }}>Zgjidh çfarë të shfaqet në raportin e printuar.</Text>
            {([
              ["showCompany", "Trego të dhënat e biznesit"],
              ["showFilters", "Trego filtrat e zbatuar"],
              ["showSummary", "Trego përmbledhjen lart"],
              ["zebra", "Rreshta me ngjyrë alternative"],
            ] as const).map(([key, label]) => (
              <View key={key} style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingVertical: 6 }}>
                <Text style={{ color: colors.foreground, fontSize: 14 }}>{label}</Text>
                <Switch value={(pdfOpts as any)[key]} onValueChange={(v) => setPdfOpts((o) => ({ ...o, [key]: v }))} trackColor={{ true: colors.primary, false: colors.border }} />
              </View>
            ))}
            <View style={{ flexDirection: "row", gap: 8, marginTop: 6 }}>
              <View style={{ flex: 1 }}><Btn title="Anulo" variant="ghost" onPress={() => setPdfOpen(false)} /></View>
              <View style={{ flex: 1 }}><Btn title="Gjenero PDF" onPress={async () => { setPdfOpen(false); await onShare(); }} /></View>
            </View>
          </View>
        </View>
      ) : null}

      {/* Multi-select overlay */}
      {multiPicker ? (
        <View style={overlayStyle}>
          <View style={{ backgroundColor: colors.background, borderRadius: 12, padding: 12, maxHeight: "85%" }}>
            <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
              <Text style={{ fontWeight: "900", fontSize: 16, color: colors.foreground }}>
                Zgjidh {multiPicker === "clients" ? "klientët" : multiPicker === "suppliers" ? "furnitorët" : multiPicker === "products" ? "artikujt" : multiPicker === "stores" ? "magazinat" : multiPicker === "salesmen" ? "shitësit" : "kategoritë"}
              </Text>
              <View style={{ backgroundColor: colors.primary, borderRadius: 12, paddingHorizontal: 10, paddingVertical: 3 }}>
                <Text style={{ color: "#fff", fontWeight: "900", fontSize: 12 }}>
                  {((filters[multiPicker] as string[] | undefined) || []).length} të zgjedhur
                </Text>
              </View>
            </View>
            <Text style={{ color: colors.muted, fontSize: 11, marginBottom: 8 }}>Zgjidh vlerat. Raporti rifreskohet automatikisht pas zgjedhjes ose pas mbylljes së popup-it.</Text>
            <TextInput
              value={partySearch}
              onChangeText={setPartySearch}
              placeholder="Kërko…"
              placeholderTextColor={colors.muted}
              style={{ borderWidth: 1, borderColor: colors.border, borderRadius: 8, padding: 10, marginBottom: 8, color: colors.foreground, backgroundColor: colors.surface }}
            />
            <FlatList
              data={optionList}
              keyExtractor={(n) => n}
              renderItem={({ item }) => {
                const selected = ((filters[multiPicker] as string[] | undefined) || []).some((x) => x.toLowerCase() === item.toLowerCase());
                return (
                  <Pressable
                    onPress={() => toggleMulti(multiPicker, item)}
                    style={{ paddingVertical: 12, paddingHorizontal: 10, borderBottomWidth: 1, borderColor: colors.border, flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}
                  >
                    <Text style={{ color: colors.foreground, fontWeight: "700", flex: 1 }}>{item}</Text>
                    <View style={{ width: 22, height: 22, borderRadius: 6, borderWidth: 2, borderColor: selected ? colors.primary : colors.border, backgroundColor: selected ? colors.primary : "transparent", alignItems: "center", justifyContent: "center" }}>
                      {selected ? <Text style={{ color: "#fff", fontWeight: "900", fontSize: 13 }}>✓</Text> : null}
                    </View>
                  </Pressable>
                );
              }}
              ListEmptyComponent={<Text style={{ textAlign: "center", color: colors.muted, padding: 20 }}>Pa rezultate</Text>}
            />
            <View style={{ flexDirection: "row", gap: 8, marginTop: 8 }}>
              <View style={{ flex: 1 }}>
                <Btn title="Pastro" variant="ghost" onPress={() => setFilter({ [multiPicker]: [] } as Partial<ReportFilter>)} />
              </View>
              <View style={{ flex: 1 }}>
                <Btn title="Mbyll" onPress={() => { setMultiPicker(null); setPartySearch(""); }} />
              </View>
            </View>
          </View>
        </View>
      ) : null}
    </ScreenContainer>
  );
}

function colWidth(colOrFormat?: any) {
  const key = typeof colOrFormat === "object" ? String(colOrFormat.key || "") : "";
  const label = typeof colOrFormat === "object" ? String(colOrFormat.label || "") : "";
  const format = typeof colOrFormat === "object" ? colOrFormat.format : colOrFormat;
  if (["product", "name"].includes(key) || /artikull|emërtim/i.test(label)) return 190;
  if (["docs", "note", "destination"].includes(key) || /dokumente|shënim|destinacion/i.test(label)) return 220;
  if (["store", "warehouse"].includes(key) || /magazin/i.test(label)) return 150;
  if (["date"].includes(key) || /data/i.test(label)) return 95;
  if (format === "money" || format === "qty" || format === "pct") return 115;
  return 135;
}

function formatValue(val: any, format?: "money" | "qty" | "pct" | "text") {
  if (val == null || val === "") return "";
  if (format === "money") return Number(val || 0).toLocaleString("sq-AL", { maximumFractionDigits: 2 });
  if (format === "qty") return Number(val || 0).toLocaleString("sq-AL", { maximumFractionDigits: 3 });
  if (format === "pct") return `${Number(val || 0).toFixed(1)}%`;
  return String(val);
}



function findReportColumn(columns: any[], matchers: (RegExp | string)[], fallback?: number) {
  const found = columns.find((c) => {
    const hay = `${String(c.key || "")} ${String(c.label || "")}`.toLowerCase();
    return matchers.some((m) => typeof m === "string" ? hay.includes(m.toLowerCase()) : m.test(hay));
  });
  return found || (typeof fallback === "number" ? columns[fallback] : undefined);
}

function reportCell(row: any, col: any) {
  if (!col) return "";
  return formatValue(row?.[col.key], col.format);
}

function VyaparReportCard({ row, columns, idx, colors, onPress }: { row: any; columns: any[]; idx: number; colors: any; onPress?: () => void }) {
  const isTotal = !!row?._total;
  const titleCol = findReportColumn(columns, [/client|customer|klient|party|furnitor|supplier|product|artikull|em[eë]rtim|name/], 0);
  const docCol = findReportColumn(columns, [/invoice|fatur|doc|dokument|nr\.?|no/]);
  const dateCol = findReportColumn(columns, [/date|data/]);
  const amountCol = findReportColumn(columns, [/amount|vler|total|sale|shitje|blerje/]);
  const balanceCol = findReportColumn(columns, [/balance|due|detyrim|mbetur|balanc/]);
  const title = reportCell(row, titleCol) || (isTotal ? "TOTAL" : `Rreshti ${idx + 1}`);
  const doc = reportCell(row, docCol);
  const date = reportCell(row, dateCol);
  const amount = reportCell(row, amountCol);
  const balance = reportCell(row, balanceCol);
  const fallbackCols = columns.filter((c) => c !== titleCol && c !== docCol && c !== dateCol && c !== amountCol && c !== balanceCol).slice(0, 4);
  return (
    <Pressable
      onPress={isTotal ? undefined : onPress}
      disabled={isTotal || !onPress}
      style={({ pressed }) => ({
        backgroundColor: isTotal ? "#16a34a" : colors.surface,
        borderRadius: 12,
        padding: 16,
        shadowColor: "#000",
        shadowOpacity: 0.13,
        shadowRadius: 5,
        elevation: 2,
        opacity: pressed ? 0.86 : 1,
      })}
    >
      <View style={{ flexDirection: "row", justifyContent: "space-between", gap: 12 }}>
        <Text style={{ flex: 1, color: isTotal ? "#fff" : colors.foreground, fontSize: 18, fontWeight: "900" }} numberOfLines={2}>{title}</Text>
        <View style={{ alignItems: "flex-end", maxWidth: 150 }}>
          {doc ? <Text style={{ color: isTotal ? "rgba(255,255,255,0.85)" : colors.muted, fontSize: 14, fontWeight: "800" }} numberOfLines={1}>{doc}</Text> : null}
          {date ? <Text style={{ color: isTotal ? "rgba(255,255,255,0.85)" : colors.muted, fontSize: 13, marginTop: 2 }} numberOfLines={1}>{date}</Text> : null}
        </View>
      </View>
      <View style={{ flexDirection: "row", gap: 18, marginTop: 18, flexWrap: "wrap" }}>
        {amount ? (
          <View style={{ minWidth: 130 }}>
            <Text style={{ color: isTotal ? "rgba(255,255,255,0.75)" : colors.muted, fontSize: 14 }}>Amount</Text>
            <Text style={{ color: isTotal ? "#fff" : colors.foreground, fontSize: 16, fontWeight: "800", marginTop: 2 }}>{amount}</Text>
          </View>
        ) : null}
        {balance ? (
          <View style={{ minWidth: 130 }}>
            <Text style={{ color: isTotal ? "rgba(255,255,255,0.75)" : colors.muted, fontSize: 14 }}>Balance</Text>
            <Text style={{ color: isTotal ? "#fff" : colors.foreground, fontSize: 16, fontWeight: "800", marginTop: 2 }}>{balance}</Text>
          </View>
        ) : null}
        {!amount && !balance ? fallbackCols.map((c) => (
          <View key={c.key} style={{ minWidth: 120 }}>
            <Text style={{ color: isTotal ? "rgba(255,255,255,0.75)" : colors.muted, fontSize: 12 }}>{c.label}</Text>
            <Text style={{ color: isTotal ? "#fff" : colors.foreground, fontSize: 14, fontWeight: "800", marginTop: 2 }}>{reportCell(row, c)}</Text>
          </View>
        )) : null}
      </View>
      {!isTotal && onPress ? <Text style={{ color: colors.primary, fontWeight: "800", fontSize: 12, marginTop: 10 }}>Prek për detaje / editim / printim</Text> : null}
    </Pressable>
  );
}

function FilterSheetOptions({ tab, db, allUnits, priceOptions, filters, activePartyKind, setFilter, toggleUnit, toggleMulti, colors }: any) {
  const partyOptions = activePartyKind === "suppliers" ? (db.suppliers || []).map((x: any) => x.name) : (db.customers || []).map((x: any) => x.name);
  const userOptions = ["Të gjithë", ...allSalesmen(db).map((x: any) => x.name || String(x))];
  const productOptions = ["Të gjithë", ...(db.products || []).map((x: any) => x.name)];
  const storeOptions = ["Të gjitha", ...Array.from(new Set([...(db.stores || []), ...(db.products || []).map((p: any) => p.store).filter(Boolean)]))];
  const unitOptions = ["Të gjitha", ...allUnits];
  const priceItems = ["Të gjithë", ...priceOptions];
  const statusOptions = [["all", "All"], ["paid", "Paid"], ["unpaid", "Unpaid"], ["partial", "Partial"], ["cancelled", "Cancelled"]];
  const txnOptions = [["all", "Sale & Cr. Note"], ["cash", "Sale"], ["credit", "Credit Note"]];
  const optionStyle = (active: boolean) => ({ paddingVertical: 16, paddingHorizontal: 20, flexDirection: "row" as const, alignItems: "center" as const, justifyContent: "space-between" as const });
  const radio = (active: boolean) => <View style={{ width: 28, height: 28, borderRadius: 14, borderWidth: 3, borderColor: active ? colors.primary : colors.muted, alignItems: "center", justifyContent: "center" }}>{active ? <View style={{ width: 13, height: 13, borderRadius: 7, backgroundColor: colors.primary }} /> : null}</View>;
  const text = (label: string, active: boolean) => <Text style={{ color: active ? colors.foreground : colors.muted, fontSize: 17, fontWeight: active ? "800" : "600", flex: 1 }}>{label}</Text>;
  const renderArray = (items: string[], selected: string[] | undefined, onAll: () => void, onPick: (v: string) => void) => (
    <ScrollView style={{ flex: 1 }}>
      {items.map((it) => {
        const all = /^t[ëe] gjith|^all/i.test(it);
        const active = all ? !(selected || []).length : (selected || []).some((x: string) => x.toLowerCase() === it.toLowerCase());
        return <Pressable key={it} onPress={() => all ? onAll() : onPick(it)} style={optionStyle(active)}>{text(it, active)}{radio(active)}</Pressable>;
      })}
    </ScrollView>
  );
  if (tab === "salesman") return renderArray(userOptions, filters.salesmen, () => setFilter({ salesmen: [] }), (v) => toggleMulti("salesmen", v));
  if (tab === "products") return renderArray(productOptions, filters.products, () => setFilter({ products: [] }), (v) => toggleMulti("products", v));
  if (tab === "party") return renderArray(["All Party", ...partyOptions], activePartyKind === "suppliers" ? filters.suppliers : filters.clients, () => setFilter(activePartyKind === "suppliers" ? { suppliers: [] } : { clients: [] }), (v) => toggleMulti(activePartyKind, v));
  if (tab === "store") return renderArray(storeOptions as string[], filters.stores, () => setFilter({ stores: [] }), (v) => toggleMulti("stores", v));
  if (tab === "unit") return renderArray(unitOptions, filters.units, () => setFilter({ units: [] }), (v) => toggleUnit(v));
  if (tab === "price") return renderArray(priceItems, filters.price ? String(filters.price).split(",") : [], () => setFilter({ price: "" }), (v) => setFilter({ price: v }));
  if (tab === "txn") return <ScrollView style={{ flex: 1 }}>{txnOptions.map(([value, label]) => { const active = (filters.txnType || "all") === value; return <Pressable key={value} onPress={() => setFilter({ txnType: value })} style={optionStyle(active)}>{text(label, active)}{radio(active)}</Pressable>; })}</ScrollView>;
  return <ScrollView style={{ flex: 1 }}>{statusOptions.map(([value, label]) => { const active = (filters.payStatus || "all") === value; return <Pressable key={value} onPress={() => setFilter({ payStatus: value })} style={optionStyle(active)}>{text(label, active)}{radio(active)}</Pressable>; })}</ScrollView>;
}

function QuickFilterChip({ label, value, active, onPress }: { label: string; value: string; active?: boolean; onPress: () => void }) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => ({
        minWidth: 104,
        borderRadius: 18,
        paddingHorizontal: 12,
        paddingVertical: 8,
        backgroundColor: active ? colors.primary : colors.surface,
        borderWidth: 1,
        borderColor: active ? colors.primary : colors.border,
        opacity: pressed ? 0.82 : 1,
      })}
    >
      <Text style={{ color: active ? "rgba(255,255,255,0.85)" : colors.muted, fontSize: 10, fontWeight: "800" }} numberOfLines={1}>{label}</Text>
      <Text style={{ color: active ? "#fff" : colors.foreground, fontSize: 12, fontWeight: "900", marginTop: 2 }} numberOfLines={1}>{value}</Text>
    </Pressable>
  );
}

function DateBox({ label, value, onPress }: { label: string; value?: string; onPress: () => void }) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => ({
        flex: 1,
        backgroundColor: colors.surface,
        borderRadius: 10,
        paddingHorizontal: 10,
        paddingVertical: 9,
        borderWidth: 1,
        borderColor: value ? colors.primary : colors.border,
        opacity: pressed ? 0.82 : 1,
      })}
    >
      <Text style={{ color: colors.muted, fontSize: 11 }}>{label}</Text>
      <Text style={{ color: colors.foreground, fontSize: 14, fontWeight: "900", marginTop: 2 }}>📅 {prettyDate(value)}</Text>
    </Pressable>
  );
}

function DatePreset({ label, onPress }: { label: string; onPress: () => void }) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => ({
        paddingHorizontal: 12,
        paddingVertical: 7,
        borderRadius: 16,
        backgroundColor: colors.surface,
        borderWidth: 1,
        borderColor: colors.border,
        opacity: pressed ? 0.8 : 1,
      })}
    >
      <Text style={{ color: colors.foreground, fontWeight: "800", fontSize: 12 }}>{label}</Text>
    </Pressable>
  );
}

function DateRangeModal({
  cursor,
  setCursor,
  from,
  to,
  activeField,
  setActiveField,
  onPick,
  onClose,
}: {
  cursor: Date;
  setCursor: (d: Date) => void;
  from: string;
  to: string;
  activeField: "from" | "to";
  setActiveField: (f: "from" | "to") => void;
  onPick: (iso: string) => void;
  onClose: () => void;
}) {
  const colors = useColors();
  const days = calendarDays(cursor);
  const today = isoDate(new Date());
  const fromD = from || "";
  const toD = to || "";
  return (
    <View style={overlayStyle}>
      <View style={{ backgroundColor: colors.background, borderRadius: 14, padding: 12, maxHeight: "88%" }}>
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
          <Text style={{ color: colors.foreground, fontSize: 17, fontWeight: "900" }}>Zgjidh periudhën</Text>
          <Pressable onPress={onClose} hitSlop={10}><Text style={{ color: colors.error, fontSize: 24, fontWeight: "900" }}>×</Text></Pressable>
        </View>
        <Text style={{ color: colors.muted, fontSize: 11, marginBottom: 8 }}>Datat aplikohen menjëherë dhe raporti rifreskohet automatikisht.</Text>
        <View style={{ flexDirection: "row", gap: 8, marginBottom: 10 }}>
          <Pressable onPress={() => setActiveField("from")} style={{ flex: 1, borderRadius: 10, borderWidth: 1, borderColor: activeField === "from" ? colors.primary : colors.border, backgroundColor: activeField === "from" ? colors.primary + "22" : colors.surface, padding: 10 }}>
            <Text style={{ color: colors.muted, fontSize: 11 }}>Nga</Text>
            <Text style={{ color: colors.foreground, fontWeight: "900" }}>{prettyDate(fromD)}</Text>
          </Pressable>
          <Pressable onPress={() => setActiveField("to")} style={{ flex: 1, borderRadius: 10, borderWidth: 1, borderColor: activeField === "to" ? colors.primary : colors.border, backgroundColor: activeField === "to" ? colors.primary + "22" : colors.surface, padding: 10 }}>
            <Text style={{ color: colors.muted, fontSize: 11 }}>Deri</Text>
            <Text style={{ color: colors.foreground, fontWeight: "900" }}>{prettyDate(toD)}</Text>
          </Pressable>
        </View>
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
          <Pressable onPress={() => setCursor(addMonths(cursor, -1))} style={{ padding: 10 }}><Text style={{ color: colors.primary, fontSize: 18, fontWeight: "900" }}>‹</Text></Pressable>
          <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: "900", textTransform: "capitalize" }}>{monthTitle(cursor)}</Text>
          <Pressable onPress={() => setCursor(addMonths(cursor, 1))} style={{ padding: 10 }}><Text style={{ color: colors.primary, fontSize: 18, fontWeight: "900" }}>›</Text></Pressable>
        </View>
        <View style={{ flexDirection: "row", marginBottom: 4 }}>
          {["H", "M", "M", "E", "P", "S", "D"].map((d, i) => (
            <Text key={`${d}-${i}`} style={{ flex: 1, textAlign: "center", color: colors.muted, fontSize: 11, fontWeight: "900" }}>{d}</Text>
          ))}
        </View>
        <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
          {days.map((d) => {
            const iso = isoDate(d);
            const inMonth = d.getMonth() === cursor.getMonth();
            const selected = iso === fromD || iso === toD;
            const inRange = !!fromD && !!toD && iso >= fromD && iso <= toD;
            const isToday = iso === today;
            return (
              <Pressable
                key={iso}
                onPress={() => onPick(iso)}
                style={({ pressed }) => ({
                  width: "14.285%",
                  paddingVertical: 8,
                  alignItems: "center",
                  opacity: pressed ? 0.7 : inMonth ? 1 : 0.35,
                })}
              >
                <View style={{
                  width: 34,
                  height: 34,
                  borderRadius: 17,
                  alignItems: "center",
                  justifyContent: "center",
                  backgroundColor: selected ? colors.primary : inRange ? colors.primary + "22" : "transparent",
                  borderWidth: isToday && !selected ? 1 : 0,
                  borderColor: colors.primary,
                }}>
                  <Text style={{ color: selected ? "#fff" : colors.foreground, fontWeight: selected ? "900" : "700", fontSize: 12 }}>{d.getDate()}</Text>
                </View>
              </Pressable>
            );
          })}
        </View>
        <View style={{ flexDirection: "row", gap: 8, marginTop: 10 }}>
          <View style={{ flex: 1 }}><Btn title="Sot" variant="soft" onPress={() => { const t = isoDate(new Date()); onPick(t); }} /></View>
          <View style={{ flex: 1 }}><Btn title="Mbyll" onPress={onClose} /></View>
        </View>
      </View>
    </View>
  );
}

function FilterField({ label, value, onChange, placeholder }: { label: string; value: string; onChange: (v: string) => void; placeholder?: string }) {
  const colors = useColors();
  return (
    <View style={{ flex: 1, backgroundColor: colors.surface, borderRadius: 10, paddingHorizontal: 10, borderWidth: 1, borderColor: colors.border }}>
      <Text style={{ color: colors.muted, fontSize: 11, marginTop: 6 }}>{label}</Text>
      <TextInput value={value} onChangeText={onChange} placeholder={placeholder} placeholderTextColor={colors.muted} style={{ paddingVertical: 8, color: colors.foreground }} />
    </View>
  );
}

function MultiField({ label, values, onOpen, onClear }: { label: string; values?: string[]; onOpen: () => void; onClear: () => void }) {
  const colors = useColors();
  const count = values?.length || 0;
  return (
    <View style={{ flexBasis: "48%", flexGrow: 1 }}>
      <Pressable onPress={onOpen} style={{ backgroundColor: colors.surface, borderRadius: 10, paddingHorizontal: 10, paddingVertical: 8, borderWidth: 1, borderColor: count ? colors.primary : colors.border }}>
        <Text style={{ color: colors.muted, fontSize: 11 }}>{label}</Text>
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
          <Text style={{ color: count ? colors.foreground : colors.muted, fontWeight: "700", fontSize: 14 }} numberOfLines={1}>
            {count === 0 ? "Të gjithë" : count === 1 ? values![0] : `${count} të zgjedhur`}
          </Text>
          {count ? (
            <Pressable onPress={onClear} hitSlop={10} style={{ paddingHorizontal: 4 }}>
              <Text style={{ color: colors.error, fontWeight: "900" }}>×</Text>
            </Pressable>
          ) : null}
        </View>
      </Pressable>
    </View>
  );
}

const bottomOverlayStyle = {
  position: "absolute" as const,
  top: 0, left: 0, right: 0, bottom: 0,
  backgroundColor: "rgba(0,0,0,0.55)",
  justifyContent: "flex-end" as const,
};

const overlayStyle = {
  position: "absolute" as const,
  top: 0, left: 0, right: 0, bottom: 0,
  backgroundColor: "rgba(0,0,0,0.45)",
  justifyContent: "center" as const,
  padding: 14,
};
