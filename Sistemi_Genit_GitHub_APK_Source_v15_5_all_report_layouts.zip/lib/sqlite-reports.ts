import { REPORT_CATALOG, type ReportFilter, type ReportResult, type ReportType, type Column, type Row } from "./reports";
import { fmt } from "./store";
import { sqliteActiveCompanyId, sqliteAll, sqliteFirst } from "./sqlite-storage";

type SqlReport = ReportResult & { source?: "sqlite" };

type SqlParts = { where: string[]; params: any[] };

function norm(s?: string): string { return String(s || "").trim().toLowerCase().replace(/\s+/g, " "); }
function periodLabel(f: ReportFilter): string {
  if (f.from && f.to) return `${f.from} → ${f.to}`;
  if (f.from) return `Nga ${f.from}`;
  if (f.to) return `Deri ${f.to}`;
  return "Të gjitha datat";
}
function addDate(parts: SqlParts, col: string, f: ReportFilter) {
  if (f.from) { parts.where.push(`${col} >= ?`); parts.params.push(f.from); }
  if (f.to) { parts.where.push(`${col} <= ?`); parts.params.push(f.to); }
}
function addText(parts: SqlParts, col: string, list?: string[], single?: string) {
  if (list && list.length) {
    const cleaned = list.map(norm).filter(Boolean);
    if (cleaned.length) {
      parts.where.push(`LOWER(TRIM(${col})) IN (${cleaned.map(() => "?").join(",")})`);
      parts.params.push(...cleaned);
    }
  } else if (single && single.trim()) {
    parts.where.push(`LOWER(${col}) LIKE ?`);
    parts.params.push(`%${norm(single)}%`);
  }
}
function addTxn(parts: SqlParts, col: string, f: ReportFilter) {
  if (!f.txnType || f.txnType === "all") return;
  if (f.txnType === "cash") parts.where.push(`${col} = 'Me arke'`);
  else parts.where.push(`${col} <> 'Me arke'`);
}
function addPayStatus(parts: SqlParts, totalCol: string, paidCol: string, f: ReportFilter) {
  if (!f.payStatus || f.payStatus === "all") return;
  if (f.payStatus === "paid") parts.where.push(`${paidCol} >= ${totalCol} - 0.001`);
  else if (f.payStatus === "unpaid") parts.where.push(`${paidCol} <= 0.001`);
  else parts.where.push(`${paidCol} > 0.001 AND ${paidCol} < ${totalCol} - 0.001`);
}
function parsePriceFilter(price?: string): number[] {
  return String(price || "")
    .split(/[;,]/)
    .map((x) => Number(String(x).trim().replace(",", ".")))
    .filter((n) => Number.isFinite(n) && n >= 0);
}
function addPriceFilter(parts: SqlParts, rateCol: string, f: ReportFilter) {
  const prices = parsePriceFilter(f.price);
  if (!prices.length) return;
  parts.where.push(`ROUND(${rateCol}, 2) IN (${prices.map(() => "?").join(",")})`);
  parts.params.push(...prices.map((p) => Math.round(p * 100) / 100));
}
function docInvoiceWhere(companyId: string, f: ReportFilter): SqlParts {
  const p: SqlParts = { where: ["i.company_id = ?"], params: [companyId] };
  addDate(p, "i.date", f);
  addText(p, "i.customer", f.clients, f.client);
  addText(p, "i.store", f.stores, f.store);
  addText(p, "i.salesman", f.salesmen, f.salesman);
  addTxn(p, "i.mode", f);
  addPayStatus(p, "i.total", "i.paid", f);
  return p;
}
function docPurchaseWhere(companyId: string, f: ReportFilter): SqlParts {
  const p: SqlParts = { where: ["p.company_id = ?"], params: [companyId] };
  addDate(p, "p.date", f);
  addText(p, "p.supplier", f.suppliers, f.supplier);
  addText(p, "p.store", f.stores, f.store);
  addText(p, "p.salesman", f.salesmen, f.salesman);
  addTxn(p, "p.mode", f);
  addPayStatus(p, "p.total", "p.paid", f);
  return p;
}
function addLineFilters(parts: SqlParts, productCol: string, unitCol: string, categoryCol: string, f: ReportFilter, rateCol?: string) {
  addText(parts, productCol, f.products, f.product);
  addText(parts, unitCol, f.units, f.unit);
  addText(parts, categoryCol, f.categories, f.category);
  if (rateCol) addPriceFilter(parts, rateCol, f);
}
function hasSaleLineFilter(f: ReportFilter): boolean {
  return Boolean(
    (f.products && f.products.length) ||
    (f.product && f.product.trim()) ||
    (f.units && f.units.length) ||
    (f.unit && f.unit.trim()) ||
    (f.categories && f.categories.length) ||
    (f.category && f.category.trim()) ||
    (f.price && f.price.trim())
  );
}
function withSource(result: ReportResult): SqlReport {
  return { ...result, subtitle: result.subtitle ? `${result.subtitle} • Burimi: SQLite` : "Burimi: SQLite", source: "sqlite" };
}
async function companyIdOrNull(): Promise<string | null> {
  return await sqliteActiveCompanyId();
}
function sum(rows: Row[], key: string): number { return rows.reduce((s, r) => s + Number((r as any)[key] || 0), 0); }
const money = (n: number) => fmt(Number(n || 0));


function preferredReportUnits(f: ReportFilter): string[] {
  const out: string[] = [];
  if (f.reportUnit && f.reportUnit.trim()) out.push(f.reportUnit.trim());
  // If no explicit reporting unit was chosen, use the unit filter as display preference.
  if (!out.length && f.units && f.units.length) out.push(...f.units);
  return out;
}
function lineUnitCoef(unitsRaw: any, unitName?: string): number {
  const units = parseUnitsJson(unitsRaw);
  const found = units.find((u) => norm(u.name) === norm(unitName));
  return Math.max(1, Number(found?.coef || 1));
}
type SqlSaleLine = {
  date: string;
  no: number;
  party: string;
  store: string;
  product: string;
  unit: string;
  qty: number;
  freeQty: number;
  rate: number;
  value: number;
  cost: number;
  unitsJson?: string;
};
async function sqliteSaleLines(companyId: string, f: ReportFilter): Promise<SqlSaleLine[]> {
  const p = docInvoiceWhere(companyId, f);
  addLineFilters(p, "ii.product_name", "ii.unit", "COALESCE(pr.category,'')", f, "ii.rate");
  // Use invoice_items as the driving table. This is more robust for report
  // filters because the filter identity lives on the line itself:
  // product + unit + rate. Invoice header filters still apply through LEFT JOIN
  // to the matching invoice header.
  return await sqliteAll<SqlSaleLine>(
    `SELECT i.date, ii.invoice_no AS no, i.customer AS party, i.store,
            ii.product_name AS product, ii.unit, ii.qty, ii.free_qty AS freeQty,
            ii.rate, ii.total AS value, ii.cost, pr.units_json AS unitsJson
     FROM invoice_items ii
     JOIN invoices i ON i.company_id=ii.company_id AND i.invoice_no=ii.invoice_no
     LEFT JOIN products pr ON pr.company_id=ii.company_id AND LOWER(TRIM(pr.name))=LOWER(TRIM(ii.product_name))
     WHERE ${p.where.join(" AND ")}
     ORDER BY i.date, ii.invoice_no, ii.line_no`,
    p.params,
  );
}
function saleLineBaseQty(l: SqlSaleLine): number {
  return Number(l.qty || 0) * lineUnitCoef(l.unitsJson, l.unit);
}
function saleLineBaseFree(l: SqlSaleLine): number {
  return Number(l.freeQty || 0) * lineUnitCoef(l.unitsJson, l.unit);
}
function displayQty(baseQty: number, unitsJson: any, f: ReportFilter): string {
  return formatBaseQty(baseQty, unitsJson, preferredReportUnits(f));
}
function reportUnitLabel(unitsJson: any, f: ReportFilter, fallback?: string): string {
  const prefs = preferredReportUnits(f);
  const units = parseUnitsJson(unitsJson);
  const picked = pickDisplayUnit(units, prefs);
  if (prefs.length) return picked.name;
  return fallback || picked.name;
}
function stripReportUnit(qtyText: string, unit: string): string {
  const q = String(qtyText || "").trim();
  const u = String(unit || "").trim();
  if (!u) return q;
  return q.replace(new RegExp(`\\s*${u.replace(/[.*+?^${}()|[\\]\\]/g, "\\$&")}\\s*$`, "i"), "").trim() || q;
}
function salesDisplayProduct(product: string, qtyText: string, freeText: string, unit: string): string {
  const free = String(freeText || "").trim();
  if (!free || free === "0" || free === "0 Copë" || free === "0 Koli") return product;
  return `${product} (${stripReportUnit(qtyText, unit)}shit+${stripReportUnit(free, unit)})`;
}

// Unit-display helpers for reports whose quantities are stored in BASE units (copë).
// The unit chips in the UI are DISPLAY units, not only line filters.
type ProductUnit = { name: string; coef: number };
function parseUnitsJson(raw: any): ProductUnit[] {
  try {
    const arr = JSON.parse(String(raw || "[]"));
    if (!Array.isArray(arr)) return [{ name: "Copë", coef: 1 }];
    const units = arr
      .map((u: any) => ({ name: String(u?.name || "").trim() || "Copë", coef: Math.max(1, Number(u?.coef || 1)) }))
      .filter((u: ProductUnit) => u.name);
    return units.length ? units : [{ name: "Copë", coef: 1 }];
  } catch {
    return [{ name: "Copë", coef: 1 }];
  }
}
function pickDisplayUnit(units: ProductUnit[], preferred?: string[]): ProductUnit {
  const prefs = (preferred || []).map(norm).filter(Boolean);
  for (const p of prefs) {
    const found = units.find((u) => norm(u.name) === p);
    if (found) return found;
  }
  return units.slice().sort((a, b) => b.coef - a.coef)[0] || { name: "Copë", coef: 1 };
}
function formatBaseQty(baseQty: number, unitsRaw: any, preferred?: string[]): string {
  const units = parseUnitsJson(unitsRaw).sort((a, b) => a.coef - b.coef);
  const baseUnit = units[0] || { name: "Copë", coef: 1 };
  const wanted = pickDisplayUnit(units, preferred);
  const base = Number(baseQty || 0);
  if (!wanted || wanted.coef <= 1) return `${fmt(base)} ${baseUnit.name}`;
  const sign = base < 0 ? -1 : 1;
  const abs = Math.abs(base);
  const whole = Math.floor(abs / wanted.coef);
  const rest = Number((abs - whole * wanted.coef).toFixed(6));
  const signedWhole = whole * sign;
  if (rest <= 0.000001) return `${fmt(signedWhole)} ${wanted.name}`;
  if (whole === 0) return `${fmt(rest * sign)} ${baseUnit.name}`;
  // Exact mixed-unit display: 45 Koli + 6 Copë, not rounded to 46 Koli.
  return `${fmt(signedWhole)} ${wanted.name} + ${fmt(rest)} ${baseUnit.name}`;
}


function retitled(report: SqlReport | null, type: ReportType, title: string, subtitleSuffix?: string): SqlReport | null {
  if (!report) return null;
  return {
    ...report,
    type,
    title,
    subtitle: subtitleSuffix ? `${report.subtitle || ""} • ${subtitleSuffix}` : report.subtitle,
  };
}
function docStockWhere(companyId: string, f: ReportFilter): SqlParts {
  const p: SqlParts = { where: ["sm.company_id = ?"], params: [companyId] };
  addDate(p, "sm.date", f);
  addText(p, "sm.warehouse", f.stores, f.store);
  addText(p, "sm.product_name", f.products, f.product);
  return p;
}
function expenseWhere(companyId: string, f: ReportFilter): SqlParts {
  const p: SqlParts = { where: ["e.company_id = ?"], params: [companyId] };
  addDate(p, "e.date", f);
  addText(p, "e.category", f.categories, f.category);
  return p;
}
function paymentPartyFilter(parts: SqlParts, partyCol: string, f: ReportFilter, partyType: "customer" | "supplier") {
  if (partyType === "customer") addText(parts, partyCol, f.clients, f.client);
  else addText(parts, partyCol, f.suppliers, f.supplier);
}
function genericRowsReport(type: ReportType, title: string, subtitle: string, rows: Row[], columns: Column[], summary?: { label: string; value: string }[]): SqlReport {
  return withSource({ type, title, subtitle, columns, rows, summary });
}

export async function buildSqliteReport(type: ReportType, f: ReportFilter): Promise<SqlReport | null> {
  const companyId = await companyIdOrNull();
  if (!companyId) return null;
  const sub = periodLabel(f);

  if (type === "salesSummary") {
    const p = docInvoiceWhere(companyId, f);
    if (hasSaleLineFilter(f)) {
      addLineFilters(p, "ii.product_name", "ii.unit", "COALESCE(pr.category,'')", f, "ii.rate");
      const rows = await sqliteAll<Row>(
        `SELECT i.invoice_no AS no, i.date, i.customer, COUNT(*) AS rows, SUM(ii.total) AS total, SUM(ii.total - ii.cost) AS profit
         FROM invoices i
         JOIN invoice_items ii ON ii.company_id=i.company_id AND ii.invoice_no=i.invoice_no
         LEFT JOIN products pr ON pr.company_id=i.company_id AND LOWER(pr.name)=LOWER(ii.product_name)
         WHERE ${p.where.join(" AND ")}
         GROUP BY i.invoice_no, i.date, i.customer
         ORDER BY i.date, i.invoice_no`,
        p.params,
      );
      return withSource({ type, title: "Regjistri Përmbledhës i Shitjeve", subtitle: `${sub} • Filtër sipas rreshtave: Artikull + Njësi + Çmim`, columns: [
        { key: "no", label: "Nr." }, { key: "date", label: "Data" }, { key: "customer", label: "Klienti" }, { key: "rows", label: "Rreshta", align: "right", format: "qty" },
        { key: "total", label: "Vlera e filtruar", align: "right", format: "money" }, { key: "profit", label: "Fitim", align: "right", format: "money" }],
        rows, summary: [{ label: "Fatura", value: String(rows.length) }, { label: "Vlerë e filtruar", value: money(sum(rows, "total")) }, { label: "Fitim", value: money(sum(rows, "profit")) }] });
    }
    const rows = await sqliteAll<Row>(`SELECT invoice_no AS no, date, customer, total, paid, due, profit FROM invoices i WHERE ${p.where.join(" AND ")} ORDER BY date, invoice_no`, p.params);
    return withSource({ type, title: "Regjistri Përmbledhës i Shitjeve", subtitle: sub, columns: [
      { key: "no", label: "Nr." }, { key: "date", label: "Data" }, { key: "customer", label: "Klienti" },
      { key: "total", label: "Totali", align: "right", format: "money" }, { key: "paid", label: "Paguar", align: "right", format: "money" }, { key: "due", label: "Detyrim", align: "right", format: "money" }, { key: "profit", label: "Fitim", align: "right", format: "money" }],
      rows, summary: [{ label: "Fatura", value: String(rows.length) }, { label: "Vlerë shitje", value: money(sum(rows, "total")) }, { label: "Paguar", value: money(sum(rows, "paid")) }, { label: "Detyrim", value: money(sum(rows, "due")) }, { label: "Fitim", value: money(sum(rows, "profit")) }] });
  }

  if (type === "salesAnalytic") {
    const lines = await sqliteSaleLines(companyId, f);
    const rows = lines.map((l) => {
      const baseQty = saleLineBaseQty(l);
      const baseFree = saleLineBaseFree(l);
      return {
        date: l.date,
        no: l.no,
        party: l.party,
        product: l.product,
        unit: reportUnitLabel(l.unitsJson, f, l.unit),
        qty: displayQty(baseQty, l.unitsJson, f),
        freeQty: baseFree ? displayQty(baseFree, l.unitsJson, f) : "0",
        physicalQty: displayQty(baseQty + baseFree, l.unitsJson, f),
        rate: l.rate,
        value: l.value,
        profit: Number(l.value || 0) - Number(l.cost || 0),
      };
    });
    return withSource({ type, title: "Regjistri Analitik i Shitjeve", subtitle: `${sub} • Filtrat realë: Artikull + Njësi shitje + Çmim • Njësia raporti: ${f.reportUnit || "Auto"}`, columns: [
      { key: "date", label: "Data" }, { key: "no", label: "Nr." }, { key: "party", label: "Klienti" }, { key: "product", label: "Artikulli" }, { key: "unit", label: "Njësia raporti" }, { key: "qty", label: "Sasia" }, { key: "freeQty", label: "Dhuratë" }, { key: "physicalQty", label: "Tot. fizik" }, { key: "rate", label: "Çmimi", align: "right", format: "money" }, { key: "value", label: "Vlera", align: "right", format: "money" }, { key: "profit", label: "Fitim", align: "right", format: "money" }],
      rows, summary: [{ label: "Rreshta", value: String(rows.length) }, { label: "Vlerë", value: money(sum(rows, "value")) }, { label: "Fitim", value: money(sum(rows, "profit")) }] });
  }


  if (type === "salesByProduct") {
    const lines = await sqliteSaleLines(companyId, f);
    type G = { product: string; unit: string; unitsJson?: string; rate: number; baseQty: number; baseFree: number; value: number; cost: number; profit: number };
    const map = new Map<string, G>();
    const useReportUnit = Boolean(f.reportUnit && f.reportUnit.trim());
    for (const l of lines) {
      const rate = Math.round(Number(l.rate || 0) * 100) / 100;
      const keyUnit = useReportUnit ? `REPORT:${f.reportUnit}` : norm(l.unit);
      const k = `${norm(l.product)}|${keyUnit}|${rate}`;
      const cur = map.get(k) || { product: l.product, unit: reportUnitLabel(l.unitsJson, f, l.unit), unitsJson: l.unitsJson, rate, baseQty: 0, baseFree: 0, value: 0, cost: 0, profit: 0 };
      cur.baseQty += saleLineBaseQty(l);
      cur.baseFree += saleLineBaseFree(l);
      cur.value += Number(l.value || 0);
      cur.cost += Number(l.cost || 0);
      cur.profit += Number(l.value || 0) - Number(l.cost || 0);
      map.set(k, cur);
    }
    const rows = [...map.values()].sort((a, b) => a.product.localeCompare(b.product) || b.value - a.value).map((g) => {
      const qtyText = displayQty(g.baseQty, g.unitsJson, f);
      const freeText = g.baseFree ? displayQty(g.baseFree, g.unitsJson, f) : "0";
      return {
        product: salesDisplayProduct(g.product, qtyText, freeText, g.unit),
        qty: stripReportUnit(qtyText, g.unit),
        unit: g.unit,
        rate: g.rate,
        value: g.value,
        freeQty: freeText,
        physicalQty: displayQty(g.baseQty + g.baseFree, g.unitsJson, f),
        cost: g.cost,
        profit: g.profit,
      };
    });
    if (rows.length > 0) rows.push({ _total: 1, product: "Total", qty: "", unit: "", rate: "", value: sum(rows, "value") } as any);
    return withSource({ type, title: "Shitje sipas artikullit", subtitle: `${sub} • Forma: Artikull / Sasi / Njësi / Çmim / Vlerë`, columns: [
      { key: "product", label: "Item Name" }, { key: "qty", label: "Sasi", align: "right", format: "qty" }, { key: "unit", label: "Njesi" }, { key: "rate", label: "Cmimi", align: "right", format: "money" }, { key: "value", label: "Vlere", align: "right", format: "money" }],
      rows, summary: [{ label: "Artikuj", value: String(map.size) }, { label: "Total", value: money(sum(rows, "value")) }] });
  }




  if (type === "salesByClient") {
    const p = docInvoiceWhere(companyId, f);
    if (hasSaleLineFilter(f)) {
      addLineFilters(p, "ii.product_name", "ii.unit", "COALESCE(pr.category,'')", f, "ii.rate");
      const rows = await sqliteAll<Row>(
        `SELECT i.customer AS party, COUNT(DISTINCT i.invoice_no) AS count, SUM(ii.total) AS total, SUM(ii.total - ii.cost) AS profit
         FROM invoices i
         JOIN invoice_items ii ON ii.company_id=i.company_id AND ii.invoice_no=i.invoice_no
         LEFT JOIN products pr ON pr.company_id=i.company_id AND LOWER(pr.name)=LOWER(ii.product_name)
         WHERE ${p.where.join(" AND ")}
         GROUP BY i.customer
         ORDER BY total DESC`,
        p.params,
      );
      return withSource({ type, title: "Shitje sipas klientit", subtitle: `${sub} • Totalet janë sipas rreshtave të filtruar`, columns: [
        { key: "party", label: "Klienti" }, { key: "count", label: "Fatura", align: "right", format: "qty" }, { key: "total", label: "Vlera e filtruar", align: "right", format: "money" }, { key: "profit", label: "Fitim", align: "right", format: "money" }],
        rows, summary: [{ label: "Total", value: money(sum(rows, "total")) }] });
    }
    const rows = await sqliteAll<Row>(`SELECT customer AS party, COUNT(*) AS count, SUM(total) AS total, SUM(profit) AS profit, SUM(due) AS due FROM invoices i WHERE ${p.where.join(" AND ")} GROUP BY customer ORDER BY total DESC`, p.params);
    return withSource({ type, title: "Shitje sipas klientit", subtitle: sub, columns: [
      { key: "party", label: "Klienti" }, { key: "count", label: "Fatura", align: "right", format: "qty" }, { key: "total", label: "Totali", align: "right", format: "money" }, { key: "profit", label: "Fitim", align: "right", format: "money" }, { key: "due", label: "Detyrim", align: "right", format: "money" }],
      rows, summary: [{ label: "Total", value: money(sum(rows, "total")) }] });
  }

  if (type === "salesDaily") {
    const p = docInvoiceWhere(companyId, f);
    if (hasSaleLineFilter(f)) {
      addLineFilters(p, "ii.product_name", "ii.unit", "COALESCE(pr.category,'')", f, "ii.rate");
      const rows = await sqliteAll<Row>(
        `SELECT i.date, COUNT(DISTINCT i.invoice_no) AS count, SUM(ii.total) AS total, SUM(ii.total - ii.cost) AS profit
         FROM invoices i
         JOIN invoice_items ii ON ii.company_id=i.company_id AND ii.invoice_no=i.invoice_no
         LEFT JOIN products pr ON pr.company_id=i.company_id AND LOWER(pr.name)=LOWER(ii.product_name)
         WHERE ${p.where.join(" AND ")}
         GROUP BY i.date
         ORDER BY i.date`,
        p.params,
      );
      return withSource({ type, title: "Shitje ditore", subtitle: `${sub} • Totalet janë sipas rreshtave të filtruar`, columns: [
        { key: "date", label: "Data" }, { key: "count", label: "Fatura", align: "right", format: "qty" }, { key: "total", label: "Vlera e filtruar", align: "right", format: "money" }, { key: "profit", label: "Fitim", align: "right", format: "money" }],
        rows, summary: [{ label: "Total", value: money(sum(rows, "total")) }] });
    }
    const rows = await sqliteAll<Row>(`SELECT date, COUNT(*) AS count, SUM(total) AS total, SUM(profit) AS profit FROM invoices i WHERE ${p.where.join(" AND ")} GROUP BY date ORDER BY date`, p.params);
    return withSource({ type, title: "Shitje ditore", subtitle: sub, columns: [
      { key: "date", label: "Data" }, { key: "count", label: "Fatura", align: "right", format: "qty" }, { key: "total", label: "Totali", align: "right", format: "money" }, { key: "profit", label: "Fitim", align: "right", format: "money" }], rows });
  }

  if (type === "salesSummaryInvoice") {
    const p = docInvoiceWhere(companyId, f);
    if (hasSaleLineFilter(f)) {
      addLineFilters(p, "ii.product_name", "ii.unit", "COALESCE(pr.category,'')", f, "ii.rate");
      const rows = await sqliteAll<Row>(
        `SELECT i.date, i.customer AS party, SUM(ii.total) AS total, SUM(ii.total - ii.cost) AS profit
         FROM invoices i
         JOIN invoice_items ii ON ii.company_id=i.company_id AND ii.invoice_no=i.invoice_no
         LEFT JOIN products pr ON pr.company_id=i.company_id AND LOWER(pr.name)=LOWER(ii.product_name)
         WHERE ${p.where.join(" AND ")}
         GROUP BY i.date, i.customer
         ORDER BY i.date, i.customer`,
        p.params,
      );
      return withSource({ type, title: "Faturë përmbledhëse shitje", subtitle: `${sub} • Totalet janë sipas rreshtave të filtruar`, columns: [
        { key: "date", label: "Data" }, { key: "party", label: "Klienti" }, { key: "total", label: "Vlera e filtruar", align: "right", format: "money" }, { key: "profit", label: "Fitim", align: "right", format: "money" }], rows, summary: [{ label: "Vlerë", value: money(sum(rows, "total")) }] });
    }
    const rows = await sqliteAll<Row>(`SELECT date, customer AS party, SUM(total) AS total, SUM(profit) AS profit FROM invoices i WHERE ${p.where.join(" AND ")} GROUP BY date, customer ORDER BY date, customer`, p.params);
    return withSource({ type, title: "Faturë përmbledhëse shitje", subtitle: sub, columns: [
      { key: "date", label: "Data" }, { key: "party", label: "Klienti" }, { key: "total", label: "Totali", align: "right", format: "money" }, { key: "profit", label: "Fitim", align: "right", format: "money" }], rows, summary: [{ label: "Vlerë", value: money(sum(rows, "total")) }] });
  }


  if (type === "salesByUnit") {
    const lines = await sqliteSaleLines(companyId, f);
    type G = { unit: string; unitsJson?: string; baseQty: number; baseFree: number; value: number };
    const map = new Map<string, G>();
    for (const l of lines) {
      const u = reportUnitLabel(l.unitsJson, f, l.unit);
      const cur = map.get(u) || { unit: u, unitsJson: l.unitsJson, baseQty: 0, baseFree: 0, value: 0 };
      cur.baseQty += saleLineBaseQty(l);
      cur.baseFree += saleLineBaseFree(l);
      cur.value += Number(l.value || 0);
      map.set(u, cur);
    }
    const rows = [...map.values()].map((g) => ({ unit: g.unit, qty: displayQty(g.baseQty, g.unitsJson, f), freeQty: g.baseFree ? displayQty(g.baseFree, g.unitsJson, f) : "0", physicalQty: displayQty(g.baseQty + g.baseFree, g.unitsJson, f), value: g.value }));
    return withSource({ type, title: "Shitje sipas njësisë", subtitle: `${sub} • Njësia raporti: ${f.reportUnit || "Auto"}`, columns: [
      { key: "unit", label: "Njësia raporti" }, { key: "qty", label: "Sasia" }, { key: "freeQty", label: "Dhuratë" }, { key: "physicalQty", label: "Tot. fizik" }, { key: "value", label: "Vlerë", align: "right", format: "money" }], rows });
  }

  if (type === "faturaTeresot") {
    const day = new Date().toISOString().slice(0, 10);
    const ff: ReportFilter = (f.from || f.to) ? f : { ...f, from: day, to: day };
    const lines = await sqliteSaleLines(companyId, ff);
    const rows = lines.map((l) => {
      const baseQty = saleLineBaseQty(l);
      const baseFree = saleLineBaseFree(l);
      return {
        no: l.no,
        date: l.date,
        product: l.product,
        unit: reportUnitLabel(l.unitsJson, ff, l.unit),
        qtySold: displayQty(baseQty, l.unitsJson, ff),
        qtyFree: baseFree ? displayQty(baseFree, l.unitsJson, ff) : "0",
        physicalQty: displayQty(baseQty + baseFree, l.unitsJson, ff),
        rate: l.rate,
        value: l.value,
      };
    });
    return withSource({ type, title: "Fatura Totale Sot", subtitle: `${ff.from || day} → ${ff.to || day} • Filtrat realë zbatohen mbi rreshtat e faturës`, columns: [
      { key: "no", label: "Nr." }, { key: "date", label: "Data" }, { key: "product", label: "Artikulli" }, { key: "unit", label: "Njësia raporti" }, { key: "qtySold", label: "Sasi shitur" }, { key: "qtyFree", label: "Dhuratë" }, { key: "physicalQty", label: "Tot. fizik" }, { key: "rate", label: "Çmimi", align: "right", format: "money" }, { key: "value", label: "Vlerë", align: "right", format: "money" }],
      rows, summary: [{ label: "Fatura", value: String(new Set(lines.map((l) => l.no)).size) }, { label: "Rreshta", value: String(rows.length) }, { label: "Vlerë totale", value: money(sum(rows, "value")) }] });
  }

  if (type === "shitjeSot") {
    const day = new Date().toISOString().slice(0, 10);
    const ff: ReportFilter = (f.from || f.to) ? f : { ...f, from: day, to: day };
    const lines = await sqliteSaleLines(companyId, ff);
    type G = { product: string; unit: string; unitsJson?: string; rate: number; baseQty: number; baseFree: number; value: number };
    const map = new Map<string, G>();
    const useReportUnit = Boolean(ff.reportUnit && ff.reportUnit.trim());
    for (const l of lines) {
      const rate = Math.round(Number(l.rate || 0) * 100) / 100;
      const keyUnit = useReportUnit ? `REPORT:${ff.reportUnit}` : norm(l.unit);
      const k = `${norm(l.product)}|${keyUnit}|${rate}`;
      const cur = map.get(k) || { product: l.product, unit: reportUnitLabel(l.unitsJson, ff, l.unit), unitsJson: l.unitsJson, rate, baseQty: 0, baseFree: 0, value: 0 };
      cur.baseQty += saleLineBaseQty(l);
      cur.baseFree += saleLineBaseFree(l);
      cur.value += Number(l.value || 0);
      map.set(k, cur);
    }
    const groups = [...map.values()].sort((a, b) => a.product.localeCompare(b.product) || b.value - a.value);
    const rows = groups.map((g) => {
      const qtyText = displayQty(g.baseQty, g.unitsJson, ff);
      const freeText = g.baseFree ? displayQty(g.baseFree, g.unitsJson, ff) : "0";
      return {
        product: salesDisplayProduct(g.product, qtyText, freeText, g.unit),
        qty: stripReportUnit(qtyText, g.unit),
        unit: g.unit,
        rate: g.rate,
        value: g.value,
        freeQty: freeText,
        physicalQty: displayQty(g.baseQty + g.baseFree, g.unitsJson, ff),
      };
    });
    if (rows.length > 0) rows.push({ _total: 1, product: "Total", qty: "", unit: "", rate: "", value: sum(rows, "value") } as any);
    return withSource({ type, title: "Shitje Sot", subtitle: `${ff.from || day} → ${ff.to || day} • Forma si regjistër ditor`, columns: [
      { key: "product", label: "Item Name" }, { key: "qty", label: "Sasi", align: "right", format: "qty" }, { key: "unit", label: "Njesi" }, { key: "rate", label: "Cmimi", align: "right", format: "money" }, { key: "value", label: "Vlere", align: "right", format: "money" }],
      rows, summary: [{ label: "Artikuj", value: String(groups.length) }, { label: "Total", value: money(sum(rows, "value")) }] });
  }

  if (type === "purchaseAnalytic") {
    const p = docPurchaseWhere(companyId, f); addLineFilters(p, "pi.product_name", "pi.unit", "COALESCE(pr.category,'')", f);
    const rows = await sqliteAll<Row>(`SELECT p.date, p.purchase_no AS no, p.supplier AS party, pi.product_name AS product, pi.unit, pi.qty, pi.free_qty AS freeQty, (pi.qty + pi.free_qty) AS physicalQty, pi.rate, pi.total AS value, pi.cost FROM purchases p JOIN purchase_items pi ON pi.company_id=p.company_id AND pi.purchase_no=p.purchase_no LEFT JOIN products pr ON pr.company_id=p.company_id AND LOWER(pr.name)=LOWER(pi.product_name) WHERE ${p.where.join(" AND ")} ORDER BY p.date, p.purchase_no, pi.line_no`, p.params);
    return withSource({ type, title: "Regjistri Analitik i Blerjeve", subtitle: sub, columns: [{ key: "date", label: "Data" }, { key: "no", label: "Nr." }, { key: "party", label: "Furnitori" }, { key: "product", label: "Artikulli" }, { key: "unit", label: "Njësia" }, { key: "qty", label: "Sasia", align: "right", format: "qty" }, { key: "freeQty", label: "Dhuratë", align: "right", format: "qty" }, { key: "physicalQty", label: "Tot. fizik", align: "right", format: "qty" }, { key: "rate", label: "Çmimi", align: "right", format: "money" }, { key: "value", label: "Vlera", align: "right", format: "money" }], rows, summary: [{ label: "Rreshta", value: String(rows.length) }, { label: "Vlerë", value: money(sum(rows, "value")) }] });
  }

  if (type === "purchaseBySupplier") {
    const p = docPurchaseWhere(companyId, f);
    const rows = await sqliteAll<Row>(`SELECT supplier AS party, COUNT(*) AS count, SUM(total) AS total, SUM(paid) AS paid, SUM(due) AS due FROM purchases p WHERE ${p.where.join(" AND ")} GROUP BY supplier ORDER BY total DESC`, p.params);
    return withSource({ type, title: "Blerje sipas furnitorit", subtitle: sub, columns: [{ key: "party", label: "Furnitori" }, { key: "count", label: "Fatura", align: "right", format: "qty" }, { key: "total", label: "Totali", align: "right", format: "money" }, { key: "paid", label: "Paguar", align: "right", format: "money" }, { key: "due", label: "Detyrim", align: "right", format: "money" }], rows, summary: [{ label: "Total", value: money(sum(rows, "total")) }] });
  }

  if (type === "purchaseByProduct") {
    const p = docPurchaseWhere(companyId, f); addLineFilters(p, "pi.product_name", "pi.unit", "COALESCE(pr.category,'')", f);
    const rows = await sqliteAll<Row>(`SELECT pi.product_name AS product, pi.unit, SUM(pi.qty) AS qty, SUM(pi.free_qty) AS freeQty, SUM(pi.qty + pi.free_qty) AS physicalQty, SUM(pi.total) AS value, SUM(pi.cost) AS cost FROM purchases p JOIN purchase_items pi ON pi.company_id=p.company_id AND pi.purchase_no=p.purchase_no LEFT JOIN products pr ON pr.company_id=p.company_id AND LOWER(pr.name)=LOWER(pi.product_name) WHERE ${p.where.join(" AND ")} GROUP BY pi.product_name, pi.unit ORDER BY value DESC`, p.params);
    return withSource({ type, title: "Blerje sipas artikullit", subtitle: sub, columns: [{ key: "product", label: "Artikulli" }, { key: "unit", label: "Njësia" }, { key: "qty", label: "Sasia", align: "right", format: "qty" }, { key: "freeQty", label: "Dhuratë", align: "right", format: "qty" }, { key: "physicalQty", label: "Tot. fizik", align: "right", format: "qty" }, { key: "value", label: "Vlerë", align: "right", format: "money" }, { key: "cost", label: "Kosto", align: "right", format: "money" }], rows, summary: [{ label: "Vlerë", value: money(sum(rows, "value")) }] });
  }

  if (type === "stockSummary") {
    const p: SqlParts = { where: ["company_id = ?"], params: [companyId] };
    addText(p, "name", f.products, f.product); addText(p, "default_store", f.stores, f.store); addText(p, "category", f.categories, f.category);
    const rows = await sqliteAll<Row>(`SELECT name AS product, category, default_store AS store, stock_base AS stock, min_stock AS minStock, sale_piece AS salePiece, buy_piece AS buyPiece, (stock_base * buy_piece) AS stockValue FROM products WHERE ${p.where.join(" AND ")} ORDER BY name`, p.params);
    return withSource({ type, title: "Gjendja aktuale e stokut", subtitle: sub, columns: [{ key: "product", label: "Artikulli" }, { key: "category", label: "Kategori" }, { key: "store", label: "Magazina" }, { key: "stock", label: "Gjendje copë", align: "right", format: "qty" }, { key: "minStock", label: "Min." , align: "right", format: "qty"}, { key: "buyPiece", label: "Kosto/copë", align: "right", format: "money" }, { key: "stockValue", label: "Vlerë stoku", align: "right", format: "money" }], rows, summary: [{ label: "Artikuj", value: String(rows.length) }, { label: "Vlerë stoku", value: money(sum(rows, "stockValue")) }] });
  }

  if (type === "stockMovement") {
    const p: SqlParts = { where: ["company_id = ?"], params: [companyId] };
    addDate(p, "date", f); addText(p, "warehouse", f.stores, f.store); addText(p, "product_name", f.products, f.product);
    const rows = await sqliteAll<Row>(`SELECT date, doc_no AS no, warehouse AS store, product_name AS product, doc_type AS type, in_base AS inBase, out_base AS outBase, balance_after AS balance, note FROM stock_movements WHERE ${p.where.join(" AND ")} ORDER BY date, movement_id`, p.params);
    return withSource({ type, title: "Lëvizjet e magazinës", subtitle: sub, columns: [{ key: "date", label: "Data" }, { key: "no", label: "Dok." }, { key: "store", label: "Magazina" }, { key: "product", label: "Artikulli" }, { key: "type", label: "Lloji" }, { key: "inBase", label: "Hyrje", align: "right", format: "qty" }, { key: "outBase", label: "Dalje", align: "right", format: "qty" }, { key: "balance", label: "Gjendje", align: "right", format: "qty" }, { key: "note", label: "Shënim" }], rows });
  }

  if (type === "inboundDocsReport" || type === "outboundDocsReport" || type === "inventoryDocsReport") {
    const kind = type === "inboundDocsReport" ? "inbound" : type === "outboundDocsReport" ? "outbound" : "inventory";
    const title = kind === "inbound" ? "Raporti Fletë Hyrje" : kind === "outbound" ? "Raporti Fletë Dalje" : "Raporti Inventar Fizik";
    const p: SqlParts = { where: ["company_id = ?", "doc_kind = ?"], params: [companyId, kind] };
    addDate(p, "date", f); addText(p, "warehouse", f.stores, f.store);
    const rows = await sqliteAll<Row>(`SELECT doc_no AS no, date, warehouse AS store, party, destination_address AS destination, total_qty AS qty, total_value AS value, status FROM warehouse_docs WHERE ${p.where.join(" AND ")} ORDER BY date, doc_id`, p.params);
    return withSource({ type, title, subtitle: sub, columns: [{ key: "no", label: "Nr." }, { key: "date", label: "Data" }, { key: "store", label: "Magazina" }, { key: "party", label: "Palë" }, { key: "destination", label: "Destinacion" }, { key: "qty", label: "Sasi" , align: "right", format: "qty"}, { key: "value", label: "Vlerë" , align: "right", format: "money"}, { key: "status", label: "Status" }], rows, summary: [{ label: "Dokumente", value: String(rows.length) }] });
  }

  if (type === "supplyNeed" || type === "kerkeseFurnizimi") {
    // V11: Kërkesë Furnizimi is the counterpart of Shitje Sot / Dalje:
    // whatever physically left the warehouse in the selected period becomes the
    // quantity requested for replenishment. No price/value columns here.
    const p: SqlParts = { where: ["company_id = ?", "out_base > 0"], params: [companyId] };
    addDate(p, "date", f);
    addText(p, "warehouse", f.stores, f.store);
    addText(p, "product_name", f.products, f.product);
    const rawRows = await sqliteAll<Row>(
      `SELECT sm.product_name AS product,
              sm.warehouse AS store,
              SUM(sm.out_base) AS needBase,
              pr.units_json AS unitsJson,
              GROUP_CONCAT(DISTINCT sm.doc_no) AS docs
       FROM stock_movements sm
       LEFT JOIN products pr ON pr.company_id=sm.company_id AND LOWER(pr.name)=LOWER(sm.product_name)
       WHERE ${p.where.join(" AND ").replace(/\bcompany_id\b/g, "sm.company_id").replace(/\bdate\b/g, "sm.date").replace(/\bwarehouse\b/g, "sm.warehouse").replace(/\bproduct_name\b/g, "sm.product_name")}
         AND sm.doc_type IN ('sale','gift','outbound','transfer-out')
       GROUP BY sm.product_name, sm.warehouse, pr.units_json
       HAVING SUM(sm.out_base) > 0
       ORDER BY sm.product_name, sm.warehouse`,
      p.params,
    );
    const rows = rawRows.map((r: any) => ({
      product: r.product,
      store: r.store,
      need: formatBaseQty(Number(r.needBase || 0), r.unitsJson, f.units || (f.unit ? [f.unit] : [])),
      baseQty: Number(r.needBase || 0),
      docs: r.docs || "",
    }));
    return withSource({
      type,
      title: "Kërkesë Furnizimi sipas Daljeve",
      subtitle: `${sub} • Çfarë doli/shit = çfarë furnizohet • Pa çmime/vlera • Njësia sipas filtrit`,
      columns: [
        { key: "product", label: "Artikulli" },
        { key: "store", label: "Magazina/Furgoni" },
        { key: "need", label: "Sasia për furnizim" },
        { key: "docs", label: "Dokumente dalje" },
      ],
      rows,
      summary: [
        { label: "Artikuj për furnizim", value: String(rows.length) },
        { label: "Sasi totale bazë", value: `${fmt(rows.reduce((a: number, r: any) => a + Number(r.baseQty || 0), 0))} Copë` },
      ],
    });
  }

  if (type === "clientBalances" || type === "supplierBalances") {
    const partyType = type === "clientBalances" ? "customer" : "supplier";
    const partyLabel = type === "clientBalances" ? "Klienti" : "Furnitori";
    const docTable = type === "clientBalances" ? "invoices" : "purchases";
    const partyCol = type === "clientBalances" ? "customer" : "supplier";
    const title = type === "clientBalances" ? "Detyrime sipas klientëve" : "Detyrime sipas furnitorëve";
    const p: SqlParts = { where: ["pt.company_id = ?", "pt.party_type = ?"], params: [companyId, partyType] };
    if (partyType === "customer") addText(p, "pt.name", f.clients, f.client); else addText(p, "pt.name", f.suppliers, f.supplier);
    const rows = await sqliteAll<Row>(`SELECT pt.name AS party, COALESCE(pt.opening_balance,0) AS opening, COALESCE(d.total,0) AS billed, COALESCE(d.due,0) AS due, COALESCE(pay.paid,0) AS paidExtra, COALESCE(pt.opening_balance,0) + COALESCE(d.due,0) - COALESCE(pay.paid,0) AS balance FROM parties pt LEFT JOIN (SELECT company_id, ${partyCol} AS party, SUM(total) AS total, SUM(due) AS due FROM ${docTable} GROUP BY company_id, ${partyCol}) d ON d.company_id=pt.company_id AND LOWER(d.party)=LOWER(pt.name) LEFT JOIN (SELECT company_id, party, SUM(amount) AS paid FROM payments WHERE party_type='${partyType}' GROUP BY company_id, party) pay ON pay.company_id=pt.company_id AND LOWER(pay.party)=LOWER(pt.name) WHERE ${p.where.join(" AND ")} ORDER BY balance DESC, pt.name`, p.params);
    return withSource({ type, title, subtitle: sub, columns: [{ key: "party", label: partyLabel }, { key: "opening", label: "Hapje", align: "right", format: "money" }, { key: "billed", label: "Faturuar", align: "right", format: "money" }, { key: "due", label: "Detyrim fature", align: "right", format: "money" }, { key: "paidExtra", label: "Pagesa", align: "right", format: "money" }, { key: "balance", label: "Balancë", align: "right", format: "money" }], rows, summary: [{ label: "Balancë totale", value: money(sum(rows, "balance")) }] });
  }


  if (type === "salesInvoiceBatch") {
    const p = docInvoiceWhere(companyId, f);
    const rows = await sqliteAll<Row>(`SELECT invoice_no AS no, date, customer, store, mode, total, paid, due, profit FROM invoices i WHERE ${p.where.join(" AND ")} ORDER BY date, invoice_no`, p.params);
    return withSource({ type, title: "Fatura shitje të renditura", subtitle: sub, columns: [
      { key: "no", label: "Nr." }, { key: "date", label: "Data" }, { key: "customer", label: "Klienti" }, { key: "store", label: "Magazina" }, { key: "mode", label: "Lloji" },
      { key: "total", label: "Totali", align: "right", format: "money" }, { key: "paid", label: "Paguar", align: "right", format: "money" }, { key: "due", label: "Detyrim", align: "right", format: "money" }, { key: "profit", label: "Fitim", align: "right", format: "money" }
    ], rows, summary: [{ label: "Fatura", value: String(rows.length) }, { label: "Total", value: money(sum(rows, "total")) }, { label: "Detyrim", value: money(sum(rows, "due")) }] });
  }

  if (type === "managerProfitItem") return retitled(await buildSqliteReport("salesByProduct", f), type, "Fitimi për artikull", "SQL-native");
  if (type === "managerTopProducts") return retitled(await buildSqliteReport("salesByProduct", f), type, "Top artikujt sipas shitjes", "SQL-native");
  if (type === "purchaseSuggestion") return retitled(await buildSqliteReport("supplyNeed", f), type, "Kërkesë furnizimi (sipas shitjes)", "SQL-native");
  if (type === "stockByCompany") return retitled(await buildSqliteReport("stockSummary", f), type, "Gjendja sipas kompanisë", "SQL-native");
  if (type === "managerInventoryValue") return retitled(await buildSqliteReport("stockSummary", f), type, "Vlera e inventarit", "SQL-native");
  if (type === "clientSalesHistoryAnalytic") return retitled(await buildSqliteReport("salesAnalytic", f), type, "Historik shitjesh klientit analitik", "SQL-native");

  if (type === "managerProfitInvoice") {
    const p = docInvoiceWhere(companyId, f);
    const rows = await sqliteAll<Row>(`SELECT invoice_no AS no, date, customer, total, total_cost AS cost, profit, CASE WHEN total > 0 THEN profit * 100.0 / total ELSE 0 END AS marginPct FROM invoices i WHERE ${p.where.join(" AND ")} ORDER BY date, invoice_no`, p.params);
    return withSource({ type, title: "Fitimi për faturë", subtitle: sub, columns: [
      { key: "no", label: "Nr." }, { key: "date", label: "Data" }, { key: "customer", label: "Klienti" }, { key: "total", label: "Shitje", align: "right", format: "money" }, { key: "cost", label: "Kosto", align: "right", format: "money" }, { key: "profit", label: "Fitim", align: "right", format: "money" }, { key: "marginPct", label: "Marzh %", align: "right", format: "pct" }
    ], rows, summary: [{ label: "Fitim", value: money(sum(rows, "profit")) }] });
  }

  if (type === "purchaseDaily") {
    const p = docPurchaseWhere(companyId, f);
    const rows = await sqliteAll<Row>(`SELECT date, COUNT(*) AS count, SUM(total) AS total, SUM(paid) AS paid, SUM(due) AS due FROM purchases p WHERE ${p.where.join(" AND ")} GROUP BY date ORDER BY date`, p.params);
    return withSource({ type, title: "Blerje ditore", subtitle: sub, columns: [
      { key: "date", label: "Data" }, { key: "count", label: "Fatura", align: "right", format: "qty" }, { key: "total", label: "Totali", align: "right", format: "money" }, { key: "paid", label: "Paguar", align: "right", format: "money" }, { key: "due", label: "Detyrim", align: "right", format: "money" }
    ], rows, summary: [{ label: "Total", value: money(sum(rows, "total")) }] });
  }

  if (type === "purchaseInvoiceBatch") {
    const p = docPurchaseWhere(companyId, f);
    const rows = await sqliteAll<Row>(`SELECT purchase_no AS no, date, supplier, store, mode, total, paid, due FROM purchases p WHERE ${p.where.join(" AND ")} ORDER BY date, purchase_no`, p.params);
    return withSource({ type, title: "Fatura blerje të renditura", subtitle: sub, columns: [
      { key: "no", label: "Nr." }, { key: "date", label: "Data" }, { key: "supplier", label: "Furnitori" }, { key: "store", label: "Magazina" }, { key: "mode", label: "Lloji" }, { key: "total", label: "Totali", align: "right", format: "money" }, { key: "paid", label: "Paguar", align: "right", format: "money" }, { key: "due", label: "Detyrim", align: "right", format: "money" }
    ], rows, summary: [{ label: "Fatura", value: String(rows.length) }, { label: "Total", value: money(sum(rows, "total")) }] });
  }

  if (type === "itemCard") {
    const p = docStockWhere(companyId, f);
    const rows = await sqliteAll<Row>(`SELECT sm.date, sm.doc_no AS no, sm.warehouse AS store, sm.product_name AS product, sm.doc_type AS type, sm.in_base AS hyrje, sm.out_base AS dalje, sm.balance_after AS gjendje, sm.note FROM stock_movements sm WHERE ${p.where.join(" AND ")} ORDER BY sm.date, sm.movement_id`, p.params);
    return withSource({ type, title: "Kartela e Artikullit", subtitle: sub, columns: [
      { key: "date", label: "Data" }, { key: "no", label: "Dok." }, { key: "store", label: "Magazina" }, { key: "product", label: "Artikulli" }, { key: "type", label: "Lloji" }, { key: "hyrje", label: "Hyrje", align: "right", format: "qty" }, { key: "dalje", label: "Dalje", align: "right", format: "qty" }, { key: "gjendje", label: "Gjendje", align: "right", format: "qty" }, { key: "note", label: "Shënim" }
    ], rows });
  }

  if (type === "stockByWarehouse" || type === "warehouseStockAsOf") {
    const p: SqlParts = { where: ["sm.company_id = ?"], params: [companyId] };
    if (type === "warehouseStockAsOf" && f.to) { p.where.push("sm.date <= ?"); p.params.push(f.to); } else addDate(p, "sm.date", f);
    addText(p, "sm.warehouse", f.stores, f.store);
    addText(p, "sm.product_name", f.products, f.product);
    const rows = await sqliteAll<Row>(`SELECT sm.warehouse AS store, sm.product_name AS product, SUM(sm.in_base - sm.out_base) AS stock FROM stock_movements sm WHERE ${p.where.join(" AND ")} GROUP BY sm.warehouse, sm.product_name HAVING ABS(SUM(sm.in_base - sm.out_base)) > 0.0001 ORDER BY sm.warehouse, sm.product_name`, p.params);
    return withSource({ type, title: type === "stockByWarehouse" ? "Gjendja sipas magazinave" : "Gjendje magazine datë", subtitle: type === "warehouseStockAsOf" && f.to ? `Deri më ${f.to}` : sub, columns: [
      { key: "store", label: "Magazina" }, { key: "product", label: "Artikulli" }, { key: "stock", label: "Gjendje copë", align: "right", format: "qty" }
    ], rows, summary: [{ label: "Rreshta", value: String(rows.length) }, { label: "Gjendje totale", value: fmt(sum(rows, "stock")) }] });
  }

  if (type === "transferReport") {
    const p = docStockWhere(companyId, f);
    p.where.push("sm.doc_type IN ('transfer-in','transfer-out')");
    const rows = await sqliteAll<Row>(`SELECT sm.date, sm.doc_no AS no, sm.product_name AS product, sm.warehouse AS store, sm.doc_type AS type, sm.in_base AS inBase, sm.out_base AS outBase, sm.note FROM stock_movements sm WHERE ${p.where.join(" AND ")} ORDER BY sm.date, sm.doc_no, sm.movement_id`, p.params);
    return withSource({ type, title: "Transferimet mes magazinave", subtitle: sub, columns: [
      { key: "date", label: "Data" }, { key: "no", label: "Dok." }, { key: "product", label: "Artikulli" }, { key: "store", label: "Magazina" }, { key: "type", label: "Tipi" }, { key: "inBase", label: "Hyrje", align: "right", format: "qty" }, { key: "outBase", label: "Dalje", align: "right", format: "qty" }, { key: "note", label: "Shënim" }
    ], rows });
  }

  if (type === "itemAnalysis") {
    const p: SqlParts = { where: ["pr.company_id = ?"], params: [companyId] };
    addText(p, "pr.name", f.products, f.product);
    addText(p, "pr.category", f.categories, f.category);
    const rows = await sqliteAll<Row>(`SELECT pr.name AS product, pr.category, pr.stock_base AS stock, pr.buy_piece AS costPiece, pr.sale_piece AS salePiece, COALESCE(s.sold,0) AS sold, COALESCE(b.bought,0) AS bought, COALESCE(m.inBase,0) AS inBase, COALESCE(m.outBase,0) AS outBase FROM products pr LEFT JOIN (SELECT company_id, product_name, SUM(qty+free_qty) AS sold FROM invoice_items GROUP BY company_id, product_name) s ON s.company_id=pr.company_id AND LOWER(s.product_name)=LOWER(pr.name) LEFT JOIN (SELECT company_id, product_name, SUM(qty+free_qty) AS bought FROM purchase_items GROUP BY company_id, product_name) b ON b.company_id=pr.company_id AND LOWER(b.product_name)=LOWER(pr.name) LEFT JOIN (SELECT company_id, product_name, SUM(in_base) AS inBase, SUM(out_base) AS outBase FROM stock_movements GROUP BY company_id, product_name) m ON m.company_id=pr.company_id AND LOWER(m.product_name)=LOWER(pr.name) WHERE ${p.where.join(" AND ")} ORDER BY pr.name`, p.params);
    return withSource({ type, title: "Analizë artikulli", subtitle: sub, columns: [
      { key: "product", label: "Artikulli" }, { key: "category", label: "Kategori" }, { key: "stock", label: "Gjendje", align: "right", format: "qty" }, { key: "bought", label: "Blerë", align: "right", format: "qty" }, { key: "sold", label: "Shitur", align: "right", format: "qty" }, { key: "inBase", label: "Hyrje stok", align: "right", format: "qty" }, { key: "outBase", label: "Dalje stok", align: "right", format: "qty" }, { key: "salePiece", label: "Çmim/copë", align: "right", format: "money" }, { key: "costPiece", label: "Kosto/copë", align: "right", format: "money" }
    ], rows });
  }

  if (type === "managerTopClients" || type === "managerMarginByClient") {
    const p = docInvoiceWhere(companyId, f);
    const rows = await sqliteAll<Row>(`SELECT customer AS party, COUNT(*) AS count, SUM(total) AS total, SUM(profit) AS profit, CASE WHEN SUM(total) > 0 THEN SUM(profit) * 100.0 / SUM(total) ELSE 0 END AS marginPct FROM invoices i WHERE ${p.where.join(" AND ")} GROUP BY customer ORDER BY total DESC`, p.params);
    return withSource({ type, title: type === "managerTopClients" ? "Top klientët sipas shitjes" : "Marzhi sipas klientit", subtitle: sub, columns: [
      { key: "party", label: "Klienti" }, { key: "count", label: "Fatura", align: "right", format: "qty" }, { key: "total", label: "Shitje", align: "right", format: "money" }, { key: "profit", label: "Fitim", align: "right", format: "money" }, { key: "marginPct", label: "Marzh %", align: "right", format: "pct" }
    ], rows, summary: [{ label: "Shitje", value: money(sum(rows, "total")) }, { label: "Fitim", value: money(sum(rows, "profit")) }] });
  }

  if (type === "managerDailyProfit") {
    const p = docInvoiceWhere(companyId, f);
    const rows = await sqliteAll<Row>(`SELECT date, SUM(total) AS total, SUM(total_cost) AS cost, SUM(profit) AS profit, CASE WHEN SUM(total)>0 THEN SUM(profit)*100.0/SUM(total) ELSE 0 END AS marginPct FROM invoices i WHERE ${p.where.join(" AND ")} GROUP BY date ORDER BY date`, p.params);
    return withSource({ type, title: "Fitimi ditor", subtitle: sub, columns: [
      { key: "date", label: "Data" }, { key: "total", label: "Shitje", align: "right", format: "money" }, { key: "cost", label: "Kosto", align: "right", format: "money" }, { key: "profit", label: "Fitim", align: "right", format: "money" }, { key: "marginPct", label: "Marzh %", align: "right", format: "pct" }
    ], rows, summary: [{ label: "Fitim", value: money(sum(rows, "profit")) }] });
  }

  if (type === "managerSalesVsPurchases") {
    const p1 = docInvoiceWhere(companyId, f);
    const p2 = docPurchaseWhere(companyId, f);
    const rows = await sqliteAll<Row>(`WITH days AS (SELECT date FROM invoices i WHERE ${p1.where.join(" AND ")} UNION SELECT date FROM purchases p WHERE ${p2.where.join(" AND ")}) SELECT d.date, COALESCE(s.total,0) AS sales, COALESCE(b.total,0) AS purchases, COALESCE(s.total,0)-COALESCE(b.total,0) AS difference FROM days d LEFT JOIN (SELECT date, SUM(total) AS total FROM invoices i WHERE ${p1.where.join(" AND ")} GROUP BY date) s ON s.date=d.date LEFT JOIN (SELECT date, SUM(total) AS total FROM purchases p WHERE ${p2.where.join(" AND ")} GROUP BY date) b ON b.date=d.date ORDER BY d.date`, [...p1.params, ...p2.params, ...p1.params, ...p2.params]);
    return withSource({ type, title: "Krahasim shitje vs blerje", subtitle: sub, columns: [
      { key: "date", label: "Data" }, { key: "sales", label: "Shitje", align: "right", format: "money" }, { key: "purchases", label: "Blerje", align: "right", format: "money" }, { key: "difference", label: "Diferencë", align: "right", format: "money" }
    ], rows });
  }

  if (type === "managerSlowMovingStock") {
    const cutoff = f.from || "0000-00-00";
    const p: SqlParts = { where: ["pr.company_id = ?"], params: [companyId] };
    addText(p, "pr.name", f.products, f.product); addText(p, "pr.category", f.categories, f.category);
    const rows = await sqliteAll<Row>(`SELECT pr.name AS product, pr.category, pr.stock_base AS stock, MAX(i.date) AS lastSaleDate, COALESCE(SUM(ii.qty+ii.free_qty),0) AS soldQty FROM products pr LEFT JOIN invoice_items ii ON ii.company_id=pr.company_id AND LOWER(ii.product_name)=LOWER(pr.name) LEFT JOIN invoices i ON i.company_id=ii.company_id AND i.invoice_no=ii.invoice_no WHERE ${p.where.join(" AND ")} GROUP BY pr.name, pr.category, pr.stock_base HAVING COALESCE(MAX(i.date),'0000-00-00') < ? ORDER BY lastSaleDate, pr.name`, [...p.params, cutoff]);
    return withSource({ type, title: "Artikuj pa lëvizje", subtitle: cutoff === "0000-00-00" ? sub : `Pa shitje nga ${cutoff}`, columns: [
      { key: "product", label: "Artikulli" }, { key: "category", label: "Kategori" }, { key: "stock", label: "Gjendje", align: "right", format: "qty" }, { key: "lastSaleDate", label: "Shitja fundit" }, { key: "soldQty", label: "Shitur", align: "right", format: "qty" }
    ], rows });
  }

  if (type === "managerWarehouseTurnover") {
    const p = docStockWhere(companyId, f);
    const rows = await sqliteAll<Row>(`SELECT sm.warehouse AS store, COUNT(*) AS movements, SUM(sm.in_base) AS inBase, SUM(sm.out_base) AS outBase, SUM(sm.in_base + sm.out_base) AS turnover FROM stock_movements sm WHERE ${p.where.join(" AND ")} GROUP BY sm.warehouse ORDER BY turnover DESC`, p.params);
    return withSource({ type, title: "Qarkullimi sipas magazinës", subtitle: sub, columns: [
      { key: "store", label: "Magazina" }, { key: "movements", label: "Lëvizje", align: "right", format: "qty" }, { key: "inBase", label: "Hyrje", align: "right", format: "qty" }, { key: "outBase", label: "Dalje", align: "right", format: "qty" }, { key: "turnover", label: "Qarkullim", align: "right", format: "qty" }
    ], rows });
  }

  if (type === "supplierLedger" || type === "clientLedger" || type === "clientBillingPayments" || type === "supplierBillingPayments") {
    const isClient = type === "clientLedger" || type === "clientBillingPayments";
    const docTable = isClient ? "invoices" : "purchases";
    const noCol = isClient ? "invoice_no" : "purchase_no";
    const partyCol = isClient ? "customer" : "supplier";
    const partyType = isClient ? "customer" : "supplier";
    const pDoc: SqlParts = { where: [`company_id = ?`], params: [companyId] };
    addDate(pDoc, "date", f); paymentPartyFilter(pDoc, partyCol, f, partyType as any);
    const pPay: SqlParts = { where: [`company_id = ?`, `party_type = ?`], params: [companyId, partyType] };
    addDate(pPay, "date", f); paymentPartyFilter(pPay, "party", f, partyType as any);
    const rows = await sqliteAll<Row>(`SELECT date, ${noCol} AS no, ${partyCol} AS party, 'Faturë' AS type, total AS debit, paid AS credit, due AS balance FROM ${docTable} WHERE ${pDoc.where.join(" AND ")} UNION ALL SELECT date, payment_id AS no, party, 'Pagesë' AS type, 0 AS debit, amount AS credit, 0 AS balance FROM payments WHERE ${pPay.where.join(" AND ")} ORDER BY date, no`, [...pDoc.params, ...pPay.params]);
    return withSource({ type, title: isClient ? (type === "clientLedger" ? "Kartela klientit" : "Faturime pagesa klientit") : (type === "supplierLedger" ? "Kartela furnitorit" : "Faturime pagesa furnitorit"), subtitle: sub, columns: [
      { key: "date", label: "Data" }, { key: "no", label: "Nr." }, { key: "party", label: isClient ? "Klienti" : "Furnitori" }, { key: "type", label: "Lloji" }, { key: "debit", label: "Faturuar", align: "right", format: "money" }, { key: "credit", label: "Paguar", align: "right", format: "money" }, { key: "balance", label: "Mbetur", align: "right", format: "money" }
    ], rows, summary: [{ label: "Faturuar", value: money(sum(rows, "debit")) }, { label: "Paguar", value: money(sum(rows, "credit")) }] });
  }

  if (type === "unpaidInvoices") {
    const p = docInvoiceWhere(companyId, { ...f, payStatus: "unpaid" });
    const rows = await sqliteAll<Row>(`SELECT invoice_no AS no, date, customer, total, paid, due FROM invoices i WHERE ${p.where.join(" AND ")} AND due > 0.001 ORDER BY date, invoice_no`, p.params);
    return withSource({ type, title: "Fatura pa paguara", subtitle: sub, columns: [
      { key: "no", label: "Nr." }, { key: "date", label: "Data" }, { key: "customer", label: "Klienti" }, { key: "total", label: "Totali", align: "right", format: "money" }, { key: "paid", label: "Paguar", align: "right", format: "money" }, { key: "due", label: "Detyrim", align: "right", format: "money" }
    ], rows, summary: [{ label: "Detyrim", value: money(sum(rows, "due")) }] });
  }

  if (type === "expenseSummary") {
    const p = expenseWhere(companyId, f);
    const rows = await sqliteAll<Row>(`SELECT date, category, description, payment_method AS method, ref, amount FROM expenses e WHERE ${p.where.join(" AND ")} ORDER BY date, expense_id`, p.params);
    return withSource({ type, title: "Përmbledhje shpenzimesh", subtitle: sub, columns: [
      { key: "date", label: "Data" }, { key: "category", label: "Kategori" }, { key: "description", label: "Përshkrim" }, { key: "method", label: "Pagesa" }, { key: "ref", label: "Ref." }, { key: "amount", label: "Shuma", align: "right", format: "money" }
    ], rows, summary: [{ label: "Shpenzime", value: money(sum(rows, "amount")) }] });
  }

  if (type === "expenseByCategory") {
    const p = expenseWhere(companyId, f);
    const rows = await sqliteAll<Row>(`SELECT category, COUNT(*) AS count, SUM(amount) AS amount FROM expenses e WHERE ${p.where.join(" AND ")} GROUP BY category ORDER BY amount DESC`, p.params);
    return withSource({ type, title: "Shpenzime sipas kategorisë", subtitle: sub, columns: [
      { key: "category", label: "Kategori" }, { key: "count", label: "Rreshta", align: "right", format: "qty" }, { key: "amount", label: "Shuma", align: "right", format: "money" }
    ], rows, summary: [{ label: "Shpenzime", value: money(sum(rows, "amount")) }] });
  }

  if (type === "expenseByMonth") {
    const p = expenseWhere(companyId, f);
    const rows = await sqliteAll<Row>(`SELECT SUBSTR(date,1,7) AS month, COUNT(*) AS count, SUM(amount) AS amount FROM expenses e WHERE ${p.where.join(" AND ")} GROUP BY SUBSTR(date,1,7) ORDER BY month`, p.params);
    return withSource({ type, title: "Shpenzime sipas muajit", subtitle: sub, columns: [
      { key: "month", label: "Muaji" }, { key: "count", label: "Rreshta", align: "right", format: "qty" }, { key: "amount", label: "Shuma", align: "right", format: "money" }
    ], rows, summary: [{ label: "Shpenzime", value: money(sum(rows, "amount")) }] });
  }

  if (type === "locationReport" || type === "salesmanActivity") {
    const p = docInvoiceWhere(companyId, f);
    const rows = await sqliteAll<Row>(`SELECT date, invoice_no AS no, customer, salesman, total, gps_json AS gps FROM invoices i WHERE ${p.where.join(" AND ")} ORDER BY date, invoice_no`, p.params);
    return withSource({ type, title: type === "locationReport" ? "Raporti i vendndodhjes (GPS)" : "Aktiviteti / Itinerari i shitësit", subtitle: sub, columns: [
      { key: "date", label: "Data" }, { key: "no", label: "Fatura" }, { key: "customer", label: "Klienti" }, { key: "salesman", label: "Shitësi" }, { key: "total", label: "Total", align: "right", format: "money" }, { key: "gps", label: "GPS" }
    ], rows });
  }

  if (type === "salesmanSummary") {
    const p = docInvoiceWhere(companyId, f);
    const rows = await sqliteAll<Row>(`SELECT salesman, COUNT(*) AS invoices, COUNT(DISTINCT customer) AS clients, SUM(total) AS total, SUM(profit) AS profit FROM invoices i WHERE ${p.where.join(" AND ")} GROUP BY salesman ORDER BY total DESC`, p.params);
    return withSource({ type, title: "Përmbledhje sipas shitësit", subtitle: sub, columns: [
      { key: "salesman", label: "Shitësi" }, { key: "invoices", label: "Fatura", align: "right", format: "qty" }, { key: "clients", label: "Klientë", align: "right", format: "qty" }, { key: "total", label: "Shitje", align: "right", format: "money" }, { key: "profit", label: "Fitim", align: "right", format: "money" }
    ], rows, summary: [{ label: "Shitje", value: money(sum(rows, "total")) }] });
  }

  // Safety net: all report types must be SQLite-backed. If a new report is added
  // but not implemented, show an explicit SQLite diagnostic report instead of
  // silently falling back to in-memory data and making the UI look stale.
  return withSource({
    type,
    title: `Raport SQLite pa implementim: ${type}`,
    subtitle: `${sub} • Ky raport duhet lidhur me SQLite përpara fazës finale.`,
    columns: [{ key: "issue", label: "Problem" }, { key: "report", label: "Raporti" }],
    rows: [{ issue: "Mungon implementimi SQL-native; fallback i heshtur është çaktivizuar.", report: type }],
    summary: [{ label: "Status", value: "FAIL" }],
  });
}


export type SqliteReportAssertion = { name: string; status: "PASS" | "FAIL"; details: string };
export type SqliteReportHealthCheckResult = { ok: boolean; message: string; reportCounts: Record<string, number>; assertions: SqliteReportAssertion[] };

function passAssert(name: string, details: string): SqliteReportAssertion {
  return { name, status: "PASS", details };
}
function failAssert(name: string, details: string): SqliteReportAssertion {
  return { name, status: "FAIL", details };
}
function sameNorm(a: any, b: any): boolean {
  return norm(String(a ?? "")) === norm(String(b ?? ""));
}
function round2(n: any): number {
  return Math.round(Number(n || 0) * 100) / 100;
}
function nearlyEqual(a: any, b: any, eps = 0.01): boolean {
  return Math.abs(Number(a || 0) - Number(b || 0)) <= eps;
}
function sumNumberRows(rows: Row[], key: string): number {
  return rows.reduce((total, r) => total + Number((r as any)[key] || 0), 0);
}
function assertNoRows(name: string, report: SqlReport | null, details: string): SqliteReportAssertion {
  if (!report) return failAssert(name, "Raporti nuk u ndërtua nga SQLite.");
  if (report.rows.length !== 0) return failAssert(name, `${details} Duhej 0 rreshta, doli ${report.rows.length}. Kjo tregon se filtri mund të jetë fasadë ose nuk po zbatohet.`);
  return passAssert(name, details);
}
function assertSalesAnalyticRowsExact(report: SqlReport | null, expected: { product: string; unit: string; rate: number; lines: number; value: number }): SqliteReportAssertion {
  if (!report) return failAssert("SQLite salesAnalytic filter exact", "Raporti nuk u ndërtua nga SQLite.");
  const bad = report.rows.find((r: any) => !sameNorm(r.product, expected.product) || !sameNorm(r.unit, expected.unit) || !nearlyEqual(r.rate, expected.rate));
  const value = sumNumberRows(report.rows, "value");
  if (bad) {
    return failAssert(
      "SQLite salesAnalytic filter exact",
      `U kthye rresht jashtë filtrit. Pritej ${expected.product} / ${expected.unit} / ${expected.rate}; doli ${String((bad as any).product)} / ${String((bad as any).unit)} / ${String((bad as any).rate)}.`,
    );
  }
  if (report.rows.length !== Number(expected.lines || 0)) {
    return failAssert("SQLite salesAnalytic filter exact", `Numër rreshtash gabim. Pritej ${expected.lines}, doli ${report.rows.length}.`);
  }
  if (!nearlyEqual(value, expected.value)) {
    return failAssert("SQLite salesAnalytic filter exact", `Shuma e vlerës gabim. Pritej ${round2(expected.value)}, doli ${round2(value)}.`);
  }
  return passAssert("SQLite salesAnalytic filter exact", `U kthyen vetëm rreshtat ${expected.product} / ${expected.unit} / ${expected.rate}; rreshta ${report.rows.length}, vlerë ${money(value)}.`);
}
function assertSalesByProductRowsExact(report: SqlReport | null, expected: { product: string; unit: string; rate: number; value: number }): SqliteReportAssertion {
  if (!report) return failAssert("SQLite salesByProduct filter exact", "Raporti nuk u ndërtua nga SQLite.");
  if (report.rows.length !== 1) return failAssert("SQLite salesByProduct filter exact", `Pritej 1 grup për Artikull+Njësi+Çmim, dolën ${report.rows.length}.`);
  const r: any = report.rows[0] || {};
  if (!sameNorm(r.product, expected.product) || !sameNorm(r.unit, expected.unit) || !nearlyEqual(r.rate, expected.rate)) {
    return failAssert("SQLite salesByProduct filter exact", `Grupi i kthyer nuk përputhet. Pritej ${expected.product} / ${expected.unit} / ${expected.rate}; doli ${String(r.product)} / ${String(r.unit)} / ${String(r.rate)}.`);
  }
  if (!nearlyEqual(r.value, expected.value)) {
    return failAssert("SQLite salesByProduct filter exact", `Vlera e grupit gabim. Pritej ${round2(expected.value)}, doli ${round2(r.value)}.`);
  }
  return passAssert("SQLite salesByProduct filter exact", `Grupimi Artikull+Njësi+Çmim është korrekt: ${expected.product} / ${expected.unit} / ${expected.rate}.`);
}
function assertMultiProductRows(report: SqlReport | null, expectedProducts: string[], expectedLineCount: number): SqliteReportAssertion {
  if (!report) return failAssert("SQLite multi-product filter exact", "Raporti nuk u ndërtua nga SQLite.");
  const expected = expectedProducts.map(norm);
  const outside = report.rows.find((r: any) => !expected.includes(norm(r.product)));
  if (outside) return failAssert("SQLite multi-product filter exact", `U kthye produkt jashtë filtrit: ${String((outside as any).product)}.`);
  const returned = Array.from(new Set(report.rows.map((r: any) => norm(r.product)))).sort();
  const missing = expected.filter((p) => !returned.includes(p));
  if (missing.length) return failAssert("SQLite multi-product filter exact", `Mungojnë produktet e filtruara: ${missing.join(", ")}.`);
  if (report.rows.length !== expectedLineCount) return failAssert("SQLite multi-product filter exact", `Numër rreshtash gabim. Pritej ${expectedLineCount}, doli ${report.rows.length}.`);
  return passAssert("SQLite multi-product filter exact", `Raporti ktheu vetëm ${expectedProducts.join(", ")} me ${report.rows.length} rreshta.`);
}

/**
 * SQLite report health check. This is a broad runtime smoke check for the
 * SQLite-backed report builders. The strict filter tests that gate final
 * readiness live in runErpSelfTests(), where an isolated deterministic demo DB
 * is synced into SQLite first.
 *
 * This health check still verifies:
 * - every major report can be built from SQLite;
 * - the current active SQLite company has enough reportable rows;
 * - basic negative cases for product/unit/price filters do not leak rows.
 *
 * Covered negative cases here are deliberately lightweight. The complete
 * product + unit + rate + date + client assertions, reportUnit conversion,
 * multi-product exactness, and performance threshold are part of the main
 * PASS/FAIL self-test suite.
 */
export async function sqliteReportsHealthCheck(): Promise<SqliteReportHealthCheckResult> {
  const checks: ReportType[] = REPORT_CATALOG.map((r) => r.value);
  const reportCounts: Record<string, number> = {};
  const assertions: SqliteReportAssertion[] = [];
  try {
    for (const t of checks) {
      const r = await buildSqliteReport(t, {});
      reportCounts[t] = r ? r.rows.length : -1;
      assertions.push(r ? passAssert(`SQLite raport bazë: ${t}`, `${r.rows.length} rreshta.`) : failAssert(`SQLite raport bazë: ${t}`, "Raporti nuk u ndërtua."));
    }

    const companyId = await companyIdOrNull();
    if (companyId) {
      const sample = await sqliteFirst<{ product: string; unit: string; rate: number; lines: number; value: number }>(
        `SELECT product_name AS product,
                unit,
                ROUND(rate, 2) AS rate,
                COUNT(*) AS lines,
                SUM(total) AS value
         FROM invoice_items
         WHERE company_id = ? AND product_name IS NOT NULL AND TRIM(product_name) <> ''
         GROUP BY product_name, unit, ROUND(rate, 2)
         ORDER BY lines DESC, product_name, unit, rate
         LIMIT 1`,
        [companyId],
      );

      if (sample) {
        const strictFilter: ReportFilter = {
          products: [sample.product],
          units: [sample.unit],
          price: String(round2(sample.rate)),
          reportUnit: sample.unit,
        };
        const exactAnalytic = await buildSqliteReport("salesAnalytic", strictFilter);
        const exactByProduct = await buildSqliteReport("salesByProduct", strictFilter);
        reportCounts.salesAnalytic_filtered_product_unit_price = exactAnalytic ? exactAnalytic.rows.length : -1;
        reportCounts.salesByProduct_filtered_product_unit_price = exactByProduct ? exactByProduct.rows.length : -1;
        assertions.push(assertSalesAnalyticRowsExact(exactAnalytic, sample));
        assertions.push(assertSalesByProductRowsExact(exactByProduct, sample));

        const wrongProduct = await buildSqliteReport("salesAnalytic", { ...strictFilter, products: [`${sample.product}__NO_MATCH__`] });
        const wrongUnit = await buildSqliteReport("salesAnalytic", { ...strictFilter, units: [`${sample.unit}__NO_MATCH__`], reportUnit: sample.unit });
        const wrongPrice = await buildSqliteReport("salesAnalytic", { ...strictFilter, price: String(round2(Number(sample.rate || 0) + 999999)) });
        assertions.push(assertNoRows("SQLite negative product filter", wrongProduct, "Produkt i gabuar nuk duhet të kthejë rreshta."));
        assertions.push(assertNoRows("SQLite negative unit filter", wrongUnit, "Njësi e gabuar nuk duhet të kthejë rreshta."));
        assertions.push(assertNoRows("SQLite negative price filter", wrongPrice, "Çmim i gabuar nuk duhet të kthejë rreshta."));
      } else {
        assertions.push(failAssert("SQLite strict sales filter data", "Nuk ka invoice_items në SQLite; nuk mund të provohet filtri Artikull+Njësi+Çmim."));
      }

      const multiProducts = await sqliteAll<{ product: string }>(
        `SELECT product_name AS product
         FROM invoice_items
         WHERE company_id = ? AND product_name IS NOT NULL AND TRIM(product_name) <> ''
         GROUP BY product_name
         ORDER BY product_name
         LIMIT 3`,
        [companyId],
      );
      if (multiProducts.length >= 2) {
        const names = multiProducts.map((p) => p.product);
        const placeholders = names.map(() => "?").join(",");
        const expected = await sqliteFirst<{ c: number }>(
          `SELECT COUNT(*) AS c
           FROM invoice_items
           WHERE company_id = ? AND LOWER(TRIM(product_name)) IN (${placeholders})`,
          [companyId, ...names.map(norm)],
        );
        const multi = await buildSqliteReport("salesAnalytic", { products: names });
        reportCounts.salesAnalytic_multi_product_filter = multi ? multi.rows.length : -1;
        assertions.push(assertMultiProductRows(multi, names, Number(expected?.c || 0)));
      } else {
        assertions.push(failAssert("SQLite multi-product filter exact", "Duhen të paktën 2 artikuj të shitur në SQLite për të provuar filtrin multi-artikuj. Ngarko/demo ose krijo dy shitje me artikuj të ndryshëm."));
      }
    } else {
      assertions.push(failAssert("SQLite active company", "Nuk u gjet kompani aktive në SQLite."));
    }

    const failed = assertions.filter((a) => a.status === "FAIL");
    return {
      ok: failed.length === 0,
      message: failed.length === 0
        ? "Raportet kryesore dhe filtrat Artikull+Njësi+Çmim u verifikuan me përputhje rreshti/vlere dhe teste negative."
        : `${failed.length} kontroll(e) SQLite dështuan.`,
      reportCounts,
      assertions,
    };
  } catch (e: any) {
    assertions.push(failAssert("SQLite reports health check", String(e?.message || e)));
    return { ok: false, message: String(e?.message || e), reportCounts, assertions };
  }
}
