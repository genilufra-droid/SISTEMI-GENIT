# Ndërtimi i APK-së me GitHub Actions

Ky projekt është Expo / React Native. Për APK testimi nuk duhet Android Studio në kompjuter: GitHub Actions e ndërton vetë në cloud.

## Çfarë është shtuar në këtë ZIP

Është shtuar workflow:

```text
.github/workflows/android-debug-apk.yml
```

Ky workflow:

1. instalon Node.js, pnpm, Java dhe Android SDK;
2. instalon dependencies;
3. krijon projektin Android me `expo prebuild`;
4. ndërton APK debug me Gradle;
5. e nxjerr si artifact: `Sistemi_Genit_debug_apk`.

## Hapat në GitHub

### 1. Krijo repository

- Hyr në GitHub.
- Shtyp **New repository**.
- Zgjidh **Private**.
- Emri p.sh. `sistemi-genit-apk`.
- Mos shto README të ri nëse po ngarkon source-in komplet.

### 2. Ngarko source-in

E rëndësishme: mos ngarko ZIP-in si një file të vetëm.

Duhet të bësh extract ZIP-in dhe të ngarkosh përmbajtjen brenda tij, që në root të repository të shihen këto file:

```text
package.json
app.config.ts
eas.json
app/
components/
lib/
.github/workflows/android-debug-apk.yml
```

Nëse `package.json` nuk shfaqet direkt në faqen kryesore të repo-s, e ke ngarkuar gabim.

### 3. Nis build-in

- Hape repository në GitHub.
- Hape tab **Actions**.
- Në listë zgjidh **Build Android Debug APK**.
- Shtyp **Run workflow**.
- Prit sa të mbarojë.

### 4. Shkarko APK-në

Kur workflow bëhet jeshil:

- hap run-in e fundit;
- në fund te **Artifacts** shkarko `Sistemi_Genit_debug_apk`;
- brenda ZIP-it të artifact-it është `Sistemi_Genit_debug.apk`.

Kjo APK është **debug APK** për testim dhe instalohet në telefon me sideload. Për Play Store duhet **AAB/release build i firmosur**.

## Gabime të zakonshme

### Gabim: `package.json not found`

E ke ngarkuar ZIP-in gabim. GitHub duhet të ketë `package.json` në root, jo brenda një folderi tjetër ose brenda ZIP-it.

### Gabim: build dështon te native module / bluetooth

Ky projekt ka `react-native-bluetooth-classic`, që është native module. Nëse dështon aty, prova e parë është të çaktivizosh New Architecture:

Në `app.config.ts` ndrysho:

```ts
newArchEnabled: true,
```

në:

```ts
newArchEnabled: false,
```

pastaj bëj commit dhe nis prapë workflow.

### Gabim: `pnpm install --frozen-lockfile`

Workflow ka fallback automatik te `pnpm install --no-frozen-lockfile`, por nëse prapë dështon, problemi është te dependency/lockfile.

### Gabim: Actions nuk shfaqet

Kontrollo që ekziston ky file në repository:

```text
.github/workflows/android-debug-apk.yml
```

Nëse mungon, GitHub nuk ka çfarë të ekzekutojë.
