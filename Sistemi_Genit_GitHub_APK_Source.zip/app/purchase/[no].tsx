import React from "react";
import { Alert, ScrollView, Text, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { Header, Btn, Badge } from "@/components/ui-kit";
import { router, useLocalSearchParams } from "expo-router";
import { fmt, num, useStore, applyLinesToStock, reverseInboundDoc } from "@/lib/store";
import { PrintPreview } from "@/components/print-preview";
import { purchaseToPrintable, warehouseDocToPrintable } from "@/lib/print-templates";

export default function PurchaseDetailScreen() {
  const colors = useColors();
  const { db, setDB } = useStore();
  const { no } = useLocalSearchParams<{ no: string }>();
  const inv = db.purchases.find((i) => String(i.no) === String(no));
  const [previewOpen, setPreviewOpen] = React.useState(false);
  const [docPreviewOpen, setDocPreviewOpen] = React.useState(false);
  const linkedDoc =
    inv && inv.linkedInboundDocId != null
      ? (db.inboundDocs || []).find((d) => d.id === inv.linkedInboundDocId)
      : undefined;

  if (!inv) {
    return (
      <ScreenContainer>
        <Header title="Blerje" back={() => router.back()} />
        <Text style={{ textAlign: "center", marginTop: 40, color: colors.muted }}>Blerja nuk u gjet.</Text>
      </ScreenContainer>
    );
  }

  const remove = async () => {
    Alert.alert("Fshi", `Fshi blerjen #${inv.no}?`, [
      { text: "Anulo" },
      {
        text: "Fshi",
        style: "destructive",
        onPress: async () => {
          // Reverse purchase stock. If a Fletë Hyrje was linked, reverse THAT
          // (also removes the doc + its movements); otherwise reverse directly.
          let next = db;
          if (inv.linkedInboundDocId != null) {
            next = reverseInboundDoc(next, inv.linkedInboundDocId);
          } else {
            next = { ...next, products: applyLinesToStock(next.products, inv.items, inv.store, -1) };
          }
          await setDB({
            ...next,
            purchases: next.purchases.filter((i) => i.no !== inv.no),
          });
          router.back();
        },
      },
    ]);
  };

  return (
    <ScreenContainer>
      <Header title={`Blerje #${inv.no}`} back={() => router.back()} />
      <ScrollView contentContainerStyle={{ paddingBottom: 40 }}>
        <View
          style={{
            margin: 12,
            backgroundColor: colors.surface,
            padding: 14,
            borderRadius: 10,
            borderWidth: 1,
            borderColor: colors.border,
          }}
        >
          <Text style={{ fontSize: 18, fontWeight: "900" }}>{inv.supplier}</Text>
          <View style={{ marginTop: 6, flexDirection: "row", gap: 8 }}>
            <Badge tone={inv.due <= 0 ? "paid" : "open"}>{inv.due <= 0 ? "Paguar" : "Detyrim"}</Badge>
            <Badge>{inv.mode}</Badge>
          </View>
          <Text style={{ color: colors.muted, marginTop: 6 }}>
            {inv.date} {inv.time}
          </Text>
        </View>

        <View
          style={{
            marginHorizontal: 12,
            backgroundColor: colors.surface,
            padding: 14,
            borderRadius: 10,
            borderWidth: 1,
            borderColor: colors.border,
          }}
        >
          <Text style={{ fontWeight: "900", marginBottom: 6 }}>Artikujt</Text>
          {inv.items.map((it, idx) => (
            <View
              key={idx}
              style={{
                paddingVertical: 8,
                borderBottomWidth: idx === inv.items.length - 1 ? 0 : 1,
                borderColor: colors.border,
              }}
            >
              <Text style={{ fontWeight: "700" }}>{it.productName}</Text>
              <View style={{ flexDirection: "row", justifyContent: "space-between", marginTop: 4 }}>
                <Text style={{ color: colors.muted, fontSize: 12 }}>
                  {fmt(it.qty)} {it.unit} x {fmt(it.rate)}
                </Text>
                <Text style={{ fontWeight: "800" }}>{fmt(it.total)}</Text>
              </View>
            </View>
          ))}
        </View>

        <View
          style={{
            margin: 12,
            backgroundColor: colors.surface,
            padding: 14,
            borderRadius: 10,
            borderWidth: 1,
            borderColor: colors.border,
          }}
        >
          <Row k="Subtotali" v={fmt(inv.subtotal)} />
          {inv.roundOff ? <Row k="Rrumbullakim" v={fmt(inv.roundOff)} /> : null}
          <Row k="Totali" v={`${fmt(inv.total)} ${db.company.currency}`} bold />
          <Row k="Paguar" v={fmt(inv.paid)} />
          <Row k="Detyrim" v={fmt(inv.due)} />
        </View>

        {linkedDoc ? (
          <View
            style={{
              marginHorizontal: 12,
              marginBottom: 12,
              backgroundColor: "#eef4ff",
              padding: 12,
              borderRadius: 10,
              borderWidth: 1,
              borderColor: "#c7d7fb",
            }}
          >
            <Text style={{ fontWeight: "900", color: "#1d4ed8" }}>Fletë Hyrje e lidhur</Text>
            <Text style={{ color: colors.muted, fontSize: 12, marginTop: 2 }}>
              {linkedDoc.no} • Magazina: {linkedDoc.warehouse}
            </Text>
            <View style={{ marginTop: 8 }}>
              <Btn
                fullWidth
                icon="doc.text.fill"
                title="Shiko / Printo Fletë Hyrjen"
                variant="soft"
                onPress={() => setDocPreviewOpen(true)}
              />
            </View>
          </View>
        ) : null}

        <View style={{ paddingHorizontal: 12, gap: 8 }}>
          <Btn
            fullWidth
            icon="pencil"
            variant="soft"
            title="Modifiko"
            onPress={() => router.push({ pathname: "/purchase", params: { edit: String(inv.no) } } as any)}
          />
          <Btn fullWidth icon="printer.fill" title="Pamja e printimit" onPress={() => setPreviewOpen(true)} />
          <Btn fullWidth icon="trash.fill" variant="warn" title="Fshi" onPress={remove} />
        </View>
      </ScrollView>

      <PrintPreview
        visible={previewOpen}
        onClose={() => setPreviewOpen(false)}
        doc={purchaseToPrintable(inv, db.company, db.products)}
        company={db.company}
        defaultPaper="A4"
      />

      {linkedDoc ? (
        <PrintPreview
          visible={docPreviewOpen}
          onClose={() => setDocPreviewOpen(false)}
          doc={warehouseDocToPrintable(linkedDoc, "inbound", db.company)}
          company={db.company}
          defaultPaper="A4"
        />
      ) : null}
    </ScreenContainer>
  );
}

function Row({ k, v, bold }: { k: string; v: string; bold?: boolean }) {
  const colors = useColors();
  return (
    <View style={{ flexDirection: "row", justifyContent: "space-between", paddingVertical: 4 }}>
      <Text style={{ color: colors.muted, fontWeight: bold ? "800" : "600", fontSize: bold ? 15 : 14 }}>{k}</Text>
      <Text style={{ color: colors.foreground, fontWeight: bold ? "900" : "700", fontSize: bold ? 15 : 14 }}>{v}</Text>
    </View>
  );
}
