import React from "react";
import { Pressable, ScrollView, Text, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { Header } from "@/components/ui-kit";
import { router } from "expo-router";
import { IconSymbol } from "@/components/ui/icon-symbol";

type Item = { icon: string; label: string; path: string; params?: Record<string, string> };

const SECTIONS: { title: string; items: Item[] }[] = [
  {
    title: "Veprime",
    items: [
      { icon: "doc.text.fill", label: "Shto Faturë Shitje", path: "/sale" },
      { icon: "cart.fill", label: "Shto Faturë Blerje", path: "/purchase" },
      { icon: "creditcard.fill", label: "Pagesë klienti", path: "/party-payment" },
      { icon: "creditcard.fill", label: "Shto Shpenzim", path: "/expense-form" },
    ],
  },
  {
    title: "Klientë & Furnitorë",
    items: [
      { icon: "person.2.fill", label: "Klientët", path: "/parties" },
      { icon: "building.2.fill", label: "Furnitorët", path: "/suppliers" },
    ],
  },
  {
    title: "Shitësi & GPS",
    items: [
      { icon: "person.fill", label: "Shitësi & GPS", path: "/salesman" },
      { icon: "map.fill", label: "Raporti i vendndodhjes", path: "/(tabs)/reports", params: { type: "locationReport" } },
      { icon: "chart.bar.fill", label: "Përmbledhje sipas shitësit", path: "/(tabs)/reports", params: { type: "salesmanSummary" } },
      { icon: "location.fill", label: "Aktiviteti i shitësit", path: "/(tabs)/reports", params: { type: "salesmanActivity" } },
    ],
  },
  {
    title: "Dokumente Magazine",
    items: [
      { icon: "doc.on.doc.fill", label: "Dokumente Magazine", path: "/warehouse-docs" },
      { icon: "tray.and.arrow.down.fill", label: "Fletë Hyrje", path: "/inbound-doc" },
      { icon: "tray.and.arrow.up.fill", label: "Fletë Dalje", path: "/outbound-doc" },
      { icon: "arrow.left.arrow.right", label: "Transferim Magazine", path: "/store-transfer" },
      { icon: "checklist", label: "Inventar Fizik", path: "/inventory-doc" },
    ],
  },
  {
    title: "Stoku",
    items: [
      { icon: "shippingbox.fill", label: "Magazinat", path: "/warehouses" },
      { icon: "arrow.up.right", label: "Transfero stok", path: "/store-transfer" },
      { icon: "shippingbox.fill", label: "Rregullim Stoku", path: "/stock-adjustment" },
      { icon: "shippingbox.fill", label: "Gjendja e stokut", path: "/(tabs)/reports", params: { type: "stockSummary" } },
      { icon: "shippingbox.fill", label: "Gjendja sipas magazinave", path: "/(tabs)/reports", params: { type: "stockByWarehouse" } },
      { icon: "arrow.up.right", label: "Transferimet mes magazinave", path: "/(tabs)/reports", params: { type: "transferReport" } },
      { icon: "exclamationmark.triangle.fill", label: "Kërkesë furnizimi", path: "/(tabs)/reports", params: { type: "supplyNeed" } },
      { icon: "doc.fill", label: "Lëvizjet e magazinës", path: "/(tabs)/reports", params: { type: "stockMovement" } },
    ],
  },
  {
    title: "Raporte të shpejta",
    items: [
      { icon: "chart.bar.fill", label: "Raport përmbledhës shitje", path: "/(tabs)/reports", params: { type: "salesSummary" } },
      { icon: "chart.bar.fill", label: "Raport analitik shitje", path: "/(tabs)/reports", params: { type: "salesAnalytic" } },
      { icon: "chart.bar.fill", label: "Fitimi për artikull", path: "/(tabs)/reports", params: { type: "managerProfitItem" } },
      { icon: "chart.bar.fill", label: "Top klientët", path: "/(tabs)/reports", params: { type: "managerTopClients" } },
      { icon: "chart.bar.fill", label: "Top artikujt", path: "/(tabs)/reports", params: { type: "managerTopProducts" } },
      { icon: "chart.bar.fill", label: "Fitimi ditor", path: "/(tabs)/reports", params: { type: "managerDailyProfit" } },
      { icon: "chart.bar.fill", label: "Krahasim shitje vs blerje", path: "/(tabs)/reports", params: { type: "managerSalesVsPurchases" } },
      { icon: "exclamationmark.triangle.fill", label: "Fatura të papaguara", path: "/(tabs)/reports", params: { type: "unpaidInvoices" } },
      { icon: "creditcard.fill", label: "Detyrime klientësh", path: "/(tabs)/reports", params: { type: "clientBalances" } },
      { icon: "creditcard.fill", label: "Detyrime furnitorësh", path: "/(tabs)/reports", params: { type: "supplierBalances" } },
      { icon: "list.bullet", label: "Të gjitha raportet", path: "/(tabs)/reports" },
    ],
  },
  {
    title: "Shpenzime",
    items: [
      { icon: "creditcard.fill", label: "Lista e shpenzimeve", path: "/expenses" },
      { icon: "chart.bar.fill", label: "Raport i shpenzimeve", path: "/(tabs)/reports", params: { type: "expenseSummary" } },
    ],
  },
  {
    title: "Sistemi",
    items: [
      { icon: "doc.fill", label: "Të gjitha Transaksionet", path: "/all-transactions" },
      { icon: "building.2.fill", label: "Kompanitë", path: "/companies" },
      { icon: "building.2.fill", label: "Profili i Kompanisë", path: "/company" },
      { icon: "square.and.arrow.up", label: "Backup (JSON)", path: "/backup" },
      { icon: "square.and.arrow.down", label: "Rikthe / Importo", path: "/restore" },
      { icon: "gearshape.fill", label: "Cilësimet e transaksionit", path: "/txn-settings" },
    ],
  },
];

export default function MenuScreen() {
  const colors = useColors();
  return (
    <ScreenContainer>
      <Header title="Menu" />
      <ScrollView contentContainerStyle={{ padding: 12, paddingBottom: 100 }}>
        {SECTIONS.map((sec) => (
          <View key={sec.title} style={{ marginBottom: 14 }}>
            <Text
              style={{
                color: colors.muted,
                fontWeight: "900",
                fontSize: 11,
                textTransform: "uppercase",
                marginBottom: 6,
                marginLeft: 2,
              }}
            >
              {sec.title}
            </Text>
            {sec.items.map((m) => (
              <Pressable
                key={`${m.path}-${m.params?.type || ""}-${m.label}`}
                onPress={() =>
                  router.push(m.params ? ({ pathname: m.path, params: m.params } as any) : (m.path as any))
                }
                style={({ pressed }) => ({
                  flexDirection: "row",
                  alignItems: "center",
                  gap: 14,
                  backgroundColor: colors.surface,
                  padding: 12,
                  borderRadius: 8,
                  marginBottom: 6,
                  borderWidth: 1,
                  borderColor: colors.border,
                  opacity: pressed ? 0.6 : 1,
                })}
              >
                <View
                  style={{
                    width: 34,
                    height: 34,
                    borderRadius: 9,
                    backgroundColor: "#dceffd",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <IconSymbol name={m.icon as any} size={20} color={colors.primary} />
                </View>
                <Text style={{ flex: 1, fontSize: 14, color: colors.foreground, fontWeight: "700" }}>{m.label}</Text>
                <IconSymbol name="chevron.right" size={18} color={colors.muted} />
              </Pressable>
            ))}
          </View>
        ))}
      </ScrollView>
    </ScreenContainer>
  );
}
