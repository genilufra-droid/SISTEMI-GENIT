import React from "react";
import { Alert, Pressable, ScrollView, Text, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { Header, Btn, Badge } from "@/components/ui-kit";
import { router, useLocalSearchParams } from "expo-router";
import { fmt, money, num, useStore, applyLinesToStock, reverseOutboundDoc } from "@/lib/store";
import * as Print from "expo-print";
import * as Sharing from "expo-sharing";
import { Platform } from "react-native";
import { PrintPreview } from "@/components/print-preview";
import { invoiceToPrintable, warehouseDocToPrintable } from "@/lib/print-templates";

export default function InvoiceDetailScreen() {
  const colors = useColors();
  const { db, setDB } = useStore();
  const { no } = useLocalSearchParams<{ no: string }>();
  const inv = db.invoices.find((i) => String(i.no) === String(no));
  const [profitOpen, setProfitOpen] = React.useState(false);
  const [historyOpen, setHistoryOpen] = React.useState(false);
  const [previewOpen, setPreviewOpen] = React.useState(false);
  const [docPreviewOpen, setDocPreviewOpen] = React.useState(false);
  const linkedDoc =
    inv && inv.linkedOutboundDocId != null
      ? (db.outboundDocs || []).find((d) => d.id === inv.linkedOutboundDocId)
      : undefined;

  if (!inv) {
    return (
      <ScreenContainer>
        <Header title="Fatura" back={() => router.back()} />
        <Text style={{ textAlign: "center", marginTop: 40, color: colors.muted }}>Fatura nuk u gjet.</Text>
      </ScreenContainer>
    );
  }

  const buildHtml = (size: "58" | "80" | "A4" = "A4") => {
    const width = size === "58" ? "58mm" : size === "80" ? "80mm" : "210mm";
    const fs = size === "A4" ? 12 : 11;
    const rows = inv.items
      .map(
        (it) => `<tr>
          <td>${it.productName}</td>
          <td style="text-align:center">${fmt(it.qty)} ${it.unit}</td>
          <td style="text-align:right">${fmt(it.rate)}</td>
          <td style="text-align:right">${fmt(it.total)}</td>
        </tr>`,
      )
      .join("");
    return `<!doctype html><html><head><meta charset="utf-8"/>
<style>
@page { size: ${size === "A4" ? "A4" : `${width} auto`}; margin: ${size === "A4" ? "12mm" : "4mm"}; }
body { font-family: -apple-system, Roboto, Helvetica, Arial, sans-serif; font-size: ${fs}px; color:#000; }
h1{font-size:18px;margin:0 0 4px} h2{font-size:14px;margin:0 0 6px} .muted{color:#555}
table{border-collapse:collapse;width:100%;margin-top:8px} th,td{padding:4px 6px;border-bottom:1px solid #ddd}
th{background:#f0f6fb;text-align:left}
.totals{margin-top:8px}.totals .row{display:flex;justify-content:space-between;margin-top:4px}
hr{border:0;border-top:1px dashed #aaa;margin:6px 0}
</style></head><body>
<h1>${db.company.name || ""}</h1>
<div class="muted">${db.company.address || ""} ${db.company.phone ? "• Tel " + db.company.phone : ""}</div>
${db.company.nipt ? `<div class="muted">NIPT: ${db.company.nipt}</div>` : ""}
<hr/>
<h2>FATURE SHITJE #${inv.no}</h2>
<div>Data: ${inv.date} ${inv.time}</div>
<div>Klient: <b>${inv.customer}</b></div>
<div>Mengyra: ${inv.mode} • ${inv.paymentType}</div>
<table>
  <thead><tr><th>Artikulli</th><th style="text-align:center">Sasia</th><th style="text-align:right">Cmimi</th><th style="text-align:right">Vlera</th></tr></thead>
  <tbody>${rows}</tbody>
</table>
<div class="totals">
  <div class="row"><span>Subtotali</span><b>${fmt(inv.subtotal)}</b></div>
  ${inv.roundOff ? `<div class="row"><span>Rrumbullakim</span><b>${fmt(inv.roundOff)}</b></div>` : ""}
  <div class="row"><span style="font-size:14px">TOTAL</span><b style="font-size:14px">${fmt(inv.total)} ${db.company.currency}</b></div>
  <div class="row"><span>Paguar</span><b>${fmt(inv.paid)}</b></div>
  <div class="row"><span>Detyrim</span><b>${fmt(inv.due)}</b></div>
</div>
${inv.note ? `<hr/><div>${inv.note}</div>` : ""}
<hr/>
<div style="text-align:center" class="muted">${db.company.footer || ""}</div>
</body></html>`;
  };

  const sharePDF = async (size: "58" | "80" | "A4") => {
    try {
      const { uri } = await Print.printToFileAsync({ html: buildHtml(size) });
      if (Platform.OS === "web") {
        await Print.printAsync({ html: buildHtml(size) });
        return;
      }
      if (await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(uri, { mimeType: "application/pdf", dialogTitle: `Fatura #${inv.no}` });
      } else {
        await Print.printAsync({ html: buildHtml(size) });
      }
    } catch (err: any) {
      Alert.alert("Gabim", err?.message || String(err));
    }
  };

  const remove = async () => {
    Alert.alert("Fshi", `Fshi faturen #${inv.no}?`, [
      { text: "Anulo" },
      {
        text: "Fshi",
        style: "destructive",
        onPress: async () => {
          // Restore stock. If a Fletë Dalje was linked, reverse THAT (which
          // also removes the doc + its movements); otherwise restore directly.
          let next = db;
          if (inv.linkedOutboundDocId != null) {
            next = reverseOutboundDoc(next, inv.linkedOutboundDocId);
          } else {
            next = { ...next, products: applyLinesToStock(next.products, inv.items, inv.store, 1) };
          }
          await setDB({
            ...next,
            invoices: next.invoices.filter((i) => i.no !== inv.no),
          });
          router.back();
        },
      },
    ]);
  };

  return (
    <ScreenContainer>
      <Header
        title={`Fatura #${inv.no}`}
        back={() => router.back()}
        right={
          <Pressable onPress={remove} hitSlop={8} style={{ padding: 6 }}>
            <Text style={{ color: colors.error, fontWeight: "800" }}>Fshi</Text>
          </Pressable>
        }
      />
      <ScrollView contentContainerStyle={{ paddingBottom: 40 }}>
        <View
          style={{
            margin: 12,
            backgroundColor: colors.surface,
            padding: 14,
            borderRadius: 10,
            borderWidth: 1,
            borderColor: colors.border,
          }}
        >
          <Text style={{ fontSize: 18, fontWeight: "900", color: colors.foreground }}>{inv.customer}</Text>
          <View style={{ marginTop: 6, flexDirection: "row", gap: 8 }}>
            <Badge tone={inv.due <= 0 ? "paid" : "open"}>{inv.due <= 0 ? "Paguar" : "Detyrim"}</Badge>
            <Badge>{inv.mode}</Badge>
          </View>
          <Text style={{ color: colors.muted, marginTop: 6 }}>
            {inv.date} {inv.time}
          </Text>
        </View>

        <View
          style={{
            marginHorizontal: 12,
            backgroundColor: colors.surface,
            padding: 14,
            borderRadius: 10,
            borderWidth: 1,
            borderColor: colors.border,
          }}
        >
          <Text style={{ fontWeight: "900", marginBottom: 6 }}>Artikujt</Text>
          {inv.items.map((it, idx) => (
            <View
              key={idx}
              style={{
                paddingVertical: 8,
                borderBottomWidth: idx === inv.items.length - 1 ? 0 : 1,
                borderColor: colors.border,
              }}
            >
              <Text style={{ fontWeight: "700" }}>{it.productName}</Text>
              <View style={{ flexDirection: "row", justifyContent: "space-between", marginTop: 4 }}>
                <Text style={{ color: colors.muted, fontSize: 12 }}>
                  {fmt(it.qty)} {it.unit} x {fmt(it.rate)}
                </Text>
                <Text style={{ fontWeight: "800" }}>{fmt(it.total)}</Text>
              </View>
            </View>
          ))}
        </View>

        <View
          style={{
            margin: 12,
            backgroundColor: colors.surface,
            padding: 14,
            borderRadius: 10,
            borderWidth: 1,
            borderColor: colors.border,
          }}
        >
          <Row k="Subtotali" v={fmt(inv.subtotal)} />
          {inv.roundOff ? <Row k="Rrumbullakim" v={fmt(inv.roundOff)} /> : null}
          <Row k="Totali" v={`${fmt(inv.total)} ${db.company.currency}`} bold />
          <Row k="Paguar" v={fmt(inv.paid)} />
          <Row k="Detyrim" v={fmt(inv.due)} />
        </View>

        {linkedDoc ? (
          <View
            style={{
              marginHorizontal: 12,
              marginBottom: 12,
              backgroundColor: "#eef4ff",
              padding: 12,
              borderRadius: 10,
              borderWidth: 1,
              borderColor: "#c7d7fb",
            }}
          >
            <Text style={{ fontWeight: "900", color: "#1d4ed8" }}>Fletë Dalje e lidhur</Text>
            <Text style={{ color: colors.muted, fontSize: 12, marginTop: 2 }}>
              {linkedDoc.no} • Magazina: {linkedDoc.warehouse}
            </Text>
            <View style={{ marginTop: 8 }}>
              <Btn
                fullWidth
                icon="doc.text.fill"
                title="Shiko / Printo Fletë Daljen"
                variant="soft"
                onPress={() => setDocPreviewOpen(true)}
              />
            </View>
          </View>
        ) : null}

        <View style={{ paddingHorizontal: 12, gap: 8 }}>
          <Btn fullWidth icon="pencil" title="Modifiko" variant="soft" onPress={() => router.push({ pathname: "/sale", params: { edit: String(inv.no) } } as any)} />
          <Btn fullWidth icon="printer.fill" title="Pamja e printimit" onPress={() => setPreviewOpen(true)} />
          <View style={{ flexDirection: "row", gap: 8 }}>
            <Btn title="PDF A4" variant="ghost" onPress={() => sharePDF("A4")} style={{ flex: 1 }} />
            <Btn title="Receipt 58mm" variant="ghost" onPress={() => sharePDF("58")} style={{ flex: 1 }} />
            <Btn title="Receipt 80mm" variant="ghost" onPress={() => sharePDF("80")} style={{ flex: 1 }} />
          </View>
          <View style={{ flexDirection: "row", gap: 8 }}>
            <Btn title="Llogaritja e fitimit" icon="chart.bar.fill" variant="soft" onPress={() => setProfitOpen(true)} style={{ flex: 1 }} />
            <Btn title="Historik pagesash" icon="creditcard.fill" variant="soft" onPress={() => setHistoryOpen(true)} style={{ flex: 1 }} />
          </View>
        </View>
      </ScrollView>

      {profitOpen ? (() => {
        const cost = inv.items.reduce((a, it) => a + num((it as any).cost || 0), 0);
        const profit = num(inv.total) - cost;
        const margin = inv.total ? (profit / inv.total) * 100 : 0;
        return (
          <Pressable
            onPress={() => setProfitOpen(false)}
            style={{ position: "absolute", inset: 0, backgroundColor: "rgba(0,0,0,0.4)", justifyContent: "center", padding: 24 }}
          >
            <Pressable onPress={() => {}} style={{ backgroundColor: colors.background, borderRadius: 12, padding: 16 }}>
              <Text style={{ fontWeight: "900", fontSize: 16, color: colors.foreground, marginBottom: 8 }}>Llogaritja e fitimit</Text>
              <Row k="Vlera e shitjes" v={`${fmt(inv.total)} ${db.company.currency}`} />
              <Row k="Kosto totale" v={fmt(cost)} />
              <Row k="Fitimi" v={fmt(profit)} bold />
              <Row k="Marzhi" v={`${margin.toFixed(1)}%`} />
              <Text style={{ color: colors.muted, fontSize: 11, marginTop: 8 }}>
                Kosto bazohet në çmimet e blerjes në momentin e shitjes.
              </Text>
              <Btn title="Mbyll" variant="ghost" onPress={() => setProfitOpen(false)} />
            </Pressable>
          </Pressable>
        );
      })() : null}

      {historyOpen ? (() => {
        const paymentsForInv = (db.payments || [])
          .filter((p: any) => p.partyType === "customer" && p.party === inv.customer)
          .filter((p: any) => p.invoiceNo === inv.no || (!p.invoiceNo && p.date >= inv.date));
        const initial = inv.paid && (!paymentsForInv.length || !paymentsForInv.some((p: any) => p.invoiceNo === inv.no))
          ? [{ date: inv.date, amount: inv.paid, method: inv.paymentType, note: "Pagesë fillestare" }]
          : [];
        const list = [...initial, ...paymentsForInv].sort((a: any, b: any) => String(a.date).localeCompare(String(b.date)));
        return (
          <Pressable
            onPress={() => setHistoryOpen(false)}
            style={{ position: "absolute", inset: 0, backgroundColor: "rgba(0,0,0,0.4)", justifyContent: "center", padding: 24 }}
          >
            <Pressable onPress={() => {}} style={{ backgroundColor: colors.background, borderRadius: 12, padding: 16, maxHeight: "80%" }}>
              <Text style={{ fontWeight: "900", fontSize: 16, color: colors.foreground, marginBottom: 8 }}>Historik pagesash</Text>
              {list.length === 0 ? (
                <Text style={{ color: colors.muted }}>Nuk ka pagesa të regjistruara.</Text>
              ) : (
                <ScrollView style={{ maxHeight: 360 }}>
                  {list.map((p: any, idx: number) => (
                    <View key={idx} style={{ paddingVertical: 8, borderBottomWidth: idx === list.length - 1 ? 0 : 1, borderColor: colors.border }}>
                      <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
                        <Text style={{ color: colors.foreground, fontWeight: "700" }}>{p.date}</Text>
                        <Text style={{ color: colors.primary, fontWeight: "800" }}>{fmt(p.amount)}</Text>
                      </View>
                      <Text style={{ color: colors.muted, fontSize: 12 }}>{p.method || "—"} · {p.note || ""}</Text>
                    </View>
                  ))}
                </ScrollView>
              )}
              <Btn title="Mbyll" variant="ghost" onPress={() => setHistoryOpen(false)} />
            </Pressable>
          </Pressable>
        );
      })() : null}

      <PrintPreview
        visible={previewOpen}
        onClose={() => setPreviewOpen(false)}
        doc={invoiceToPrintable(inv, db.company, db.products)}
        company={db.company}
        defaultPaper="A4"
      />

      {linkedDoc ? (
        <PrintPreview
          visible={docPreviewOpen}
          onClose={() => setDocPreviewOpen(false)}
          doc={warehouseDocToPrintable(linkedDoc, "outbound", db.company)}
          company={db.company}
          defaultPaper="A4"
        />
      ) : null}
    </ScreenContainer>
  );
}

function Row({ k, v, bold }: { k: string; v: string; bold?: boolean }) {
  const colors = useColors();
  return (
    <View style={{ flexDirection: "row", justifyContent: "space-between", paddingVertical: 4 }}>
      <Text style={{ color: colors.muted, fontWeight: bold ? "800" : "600", fontSize: bold ? 15 : 14 }}>{k}</Text>
      <Text style={{ color: colors.foreground, fontWeight: bold ? "900" : "700", fontSize: bold ? 15 : 14 }}>{v}</Text>
    </View>
  );
}
