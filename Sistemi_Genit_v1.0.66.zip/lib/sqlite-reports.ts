import { REPORT_CATALOG, buildReport, type ReportFilter, type ReportResult, type ReportType, type Column, type Row } from "./reports";
import { fmt, saveMultiDB, getMultiDB, type DB, type MultiDB } from "./store";
import { sqliteActiveCompanyId, sqliteAll, sqliteFirst } from "./sqlite-storage";

/**
 * Reads the persisted MultiDB JSON blob directly out of SQLite's kv_store
 * table (bypassing any in-memory/React state) and returns the DB slice for
 * `companyId`. This is used as the data source for every report type that
 * doesn't have a hand-written SQL-native implementation below, so those
 * reports still read live from SQLite on every call, never a cached
 * `useMemo` snapshot, while reusing the already-tested business logic in
 * `buildReport()`.
 */
async function loadFreshDbFromSqlite(companyId: string): Promise<DB | null> {
  try {
    const row = await sqliteFirst<{ value: string }>(
      "SELECT value FROM kv_store WHERE key = ?",
      ["sistemi_genit_mdb_v1"]
    );
    if (row?.value) {
      const parsed = JSON.parse(row.value) as MultiDB;
      const slice = parsed?.data?.[companyId];
      if (slice) return slice;
    }
  } catch (_) {}
  return null;
}

type SqlReport = ReportResult & { source?: "sqlite" };
type SqlParts = { where: string[]; params: any[] };

function normKey(s: string | undefined): string {
  return String(s || "").trim().toLowerCase().replace(/\s+/g, " ");
}

function periodLabel(f: ReportFilter): string {
  if (f.from && f.to) return `${f.from} → ${f.to}`;
  if (f.from) return `Nga ${f.from}`;
  if (f.to) return `Deri ${f.to}`;
  return "Të gjitha datat";
}

function addDate(parts: SqlParts, col: string, f: ReportFilter) {
  if (f.from) { parts.where.push(`${col} >= ?`); parts.params.push(f.from); }
  if (f.to) { parts.where.push(`${col} <= ?`); parts.params.push(f.to); }
}

function addText(parts: SqlParts, col: string, list?: string[], single?: string) {
  if (list && list.length) {
    const cleaned = list.map(normKey).filter(Boolean);
    if (cleaned.length) {
      parts.where.push(`LOWER(TRIM(${col})) IN (${cleaned.map(() => "?").join(",")})`);
      parts.params.push(...cleaned);
    }
  } else if (single && single.trim()) {
    parts.where.push(`LOWER(${col}) LIKE ?`);
    parts.params.push(`%${normKey(single)}%`);
  }
}

function addTxn(parts: SqlParts, col: string, f: ReportFilter) {
  if (!f.txnType || f.txnType === "all") return;
  if (f.txnType === "cash") parts.where.push(`${col} = 'Me arke'`);
  else parts.where.push(`${col} <> 'Me arke'`);
}

function addPayStatus(parts: SqlParts, totalCol: string, paidCol: string, f: ReportFilter) {
  if (!f.payStatus || f.payStatus === "all") return;
  if (f.payStatus === "paid") parts.where.push(`${paidCol} >= ${totalCol} - 0.001`);
  else if (f.payStatus === "unpaid") parts.where.push(`${paidCol} <= 0.001`);
  else parts.where.push(`${paidCol} > 0.001 AND ${paidCol} < ${totalCol} - 0.001`);
}

function addPriceFilter(parts: SqlParts, rateCol: string, f: ReportFilter) {
  if (!f.price || !f.price.trim()) return;
  const prices = f.price.split(/[;,]/).map(x => Number(x.trim().replace(",", "."))).filter(n => !isNaN(n));
  if (!prices.length) return;
  parts.where.push(`ROUND(${rateCol}, 2) IN (${prices.map(() => "?").join(",")})`);
  parts.params.push(...prices.map(p => Math.round(p * 100) / 100));
}

function docInvoiceWhere(companyId: string, f: ReportFilter): SqlParts {
  const p: SqlParts = { where: ["i.company_id = ?"], params: [companyId] };
  addDate(p, "i.date", f);
  addText(p, "i.customer", f.clients, f.client);
  addText(p, "i.store", f.stores, f.store);
  addText(p, "i.salesman", f.salesmen, f.salesman);
  addTxn(p, "i.mode", f);
  addPayStatus(p, "i.total", "i.paid", f);
  return p;
}

function addLineFilters(parts: SqlParts, productCol: string, unitCol: string, categoryCol: string, f: ReportFilter, rateCol?: string) {
  addText(parts, productCol, f.products, f.product);
  addText(parts, unitCol, f.units, f.unit);
  addText(parts, categoryCol, f.categories, f.category);
  if (rateCol) addPriceFilter(parts, rateCol, f);
}

function withSource(result: ReportResult): SqlReport {
  return { ...result, source: "sqlite" };
}

const money = (n: number) => fmt(Number(n || 0));

export async function buildSqliteReport(type: ReportType, f: ReportFilter): Promise<SqlReport | null> {
  const companyId = await sqliteActiveCompanyId();
  if (!companyId) return null;

  try { await saveMultiDB(getMultiDB()); } catch (_) {}

  const sub = periodLabel(f);

  if (type === "salesSummary" || type === "faturaTeresot" || type === "unpaidInvoices") {
    const p = docInvoiceWhere(companyId, f);
    if (type === "unpaidInvoices") {
      p.where.push("i.paid < i.total - 0.001");
    }
    const rows = await sqliteAll<Row>(
      `SELECT i.invoice_no AS no, i.date, i.customer AS party, i.total, i.paid, i.due, i.mode, i.profit 
       FROM invoices i 
       WHERE ${p.where.join(" AND ")} 
       ORDER BY i.date DESC, i.invoice_no DESC`,
      p.params
    );
    return withSource({
      type,
      title: REPORT_CATALOG.find(r => r.value === type)?.label || "Raport",
      subtitle: sub,
      columns: [
        { key: "party", label: "Klienti" },
        { key: "no", label: "Nr. Faturës" },
        { key: "date", label: "Data" },
        { key: "total", label: "Vlera", align: "right", format: "money" },
        { key: "due", label: "Detyrim", align: "right", format: "money" }
      ],
      rows,
      summary: [
        { label: "Fatura", value: String(rows.length) },
        { label: "Vlera Totale", value: money(rows.reduce((s, r) => s + Number(r.total || 0), 0)) },
        { label: "Detyrim Total", value: money(rows.reduce((s, r) => s + Number(r.due || 0), 0)) }
      ]
    });
  }

  if (type === "shitjeSot" || type === "salesByProduct") {
    const p = docInvoiceWhere(companyId, f);
    addLineFilters(p, "ii.product_name", "ii.unit", "COALESCE(pr.category,'')", f, "ii.rate");
    
    const lines = await sqliteAll<any>(
      `SELECT ii.product_name AS product, SUM(ii.qty) AS qty, SUM(ii.free_qty) AS free, ii.unit, ii.rate, SUM(ii.total) AS value
       FROM invoice_items ii
       JOIN invoices i ON i.company_id = ii.company_id AND i.invoice_no = ii.invoice_no
       LEFT JOIN products pr ON pr.company_id = ii.company_id AND LOWER(TRIM(pr.name)) = LOWER(TRIM(ii.product_name))
       WHERE ${p.where.join(" AND ")}
       GROUP BY ii.product_name, ii.unit, ii.rate
       ORDER BY ii.product_name ASC`,
      p.params
    );

    const totalValue = lines.reduce((s, l) => s + Number(l.value || 0), 0);
    const qtyTxt = (n: number) => Number(n || 0).toLocaleString("sq-AL", { maximumFractionDigits: 3 });
    
    const rows: Row[] = lines.map((l) => ({
      product: l.free > 0 ? `${l.product} (${qtyTxt(l.qty)} shitur +${qtyTxt(l.free)})` : l.product,
      qty: l.qty,
      unit: l.unit,
      rate: l.rate,
      value: l.value,
    }));

    // Add Total row
    rows.push({
      product: "TOTAL",
      qty: "",
      unit: "",
      rate: "",
      value: totalValue,
      _total: 1,
      _green: true
    });

    if (type === "shitjeSot") {
      const totalDue = await sqliteFirst<{val: number}>(
        `SELECT SUM(due) as val FROM invoices i WHERE ${p.where.join(" AND ")}`,
        p.params
      );
      const totalPaid = await sqliteFirst<{val: number}>(
        `SELECT SUM(paid) as val FROM invoices i WHERE ${p.where.join(" AND ")}`,
        p.params
      );

      rows.push({
        product: "BORXHI",
        qty: "",
        unit: "",
        rate: "",
        value: totalDue?.val || 0,
        _yellow: true
      });

      rows.push({
        product: "Arketuar",
        qty: "",
        unit: "",
        rate: "",
        value: totalPaid?.val || 0,
        _green: true
      });
    }

    return withSource({
      type,
      title: type === "shitjeSot" ? "Shitje Sot" : "Shitje sipas artikullit",
      subtitle: sub,
      columns: [
        { key: "product", label: "Emërtimi" },
        { key: "qty", label: "Sasi", align: "right", format: "qty" },
        { key: "unit", label: "Njësia" },
        { key: "rate", label: "Çmimi", align: "right", format: "money" },
        { key: "value", label: "Vlerë", align: "right", format: "money" }
      ],
      rows
    });
  }

  // Every other report in the catalog: read a FRESH snapshot straight out of
  // SQLite (kv_store, not React state) and run it through the fully
  // implemented, tested buildReport() logic. This guarantees full catalog
  // coverage with correct business logic while still honoring "SQLite is the
  // single source of truth" — there is no stale memoized `db` involved here,
  // every call re-reads SQLite.
  const freshDb = await loadFreshDbFromSqlite(companyId);
  if (freshDb) {
    try {
      return withSource(buildReport(type, freshDb, f));
    } catch (_) {
      // fall through to the diagnostic report below
    }
  }

  const entry = REPORT_CATALOG.find(r => r.value === type) || REPORT_CATALOG[0];
  return withSource({
    type,
    title: entry.label,
    subtitle: sub,
    columns: [{ key: "info", label: "Informacion" }],
    rows: [{ info: "Raporti SQLite pa implementim." }],
    emptyMessage: "Ky raport nuk u gjend dot në bazën e të dhënave SQLite."
  });
}

/**
 * Diagnostic smoke check used by the dev ERP self-test screen
 * (`app/erp-test.tsx`). Runs every report in `REPORT_CATALOG` through
 * `buildSqliteReport` and reports how many rows each returned (or -1 if it
 * threw), so a developer can see at a glance whether any report is broken.
 */
export async function sqliteReportsHealthCheck(): Promise<{
  ok: boolean;
  message: string;
  reportCounts: Record<string, number>;
}> {
  const companyId = await sqliteActiveCompanyId();
  if (!companyId) {
    return { ok: false, message: "Nuk u gjet kompani aktive në SQLite.", reportCounts: {} };
  }

  const reportCounts: Record<string, number> = {};
  let failures = 0;
  for (const entry of REPORT_CATALOG) {
    try {
      const res = await buildSqliteReport(entry.value, {});
      reportCounts[entry.value] = res?.rows?.length ?? 0;
    } catch (_) {
      reportCounts[entry.value] = -1;
      failures += 1;
    }
  }

  const ok = failures === 0;
  return {
    ok,
    message: ok
      ? `Të ${REPORT_CATALOG.length} raportet u gjeneruan pa gabime.`
      : `${failures} nga ${REPORT_CATALOG.length} raportet dështuan.`,
    reportCounts,
  };
}
