# Push to GitHub

This zip is the repo root (no wrapping folder) — extract it and the files
land directly where your repo should be.

```bash
unzip Sistemi_Genit_v1.0.66.zip -d sistemi-genit
cd sistemi-genit

git init
git add .
git commit -m "Sistemi Genit v1.0.66 — full report catalog live from SQLite"

# Create the repo on GitHub first (via github.com or `gh repo create`), then:
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo>.git
git push -u origin main
```

If you already have a GitHub repo for this project, replace the tracked
files instead of re-initializing:

```bash
cd path/to/existing/repo
rm -rf $(git ls-files)   # clears tracked files, keeps .git
unzip -o Sistemi_Genit_v1.0.66.zip -d .
git add -A
git commit -m "v1.0.66 — full report catalog live from SQLite, fix erp-test build error"
git push
```

A `.gitignore` is included (node_modules, .expo, build output, env files),
so `git add .` won't commit dependencies or secrets.

After pushing, install and run as usual:

```bash
npm install   # or pnpm install
npx expo start
```

See `BUILD_INSTRUCTIONS.md` for the full Android APK build steps.
