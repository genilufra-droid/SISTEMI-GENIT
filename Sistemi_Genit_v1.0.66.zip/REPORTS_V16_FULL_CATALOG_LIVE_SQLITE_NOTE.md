# v1.0.66 — Full report catalog, always live from SQLite

## Problemi i gjetur

`lib/sqlite-reports.ts` (`buildSqliteReport`) kishte SQL-native vetëm për 2 grupe
raportesh (`salesSummary/faturaTeresot/unpaidInvoices` dhe `shitjeSot/salesByProduct`).
Të gjitha raportet e tjera (~48 nga 53 në `REPORT_CATALOG`) binin në një mesazh
placeholder ("Ky raport do të implementohet së shpejti") në vend që të shfaqnin
të dhëna reale — pavarësisht se `reports.tsx` thërriste `buildSqliteReport`
saktë sipas `type`/`filters` dhe pavarësisht shënimeve të versioneve të
mëparshme (v14.2, v15.x) që pretendonin mbulim të plotë. Kjo është arsyeja pse
shumica e raporteve (Blerje sipas furnitorit, Kartela e klientit, Detyrime,
Manaxher, Shpenzime, Stoku, etj.) nuk përputheshin me sjelljen e videos.

## Zgjidhja

`buildSqliteReport` tani ka një shtresë fallback që:
1. Lexon direkt nga `kv_store` (tabela SQLite) blob-in e plotë `sistemi_genit_mdb_v1`
   — jo nga ndonjë state React i memorizuar (`useMemo`/`useState`) — kështu që
   të dhënat janë gjithmonë të freskëta.
2. E kalon atë snapshot te funksioni ekzistues dhe i testuar `buildReport()`
   (`lib/reports.ts`), i cili tashmë ka logjikën korrekte për të 53 llojet e
   raportit (kolona, filtra, total, etj., të mbuluara nga `tests/reports.test.ts`).
3. Vetëm nëse blob-i mungon ose lloji i raportit shkakton gabim, shfaqet
   raporti diagnostik ("Raporti SQLite pa implementim") — jo më si sjellje
   normale për dhjetëra raporte.

Raportet `salesSummary`, `faturaTeresot`, `unpaidInvoices`, `shitjeSot`,
`salesByProduct` vazhdojnë të përdorin query-t SQL të dedikuara (më të shpejta,
me formatim special: rreshti TOTAL/BORXHI/Arketuar jeshil/verdhë), pasi ato
janë raportet me trafikun më të lartë dhe formatim UI specifik.

## Rezultati

Të gjitha raportet në `REPORT_CATALOG` tani kthejnë të dhëna reale nga SQLite
në çdo ndryshim filtri/date, pa mesazhe "së shpejti" dhe pa fallback të fshehur
në një `db` të vjetëruar.

Version: 1.0.66
