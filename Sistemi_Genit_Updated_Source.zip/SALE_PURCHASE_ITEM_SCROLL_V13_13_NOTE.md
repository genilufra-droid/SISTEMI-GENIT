# v13.13 — Sale/Purchase Item Form Scroll Fix

Ky hotfix rregullon formën e vendosjes së artikullit në Shitje dhe Blerje.

Ndryshime:
- Forma e artikullit është brenda KeyboardAvoidingView + ScrollView me scroll vertikal të detyruar.
- Scroll punon edhe kur tastiera është hapur.
- U shtua padding i madh poshtë që butoni “Shto rreshtin” të mos mbulohet nga navigation bar.
- Njësitë Copë/Koli/Paletë janë horizontal-scrollable.
- Listat e çmimeve janë horizontal-scrollable që të mos zgjerojnë ekranin.
- E njëjta formë përdoret për Shitje dhe Blerje sepse të dyja hapin `/sale-item-select` me `kind=sale|purchase`.
- Versioni u rrit në 1.0.48.

Testo:
1. Shitje → Shto artikull → hap tastierën te Sasia/Cmimi → lëviz poshtë/lart.
2. Blerje → Shto artikull → hap tastierën → lëviz poshtë/lart.
3. Kontrollo që “Shto rreshtin” mbetet i arritshëm.
