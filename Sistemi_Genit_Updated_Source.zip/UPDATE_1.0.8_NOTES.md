# Sistemi Genit v1.0.8 — Patch Notes

Ky patch është bërë mbi source code-in e eksportuar nga Manus.ai.

## Rregullime të futura

1. **Bllokim shitjeje pa gjendje**
   - Shitja tani kontrollon stokun në magazinën e zgjedhur para ruajtjes.
   - Sasia llogaritet në copë bazë sipas njësisë/koeficientit.
   - Sasia falas (`freeQty`) del gjithashtu nga stoku.
   - Në editim fature, stoku i faturës së vjetër kthehet përkohësisht dhe pastaj kontrollohet fatura e re.

2. **Mbrojtje nga klikimi dy herë te Ruaj**
   - Te shitja dhe blerja u shtua `saving` state.
   - Kjo ul rrezikun e faturave të dyfishta nga shtypja e shpejtë.

3. **Bug te blerja**
   - Pas ruajtjes së blerjes, drafti po pastrohej gabimisht si `sale`.
   - U rregullua në `purchase`.

4. **Mbrojtje nga stok negativ në editim blerjeje**
   - Nëse ndryshimi i një blerjeje do krijonte stok negativ, sistemi e ndalon.

5. **Rregullim stoku më i sigurt**
   - Ulja e stokut nuk lejohet më nëse magazina nuk ka gjendje të mjaftueshme.

6. **Heqje permissions të panevojshme**
   - U hoqën `expo-audio`, `expo-video`, `expo-notifications` nga `package.json`.
   - U hoqën plugin-et audio/video nga `app.config.ts`.
   - `android.permissions` u vendos bosh për të shmangur mikrofon/audio/notification permissions pa arsye.

7. **Versionimi**
   - `package.json` dhe `app.config.ts` u ngritën në version `1.0.8`.

## Çfarë nuk është bërë ende

- Nuk u kalua ende në SQLite. Aktualisht ruajtja është ende `AsyncStorage`.
- Nuk u ndërtua APK sepse mungojnë `node_modules` dhe build environment lokal.
- `pnpm-lock.yaml` mund të ketë ende varësi të vjetra; pas patch-it ekzekuto `pnpm install` që lockfile të rifreskohet.

## Komandat për testim

```bash
pnpm install
pnpm check
pnpm test
npx expo prebuild --clean
npx expo run:android
```

## Rekomandimi teknik

Ky patch është stabilizim. Për version profesional duhet faza tjetër:

1. Migrim nga AsyncStorage në SQLite.
2. Tabelë `stock_movements` e vërtetë.
3. Backup/restore me version skeme.
4. Print 58mm/A4 me template të centralizuar.
5. PDF dhe XLSX të testuara në Android real.
