# v15.5 — All Report Layouts

Ndryshime kryesore:

- Shitje Sot, Shitje sipas artikullit, Blerje sipas artikullit, Kerkese Furnizimi, Supply Need dhe Purchase Suggestion dalin me format fizik:
  Item Name | Sasi | Njesi | Cmimi | Vlere + rresht Total.
- Raportet e transaksioneve/faturave mbeten si karta Vyapar, sepse rreshti hap dokumentin per editim/printim/fshirje.
- Te gjitha raportet e tjera dalin si tabela profesionale horizontale, jo si karta te perziera.
- Rreshtat total shfaqen me jeshile.
- Rreshtat normal mund te klikohen per hapje detajesh kur kane dokument/artikull/klient/furnitor.
- Popup 5 cmimet e fundit, scroll i formes Shto Artikull dhe filter bottom-sheet mbeten nga versionet e meparshme.

Version: 1.0.65
