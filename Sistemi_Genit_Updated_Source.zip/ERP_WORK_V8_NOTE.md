# Sistemi Genit v8 — ERP Work Package

Ky ZIP është paketë pune ERP mbi versionin që hapi APK-në në telefon. Qëllimi i v8 është të mos jetë vetëm ekran i bukur, por bazë pune për biznes shpërndarje/furgon:

## Përfshirë në paketë

- Shitje me artikuj, njësi, çmime, dhurata, pagesë, detyrim, kusur.
- Blerje me furnitor, artikuj, çmime, pagesë/detyrim.
- Klientë dhe furnitorë me kartela dhe balanca.
- Produkte me kategori, barkod/kod, njësi copë/koli/paletë, koeficientë, çmime blerje/shitje.
- Lista çmimesh dhe historik 5 çmimet e fundit për klient + artikull.
- Magazinë dhe stok sipas magazinës.
- Fletë Hyrje, Fletë Dalje, Transferim Magazine, Inventar Fizik.
- Fletë Dalje/Fletë Hyrje me tabelë si formular fizik: Nr, Emërtimi, Njësia, Sasia, Çmimi, Vlefta.
- Preview / PDF / Excel / Print nga lista e dokumenteve të magazinës për FH/FD.
- Raporte shitje, blerje, stok, fitim, detyrime, shpenzime, GPS/shitës.
- Eksport raportesh në XLSX real.
- Print/PDF për dokumente/fatura ku mbështetet nga moduli.
- Backup/restore JSON.
- Audit log për krijim/modifikim/fshirje shitje dhe blerje.
- Mbrojtje stoku: fshirje/ndryshim dokumentesh korrigjon stokun dhe bllokon stok negativ kur aplikohet.
- GPS/shitës për faturat dhe raporte vendndodhjeje.
- Multi-company dhe konfigurim kompanie.

## Çfarë u shtua në v8

- Versioni u ngrit në 1.0.30.
- Te `Dokumente Magazine`, dokumentet e fundit FH/FD nuk janë më vetëm listë: tani kanë butonin `Preview / PDF / Excel / Print`.
- FH/FD përdorin të njëjtin `PrintPreview` dhe `exportWarehouseDocToExcel`, që i mban formatet më të lidhura me njëri-tjetrin.

## Kufiri i sinqertë

Ky është version pune mbi source-in aktual, jo ERP final enterprise me databazë relacionale të plotë. Për fazën tjetër duhet migrim i plotë në SQLite, testim automatik i transaksioneve dhe stabilizim i çdo raporti me të dhëna reale.

## Testet minimale pas instalimit

1. Krijo produkt me 1 koli = 12 copë.
2. Bëj Fletë Hyrje 10 koli dhe kontrollo stokun.
3. Bëj Fletë Dalje 2 koli dhe kontrollo stokun.
4. Hap `Dokumente Magazine`, zgjidh FD/FH e fundit dhe testo Preview/PDF/Excel/Print.
5. Bëj shitje 10 koli + 1 dhuratë dhe kontrollo zbritjen e stokut.
6. Fshi faturën dhe kontrollo kthimin e stokut.
7. Hap raportet Shitje Sot, Stok, Fitim dhe Kërkesë Furnizimi.
