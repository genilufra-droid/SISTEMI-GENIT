# v13.9 Strict Filter Fix

- Forcon testet e filtrave duke përdorur kompani testimi të detyruar gjatë self-test.
- Shton kontroll raw SQL për të vërtetuar që fixture exact ekziston para testimit të raporteve.
- sqliteSaleLines tani përdor invoice_items si tabelë kryesore sepse filtrat realë janë në rreshtat e faturës: Artikull + Njësi + Çmim.
- Testet e salesAnalytic, salesByProduct, negative filters, reportUnit dhe multi-product mbeten PASS/FAIL kryesore.
