# v13.8 Strict Test Fix

Fixes false FAIL/false PASS risk in SQLite filter tests.

- `sqliteActiveCompanyId()` now reads the real multi-company key `sistemi_genit_mdb_v1` before legacy fallback.
- `Run tests` persists an isolated deterministic demo DB directly to SQLite before strict tests.
- PASS/FAIL rows now come only from `runErpSelfTests()`; `sqliteReportsHealthCheck()` remains a smoke/status message.
- Strict tests fail if the deterministic fixture has no invoice rows, instead of silently passing with zero expected rows.
- `salesAnalytic`, `salesByProduct`, negative product/unit/price, multi-product, reportUnit and performance tests validate against known SQLite data.
