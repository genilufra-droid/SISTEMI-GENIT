# v14.2 — SQLite report coverage / no silent fallback

Ky version heq fallback-in e heshtur nga moduli Raporte. Në v14.1 disa raporte ktheheshin `null` nga `buildSqliteReport` dhe UI binte në `buildReport(db)` në memorie. Kjo krijonte vonesa, të dhëna jo të rifreskuara dhe sjellje të paqëndrueshme kur ndërrohej raporti.

Ndryshimet kryesore:
- `buildSqliteReport` mbulon gjithë katalogun e raporteve me SQL-native ose raport diagnostik eksplicit.
- `reports.tsx` nuk bën më fallback të heshtur te memory `buildReport`.
- U shtuan implementime SQLite për ledger, unpaid invoices, stock by warehouse, item card, transfer report, salesman/GPS, expenses, manager reports dhe raportet e tjera që mungonin.
- U shtua tabela `expenses` në SQLite mirror dhe sinkronizim nga `db.expenses`.
- `sqliteReportsHealthCheck` tani kontrollon gjithë `REPORT_CATALOG`, jo vetëm një listë të vogël raportesh.

Nëse një raport i ri shtohet në katalog por nuk lidhet me SQLite, ekrani duhet të tregojë raport diagnostik “Raport SQLite pa implementim”, jo të lexojë fshehurazi nga memoria.
