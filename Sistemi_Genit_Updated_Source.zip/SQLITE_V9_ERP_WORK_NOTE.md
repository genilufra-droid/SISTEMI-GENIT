# Sistemi Genit v9 — SQLite ERP Work

Ky version kalon persistencën nga AsyncStorage-only në SQLite reale në telefon.

## Pikat kryesore

- Shton `expo-sqlite`.
- Krijon databazën `sistemi_genit_erp.sqlite`.
- Krijon tabela reale ERP:
  - `companies`
  - `products`
  - `parties`
  - `invoices`
  - `invoice_items`
  - `purchases`
  - `purchase_items`
  - `payments`
  - `stock_movements`
  - `warehouse_docs`
  - `audit_logs`
  - `kv_store` për snapshot-in e plotë multi-company.
- Mban fallback/migrim nga AsyncStorage që të mos humbasin të dhënat ekzistuese.
- Çdo `saveMultiDB()` ruan snapshot-in dhe rifreskon tabelat e normalizuara.
- Shton ekranin `Menu → Sistemi → Test ERP / SQLite`.

## Testimi i përfshirë

Ekrani `Test ERP / SQLite` teston:

1. Blerje 10+1 koli → krijon Fletë Hyrje.
2. Stoku pas blerjes = 132 copë.
3. Shitje 3+1 koli → krijon Fletë Dalje.
4. Stoku pas shitjes = 84 copë.
5. Bllokim shitje pa stok.
6. Fshirje fature → kthim stoku.
7. Historik i çmimeve të klientit.
8. Ndërtim raportesh kryesore.
9. HTML/PDF template për raportet kontrollon që kolonat janë të njëjta me report engine.
10. SQLite health check + numërim rreshtash në tabela.

## Print / PDF / Excel

Raportet vazhdojnë të përdorin të njëjtin `ReportResult` për ekran, PDF/print dhe Excel. Në v9 u përmirësua rreshti i filtrave në HTML/PDF që të pasqyrojë edhe filtrat multi-select: klientë, furnitorë, artikuj, magazina, njësi, shitës, kategori, status pagese dhe lloj transaksioni.

## Kujdes

Ky është migrim praktik mbi arkitekturën ekzistuese. Ekranet ende punojnë me DB object në memorie për të mos thyer aplikacionin. Persistenca reale dhe tabelat e normalizuara janë në SQLite. Faza tjetër mund të kalojë leximin e raporteve direkt mbi SQL queries për performancë më të madhe.
