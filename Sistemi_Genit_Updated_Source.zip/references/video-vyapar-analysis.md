# Analiza e videos (Vyapar) — XRecorder_20260602_01.mp4 (5:56 min)

## Home / Transactions
- Tabs: Transaction Details / Party Details
- Quick links: Add Txn, Sale Report, Txn Settings, Show All
- Search + filter
- Transaction list: emër klienti, status tag (SALE: PAID, PAYIN: USED), #ref, datë, total + balancë, ikona Print/Share/3-dot
- FAB i kuq: "Add New Sale"
- Bottom nav: Home, Dashboard, +, Items, Menu

## Dashboard (KPI)
- You'll Get (do marrësh) L 5,112 / You'll Give (do japësh) L 93,054
- Sale Overview (muaji) me grafik linje Prill→Qershor + % ndryshim
- Purchases (muaji), Expenses (muaji)
- Most Used Reports: Sales, Purchases, Bal. Sheet, Profit & Loss
- Cash In-Hand: L 381,836
- Inventory widget: Stock Value, No. of Items (94), Low Stock Items (52) me lista negative/zero
- Open Estimate/Quotations (1), Order Amount
- Expenses widget: Petrol, Manufacturing Expense, Karburant

## Items / Stock
- Tabs: PRODUCTS / CATEGORIES / UNITS
- Store selector (All Stores / Rugova)
- Quick links: Online Store, Stock Summary, Item Settings, Show All
- Item card: emër, kategori tag, çmim shitje, çmim blerje, in stock
- Item Details: Sale Price, Purchase Price, In Stock, Stock Value, Item Code, Stock Transactions list (Sale/Purchase/Add/Reduce me datë+sasi+total), butoni Adjust Stock
- Edit Item: Item Name, Item Code/Barcode, Category; Edit Unit (1 Koli = 12 Copë); custom: Cmimi Blerjes Cope, Cmim Shitje Cope; Pricing (Sale, Wholesale, Purchase); Stock (Opening Stock, As of Date, At Price/Unit, Min Stock Qty, Item Location)

## Sale invoice
- Invoice No, Date, Time, Store, Customer, Billed Items (qty, unit, price, subtotal), Charges, Round Off, Total, Received, Balance Due, Payment Type, Terms & Conditions
- Add new party inline (Contact, Opening Balance, Credit Limit, Address)
- Add Items: search, qty, unit dropdown (Copë→Koli), rate auto
- Received checkbox -> balance 0
- Warning për unsaved changes

## PDF / Export
- PDF popup: Open / Print / Share / Save to Phone
- Config çfarë të përfshihet (Item Details, Description, Payment status)
- Sale Report PDF: kolona Date, Ref No, Party, Txn Type, Total, Payment Type, Received/Paid, Balance + nën çdo rresht artikujt me qty/unit/price/amount
- Excel export te All Transactions

## Reports
- Sale Report (grouped by customer, This Month) + filter User/Txns Type/Party/Status (Paid/Unpaid/Partial/Cancelled)
- Bill Wise Profit (fitim per faturë; detail: Purchase Price, Total Cost, Sale Amount, Profit)
- Party Wise P&L (fitim per klient)
- Sale/Purchase by Party
- Item Report by Party (sasi shitur vs blerë)
- All Transactions (master ledger; filter status; Excel export)

## Settings
- General, Transaction, Invoice Print, Taxes, User Management, Reminders, Party, Item
- General: App Language, Currency, Decimal Places, Date Format, warning unsaved, Theme, Security (Passcode/Fingerprint), Stock Transfer Between Stores ON

## Transaction more-options menu (3-dot)
- Duplicate, Return, Delivery Note, Payment History, Share as Image
