# Sistemi Genit v3 hardening

Ky version shton rregullime reale, jo vetëm fasadë UI:

- Rregullon gabimin TypeScript në `purchaseSuggestion` ku `const prod` ishte deklaruar dy herë.
- Shton `auditLogs` në databazë për create/update/delete të shitjeve dhe blerjeve.
- Fshirja e faturës së shitjes tani kalon në `deleteSaleInvoice()`: kthen stokun, heq lëvizjet e magazinës dhe shkruan audit log.
- Fshirja e blerjes tani kalon në `deletePurchaseInvoice()`: kthen stokun, heq lëvizjet dhe shkruan audit log.
- Historiku i çmimeve të klientit tani përdor çelës të normalizuar (pa problem me shkronja të mëdha/spaces), nuk rrumbullakos çmime decimal dhe mban 5 sugjerime të fundit unike.
- Backup tani numëron edhe `auditLogs`.

Ngarko këtë ZIP në GitHub në vend të ZIP-it të vjetër dhe ekzekuto `Build APK From ZIP`.
