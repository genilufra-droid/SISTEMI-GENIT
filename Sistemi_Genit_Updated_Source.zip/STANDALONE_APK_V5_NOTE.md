# Sistemi Genit v5 - Standalone APK stability

Ky version fik React Native New Architecture ne `app.config.ts` per stabilitet me APK standalone nga GitHub Actions.

Arsyeja: APK debug i ndertuar me `assembleDebug` mund te ngece ne splash sepse nuk perfshin JS bundle dhe pret Metro/dev server. Per APK qe hapet direkt ne telefon duhet `assembleRelease` ose build standalone.

Ndryshime:
- version 1.0.20
- `newArchEnabled: false`
- workflow i rekomanduar: `assembleRelease`, jo `assembleDebug`

Pas instalimit, fshi versionin e vjeter debug nese Android thote "App not installed".
