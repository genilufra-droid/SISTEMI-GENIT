# v15.1 — Vyapar Exact Report UI

- Reports screen reshaped to match the Vyapar reference: header with PDF/XLS buttons, top date bar, filters applied row, filter bottom sheet, blue summary strip, and card-style result list.
- Filter button opens a bottom-sheet with left category tabs and right radio/check options.
- Result table is rendered as mobile cards similar to Vyapar sale report cards.
- Date changes continue to auto-refresh reports.
- Popup price history and sale/purchase item scroll remain unchanged.
- Version: 1.0.61
