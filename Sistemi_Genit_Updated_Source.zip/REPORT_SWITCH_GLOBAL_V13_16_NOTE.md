# v13.16 Global Report Switch Fix

Ky hotfix e zbaton rregullimin e ndërrimit të raportit në të gjitha raportet, jo vetëm në disa emra raportesh.

Ndryshime:
- U krijua një rrugë globale `selectReport()` për çdo ndërrim raporti.
- Picker-i i raporteve dhe strip-i i të preferuarave nuk përdorin më `setType()` direkt.
- Kur ndërrohet raporti pastrohet `rowSearch`, fshihet SQLite snapshot i vjetër dhe detyrohet refresh i ri.
- Tabela shfaq loading kur raporti i ri nuk ka ende rreshta, në vend që të duket si bosh ose të mbajë kolonat e vjetra.
- Route params bëjnë refresh të ri kur hapet raport tjetër nga menuja.
- Version 1.0.51.
