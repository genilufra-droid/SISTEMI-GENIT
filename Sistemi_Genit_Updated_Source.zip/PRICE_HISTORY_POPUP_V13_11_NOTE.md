# v13.11 — Price History Popup

Ndryshim kryesor:
- Lista “5 çmimet e fundit” nuk shfaqet më si listë e gjatë poshtë në ekranin e zgjedhjes së artikullit.
- Tani shfaqet si buton “5 çmimet e fundit”; kur klikohet hapet popup/modal.
- “Çmimet e fundit për këtë klient” gjithashtu hapen në popup.
- Kur zgjidhet një çmim nga popup, vendosen automatikisht njësia dhe çmimi te rreshti.
- Popup mbyllet vetë pas zgjedhjes.
- Butoni “Shto rreshtin” nuk shtyhet më poshtë nga lista e çmimeve.

Version: 1.0.46
