# V13.2 — Unit display + print button hotfix

Fixes after field testing on Android:

1. Print-preview action buttons are lifted above the Android navigation bar so PDF / Excel / Print / Close remain pressable.
2. Native print preview for Fletë Dalje / Fletë Hyrje now matches the physical form: only Nr, Emërtimi, Njësia, Sasia, Çmimi, Vlefta.
3. Koef and Sasia Copë are removed from warehouse physical preview and warehouse Excel line sheets.
4. Kërkesë Furnizimi sipas Daljeve now formats quantities based on the selected unit filter.
5. If Koli is selected and the base quantity is not divisible by the Koli coefficient, the report shows an exact mixed unit, e.g. 45 Koli + 6 Copë, not a false rounded 46 Koli.
6. Summary keeps total in base units because totals across products with different package coefficients cannot be safely summed as Koli/Paletë.
7. Report table column widths were improved so product/magazine/document columns are not crushed on mobile.

Internal stock remains in base units. Only report display changes.
