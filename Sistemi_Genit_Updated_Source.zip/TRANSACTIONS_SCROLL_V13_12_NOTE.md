# v13.12 Transactions Scroll Fix

- Moduli “Të gjitha transaksionet” u bë FlatList me scroll vertikal të detyruar (`style: flex: 1`, `showsVerticalScrollIndicator`, bottom padding).
- Filtrat Shitje/Blerje/Pagesa u bënë horizontal-scrollable që të mos priten në ekran të vogël.
- U shtua kërkim në transaksione sipas nr, klient/furnitor, datë, shumë, mënyrë pagese.
- U shtuan karta përmbledhëse për Shitje/Blerje/Pagesa/Detyrim.
- U shtua pull-to-refresh vizual. Store rifreskohet reaktivisht, por përdoruesi merr feedback.
- Version: 1.0.47
