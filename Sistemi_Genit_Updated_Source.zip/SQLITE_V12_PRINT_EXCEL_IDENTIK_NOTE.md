# Sistemi Genit v12 — Print/PDF/Excel identik për Dokumente Magazine

Ky version vazhdon mbi v11 që kaloi testet bazë.

## Fokus

- Fletë Dalje / Fletë Hyrje në format fizik A4 me kolonat reale:
  - Nr
  - Emërtimi i mallit
  - Njësia
  - Sasia
  - Çmimi
  - Vlefta
- U hoqën nga forma fizike kolonat teknike Koef / Sasia Copë. Ato mbeten vetëm te raportet teknike.
- Print/PDF përdorin të njëjtin template fizik.
- Excel për një dokument përdor të njëjtën strukturë fizike 6-kolonëshe.
- Excel masiv për dokumente magazine ka sheet shtesë `Fletet A4`, ku dokumentet dalin njëra pas tjetrës në format printimi.
- Sheet-et `Dokumente` dhe `Rreshtat` mbeten për kontroll analitik.

## Rregull pune

Dokumentet e magazinës janë dokumente sasiore. Koeficientët dhe copët janë për motorin e stokut; forma fizike mbetet e pastër për magazinierin/furnizimin.
