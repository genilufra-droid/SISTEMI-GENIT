# v13.10 Progressive Refresh + Sale Price List Fix

- Reports screen rebuilds SQLite reports automatically after every DB transaction, not only when filters/type change.
- SQLite report loading is progressive: memory result appears immediately, SQLite result replaces it when ready.
- Stale async SQLite results are ignored if filters change while a query is running.
- Sale item detail screen is scrollable with bottom safe-area padding so the Add Row button is not hidden by Android navigation/keyboard.
- Sale item add validates positive quantity/free quantity and rounds sale price at line creation.
- Version bumped to 1.0.45.
