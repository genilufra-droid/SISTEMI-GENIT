# Sistemi Genit v13.1 — Critical fixes

Ky version është hotfix mbi v13. Rregullon bug-et kritike të identifikuara para fazës UI/UX.

## Fix-e

1. `PrintableDoc.authorizedPerson` nuk është më duplikat në `lib/print-templates.ts`.
2. U shtua `isWarehousePhysicalDoc` dhe `WarehousePrintLine` për të ndarë dokumentet fizike të magazinës nga faturat/raportet teknike.
3. `warehouseDocToPrintable()` nuk dërgon më `coef`, `baseQty`, `costPiece` në line-at fizike të Fletë Hyrje/Fletë Dalje.
4. Stoku vazhdon të lëvizë vetëm me `baseQty = qty * coef`; u shtua helper `warehouseLineBaseQty()` dhe komente të qarta.
5. Çmimi i rreshtave të shitjes normalizohet me `Math.round()` para ruajtjes në DB.
6. `recordClientPrice()` ruan çmime të rrumbullakosura dhe deduplikon me çmime të rrumbullakosura.
7. `FilterModal` pranon `availableStatuses`, dhe Home screen i dërgon statuset reale që ekzistojnë në dokumente.
8. Forma e Fletë Daljes bën validim stokut para ruajtjes, përveç validimit final në `createOutboundDoc()`.

## Version

`app.config.ts`: 1.0.36
