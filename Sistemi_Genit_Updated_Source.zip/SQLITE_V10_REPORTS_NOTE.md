# Sistemi Genit v10 — SQLite Native Reports

Ky version e kalon fazën tjetër pas v9:

- Raportet kryesore lexohen direkt nga tabelat SQLite, jo vetëm nga objekti në memorie.
- Reports screen përdor SQLite kur raporti mbështetet; për raportet e pambështetura ruan fallback në motorin ekzistues.
- U shtua `lib/sqlite-reports.ts` me SQL-native reports për shitje, blerje, stok, lëvizje magazine, fletë hyrje/dalje, kërkesë furnizimi dhe balanca.
- Test ERP / SQLite tani kontrollon edhe raportet SQL-native dhe tregon numrin e rreshtave për çdo raport kryesor.
- Raportet analitike të shitjes/blerjes shfaqin qartë `Dhuratë` dhe `Tot. fizik` për të mos fshehur sasinë që lëviz stokun.

Version: 1.0.32
