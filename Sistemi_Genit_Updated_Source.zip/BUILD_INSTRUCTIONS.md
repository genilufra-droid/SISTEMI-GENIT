# Sistemi Genit — Build Instructions

**Sistemi Genit** is a React Native / Expo business management mobile app for sales, purchases, inventory, reports, clients, suppliers, and expenses — built in Albanian language.

## Tech Stack

- **Framework**: React Native 0.81 + Expo SDK 54
- **Language**: TypeScript 5.9
- **Routing**: Expo Router 6
- **Styling**: NativeWind 4 (Tailwind CSS)
- **State**: React Context + AsyncStorage (local persistence)
- **Database**: Local SQLite/JSON (offline-first, no cloud sync)
- **UI Language**: Albanian
- **Target Platform**: Android (APK)

## Prerequisites

Before building locally, ensure you have:

1. **Node.js** (v18+) and **pnpm** (v9.12.0+)
   ```bash
   node --version  # Should be v18 or higher
   npm install -g pnpm@9.12.0
   ```

2. **Android Studio** (for APK builds)
   - Download from [developer.android.com](https://developer.android.com/studio)
   - Install Android SDK (API 24+)
   - Set `ANDROID_HOME` environment variable

3. **Expo CLI** (installed via pnpm)
   ```bash
   pnpm install -g expo-cli
   ```

## Setup & Installation

### 1. Extract and Install Dependencies

```bash
# Extract the ZIP file
unzip sistemi-genit-source.zip
cd copy-of-sistemi-genit

# Install dependencies using pnpm
pnpm install
```

### 2. Verify TypeScript & Linting

```bash
# Check TypeScript compilation
pnpm check

# Run linting
pnpm lint

# Run tests
pnpm test
```

## Development

### Web Preview (for testing)

```bash
# Start dev server with Metro bundler
pnpm dev:metro

# This will open a web preview at http://localhost:8081
# Scan the QR code with Expo Go app on your Android device to preview on mobile
```

### Android Device / Emulator

```bash
# Start Expo for Android
pnpm android

# This will:
# 1. Start Metro bundler
# 2. Open Expo Go on your Android device/emulator
# 3. Load the app for live preview
```

## Building APK for Android Studio

### Option 1: Using Expo EAS (Recommended for Cloud Build)

If you want to build in the cloud:

```bash
# Install EAS CLI
pnpm install -g eas-cli

# Configure EAS (if not already done)
eas build:configure

# Build APK for Android
eas build --platform android --local
```

### Option 2: Local Build with Android Studio

If you want to build locally in Android Studio:

#### Step 1: Generate Android Project

```bash
# Prebuild the Android project
npx expo prebuild --clean
```

This creates an `android/` folder with a full Android Studio project.

#### Step 2: Open in Android Studio

1. Open **Android Studio**
2. Select **File → Open** and choose the `android/` folder
3. Wait for Gradle sync to complete

#### Step 3: Build APK

1. In Android Studio, go to **Build → Build Bundle(s) / APK(s) → Build APK(s)**
2. Wait for the build to complete
3. APK will be saved in `android/app/build/outputs/apk/release/`

#### Step 4: Install on Device

```bash
# Install APK on connected Android device
adb install android/app/build/outputs/apk/release/app-release.apk
```

## Project Structure

```
copy-of-sistemi-genit/
├── app/                          # Expo Router screens (Albanian UI)
│   ├── (tabs)/                   # Tab-based navigation
│   │   ├── index.tsx             # Home screen
│   │   ├── shitje.tsx            # Sales invoicing
│   │   ├── blerje.tsx            # Purchase invoicing
│   │   ├── raporte/              # Reports (Fatura Totale Sot, etc.)
│   │   ├── klientet.tsx          # Clients/Customers
│   │   ├── furnitoret.tsx        # Suppliers
│   │   ├── produktet.tsx         # Products & Inventory
│   │   └── settings.tsx          # Settings & Backup
│   ├── _layout.tsx               # Root layout with providers
│   └── oauth/                    # Auth callbacks
├── components/                   # Reusable UI components
│   ├── screen-container.tsx      # SafeArea wrapper
│   └── ui/                       # Icon mappings, themed views
├── lib/                          # Utilities & logic
│   ├── store.ts                  # Local data store (AsyncStorage)
│   ├── reports.ts                # Report aggregation logic
│   ├── excel.ts                  # Excel export
│   ├── sale-draft.ts             # Sale draft management
│   └── trpc.ts                   # API client
├── server/                       # Backend (Node.js + Express)
│   ├── _core/                    # Core server logic
│   ├── db.ts                     # Database setup (Drizzle ORM)
│   └── routers.ts                # API routes
├── database/                     # Database schema & migrations
├── assets/images/                # App icons, splash screen
├── tests/                        # Vitest unit tests
├── package.json                  # Dependencies
├── app.config.ts                 # Expo configuration
├── tsconfig.json                 # TypeScript config
├── tailwind.config.js            # Tailwind theme
└── pnpm-lock.yaml                # Dependency lock file
```

## Key Features

### ✅ Implemented

- **Sales Invoicing** (`shitje.tsx`) — Create, edit, save invoices with line items
- **Purchase Invoicing** (`blerje.tsx`) — Manage purchase orders
- **Inventory Management** — Track products, stock levels, units
- **Reports** — Daily sales aggregation, filtering by client/supplier/product
- **PDF/Excel Export** — Export filtered reports with recomputed totals
- **Client & Supplier Management** — Add, edit, delete parties
- **Settings & Backup** — Local data backup/import
- **Live Filtering** — Instant report filtering with normalized matching
- **Albanian Language** — Complete UI in Albanian

### 🚀 Next Steps (From Gap Analysis)

- Dashboard with KPI cards (Daily sales, Stock value, Low stock alerts)
- Return invoices (Faturë Kthimi / Credit Notes)
- Duplicate invoice feature
- Sale/Purchase by Party reports
- Share invoice as image (in addition to PDF)

## Configuration

### App Branding

Edit `app.config.ts` to customize:

```typescript
const env = {
  appName: "Sistemi Genit",        // App display name
  appSlug: "sistemi-genit",        // Unique identifier
  logoUrl: "...",                  // S3 URL of app icon
};
```

### Theme Colors

Edit `theme.config.js` to customize colors:

```javascript
const themeColors = {
  primary: { light: '#0a7ea4', dark: '#0a7ea4' },
  background: { light: '#ffffff', dark: '#151718' },
  // ... other colors
};
```

## Troubleshooting

### Build Fails with "Metro Bundler Error"

```bash
# Clear Metro cache
rm -rf .metro-cache
pnpm dev:metro
```

### Android Build Fails

```bash
# Clean Gradle cache
cd android
./gradlew clean
cd ..

# Rebuild
npx expo prebuild --clean
```

### TypeScript Errors

```bash
# Regenerate types
pnpm check
```

### Dependency Issues

```bash
# Reinstall all dependencies
rm -rf node_modules pnpm-lock.yaml
pnpm install
```

## Testing

```bash
# Run all tests
pnpm test

# Run specific test file
pnpm test tests/reports.test.ts

# Watch mode
pnpm test --watch
```

## Environment Variables

The app uses local storage (AsyncStorage) for data persistence. No external API keys are required for core functionality.

**Optional**: If you want to enable backend features (cloud sync, user auth, push notifications), see `server/README.md`.

## Database

The app uses **local SQLite/JSON** for offline-first data storage. No setup required — database is created automatically on first run.

To reset the database:

```bash
# Clear AsyncStorage
pnpm run reset-project
```

## Support & Resources

- **Expo Documentation**: https://docs.expo.dev
- **React Native Docs**: https://reactnative.dev
- **TypeScript**: https://www.typescriptlang.org
- **Tailwind CSS**: https://tailwindcss.com

## License

This project is proprietary. All rights reserved.

---

**Last Updated**: June 2026  
**Version**: 1.0.0
