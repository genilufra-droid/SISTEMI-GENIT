/**
 * Dokumente Magazine — v11 ERP Work.
 * Searchable warehouse-document module with filters and batch Preview/PDF/Print/Excel
 * for Fletë Hyrje / Fletë Dalje. This screen intentionally keeps the mobile UI
 * simple while the printed/exported output uses the same warehouse template.
 */
import { useMemo, useState } from "react";
import { Alert, FlatList, Platform, Pressable, Text, TextInput, View } from "react-native";
import { Stack, useRouter } from "expo-router";
import * as Print from "expo-print";
import * as Sharing from "expo-sharing";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { Badge, Btn, Card } from "@/components/ui-kit";
import { PrintPreview } from "@/components/print-preview";
import { useColors } from "@/hooks/use-colors";
import { useStore, type InboundDoc, type OutboundDoc } from "@/lib/store";
import { buildDocHtml, warehouseDocToPrintable, type PrintableDoc } from "@/lib/print-templates";
import { exportWarehouseDocsBatchToExcel } from "@/lib/excel";

type Recent = {
  key: string;
  no: string;
  date: string;
  warehouse: string;
  kind: "Fletë Hyrje" | "Fletë Dalje" | "Inventar" | "Transferim";
  docKind: "inbound" | "outbound" | "inventory" | "transfer";
  tone: "paid" | "open" | "neutral";
  lines: number;
  party?: string;
  destination?: string;
  note?: string;
  raw?: InboundDoc | OutboundDoc;
  warehouseKind?: "inbound" | "outbound";
};

type FilterKind = "all" | "inbound" | "outbound" | "inventory" | "transfer";

function norm(v: any): string {
  return String(v || "").trim().toLowerCase().replace(/\s+/g, " ");
}

function safeDocBody(html: string): string {
  const body = /<body[^>]*>([\s\S]*?)<\/body>/i.exec(html)?.[1];
  return body || html;
}
function safeDocStyle(html: string): string {
  const style = /<style[^>]*>([\s\S]*?)<\/style>/i.exec(html)?.[1];
  return style || "";
}

function buildBatchWarehouseHtml(docs: PrintableDoc[], company: any): string {
  const firstHtml = buildDocHtml(docs[0], company, "A4");
  const style = safeDocStyle(firstHtml);
  const pages = docs
    .map((d, i) => {
      const html = i === 0 ? firstHtml : buildDocHtml(d, company, "A4");
      return `<section class="doc-page">${safeDocBody(html)}</section>`;
    })
    .join('<div class="page-break"></div>');
  return `<!doctype html><html><head><meta charset="utf-8" />
<style>
${style}
@page { size: A4; margin: 12mm; }
body { background: #fff; }
.doc-page { page-break-inside: avoid; break-inside: avoid; }
.page-break { page-break-after: always; break-after: page; height: 0; }
</style></head><body>${pages}</body></html>`;
}

export default function WarehouseDocsScreen() {
  const router = useRouter();
  const colors = useColors();
  const { db } = useStore();
  const [previewDoc, setPreviewDoc] = useState<PrintableDoc | null>(null);
  const [query, setQuery] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [warehouse, setWarehouse] = useState("");
  const [kind, setKind] = useState<FilterKind>("all");
  const [busy, setBusy] = useState(false);

  const actions = [
    { label: "Fletë Hyrje", desc: "Shto stok në magazinë", icon: "tray.and.arrow.down.fill", path: "/inbound-doc" },
    { label: "Fletë Dalje", desc: "Zbrit stok nga magazina", icon: "tray.and.arrow.up.fill", path: "/outbound-doc" },
    { label: "Transferim Magazine", desc: "Lëviz stok mes magazinave", icon: "arrow.left.arrow.right", path: "/store-transfer" },
    { label: "Inventar Fizik", desc: "Numërim & rregullim stoku", icon: "checklist", path: "/inventory-doc" },
  ];

  const allDocs = useMemo<Recent[]>(() => {
    const rows: Recent[] = [];
    (db.inboundDocs || []).forEach((d) =>
      rows.push({
        key: "fh" + d.id,
        no: d.no,
        date: d.date,
        warehouse: d.warehouse,
        kind: "Fletë Hyrje",
        docKind: "inbound",
        tone: "paid",
        lines: d.lines.length,
        party: d.supplierName,
        destination: d.destinationAddress,
        note: d.reason || d.note,
        raw: d,
        warehouseKind: "inbound",
      }),
    );
    (db.outboundDocs || []).forEach((d) =>
      rows.push({
        key: "fd" + d.id,
        no: d.no,
        date: d.date,
        warehouse: d.warehouse,
        kind: "Fletë Dalje",
        docKind: "outbound",
        tone: "open",
        lines: d.lines.length,
        party: d.customerName,
        destination: d.destinationAddress,
        note: d.reason || d.note,
        raw: d,
        warehouseKind: "outbound",
      }),
    );
    (db.inventoryDocs || []).forEach((d) =>
      rows.push({
        key: "if" + d.id,
        no: d.no,
        date: d.date,
        warehouse: d.warehouse,
        kind: "Inventar",
        docKind: "inventory",
        tone: "neutral",
        lines: d.lines.length,
        party: d.customerName || d.supplierName,
        destination: d.destinationAddress,
        note: d.note,
      }),
    );
    (db.transfers || []).forEach((d) =>
      rows.push({
        key: "tr" + d.id,
        no: d.transferNo || `TR-${d.id}`,
        date: d.date,
        warehouse: `${d.fromWarehouse} → ${d.toWarehouse}`,
        kind: "Transferim",
        docKind: "transfer",
        tone: "neutral",
        lines: 1,
        party: "Transferim",
        note: d.note,
      }),
    );
    rows.sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : b.no.localeCompare(a.no)));
    return rows;
  }, [db.inboundDocs, db.outboundDocs, db.inventoryDocs, db.transfers]);

  const filteredDocs = useMemo(() => {
    const q = norm(query);
    const wh = norm(warehouse);
    return allDocs.filter((d) => {
      if (kind !== "all" && d.docKind !== kind) return false;
      if (from && d.date < from) return false;
      if (to && d.date > to) return false;
      if (wh && !norm(d.warehouse).includes(wh)) return false;
      if (q) {
        const hay = norm([
          d.no,
          d.date,
          d.kind,
          d.warehouse,
          d.party,
          d.destination,
          d.note,
          d.raw?.lines?.map((l) => l.productName).join(" "),
        ].join(" "));
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [allDocs, query, from, to, warehouse, kind]);

  const printableDocs = useMemo(() => {
    return filteredDocs
      .filter((d) => d.raw && d.warehouseKind)
      .map((d) => warehouseDocToPrintable(d.raw!, d.warehouseKind!, db.company));
  }, [filteredDocs, db.company]);

  const openWarehousePreview = (item: Recent) => {
    if (!item.raw || !item.warehouseKind) return;
    setPreviewDoc(warehouseDocToPrintable(item.raw, item.warehouseKind, db.company));
  };

  const resetFilters = () => {
    setQuery("");
    setFrom("");
    setTo("");
    setWarehouse("");
    setKind("all");
  };

  const batchHtml = () => {
    if (!printableDocs.length) throw new Error("Nuk ka Fletë Hyrje/Dalje në filtrin aktual.");
    return buildBatchWarehouseHtml(printableDocs, db.company);
  };

  const shareBatchPdf = async () => {
    try {
      setBusy(true);
      const html = batchHtml();
      if (Platform.OS === "web") {
        await Print.printAsync({ html });
        return;
      }
      const { uri } = await Print.printToFileAsync({ html });
      if (await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(uri, { mimeType: "application/pdf", dialogTitle: "Dokumente magazine", UTI: "com.adobe.pdf" });
      } else {
        await Print.printAsync({ html });
      }
    } catch (err: any) {
      Alert.alert("Gabim", err?.message || String(err));
    } finally {
      setBusy(false);
    }
  };

  const printBatch = async () => {
    try {
      setBusy(true);
      await Print.printAsync({ html: batchHtml() });
    } catch (err: any) {
      Alert.alert("Gabim", err?.message || String(err));
    } finally {
      setBusy(false);
    }
  };

  const excelBatch = async () => {
    try {
      setBusy(true);
      if (!printableDocs.length) throw new Error("Nuk ka Fletë Hyrje/Dalje në filtrin aktual.");
      await exportWarehouseDocsBatchToExcel(printableDocs, db.company, { title: "Dokumente Magazine" });
    } catch (err: any) {
      Alert.alert("Gabim", err?.message || String(err));
    } finally {
      setBusy(false);
    }
  };

  const chip = (value: FilterKind, label: string) => {
    const active = kind === value;
    return (
      <Pressable
        key={value}
        onPress={() => setKind(value)}
        style={{
          paddingHorizontal: 10,
          paddingVertical: 7,
          borderRadius: 999,
          borderWidth: 1,
          borderColor: active ? colors.primary : colors.border,
          backgroundColor: active ? colors.primary : colors.surface,
        }}
      >
        <Text style={{ color: active ? "#fff" : colors.foreground, fontWeight: "800", fontSize: 12 }}>{label}</Text>
      </Pressable>
    );
  };

  return (
    <>
      <Stack.Screen
        options={{
          title: "Dokumente Magazine",
          headerStyle: { backgroundColor: colors.primary },
          headerTintColor: "#fff",
        }}
      />
      <ScreenContainer>
        <FlatList
          data={filteredDocs}
          keyExtractor={(r) => r.key}
          contentContainerStyle={{ padding: 12, gap: 10, paddingBottom: 90 }}
          ListHeaderComponent={
            <View style={{ gap: 10, marginBottom: 4 }}>
              <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 10 }}>
                {actions.map((a) => (
                  <Pressable key={a.path} onPress={() => router.push(a.path as any)} style={{ width: "47.5%" }}>
                    <Card style={{ gap: 8, minHeight: 110, justifyContent: "center", marginHorizontal: 0 }}>
                      <IconSymbol name={a.icon as any} size={26} color={colors.primary} />
                      <Text style={{ color: colors.foreground, fontWeight: "800", fontSize: 15 }}>{a.label}</Text>
                      <Text style={{ color: colors.muted, fontSize: 11 }}>{a.desc}</Text>
                    </Card>
                  </Pressable>
                ))}
              </View>

              <Card style={{ marginHorizontal: 0, gap: 9 }}>
                <Text style={{ color: colors.foreground, fontWeight: "900", fontSize: 16 }}>Kërko dokumente</Text>
                <TextInput
                  value={query}
                  onChangeText={setQuery}
                  placeholder="Nr, artikull, palë, adresë, shënim..."
                  placeholderTextColor={colors.muted}
                  style={{ borderWidth: 1, borderColor: colors.border, borderRadius: 8, padding: 12, color: colors.foreground, backgroundColor: colors.surface }}
                />
                <View style={{ flexDirection: "row", gap: 8 }}>
                  <TextInput value={from} onChangeText={setFrom} placeholder="Nga YYYY-MM-DD" placeholderTextColor={colors.muted} style={{ flex: 1, borderWidth: 1, borderColor: colors.border, borderRadius: 8, padding: 10, color: colors.foreground }} />
                  <TextInput value={to} onChangeText={setTo} placeholder="Deri YYYY-MM-DD" placeholderTextColor={colors.muted} style={{ flex: 1, borderWidth: 1, borderColor: colors.border, borderRadius: 8, padding: 10, color: colors.foreground }} />
                </View>
                <TextInput
                  value={warehouse}
                  onChangeText={setWarehouse}
                  placeholder="Magazina / furgoni..."
                  placeholderTextColor={colors.muted}
                  style={{ borderWidth: 1, borderColor: colors.border, borderRadius: 8, padding: 10, color: colors.foreground }}
                />
                <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
                  {chip("all", "Të gjitha")}
                  {chip("inbound", "Fletë Hyrje")}
                  {chip("outbound", "Fletë Dalje")}
                  {chip("inventory", "Inventar")}
                  {chip("transfer", "Transferim")}
                </View>
                <Text style={{ color: colors.muted, fontSize: 12 }}>
                  U gjetën {filteredDocs.length} dokumente. Për batch PDF/Excel/Print përfshihen {printableDocs.length} Fletë Hyrje/Dalje.
                </Text>
                <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
                  <Btn title="PDF të gjitha" size="sm" variant="soft" icon="square.and.arrow.up" onPress={shareBatchPdf} disabled={busy || !printableDocs.length} />
                  <Btn title="Excel të gjitha" size="sm" variant="soft" icon="tablecells" onPress={excelBatch} disabled={busy || !printableDocs.length} />
                  <Btn title="Printo të gjitha" size="sm" icon="printer.fill" onPress={printBatch} disabled={busy || !printableDocs.length} />
                  <Btn title="Pastro" size="sm" variant="ghost" onPress={resetFilters} disabled={busy} />
                </View>
              </Card>

              <Text style={{ color: colors.foreground, fontWeight: "800", fontSize: 15, marginTop: 4 }}>
                Lista e dokumenteve
              </Text>
            </View>
          }
          renderItem={({ item }) => (
            <Card style={{ marginHorizontal: 0 }}>
              <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", gap: 8 }}>
                <View style={{ flex: 1, gap: 3 }}>
                  <View style={{ flexDirection: "row", alignItems: "center", gap: 6, flexWrap: "wrap" }}>
                    <Badge tone={item.tone}>{item.kind}</Badge>
                    <Text style={{ color: colors.foreground, fontWeight: "700" }}>{item.no}</Text>
                  </View>
                  <Text style={{ color: colors.muted, fontSize: 12 }}>{item.warehouse}</Text>
                  {item.party ? <Text style={{ color: colors.muted, fontSize: 12 }}>Palë: {item.party}</Text> : null}
                  {item.destination ? <Text style={{ color: colors.muted, fontSize: 12 }}>Dest.: {item.destination}</Text> : null}
                </View>
                <View style={{ alignItems: "flex-end" }}>
                  <Text style={{ color: colors.muted, fontSize: 12 }}>{item.date}</Text>
                  <Text style={{ color: colors.muted, fontSize: 12 }}>{item.lines} artikuj</Text>
                </View>
              </View>
              {item.raw && item.warehouseKind ? (
                <View style={{ flexDirection: "row", gap: 8, marginTop: 10 }}>
                  <Pressable
                    onPress={() => openWarehousePreview(item)}
                    style={({ pressed }) => ({
                      flex: 1,
                      borderRadius: 8,
                      borderWidth: 1,
                      borderColor: colors.primary,
                      paddingVertical: 9,
                      alignItems: "center",
                      opacity: pressed ? 0.7 : 1,
                    })}
                  >
                    <Text style={{ color: colors.primary, fontWeight: "900", fontSize: 12 }}>Preview / PDF / Excel / Print</Text>
                  </Pressable>
                </View>
              ) : null}
            </Card>
          )}
          ListEmptyComponent={
            <Text style={{ color: colors.muted, textAlign: "center", padding: 20 }}>
              Nuk u gjet asnjë dokument me këta filtra.
            </Text>
          }
        />
      </ScreenContainer>
      <PrintPreview
        visible={!!previewDoc}
        onClose={() => setPreviewDoc(null)}
        doc={previewDoc}
        company={db.company}
        defaultPaper="A4"
      />
    </>
  );
}
