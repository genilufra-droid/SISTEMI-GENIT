import React from "react";
import { Pressable, ScrollView, Text, View, Alert, Platform } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { Header } from "@/components/ui-kit";
import { router } from "expo-router";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useStore } from "@/lib/store";
import { serializeMultiBackup, multiBackupFilename } from "@/lib/backup";
import * as FileSystem from "expo-file-system/legacy";
import * as Sharing from "expo-sharing";

const ROWS = [
  { icon: "building.2.fill", label: "Profili i Kompanisë", path: "/company" },
  { icon: "gearshape.fill", label: "Cilësimet e transaksionit", path: "/txn-settings" },
  { icon: "square.and.arrow.up", label: "Backup të dhënat", path: "/backup" },
  { icon: "square.and.arrow.down", label: "Importo të dhënat", path: "/restore" },
];

export default function SettingsScreen() {
  const colors = useColors();
  const { db, reset, getMultiDB } = useStore();

  const makeSafetyBackup = async () => {
    const json = serializeMultiBackup(getMultiDB());
    const filename = `SIGURIA_PARA_RESET_${multiBackupFilename()}`;
    if (Platform.OS === "web") {
      const blob = new Blob([json], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      a.click();
      URL.revokeObjectURL(url);
      return;
    }
    const path = `${FileSystem.cacheDirectory}${filename}`;
    await FileSystem.writeAsStringAsync(path, json);
    if (await Sharing.isAvailableAsync()) {
      await Sharing.shareAsync(path, { mimeType: "application/json", dialogTitle: "Backup sigurie para reset" });
    }
  };

  const resetWithSafetyBackup = async () => {
    try {
      await makeSafetyBackup();
    } catch (_) {
      // Reset can continue even if the share dialog fails; the user already confirmed.
    }
    await reset();
    Alert.alert("U rivendos", "Të dhënat demo u rivendosën. U tentua backup sigurie para reset.");
  };

  return (
    <ScreenContainer>
      <Header title="Cilësime" />
      <ScrollView contentContainerStyle={{ padding: 12, paddingBottom: 100 }}>
        <View
          style={{
            backgroundColor: colors.surface,
            padding: 16,
            borderRadius: 8,
            borderWidth: 1,
            borderColor: colors.border,
            marginBottom: 12,
            alignItems: "center",
          }}
        >
          <View
            style={{
              width: 64,
              height: 64,
              borderRadius: 32,
              backgroundColor: colors.primary,
              alignItems: "center",
              justifyContent: "center",
              marginBottom: 8,
            }}
          >
            <Text style={{ color: "#fff", fontWeight: "900", fontSize: 18 }}>SG</Text>
          </View>
          <Text style={{ fontWeight: "900", fontSize: 18, color: colors.foreground }}>{db.company.name}</Text>
          {db.company.address ? (
            <Text style={{ color: colors.muted, marginTop: 2 }}>{db.company.address}</Text>
          ) : null}
        </View>
        {ROWS.map((m) => (
          <Pressable
            key={m.path}
            onPress={() => router.push(m.path as any)}
            style={({ pressed }) => ({
              flexDirection: "row",
              alignItems: "center",
              gap: 14,
              backgroundColor: colors.surface,
              padding: 14,
              borderRadius: 8,
              marginBottom: 8,
              borderWidth: 1,
              borderColor: colors.border,
              opacity: pressed ? 0.6 : 1,
            })}
          >
            <IconSymbol name={m.icon as any} size={22} color={colors.primary} />
            <Text style={{ flex: 1, fontSize: 15, color: colors.foreground, fontWeight: "700" }}>{m.label}</Text>
            <IconSymbol name="chevron.right" size={20} color={colors.muted} />
          </Pressable>
        ))}
        <Pressable
          onPress={() =>
            Alert.alert("Rivendos të dhënat", "Të gjitha të dhënat do të fshihen. Para reset do të krijohet backup sigurie. Vazhdo?", [
              { text: "Anulo" },
              { text: "Po", style: "destructive", onPress: resetWithSafetyBackup },
            ])
          }
          style={({ pressed }) => ({
            marginTop: 12,
            backgroundColor: "#fee2e2",
            padding: 14,
            borderRadius: 8,
            alignItems: "center",
            borderWidth: 1,
            borderColor: "#fecaca",
            opacity: pressed ? 0.7 : 1,
          })}
        >
          <Text style={{ color: "#991b1b", fontWeight: "800" }}>Rivendos demo data</Text>
        </Pressable>
        <Text style={{ color: colors.muted, textAlign: "center", marginTop: 18, fontSize: 12 }}>
          Sistemi Genit v1.0 — Vyapar Albania clone
        </Text>
      </ScrollView>
    </ScreenContainer>
  );
}
