import React from "react";
import { FlatList, Pressable, Switch, Text, TextInput, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { Header } from "@/components/ui-kit";
import { fmt, useStore, formatStockUnits, warehouseNames, warehouseStockOf } from "@/lib/store";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { router } from "expo-router";

export default function ItemsScreen() {
  const colors = useColors();
  const { db } = useStore();
  const [q, setQ] = React.useState("");
  const [selectedWarehouse, setSelectedWarehouse] = React.useState<string>("all");
  const [showOnlyWithStock, setShowOnlyWithStock] = React.useState<boolean>(false);

  // Warehouse chips: "Të gjitha magazinat" + every active warehouse.
  const warehouseOptions = React.useMemo(
    () => ["all", ...warehouseNames(db, false)],
    [db],
  );

  // If the selected warehouse disappears (renamed/removed), fall back to "all".
  React.useEffect(() => {
    if (selectedWarehouse !== "all" && !warehouseOptions.includes(selectedWarehouse)) {
      setSelectedWarehouse("all");
    }
  }, [warehouseOptions, selectedWarehouse]);

  const list = React.useMemo(() => {
    const v = q.trim().toLowerCase();
    let base = db.products;
    if (v) {
      base = base.filter(
        (p) =>
          p.name.toLowerCase().includes(v) ||
          (p.code || "").toLowerCase().includes(v) ||
          (p.barcode || "").toLowerCase().includes(v) ||
          (p.category || "").toLowerCase().includes(v),
      );
    }
    if (showOnlyWithStock) {
      base = base.filter((p) => warehouseStockOf(p, selectedWarehouse) > 0);
    }
    return base;
  }, [db.products, q, showOnlyWithStock, selectedWarehouse]);

  return (
    <ScreenContainer>
      <Header title="Artikujt" />
      <View style={{ padding: 12 }}>
        <View
          style={{
            backgroundColor: colors.surface,
            borderRadius: 8,
            paddingHorizontal: 12,
            flexDirection: "row",
            alignItems: "center",
            gap: 8,
            borderWidth: 1,
            borderColor: colors.border,
          }}
        >
          <IconSymbol name="magnifyingglass" size={20} color={colors.primary} />
          <TextInput
            value={q}
            onChangeText={setQ}
            placeholder="Kërko artikull, kod ose kategori"
            placeholderTextColor={colors.muted}
            style={{ flex: 1, paddingVertical: 12, color: colors.foreground }}
          />
        </View>
        <View style={{ flexDirection: "row", gap: 8, marginTop: 10 }}>
          <ItemsQuickLink
            label="Gjendja"
            icon="shippingbox.fill"
            onPress={() =>
              router.push({ pathname: "/(tabs)/reports", params: { type: "stockSummary" } } as any)
            }
          />
          <ItemsQuickLink
            label="Furnizim"
            icon="exclamationmark.triangle.fill"
            onPress={() =>
              router.push({ pathname: "/(tabs)/reports", params: { type: "supplyNeed" } } as any)
            }
          />
          <ItemsQuickLink
            label="Lëvizjet"
            icon="doc.fill"
            onPress={() =>
              router.push({ pathname: "/(tabs)/reports", params: { type: "stockMovement" } } as any)
            }
          />
          <ItemsQuickLink
            label="Inventar"
            icon="chart.bar.fill"
            onPress={() =>
              router.push({ pathname: "/(tabs)/reports", params: { type: "managerInventoryValue" } } as any)
            }
          />
        </View>

        {/* Warehouse filter */}
        <Text style={{ color: colors.muted, fontSize: 11, fontWeight: "800", textTransform: "uppercase", marginTop: 12, marginBottom: 6 }}>
          Magazina
        </Text>
        <FlatList
          horizontal
          showsHorizontalScrollIndicator={false}
          data={warehouseOptions}
          keyExtractor={(w) => w}
          contentContainerStyle={{ gap: 8 }}
          renderItem={({ item: w }) => {
            const active = selectedWarehouse === w;
            const label = w === "all" ? "Të gjitha magazinat" : w;
            return (
              <Pressable
                onPress={() => setSelectedWarehouse(w)}
                style={({ pressed }) => ({
                  paddingHorizontal: 14,
                  paddingVertical: 8,
                  borderRadius: 20,
                  backgroundColor: active ? colors.primary : colors.surface,
                  borderWidth: 1,
                  borderColor: active ? colors.primary : colors.border,
                  opacity: pressed ? 0.8 : 1,
                })}
              >
                <Text style={{ color: active ? "#fff" : colors.foreground, fontWeight: "700", fontSize: 13 }}>{label}</Text>
              </Pressable>
            );
          }}
        />

        {/* Show-only-with-stock toggle */}
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 10 }}>
          <Text style={{ color: colors.foreground, fontSize: 13, fontWeight: "600" }}>
            {showOnlyWithStock ? "Shfaq vetëm artikujt me stok" : "Shfaq të gjithë artikujt"}
          </Text>
          <Switch
            value={showOnlyWithStock}
            onValueChange={setShowOnlyWithStock}
            trackColor={{ true: colors.primary, false: colors.border }}
          />
        </View>
      </View>

      <FlatList
        data={list}
        keyExtractor={(p) => String(p.id)}
        contentContainerStyle={{ paddingBottom: 120 }}
        ListEmptyComponent={
          <Text style={{ textAlign: "center", color: colors.muted, marginTop: 30 }}>
            Asnjë artikull. Shto një me butonin (+)
          </Text>
        }
        renderItem={({ item }) => {
          const whStock = warehouseStockOf(item, selectedWarehouse);
          const whLabel = selectedWarehouse === "all" ? "Total" : selectedWarehouse;
          const zero = whStock <= 0;
          return (
          <Pressable
            onPress={() => router.push({ pathname: "/product/[id]", params: { id: String(item.id) } } as any)}
            style={{
              backgroundColor: colors.surface,
              marginHorizontal: 12,
              marginVertical: 5,
              borderRadius: 8,
              padding: 14,
              borderWidth: 1,
              borderColor: colors.border,
            }}
          >
            <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
              <Text style={{ fontWeight: "800", color: colors.foreground, fontSize: 15, flex: 1 }} numberOfLines={1}>
                {item.name}
              </Text>
              {item.category ? (
                <View style={{ backgroundColor: "#dceffd", paddingHorizontal: 8, paddingVertical: 2, borderRadius: 6 }}>
                  <Text style={{ fontSize: 11, color: colors.primary, fontWeight: "800" }}>{item.category}</Text>
                </View>
              ) : null}
            </View>
            <View style={{ flexDirection: "row", justifyContent: "space-between", marginTop: 8 }}>
              <Text style={{ color: colors.muted, fontSize: 12 }}>
                Shitje: <Text style={{ color: colors.foreground, fontWeight: "800" }}>{fmt(item.salePiece)}</Text>
              </Text>
              <Text style={{ color: colors.muted, fontSize: 12 }}>
                Blerje: <Text style={{ color: colors.foreground, fontWeight: "800" }}>{fmt(item.buyPiece)}</Text>
              </Text>
            </View>
            <View style={{ flexDirection: "row", justifyContent: "space-between", marginTop: 4 }}>
              <Text style={{ color: colors.muted, fontSize: 12 }}>
                Magazina: <Text style={{ color: colors.foreground, fontWeight: "800" }}>{whLabel}</Text>
              </Text>
            </View>
            <Text style={{ color: colors.muted, fontSize: 12, marginTop: 2 }}>
              Stok: <Text style={{ color: zero ? colors.error : colors.success, fontWeight: "800" }}>{formatStockUnits(item, whStock)}</Text>
            </Text>
          </Pressable>
          );
        }}
      />

      <Pressable
        onPress={() => router.push("/product/new" as any)}
        style={({ pressed }) => ({
          position: "absolute",
          bottom: 20,
          right: 20,
          width: 56,
          height: 56,
          borderRadius: 28,
          backgroundColor: colors.error,
          alignItems: "center",
          justifyContent: "center",
          opacity: pressed ? 0.85 : 1,
          elevation: 6,
        })}
      >
        <IconSymbol name="plus" size={28} color="#fff" />
      </Pressable>
    </ScreenContainer>
  );
}

function ItemsQuickLink({
  label,
  icon,
  onPress,
}: {
  label: string;
  icon: string;
  onPress: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => ({
        flex: 1,
        backgroundColor: colors.surface,
        borderWidth: 1,
        borderColor: colors.border,
        borderRadius: 10,
        paddingVertical: 10,
        alignItems: "center",
        opacity: pressed ? 0.7 : 1,
      })}
    >
      <IconSymbol name={icon as any} size={20} color={colors.primary} />
      <Text style={{ fontSize: 11, color: colors.foreground, fontWeight: "700", marginTop: 2 }}>{label}</Text>
    </Pressable>
  );
}
