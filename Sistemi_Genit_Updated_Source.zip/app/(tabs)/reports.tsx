import React from "react";
import { ActivityIndicator, Alert, FlatList, Platform, Pressable, ScrollView, Text, TextInput, View, Modal } from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useStore, allSalesmen } from "@/lib/store";
import {
  REPORT_CATALOG,
  ReportFilter,
  ReportType,
  type ReportResult,
  renderReportHtml,
} from "@/lib/reports";
import { exportReportToExcel } from "@/lib/excel";
import { buildSqliteReport } from "@/lib/sqlite-reports";
import * as Print from "expo-print";
import * as Sharing from "expo-sharing";
import { useSafeAreaInsets } from "react-native-safe-area-context";

type ParamShape = { type?: string; client?: string; supplier?: string; product?: string };
type ReportFilterTab = "salesman" | "txn" | "party" | "status" | "products" | "unit" | "price" | "store";

const EMPTY_FILTERS: ReportFilter = {
  clients: [],
  suppliers: [],
  products: [],
  stores: [],
  units: [],
  salesmen: [],
  categories: [],
  from: "",
  to: "",
  price: "",
  reportUnit: "",
  txnType: "all",
  payStatus: "all",
};

function pad2(n: number) { return String(n).padStart(2, "0"); }
function isoDate(d: Date) { return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`; }
function startOfMonth(d: Date) { return new Date(d.getFullYear(), d.getMonth(), 1); }
function endOfMonth(d: Date) { return new Date(d.getFullYear(), d.getMonth() + 1, 0); }
function addDays(d: Date, n: number) { const x = new Date(d); x.setDate(x.getDate() + n); return x; }

export default function ReportsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { db } = useStore();
  const params = useLocalSearchParams<ParamShape>();

  const [type, setType] = React.useState<ReportType>((params.type as ReportType) || "salesSummary");
  const [filters, setFilters] = React.useState<ReportFilter>(() => {
    const now = new Date();
    return {
      ...EMPTY_FILTERS,
      from: isoDate(startOfMonth(now)),
      to: isoDate(endOfMonth(now)),
    };
  });
  const [reportResult, setReportResult] = React.useState<ReportResult | null>(null);
  const [loading, setLoading] = React.useState(false);
  const [filterSheetOpen, setFilterSheetOpen] = React.useState(false);
  const [filterTab, setFilterTab] = React.useState<ReportFilterTab>("salesman");
  const [reportPickerOpen, setReportPickerOpen] = React.useState(false);

  const reportEntry = REPORT_CATALOG.find(r => r.value === type) || REPORT_CATALOG[0];

  const loadReport = React.useCallback(async () => {
    setLoading(true);
    try {
      const res = await buildSqliteReport(type, filters);
      setReportResult(res);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [type, filters]);

  React.useEffect(() => {
    loadReport();
  }, [loadReport]);

  const onExportPdf = async () => {
    if (!reportResult) return;
    const html = renderReportHtml(reportResult, { companyName: db.company.name, filters, currency: db.company.currency });
    try {
      if (Platform.OS === "web") {
        await Print.printAsync({ html });
      } else {
        const { uri } = await Print.printToFileAsync({ html });
        await Sharing.shareAsync(uri);
      }
    } catch (e) {
      Alert.alert("Gabim", "Dështoi gjenerimi i PDF.");
    }
  };

  const onExportExcel = async () => {
    if (!reportResult) return;
    try {
      await exportReportToExcel(reportResult, { companyName: db.company.name, filtersText: "", currency: db.company.currency });
    } catch (e) {
      Alert.alert("Gabim", "Dështoi gjenerimi i Excel.");
    }
  };

  const handleRowPress = (row: any) => {
    if (row._total) return;
    if (row.no) {
      const isSale = (db.invoices || []).some(i => String(i.no) === String(row.no));
      if (isSale) router.push(`/invoice/${row.no}`);
      else router.push(`/purchase/${row.no}`);
    } else if (row.party) {
      router.push(`/party/${encodeURIComponent(row.party)}`);
    } else if (row.name) {
      const prod = db.products.find(p => p.name === row.name);
      if (prod) router.push(`/product/${prod.id}`);
    }
  };

  const appliedChips = React.useMemo(() => {
    const chips = [];
    if (filters.txnType !== "all") chips.push(filters.txnType === "cash" ? "Kesh" : "Kredi");
    if (filters.payStatus !== "all") chips.push(filters.payStatus === "paid" ? "Paguar" : "Pa paguar");
    if (filters.clients?.length) chips.push(`${filters.clients.length} Klientë`);
    if (filters.products?.length) chips.push(`${filters.products.length} Artikuj`);
    return chips;
  }, [filters]);

  const renderFilterOptions = () => {
    let options: string[] = [];
    let key: keyof ReportFilter | null = null;

    if (filterTab === "salesman") { options = allSalesmen(db); key = "salesmen"; }
    else if (filterTab === "party") { options = [...db.customers.map(c => c.name), ...db.suppliers.map(s => s.name)]; key = "clients"; }
    else if (filterTab === "products") { options = db.products.map(p => p.name); key = "products"; }
    else if (filterTab === "store") { options = db.stores; key = "stores"; }

    if (filterTab === "txn") {
      return ["all", "cash", "credit"].map(t => (
        <Pressable key={t} onPress={() => setFilters(prev => ({ ...prev, txnType: t as any }))} style={{ paddingVertical: 12, flexDirection: "row", alignItems: "center" }}>
          <View style={{ width: 20, height: 20, borderRadius: 10, borderWidth: 2, borderColor: "#2196F3", marginRight: 10, backgroundColor: filters.txnType === t ? "#2196F3" : "transparent" }} />
          <Text style={{ fontSize: 16 }}>{t.toUpperCase()}</Text>
        </Pressable>
      ));
    }

    if (filterTab === "status") {
      return ["all", "paid", "partial", "unpaid"].map(t => (
        <Pressable key={t} onPress={() => setFilters(prev => ({ ...prev, payStatus: t as any }))} style={{ paddingVertical: 12, flexDirection: "row", alignItems: "center" }}>
          <View style={{ width: 20, height: 20, borderRadius: 10, borderWidth: 2, borderColor: "#2196F3", marginRight: 10, backgroundColor: filters.payStatus === t ? "#2196F3" : "transparent" }} />
          <Text style={{ fontSize: 16 }}>{t.toUpperCase()}</Text>
        </Pressable>
      ));
    }

    if (key && options.length) {
      return options.map(opt => {
        const isSelected = ((filters[key!] as string[]) || []).includes(opt);
        return (
          <Pressable key={opt} onPress={() => {
            setFilters(prev => {
              const cur = (prev[key!] as string[]) || [];
              const next = isSelected ? cur.filter(x => x !== opt) : [...cur, opt];
              return { ...prev, [key!]: next };
            });
          }} style={{ paddingVertical: 12, flexDirection: "row", alignItems: "center" }}>
            <View style={{ width: 20, height: 20, borderWidth: 2, borderColor: "#2196F3", marginRight: 10, backgroundColor: isSelected ? "#2196F3" : "transparent" }} />
            <Text style={{ fontSize: 16 }}>{opt}</Text>
          </Pressable>
        );
      });
    }

    return <Text style={{ color: "#999", marginTop: 20 }}>Nuk ka opsione.</Text>;
  };

  return (
    <ScreenContainer>
      <View style={{ height: 60, flexDirection: "row", alignItems: "center", paddingHorizontal: 16, backgroundColor: "#fff", borderBottomWidth: 1, borderColor: "#eee" }}>
        <Pressable onPress={() => router.back()} style={{ paddingRight: 16 }}>
          <Text style={{ fontSize: 24, fontWeight: "bold" }}>←</Text>
        </Pressable>
        <Pressable onPress={() => setReportPickerOpen(true)} style={{ flex: 1 }}>
          <Text style={{ fontSize: 18, fontWeight: "bold" }} numberOfLines={1}>{reportEntry.label}</Text>
        </Pressable>
        <Pressable onPress={onExportPdf} style={{ backgroundColor: "#ff4d4d", paddingHorizontal: 10, paddingVertical: 6, borderRadius: 4, marginRight: 8 }}>
          <Text style={{ color: "#fff", fontWeight: "bold" }}>PDF</Text>
        </Pressable>
        <Pressable onPress={onExportExcel} style={{ backgroundColor: "#2ecc71", paddingHorizontal: 10, paddingVertical: 6, borderRadius: 4 }}>
          <Text style={{ color: "#fff", fontWeight: "bold" }}>XLS</Text>
        </Pressable>
      </View>

      <View style={{ backgroundColor: "#fff", padding: 12, borderBottomWidth: 1, borderColor: "#eee" }}>
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
          <View style={{ flexDirection: "row", alignItems: "center" }}>
            <Text style={{ fontSize: 16, color: "#333", marginRight: 8 }}>📅</Text>
            <Text style={{ fontSize: 14, color: "#666" }}>{filters.from} - {filters.to}</Text>
          </View>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
            {["Today", "Yesterday", "This Week", "This Month"].map(p => (
              <Pressable key={p} onPress={() => {
                const now = new Date();
                let f = isoDate(now), t = isoDate(now);
                if (p === "Yesterday") { f = isoDate(addDays(now, -1)); t = f; }
                if (p === "This Week") { f = isoDate(addDays(now, -now.getDay())); }
                if (p === "This Month") { f = isoDate(startOfMonth(now)); t = isoDate(endOfMonth(now)); }
                setFilters(prev => ({ ...prev, from: f, to: t }));
              }}>
                <Text style={{ fontSize: 12, color: "#2196F3", paddingHorizontal: 4 }}>{p}</Text>
              </Pressable>
            ))}
          </ScrollView>
        </View>
      </View>

      <View style={{ backgroundColor: "#f9f9f9", padding: 12 }}>
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
          <Text style={{ fontSize: 14, fontWeight: "bold", color: "#666" }}>Filters Applied:</Text>
          <Pressable onPress={() => setFilterSheetOpen(true)}>
            <Text style={{ color: "#2196F3", fontWeight: "bold" }}>Filters ▽</Text>
          </Pressable>
        </View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {appliedChips.map((c, i) => (
            <View key={i} style={{ backgroundColor: "#e3f2fd", borderRadius: 16, paddingHorizontal: 12, paddingVertical: 4, marginRight: 8 }}>
              <Text style={{ fontSize: 12, color: "#1976d2" }}>{c}</Text>
            </View>
          ))}
        </ScrollView>
      </View>

      {loading ? (
        <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
          <ActivityIndicator size="large" color="#2196F3" />
        </View>
      ) : (
        <FlatList
          data={reportResult?.rows || []}
          keyExtractor={(_, index) => index.toString()}
          contentContainerStyle={{ padding: 12, paddingBottom: insets.bottom + 20 }}
          renderItem={({ item }) => {
            if (item._total || item._green || item._yellow) {
              return (
                <View style={{ 
                  backgroundColor: item._green ? "#16a34a" : item._yellow ? "#ffff00" : "#eee",
                  padding: 12, borderRadius: 4, marginVertical: 4, flexDirection: "row", justifyContent: "space-between"
                }}>
                  <Text style={{ fontWeight: "bold", flex: 2, color: item._green ? "#fff" : "#333" }}>{item.name || "Total"}</Text>
                  <Text style={{ fontWeight: "bold", flex: 1, textAlign: "right", color: item._green ? "#fff" : "#333" }}>{item.vlere ? Number(item.vlere).toLocaleString() : ""}</Text>
                </View>
              );
            }

            if (type === "salesSummary" || type === "faturaTeresot" || type === "unpaidInvoices") {
              return (
                <Pressable onPress={() => handleRowPress(item)} style={{ backgroundColor: "#fff", padding: 16, borderRadius: 8, marginBottom: 12, elevation: 2, shadowColor: "#000", shadowOpacity: 0.1, shadowRadius: 4 }}>
                  <View style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: 8 }}>
                    <Text style={{ fontSize: 16, fontWeight: "bold" }}>{item.party}</Text>
                    <Text style={{ fontSize: 12, color: "#666" }}>#{item.no} | {item.date}</Text>
                  </View>
                  <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
                    <Text style={{ color: "#666" }}>Amount: <Text style={{ color: "#333", fontWeight: "bold" }}>{Number(item.total).toLocaleString()}</Text></Text>
                    <Text style={{ color: "#666" }}>Balance: <Text style={{ color: "#ff4d4d", fontWeight: "bold" }}>{Number(item.due).toLocaleString()}</Text></Text>
                  </View>
                </Pressable>
              );
            }

            return (
              <Pressable onPress={() => handleRowPress(item)} style={{ flexDirection: "row", borderBottomWidth: 1, borderColor: "#eee", paddingVertical: 10 }}>
                <Text style={{ flex: 2, fontSize: 12 }} numberOfLines={2}>{item.name}</Text>
                <Text style={{ flex: 0.8, textAlign: "right", fontSize: 12 }}>{item.sasi}</Text>
                <Text style={{ flex: 0.6, textAlign: "center", fontSize: 12 }}>{item.njesi}</Text>
                <Text style={{ flex: 1, textAlign: "right", fontSize: 12 }}>{Number(item.cmimi).toLocaleString()}</Text>
                <Text style={{ flex: 1, textAlign: "right", fontSize: 12 }}>{Number(item.vlere).toLocaleString()}</Text>
              </Pressable>
            );
          }}
          ListHeaderComponent={
            (type === "shitjeSot" || type === "salesByProduct") ? (
              <View style={{ flexDirection: "row", borderBottomWidth: 2, borderColor: "#333", paddingBottom: 8, marginBottom: 8 }}>
                <Text style={{ flex: 2, fontWeight: "bold" }}>Item Name</Text>
                <Text style={{ flex: 0.8, textAlign: "right", fontWeight: "bold" }}>Sasi</Text>
                <Text style={{ flex: 0.6, textAlign: "center", fontWeight: "bold" }}>Njesi</Text>
                <Text style={{ flex: 1, textAlign: "right", fontWeight: "bold" }}>Cmimi</Text>
                <Text style={{ flex: 1, textAlign: "right", fontWeight: "bold" }}>Vlere</Text>
              </View>
            ) : null
          }
        />
      )}

      <Modal visible={filterSheetOpen} animationType="slide" transparent>
        <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "flex-end" }}>
          <View style={{ backgroundColor: "#fff", height: "80%", borderTopLeftRadius: 20, borderTopRightRadius: 20 }}>
            <View style={{ flexDirection: "row", justifyContent: "space-between", padding: 20, borderBottomWidth: 1, borderColor: "#eee" }}>
              <Text style={{ fontSize: 20, fontWeight: "bold" }}>Filters</Text>
              <Pressable onPress={() => setFilterSheetOpen(false)}><Text style={{ fontSize: 30 }}>×</Text></Pressable>
            </View>
            <View style={{ flex: 1, flexDirection: "row" }}>
              <View style={{ width: 140, backgroundColor: "#f5f5f5" }}>
                {[
                  ["salesman", "By User"],
                  ["txn", "By Txns Type"],
                  ["party", "By Party"],
                  ["status", "By Status"],
                  ["products", "By Item"],
                  ["unit", "By Unit"],
                  ["price", "By Price"],
                  ["store", "By Store"]
                ].map(([t, l]) => (
                  <Pressable key={t} onPress={() => setFilterTab(t as ReportFilterTab)} style={{ padding: 15, backgroundColor: filterTab === t ? "#fff" : "transparent" }}>
                    <Text style={{ fontWeight: filterTab === t ? "bold" : "normal", color: filterTab === t ? "#2196F3" : "#333" }}>{l}</Text>
                  </Pressable>
                ))}
              </View>
              <ScrollView style={{ flex: 1, padding: 15 }}>
                {renderFilterOptions()}
              </ScrollView>
            </View>
            <View style={{ padding: 20, borderTopWidth: 1, borderColor: "#eee", flexDirection: "row", gap: 10, paddingBottom: Math.max(insets.bottom, 20) }}>
              <Pressable onPress={() => setFilters(EMPTY_FILTERS)} style={{ flex: 1, padding: 15, backgroundColor: "#eee", borderRadius: 8, alignItems: "center" }}>
                <Text style={{ fontWeight: "bold" }}>Reset</Text>
              </Pressable>
              <Pressable onPress={() => { setFilterSheetOpen(false); loadReport(); }} style={{ flex: 1, padding: 15, backgroundColor: "#2196F3", borderRadius: 8, alignItems: "center" }}>
                <Text style={{ color: "#fff", fontWeight: "bold" }}>Apply</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>

      <Modal visible={reportPickerOpen} animationType="fade" transparent>
        <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "center", padding: 20 }}>
          <View style={{ backgroundColor: "#fff", borderRadius: 12, maxHeight: "80%" }}>
            <Text style={{ fontSize: 18, fontWeight: "bold", padding: 20, borderBottomWidth: 1, borderColor: "#eee" }}>Select Report</Text>
            <FlatList
              data={REPORT_CATALOG}
              renderItem={({ item }) => (
                <Pressable onPress={() => { setType(item.value); setReportPickerOpen(false); }} style={{ padding: 15, borderBottomWidth: 1, borderColor: "#eee" }}>
                  <Text style={{ fontWeight: type === item.value ? "bold" : "normal", color: type === item.value ? "#2196F3" : "#333" }}>{item.label}</Text>
                </Pressable>
              )}
            />
            <Pressable onPress={() => setReportPickerOpen(false)} style={{ padding: 20, alignItems: "center" }}>
              <Text style={{ color: "#2196F3", fontWeight: "bold" }}>Close</Text>
            </Pressable>
          </View>
        </View>
      </Modal>
    </ScreenContainer>
  );
}
