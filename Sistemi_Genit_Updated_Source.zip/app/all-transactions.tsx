import React from "react";
import { FlatList, Pressable, RefreshControl, ScrollView, Text, TextInput, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { Badge, Header } from "@/components/ui-kit";
import { router } from "expo-router";
import { fmt, useStore } from "@/lib/store";

type TxnFilter = "all" | "sale" | "purchase" | "payment";

type Row =
  | { kind: "sale"; date: string; no: number; party: string; total: number; due: number; search: string }
  | { kind: "purchase"; date: string; no: number; party: string; total: number; due: number; search: string }
  | { kind: "payment"; date: string; partyType: "customer" | "supplier"; party: string; amount: number; method: string; search: string };

const FILTERS: { value: TxnFilter; label: string }[] = [
  { value: "all", label: "Të gjitha" },
  { value: "sale", label: "Shitje" },
  { value: "purchase", label: "Blerje" },
  { value: "payment", label: "Pagesa" },
];

function norm(v: unknown) {
  return String(v ?? "").trim().toLowerCase();
}

export default function AllTransactionsScreen() {
  const colors = useColors();
  const { db } = useStore();
  const [filter, setFilter] = React.useState<TxnFilter>("all");
  const [query, setQuery] = React.useState("");
  const [refreshing, setRefreshing] = React.useState(false);

  const rows: Row[] = React.useMemo(() => {
    const sales = db.invoices.map((i) => {
      const search = ["shitje", i.no, i.date, i.customer, i.total, i.due, i.paymentType, i.mode]
        .map(norm)
        .join(" ");
      return { kind: "sale", date: i.date, no: i.no, party: i.customer, total: i.total, due: i.due, search } as Row;
    });
    const purchases = db.purchases.map((i) => {
      const search = ["blerje", i.no, i.date, i.supplier, i.total, i.due, i.paymentType, i.mode]
        .map(norm)
        .join(" ");
      return { kind: "purchase", date: i.date, no: i.no, party: i.supplier, total: i.total, due: i.due, search } as Row;
    });
    const payments = db.payments.map((p) => {
      const search = ["pagese", p.date, p.partyType, p.party, p.amount, p.method].map(norm).join(" ");
      return { kind: "payment", date: p.date, partyType: p.partyType, party: p.party, amount: p.amount, method: p.method, search } as Row;
    });

    const q = norm(query);
    let all = [...sales, ...purchases, ...payments];
    if (filter !== "all") all = all.filter((r) => r.kind === filter);
    if (q) all = all.filter((r) => r.search.includes(q));

    return all.sort((a, b) => {
      const dateCmp = b.date.localeCompare(a.date);
      if (dateCmp !== 0) return dateCmp;
      const aNo = "no" in a ? a.no : 0;
      const bNo = "no" in b ? b.no : 0;
      return bNo - aNo;
    });
  }, [db, filter, query]);

  const totals = React.useMemo(() => {
    return rows.reduce(
      (acc, r) => {
        if (r.kind === "sale") {
          acc.sales += 1;
          acc.salesTotal += r.total;
          acc.due += r.due;
        } else if (r.kind === "purchase") {
          acc.purchases += 1;
          acc.purchaseTotal += r.total;
          acc.due += r.due;
        } else {
          acc.payments += 1;
          acc.paymentTotal += r.amount;
        }
        return acc;
      },
      { sales: 0, purchases: 0, payments: 0, salesTotal: 0, purchaseTotal: 0, paymentTotal: 0, due: 0 },
    );
  }, [rows]);

  const refresh = React.useCallback(() => {
    // The store updates reactively; this explicit pull gesture is only visual feedback
    // for users who expect a transaction screen to refresh like a ledger.
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 350);
  }, []);

  const renderHeader = () => (
    <View style={{ paddingBottom: 8 }}>
      <View style={{ paddingHorizontal: 12, paddingTop: 12 }}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8, paddingRight: 12 }}>
          {FILTERS.map((o) => {
            const active = o.value === filter;
            return (
              <Pressable
                key={o.value}
                onPress={() => setFilter(o.value)}
                style={{
                  backgroundColor: active ? colors.primary : colors.surface,
                  borderColor: active ? colors.primary : colors.border,
                  borderWidth: 1,
                  borderRadius: 999,
                  paddingHorizontal: 16,
                  paddingVertical: 10,
                }}
              >
                <Text style={{ color: active ? "#fff" : colors.foreground, fontWeight: "900" }}>{o.label}</Text>
              </Pressable>
            );
          })}
        </ScrollView>
      </View>

      <View style={{ paddingHorizontal: 12, paddingTop: 10 }}>
        <TextInput
          value={query}
          onChangeText={setQuery}
          placeholder="Kërko nr, klient, furnitor, datë, shumë..."
          placeholderTextColor={colors.muted}
          style={{
            minHeight: 48,
            borderWidth: 1,
            borderColor: colors.border,
            borderRadius: 12,
            paddingHorizontal: 14,
            backgroundColor: colors.surface,
            color: colors.foreground,
            fontWeight: "700",
          }}
        />
      </View>

      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8, paddingHorizontal: 12, paddingTop: 10 }}>
        <SummaryCard title="Shitje" value={`${totals.sales}`} sub={fmt(totals.salesTotal)} />
        <SummaryCard title="Blerje" value={`${totals.purchases}`} sub={fmt(totals.purchaseTotal)} />
        <SummaryCard title="Pagesa" value={`${totals.payments}`} sub={fmt(totals.paymentTotal)} />
        <SummaryCard title="Detyrim" value={fmt(totals.due)} sub="hapur" warn />
      </View>

      <Text style={{ color: colors.muted, fontWeight: "800", paddingHorizontal: 16, paddingTop: 8 }}>
        {rows.length} transaksione
      </Text>
    </View>
  );

  function SummaryCard({ title, value, sub, warn }: { title: string; value: string; sub: string; warn?: boolean }) {
    return (
      <View
        style={{
          flexGrow: 1,
          minWidth: "46%",
          backgroundColor: colors.surface,
          borderWidth: 1,
          borderColor: colors.border,
          borderRadius: 12,
          padding: 10,
        }}
      >
        <Text style={{ color: colors.muted, fontWeight: "800", fontSize: 12 }}>{title}</Text>
        <Text style={{ color: warn ? colors.error : colors.foreground, fontWeight: "900", fontSize: 18, marginTop: 2 }}>
          {value}
        </Text>
        <Text style={{ color: colors.muted, fontWeight: "700", marginTop: 2 }} numberOfLines={1}>
          {sub}
        </Text>
      </View>
    );
  }

  return (
    <ScreenContainer>
      <Header title="Të gjitha transaksionet" back={() => router.back()} />
      <FlatList
        style={{ flex: 1 }}
        data={rows}
        keyExtractor={(item, i) => `${item.kind}-${"no" in item ? item.no : item.party}-${item.date}-${i}`}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator
        bounces
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={refresh} />}
        contentContainerStyle={{ paddingBottom: 130 }}
        ListHeaderComponent={renderHeader}
        ListEmptyComponent={
          <Text style={{ textAlign: "center", color: colors.muted, marginTop: 30, fontWeight: "700" }}>
            Asnjë transaksion për këtë filtër.
          </Text>
        }
        renderItem={({ item }) => {
          if (item.kind === "payment") {
            return (
              <View
                style={{
                  marginHorizontal: 12,
                  marginVertical: 5,
                  backgroundColor: colors.surface,
                  padding: 12,
                  borderRadius: 10,
                  borderWidth: 1,
                  borderColor: colors.border,
                }}
              >
                <View style={{ flexDirection: "row", justifyContent: "space-between", gap: 8 }}>
                  <View style={{ flexDirection: "row", gap: 6, alignItems: "center", flex: 1 }}>
                    <Badge tone="paid">Pagesë</Badge>
                    <Text style={{ fontWeight: "900", flex: 1 }} numberOfLines={1}>{item.party}</Text>
                  </View>
                  <Text style={{ fontWeight: "900", color: colors.success }}>{fmt(item.amount)}</Text>
                </View>
                <Text style={{ color: colors.muted, marginTop: 4, fontSize: 12, fontWeight: "700" }}>
                  {item.date} • {item.method} • {item.partyType === "customer" ? "Klient" : "Furnitor"}
                </Text>
              </View>
            );
          }
          return (
            <Pressable
              onPress={() =>
                item.kind === "sale"
                  ? router.push({ pathname: "/invoice/[no]", params: { no: String(item.no) } } as any)
                  : router.push({ pathname: "/purchase/[no]", params: { no: String(item.no) } } as any)
              }
              style={({ pressed }) => ({
                marginHorizontal: 12,
                marginVertical: 5,
                backgroundColor: colors.surface,
                padding: 12,
                borderRadius: 10,
                borderWidth: 1,
                borderColor: colors.border,
                opacity: pressed ? 0.88 : 1,
              })}
            >
              <View style={{ flexDirection: "row", justifyContent: "space-between", gap: 8 }}>
                <View style={{ flexDirection: "row", gap: 6, alignItems: "center", flex: 1 }}>
                  <Badge tone={item.kind === "sale" ? "paid" : "open"}>{item.kind === "sale" ? "Shitje" : "Blerje"}</Badge>
                  <Text style={{ fontWeight: "900", flex: 1 }} numberOfLines={1}>{item.party}</Text>
                </View>
                <Text style={{ fontWeight: "900", color: colors.foreground }}>{fmt(item.total)}</Text>
              </View>
              <View style={{ flexDirection: "row", justifyContent: "space-between", marginTop: 4, gap: 8 }}>
                <Text style={{ color: colors.muted, fontSize: 12, fontWeight: "700" }}>
                  #{item.no} • {item.date}
                </Text>
                {item.due > 0 ? (
                  <Text style={{ color: colors.error, fontWeight: "900", fontSize: 12 }}>Detyrim: {fmt(item.due)}</Text>
                ) : (
                  <Text style={{ color: colors.success, fontWeight: "900", fontSize: 12 }}>Mbyllur</Text>
                )}
              </View>
            </Pressable>
          );
        }}
      />
    </ScreenContainer>
  );
}
