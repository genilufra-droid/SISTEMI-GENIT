import React from "react";
import { Alert, ScrollView, View, Text, Pressable } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { Header, Btn, Field } from "@/components/ui-kit";
import { router, useLocalSearchParams } from "expo-router";
import { fmt, nextProductId, num, stockInStore, totalStock, stockUnitBreakdown, stockByWarehouseRows, formatStockUnits, useStore, type Product, type Unit, todayStr } from "@/lib/store";
import { IconSymbol } from "@/components/ui/icon-symbol";

/** Unit row uses free-text coef so the user can clear "1" and type e.g. "12". */
type UnitDraft = { name: string; coef: string };

/**
 * Convert stored units (base-unit coefficients) into form drafts whose coef is
 * RELATIVE to the previous unit. base[0] is always the base unit (relative 1).
 * e.g. base coefs [1, 12, 1368] => relative drafts ["1", "12", "114"].
 */
function baseUnitsToRelativeDrafts(units: Unit[]): UnitDraft[] {
  return units.map((u, i) => {
    if (i === 0) return { name: u.name, coef: "1" };
    const prevBase = num(units[i - 1].coef) || 1;
    const rel = prevBase > 0 ? num(u.coef) / prevBase : num(u.coef);
    // Trim trailing decimals for clean display (e.g. 12.0 -> "12").
    return { name: u.name, coef: String(Number(rel.toFixed(6))) };
  });
}

export default function ProductFormScreen() {
  const colors = useColors();
  const { db, setDB } = useStore();
  const { id } = useLocalSearchParams<{ id: string }>();
  const isNew = id === "new";
  const editing = !isNew ? db.products.find((p) => String(p.id) === String(id)) : null;

  const [name, setName] = React.useState(editing?.name || "");
  const [code, setCode] = React.useState(editing?.code || "");
  const [barcode, setBarcode] = React.useState(editing?.barcode || "");
  const [category, setCategory] = React.useState(editing?.category || "");
  const [store, setStore] = React.useState(editing?.store || db.stores[0] || "Magazina kryesore");
  const [salePiece, setSalePiece] = React.useState(String(editing?.salePiece ?? ""));
  const [buyPiece, setBuyPiece] = React.useState(String(editing?.buyPiece ?? ""));
  // Opening stock is entered for the chosen store. For existing items show that store's stock.
  const [stock, setStock] = React.useState(
    String(editing ? stockInStore(editing, editing.store || db.stores[0]) : "0"),
  );
  const [minStock, setMinStock] = React.useState(String(editing?.minStock ?? ""));
  // Units are stored with a BASE-unit coefficient (how many base pieces = 1 unit).
  // In the form we show each unit's coefficient RELATIVE to the previous unit
  // (e.g. 1 Koli = 12 Copë, 1 Paletë = 114 Koli). The base coefficient is then
  // computed by cascading: base[i] = relative[i] × base[i-1] (base[0] = 1).
  const [units, setUnits] = React.useState<UnitDraft[]>(() =>
    baseUnitsToRelativeDrafts(
      editing?.units || [
        { name: "Copë", coef: 1 },
        { name: "Koli", coef: 12 },
      ],
    ),
  );
  // Live base-unit coefficients derived from the relative inputs above.
  const baseCoefs = React.useMemo(() => {
    let prev = 1;
    return units.map((u, i) => {
      if (i === 0) {
        prev = 1;
        return 1;
      }
      const rel = num(u.coef) > 0 ? num(u.coef) : 1;
      const base = rel * prev;
      prev = base;
      return base;
    });
  }, [units]);
  const baseUnitName = units[0]?.name?.trim() || "copë";

  // Live multi-unit stock breakdown (base / second / third …). Stock is stored
  // in base units; here we convert the TOTAL base stock into every unit using
  // the live coefficients so the user sees e.g. 1.368 copë / 114 koli / 1 paletë.
  const stockBreakdown = React.useMemo(() => {
    const otherStores = editing
      ? totalStock(editing) - stockInStore(editing, editing.store || store)
      : 0;
    const totalBase = Math.max(0, otherStores) + num(stock);
    const liveUnits: Unit[] = units
      .map((u, i) => ({ name: u.name.trim(), coef: baseCoefs[i] || 1 }))
      .filter((u) => u.name);
    return stockUnitBreakdown(
      { units: liveUnits.length ? liveUnits : [{ name: baseUnitName, coef: 1 }] } as Product,
      totalBase,
    );
  }, [editing, store, stock, units, baseCoefs, baseUnitName]);

  // Per-warehouse stock overview (read-only). Reflects the live-edited value for
  // the currently selected store; other stores show their persisted stock.
  const warehouseRows = React.useMemo(() => {
    if (!editing) return [];
    const norm = (s: string) => s.trim().toLowerCase();
    return stockByWarehouseRows(db, editing).map((r) =>
      norm(r.warehouse) === norm(store)
        ? { ...r, pieces: num(stock), label: formatStockUnits(editing, num(stock)) }
        : r,
    );
  }, [db, editing, store, stock]);
  const warehouseTotal = warehouseRows.reduce((s, r) => s + r.pieces, 0);

  const listNames = db.company.priceListNames || [];
  const [prices, setPrices] = React.useState<string[]>(() => {
    const arr = editing?.prices || [];
    return Array.from({ length: 10 }, (_, i) => (arr[i] != null && arr[i] > 0 ? String(arr[i]) : ""));
  });
  const [showPrices, setShowPrices] = React.useState(false);

  const save = async () => {
    if (!name.trim()) {
      Alert.alert("Emri", "Emri eshte i detyrueshem.");
      return;
    }
    // Normalize units: drop empty names, then cascade the RELATIVE coefficients
    // into BASE-unit coefficients. The first unit is always the base (coef 1).
    // e.g. relative [1, 12, 114] => base [1, 12, 12×114=1368].
    const named = units.filter((u) => u.name.trim());
    let prevBase = 1;
    const cleanUnits: Unit[] = named.map((u, i) => {
      if (i === 0) {
        prevBase = 1;
        return { name: u.name.trim(), coef: 1 };
      }
      const rel = num(u.coef) > 0 ? num(u.coef) : 1;
      const base = rel * prevBase;
      prevBase = base;
      return { name: u.name.trim(), coef: base };
    });
    const finalUnits = cleanUnits.length > 0 ? cleanUnits : [{ name: "Copë", coef: 1 }];

    const openingBase = num(stock); // entered in base units for the chosen store

    // Build stockByStore: keep other stores intact, set the chosen store to the entered value.
    const prevMap: Record<string, number> = { ...(editing?.stockByStore || {}) };
    if (editing && (!editing.stockByStore || Object.keys(editing.stockByStore).length === 0)) {
      // migrate legacy single stock into its home store
      prevMap[editing.store || store] = num(editing.stock);
    }
    prevMap[store] = openingBase;
    const total = Object.values(prevMap).reduce((s, v) => s + num(v), 0);

    const newProduct: Product = {
      id: editing?.id ?? nextProductId(db),
      name: name.trim(),
      code: code.trim() || undefined,
      barcode: barcode.trim() || undefined,
      category: category.trim() || undefined,
      store,
      salePiece: num(salePiece),
      buyPiece: num(buyPiece),
      stock: total,
      stockByStore: prevMap,
      minStock: minStock ? num(minStock) : undefined,
      units: finalUnits,
      prices: prices.map((p) => num(p)),
    };
    let nextProducts: Product[];
    if (editing) {
      nextProducts = db.products.map((p) => (p.id === editing.id ? newProduct : p));
    } else {
      nextProducts = [...db.products, newProduct];
    }
    // Add price history entry if prices changed or new
    let priceHistory = db.priceHistory;
    const lastPh = db.priceHistory.filter((r) => r.product === newProduct.name).slice(-1)[0];
    if (
      !lastPh ||
      lastPh.salePiece !== newProduct.salePiece ||
      lastPh.buyPiece !== newProduct.buyPiece
    ) {
      priceHistory = [
        ...db.priceHistory,
        {
          product: newProduct.name,
          fromDate: todayStr(),
          salePiece: newProduct.salePiece,
          buyPiece: newProduct.buyPiece,
        },
      ];
    }
    await setDB({ ...db, products: nextProducts, priceHistory });
    router.back();
  };

  const remove = async () => {
    if (!editing) return;
    Alert.alert("Fshi", `Fshi artikullin "${editing.name}"?`, [
      { text: "Anulo" },
      {
        text: "Fshi",
        style: "destructive",
        onPress: async () => {
          await setDB({ ...db, products: db.products.filter((p) => p.id !== editing.id) });
          router.back();
        },
      },
    ]);
  };

  return (
    <ScreenContainer>
      <Header title={editing ? `Modifiko ${editing.name}` : "Artikull i ri"} back={() => router.back()} />
      <ScrollView contentContainerStyle={{ padding: 12, paddingBottom: 40 }}>
        <Field label="Emri *" value={name} onChangeText={setName} />
        <View style={{ flexDirection: "row", gap: 8 }}>
          <Field containerStyle={{ flex: 1 }} label="Kodi / SKU" value={code} onChangeText={setCode} />
          <Field containerStyle={{ flex: 1 }} label="Barkodi" value={barcode} onChangeText={setBarcode} keyboardType="numeric" />
        </View>
        <Field label="Kategoria" value={category} onChangeText={setCategory} />

        {/* Store selector */}
        <Text style={{ color: colors.muted, fontSize: 12, marginTop: 8, marginBottom: 4 }}>Magazina</Text>
        <View style={{ flexDirection: "row", gap: 6, flexWrap: "wrap" }}>
          {db.stores.map((s) => (
            <Pressable
              key={s}
              onPress={() => {
                setStore(s);
                if (editing) setStock(String(stockInStore(editing, s)));
              }}
              style={{
                paddingVertical: 8,
                paddingHorizontal: 12,
                borderRadius: 999,
                borderWidth: 1,
                borderColor: s === store ? colors.primary : colors.border,
                backgroundColor: s === store ? "#dceffd" : colors.surface,
              }}
            >
              <Text style={{ color: s === store ? colors.primary : colors.foreground, fontWeight: "700", fontSize: 12 }}>{s}</Text>
            </Pressable>
          ))}
        </View>

        <View style={{ flexDirection: "row", gap: 8, marginTop: 8 }}>
          <Field containerStyle={{ flex: 1 }} label="Cmim shitje *" keyboardType="numeric" value={salePiece} onChangeText={setSalePiece} />
          <Field containerStyle={{ flex: 1 }} label="Cmim blerje" keyboardType="numeric" value={buyPiece} onChangeText={setBuyPiece} />
        </View>
        <View style={{ flexDirection: "row", gap: 8 }}>
          <Field
            containerStyle={{ flex: 1 }}
            label={`Stoku te "${store}" (copë)`}
            keyboardType="numeric"
            value={stock}
            onChangeText={setStock}
          />
          <Field containerStyle={{ flex: 1 }} label="Stoku min." keyboardType="numeric" value={minStock} onChangeText={setMinStock} />
        </View>
        {editing && db.stores.length > 1 ? (
          <Text style={{ color: colors.muted, fontSize: 11, marginBottom: 4 }}>
            Stok total (të gjitha magazinat): {totalStock(editing)} copë
          </Text>
        ) : null}

        {/* Gjendja në njësi të shumëfishta (bazë / njësia 2 / njësia 3) */}
        {stockBreakdown.length ? (
          <View
            style={{
              backgroundColor: colors.surface,
              borderWidth: 1,
              borderColor: colors.border,
              borderRadius: 10,
              padding: 12,
              marginTop: 4,
              marginBottom: 4,
            }}
          >
            <Text style={{ color: colors.muted, fontWeight: "800", fontSize: 12, marginBottom: 6 }}>
              Gjendja sipas njësive
            </Text>
            {stockBreakdown.map((u, i) => (
              <View
                key={i}
                style={{ flexDirection: "row", justifyContent: "space-between", marginTop: i === 0 ? 0 : 4 }}
              >
                <Text style={{ color: colors.muted, fontSize: 13 }}>
                  {i === 0 ? "Stoku bazë" : `Njësia ${i + 1}`} ({u.name})
                </Text>
                <Text style={{ color: colors.foreground, fontWeight: "800", fontSize: 13 }}>
                  {fmt(u.qty)} {u.name}
                </Text>
              </View>
            ))}
          </View>
        ) : null}

        {/* Gjendje sipas magazinës (stock by warehouse) */}
        {editing && warehouseRows.length ? (
          <View
            style={{
              backgroundColor: colors.surface,
              borderWidth: 1,
              borderColor: colors.border,
              borderRadius: 10,
              padding: 12,
              marginTop: 4,
              marginBottom: 4,
            }}
          >
            <Text style={{ color: colors.muted, fontWeight: "800", fontSize: 12, marginBottom: 6 }}>
              Gjendje sipas magazinës
            </Text>
            {warehouseRows.map((r, i) => (
              <View
                key={r.warehouse}
                style={{ flexDirection: "row", justifyContent: "space-between", marginTop: i === 0 ? 0 : 4 }}
              >
                <Text style={{ color: colors.muted, fontSize: 13 }}>{r.warehouse}</Text>
                <Text style={{ color: r.pieces > 0 ? colors.foreground : colors.error, fontWeight: "800", fontSize: 13 }}>
                  {r.label}
                </Text>
              </View>
            ))}
            <View style={{ height: 1, backgroundColor: colors.border, marginVertical: 8 }} />
            <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
              <Text style={{ color: colors.foreground, fontWeight: "900", fontSize: 13 }}>Total</Text>
              <Text style={{ color: colors.primary, fontWeight: "900", fontSize: 13 }}>
                {editing ? formatStockUnits(editing, warehouseTotal) : ""}
              </Text>
            </View>
          </View>
        ) : null}

        <Text style={{ color: colors.muted, fontWeight: "800", marginTop: 8, marginBottom: 4 }}>Njesite & konvertimet</Text>
        <Text style={{ color: colors.muted, fontSize: 11, marginBottom: 6 }}>
          Njësia 1 është gjithmonë njësia bazë (copë). Koeficienti i çdo njësie tjetër
          tregon sa njësi të mëparshme bën 1 njësi e re. P.sh. 1 Koli = 12 Copë → 12;
          1 Paletë = 114 Koli → 114 (llogaritet automatikisht: 114 × 12 = 1.368 copë).
        </Text>
        {units.map((u, i) => {
          const isBase = i === 0;
          const prevName = i > 0 ? units[i - 1].name?.trim() || "njësi" : baseUnitName;
          return (
            <View key={i}>
              <View style={{ flexDirection: "row", gap: 8, alignItems: "flex-end" }}>
                <Field
                  containerStyle={{ flex: 2 }}
                  label={isBase ? "Njesia 1 (bazë)" : `Njesia ${i + 1}`}
                  value={u.name}
                  onChangeText={(v) => setUnits((arr) => arr.map((x, j) => (j === i ? { ...x, name: v } : x)))}
                />
                <Field
                  containerStyle={{ flex: 1 }}
                  label={isBase ? "Bazë" : `Sa ${prevName}`}
                  keyboardType="numeric"
                  value={isBase ? "1" : u.coef}
                  editable={!isBase}
                  onChangeText={(v) =>
                    setUnits((arr) => arr.map((x, j) => (j === i ? { ...x, coef: v.replace(/[^\d.]/g, "") } : x)))
                  }
                />
                {isBase ? (
                  <View style={{ paddingBottom: 14, paddingHorizontal: 6, width: 32 }} />
                ) : (
                  <Pressable
                    hitSlop={8}
                    onPress={() => setUnits((arr) => arr.filter((_, j) => j !== i))}
                    style={{ paddingBottom: 14, paddingHorizontal: 6 }}
                  >
                    <IconSymbol name="trash.fill" size={20} color={colors.error} />
                  </Pressable>
                )}
              </View>
              {!isBase && u.name.trim() ? (
                <Text style={{ color: colors.primary, fontSize: 11, marginTop: -2, marginBottom: 6, fontWeight: "700" }}>
                  1 {u.name.trim()} = {fmt(baseCoefs[i])} {baseUnitName}
                </Text>
              ) : null}
            </View>
          );
        })}
        <Btn
          fullWidth
          variant="soft"
          icon="plus"
          title="Shto njesi"
          onPress={() => setUnits((u) => [...u, { name: "", coef: "" }])}
          style={{ marginTop: 6 }}
        />

        <Pressable
          onPress={() => setShowPrices((s) => !s)}
          style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 16, marginBottom: 4 }}
        >
          <Text style={{ color: colors.muted, fontWeight: "800" }}>Listat e cmimeve (10)</Text>
          <IconSymbol name={showPrices ? "chevron.up" : "chevron.down"} size={18} color={colors.muted} />
        </Pressable>
        <Text style={{ color: colors.muted, fontSize: 12, marginBottom: 6 }}>
          Lista 1 është cmimi bazë për copë. Bosh = përdor cmimin e shitjes më sipër.
        </Text>
        {showPrices ? (
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
            {Array.from({ length: 10 }).map((_, i) => (
              <Field
                key={i}
                containerStyle={{ width: "47%" }}
                label={`${i + 1}. ${listNames[i] || `Lista ${i + 1}`}`}
                keyboardType="numeric"
                value={prices[i]}
                onChangeText={(v) => setPrices((arr) => arr.map((x, j) => (j === i ? v : x)))}
              />
            ))}
          </View>
        ) : null}
        <Btn fullWidth title="Ruaj" onPress={save} style={{ marginTop: 16 }} />
        {editing ? (
          <View style={{ flexDirection: "row", gap: 8, marginTop: 8 }}>
            <Btn
              title="Kartela"
              variant="ghost"
              icon="doc.fill"
              onPress={() =>
                router.push({ pathname: "/(tabs)/reports", params: { type: "itemCard", product: editing.name } } as any)
              }
              style={{ flex: 1 }}
            />
            <Btn
              title="Analizë"
              variant="ghost"
              icon="chart.bar.fill"
              onPress={() =>
                router.push({ pathname: "/(tabs)/reports", params: { type: "itemAnalysis", product: editing.name } } as any)
              }
              style={{ flex: 1 }}
            />
          </View>
        ) : null}
        {editing ? <Btn fullWidth variant="warn" title="Fshi" onPress={remove} style={{ marginTop: 8 }} /> : null}
      </ScrollView>
    </ScreenContainer>
  );
}
