# Sistemi Genit v13.3 — Sales price + unit filter everywhere

Ky hotfix e kthen çmimin dhe njësinë e shitjes në pjesë të identitetit të rreshtit të raportit.

## Rregulli i ri

Në raportet e shitjes, grupimi nuk bëhet më vetëm sipas artikullit. Grupimi i saktë është:

```
Artikull + Njësi + Çmim
```

Kjo shmang përzierjen e të njëjtit artikull kur shitet me çmime të ndryshme ose në njësi të ndryshme.

## Filtrat globalë

U forcuan filtrat në raportet e shitjes:

- Çmimi i shitjes: p.sh. `300` ose `300,240,250`
- Njësia e shitjes: Copë / Koli / Paletë
- Artikull
- Klient
- Magazina/Furgon
- Kategori
- Shitës
- Datë
- Status pagese

## Raportet e prekura

- Regjistri Përmbledhës i Shitjeve
- Regjistri Analitik i Shitjeve
- Faturë Përmbledhëse Shitje
- Shitje sipas Artikullit
- Shitje sipas Klientit
- Shitje sipas Njësisë
- Shitje Ditore
- Fatura Totale Sot
- Shitje Sot
- Historik Shitjesh Klienti Analitik
- Eksport Excel / PDF / Print

## Sjellja e re

Nëse vendos filtër çmimi ose njësi, raportet që më parë shfaqnin totalin e plotë të faturës tani shfaqin vetëm vlerën e rreshtave të filtruar. Kjo është e domosdoshme për artikuj që shiten me çmime të ndryshme.

Shembull:

```
Rugove 0.5L | Koli | 300 | 45 koli | 6 dhuratë | 13,500
Rugove 0.5L | Koli | 250 | 12 koli | 0 dhuratë | 3,000
Rugove 0.5L | Copë | 25 | 18 copë | 0 dhuratë | 450
```

## SQLite

Raportet SQL-native kryesore respektojnë filtrin çmim/njësi edhe te raportet përmbledhëse.
