# Sistemi Genit v15 — Raporte Vyapar Final i konsoliduar

Ky version ndalon zinxhirin e hotfix-eve dhe bashkon ndryshimet kryesore:

- Raporte me pamje dhe sjellje më afër Vyapar: lloji i raportit, periudha, filtra chips/popup, tabela, eksport.
- Datat `Nga/Deri` hapin kalendar dhe rifreskojnë raportin automatikisht.
- Filtrat kryesorë (artikull, klient, furnitor, magazinë, njësi, çmim) aplikohen me popup/chips dhe debounce të shkurtër.
- Nuk ka më buton të dukshëm `Rifresko SQL` për përdorues normal; rifreskimi është automatik.
- Nuk ka më silent fallback te `buildReport()` në ekranin e raporteve.
- `buildSqliteReport()` mbulon të gjithë `REPORT_CATALOG`.
- Ndërrimi i raportit reseton viewer-in që të mos mbeten rreshta/kolona nga raporti i vjetër.
- Popup-i i 5 çmimeve të fundit mbetet.
- Scroll/KeyboardAvoidingView në formularin `Shto artikull` për shitje/blerje mbetet.
- Version app/package: 1.0.60.

## Kontroll statik i bërë në sandbox

- ZIP/source integrity: OK
- TS/TSX syntax parse: 125 file, PASS
- REPORT_CATALOG: 53 raporte
- SQLite implementations: 53 raporte
- Missing SQLite report implementations: 0
- Manual `Rifresko SQL` button in Reports UI: removed
- `buildReport()` runtime call in Reports UI: removed; only comment reference remains

## Kufizim i sinqertë

Sandbox-i nuk ndërton APK Android sepse nuk ka node_modules/Gradle Android environment. Build real duhet bërë me GitHub Actions si më parë.
