# v13.15 — Report Switch Refresh Fix

Ky hotfix rregullon problemin kur ndërrohet raporti dhe tabela/kolonat ose të dhënat nuk rifreskohen saktë.

Ndryshime:
- SQLite result tani lidhet me key: report type + applied filters + refresh sequence.
- Rezultatet e vjetra asinkrone nuk lejohen të mbishkruajnë raportin e ri.
- Kur ndërrohet raporti, tabela përdor menjëherë memory fallback dhe pastaj SQLite i freskët.
- Horizontal table remontohet me key të ri që scroll-i i tabelës të kthehet në fillim.
- Shitje Sot nuk krijon më rresht TOTAL bosh kur nuk ka grupe reale.
- Version: 1.0.50
