# v15.2 — Report card navigation + filter button visibility

Ndryshimet kryesore:

1. Kartat e rezultateve te Raporte tani jane te klikueshme.
   - Nese rreshti lidhet me fature shitje, hap `/invoice/[no]` ku mund te shikosh, modifikosh, printosh/PDF dhe fshish.
   - Nese rreshti lidhet me blerje, hap `/purchase/[no]` ku mund te shikosh, modifikosh, printosh/PDF dhe fshish.
   - Nese rreshti lidhet me produkt/klient/furnitor, hap ekranin perkates kur nuk ka numer dokumenti.
   - Rreshtat TOTAL nuk jane te klikueshem.

2. Bottom-sheet i filtrave eshte rregulluar qe butonat Reset / Apply te duken dhe te jene te shtypshem.
   - U shtua safe-area padding per Android navigation bar.
   - Footer-i i filtrave eshte fiks poshte dhe nuk mbulohet nga lista.
   - Lista e opsioneve ben scroll brenda zones se saj.

3. Versioni u rrit ne 1.0.62.
