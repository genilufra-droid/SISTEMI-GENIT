import { describe, it, expect } from "vitest";
import { migrateDB, type DB, type Product } from "../lib/store";
import {
  BACKUP_VERSION,
  BACKUP_APP_NAME,
  buildBackup,
  serializeBackup,
  recordCountsOf,
  totalRecords,
  backupFilename,
  validateBackupStructure,
  parseBackup,
  previewSummary,
} from "../lib/backup";

function makeProduct(): Product {
  return {
    id: 1,
    name: "UJE 0.5L",
    salePiece: 25,
    buyPiece: 18,
    stock: 300,
    stockByStore: { "Magazina kryesore": 300 },
    units: [
      { name: "Copë", coef: 1 },
      { name: "Koli", coef: 12 },
    ],
  };
}

function makeDB(): DB {
  const db: DB = {
    company: { name: "TEST", currency: "LEK" },
    stores: ["Magazina kryesore"],
    products: [makeProduct()],
    customers: [{ id: 1, name: "Klient" }],
    suppliers: [{ id: 1, name: "Furnitor" }],
    invoices: [],
    purchases: [],
    payments: [],
    priceHistory: [],
    stockAdjustments: [],
    expenses: [],
    expenseCategories: [],
    storeTransfers: [],
    settings: { favoriteReports: [] },
    nextInvoice: 1,
    nextPurchase: 1,
  };
  return migrateDB(db);
}

describe("backup envelope", () => {
  it("builds a backup with version, app name, data and recordCounts", () => {
    const db = makeDB();
    const b = buildBackup(db, "2026-06-15T10:00:00.000Z");
    expect(b.version).toBe(BACKUP_VERSION);
    expect(BACKUP_VERSION).toBe("1.0.18");
    expect(b.app).toBe(BACKUP_APP_NAME);
    expect(b.exportDate).toBe("2026-06-15T10:00:00.000Z");
    expect(b.data).toBeTruthy();
    expect(b.data.products.length).toBe(1);
    expect(b.recordCounts).toBeTruthy();
    expect(b.recordCounts.products).toBe(1);
  });

  it("counts records correctly", () => {
    const db = makeDB();
    const counts = recordCountsOf(db);
    expect(counts.products).toBe(1);
    expect(counts.customers).toBe(1);
    expect(counts.suppliers).toBe(1);
    expect(counts.invoices).toBe(0);
    expect(counts.warehouses).toBe(1);
    expect(totalRecords(counts)).toBeGreaterThan(0);
  });
});

describe("serialize / parse roundtrip", () => {
  it("serializes and parses back successfully", () => {
    const db = makeDB();
    const raw = serializeBackup(db, "2026-06-15T10:00:00.000Z");
    const res = parseBackup(raw);
    expect(res.ok).toBe(true);
    expect(res.data).toBeTruthy();
    if (res.data) {
      expect(res.data.products.length).toBe(1);
      expect(res.data.warehouses && res.data.warehouses.length).toBe(1);
    }
  });

  it("parseBackup fails on invalid JSON", () => {
    const res = parseBackup("{not valid json");
    expect(res.ok).toBe(false);
  });
});

describe("validateBackupStructure", () => {
  it("rejects an object without products", () => {
    const res = validateBackupStructure({ app: "x", version: "1.0.12", data: { customers: [] } });
    expect(res.ok).toBe(false);
  });

  it("accepts a legacy raw DB (no envelope)", () => {
    const db = makeDB();
    const res = validateBackupStructure(db);
    expect(res.ok).toBe(true);
    expect(res.data && res.data.products.length).toBe(1);
  });

  it("accepts a proper envelope", () => {
    const db = makeDB();
    const env = buildBackup(db);
    const res = validateBackupStructure(env);
    expect(res.ok).toBe(true);
  });
});

describe("backup filename", () => {
  it("matches the expected pattern", () => {
    const name = backupFilename(new Date("2026-06-15T10:30:00.000Z"));
    expect(name).toMatch(/^Sistemi_Genit_Backup_\d{4}-\d{2}-\d{2}_\d{2}-\d{2}\.json$/);
  });
});

describe("previewSummary", () => {
  it("produces a non-empty summary string", () => {
    const db = makeDB();
    const counts = recordCountsOf(db);
    const summary = previewSummary(counts);
    expect(typeof summary).toBe("string");
    expect(summary.length).toBeGreaterThan(0);
    expect(summary).toContain("artikuj");
  });
});
