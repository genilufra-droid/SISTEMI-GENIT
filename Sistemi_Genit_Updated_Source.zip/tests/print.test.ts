import { describe, it, expect } from "vitest";
import {
  fmtMoney,
  fmtQty,
  formatAlbDateTime,
  paymentLabel,
  vatBreakdown,
  qrPayload,
  esc,
  buildDocHtml,
  invoiceToPrintable,
  purchaseToPrintable,
  transferToPrintable,
  warehouseDocToPrintable,
  WAREHOUSE_DOC_COLUMNS,
  PAPER_SIZES,
  type PaperSize,
  type PrintableDoc,
} from "../lib/print-templates";
import type { Company, Invoice, Purchase, Transfer, Product, OutboundDoc } from "../lib/store";

const company: Company = {
  name: "RUGOVE LUSHNJE",
  address: "Rruga Kongresi i Lushnjes",
  city: "Lushnjë",
  nipt: "L12345678A",
  currency: "ALL",
  phone: "0691234567",
};

const products: Product[] = [
  {
    id: 1,
    name: "Ujë 1.5L",
    code: "P001",
    barcode: "5901234123457",
    units: [{ name: "Copë", factor: 1, price: 50 }],
  } as unknown as Product,
];

const invoice: Invoice = {
  no: 1024,
  date: "2026-06-18",
  time: "14:30",
  customer: "Klienti Test",
  mode: "Me arke",
  items: [
    { productName: "Ujë 1.5L", qty: 10, unit: "Copë", rate: 50, total: 500 } as any,
    { productName: "Pa kod", qty: 2, unit: "Copë", rate: 100, total: 200 } as any,
  ],
  subtotal: 700,
  roundOff: 0,
  total: 700,
  paid: 700,
  due: 0,
  paymentType: "Para në dorë",
} as unknown as Invoice;

const purchase: Purchase = {
  no: 55,
  date: "2026-06-01",
  time: "09:05",
  supplier: "Furnitori Test",
  mode: "Me detyrim",
  items: [{ productName: "Ujë 1.5L", qty: 100, unit: "Copë", rate: 30, total: 3000 } as any],
  subtotal: 3000,
  roundOff: 0,
  total: 3000,
  paid: 1000,
  due: 2000,
  paymentType: "Me detyrim",
} as unknown as Purchase;

const transfer: Transfer = {
  id: 7,
  transferNo: "TR-20260618-001",
  date: "2026-06-18",
  fromWarehouse: "Magazina Qendrore",
  toWarehouse: "Pika 2",
  product: "Ujë 1.5L",
  unit: "Copë",
  qty: 24,
  pieces: 24,
  createdAt: "2026-06-18T10:00:00.000Z",
};

describe("money & quantity formatting", () => {
  it("formats money with thousands separators and 2 decimals", () => {
    expect(fmtMoney(1234.5)).toBe("1,234.50");
    expect(fmtMoney(0)).toBe("0.00");
    expect(fmtMoney(undefined)).toBe("0.00");
    expect(fmtMoney(1000000)).toBe("1,000,000.00");
  });

  it("formats quantity with up to 3 decimals and no forced decimals", () => {
    expect(fmtQty(10)).toBe("10");
    expect(fmtQty(1.5)).toBe("1.5");
    expect(fmtQty(2.125)).toBe("2.125");
    expect(fmtQty(undefined)).toBe("0");
  });
});

describe("formatAlbDateTime", () => {
  it("converts ISO date to dd/mm/yyyy and appends seconds", () => {
    expect(formatAlbDateTime("2026-06-18", "14:30")).toBe("18/06/2026 14:30:00");
  });
  it("keeps existing seconds", () => {
    expect(formatAlbDateTime("2026-06-18", "14:30:45")).toBe("18/06/2026 14:30:45");
  });
  it("converts dotted date and handles missing time", () => {
    expect(formatAlbDateTime("18.06.2026")).toBe("18/06/2026");
  });
  it("handles empty input", () => {
    expect(formatAlbDateTime("")).toBe("");
  });
});

describe("vatBreakdown", () => {
  it("treats vatRate 0 as no VAT (net == gross)", () => {
    const r = vatBreakdown(1000, 0);
    expect(r.net).toBe(1000);
    expect(r.vat).toBe(0);
    expect(r.gross).toBe(1000);
  });
  it("splits a gross-inclusive total for vatRate 20", () => {
    const r = vatBreakdown(1200, 20);
    expect(r.net).toBeCloseTo(1000, 5);
    expect(r.vat).toBeCloseTo(200, 5);
    expect(r.gross).toBe(1200);
  });
});

describe("paymentLabel", () => {
  it("prefers explicit paymentType", () => {
    expect(paymentLabel({ paymentType: "Kartë" } as PrintableDoc)).toBe("Kartë");
  });
  it("maps Me arke to cash label", () => {
    expect(paymentLabel({ mode: "Me arke" } as PrintableDoc)).toBe("Para në dorë");
  });
  it("falls back to Me detyrim", () => {
    expect(paymentLabel({} as PrintableDoc)).toBe("Me detyrim");
  });
});

describe("esc", () => {
  it("escapes HTML special chars", () => {
    expect(esc('<b>"a"&\'b\'</b>')).toBe("&lt;b&gt;&quot;a&quot;&amp;'b'&lt;/b&gt;");
  });
  it("returns empty string for null/undefined", () => {
    expect(esc(undefined)).toBe("");
    expect(esc(null)).toBe("");
  });
});

describe("converters", () => {
  it("invoiceToPrintable enriches lines with product code/barcode", () => {
    const doc = invoiceToPrintable(invoice, company, products);
    expect(doc.docType).toBe("sale");
    expect(doc.title).toBe("FATURË TATIMORE");
    expect(doc.number).toBe("1024");
    expect(doc.partyName).toBe("Klienti Test");
    expect(doc.lines).toHaveLength(2);
    expect(doc.lines[0].code).toBe("P001");
    expect(doc.lines[0].barcode).toBe("5901234123457");
    expect(doc.lines[1].code).toBeUndefined();
    expect(doc.total).toBe(700);
  });

  it("purchaseToPrintable maps supplier and totals", () => {
    const doc = purchaseToPrintable(purchase, company, products);
    expect(doc.docType).toBe("purchase");
    expect(doc.partyLabel).toBe("Furnitori");
    expect(doc.partyName).toBe("Furnitori Test");
    expect(doc.due).toBe(2000);
  });

  it("transferToPrintable builds a single line and warehouses", () => {
    const doc = transferToPrintable(transfer, company);
    expect(doc.docType).toBe("transfer");
    expect(doc.number).toBe("TR-20260618-001");
    expect(doc.fromWarehouse).toBe("Magazina Qendrore");
    expect(doc.toWarehouse).toBe("Pika 2");
    expect(doc.lines).toHaveLength(1);
    expect(doc.lines[0].name).toBe("Ujë 1.5L");
  });
});

describe("qrPayload", () => {
  it("encodes NIVF/NSLF when present", () => {
    const doc = { ...invoiceToPrintable(invoice, company, products), nivf: "ABC", nslf: "XYZ" };
    expect(qrPayload(doc)).toBe("NIVF:ABC|NSLF:XYZ");
  });
  it("falls back to a descriptive string when no fiscal codes", () => {
    const doc = invoiceToPrintable(invoice, company, products);
    const payload = qrPayload(doc);
    expect(payload).toContain("FATURË TATIMORE");
    expect(payload).toContain("1024");
  });
});

describe("buildDocHtml", () => {
  const sizes: PaperSize[] = ["58", "80", "110", "A4"];

  it("PAPER_SIZES lists all four formats", () => {
    expect(PAPER_SIZES.map((p) => p.value)).toEqual(["58", "80", "110", "A4"]);
  });

  for (const size of sizes) {
    it(`produces valid HTML for an invoice at ${size}`, () => {
      const doc = invoiceToPrintable(invoice, company, products);
      const html = buildDocHtml(doc, company, size, "<svg></svg>");
      expect(html.startsWith("<!doctype html>")).toBe(true);
      expect(html).toContain("</html>");
      expect(html).toContain("RUGOVE LUSHNJE");
      // total appears in every layout
      expect(html).toContain("700.00");
    });
  }

  it("A4 invoice includes the full tax-invoice sections", () => {
    const doc = invoiceToPrintable(invoice, company, products);
    const html = buildDocHtml(doc, company, "A4");
    expect(html).toContain("DETAJE");
    expect(html).toContain("Artikujt");
    expect(html).toContain("TVSH");
    expect(html).toContain("Pagesa");
    expect(html).toContain("SHITËSI");
    expect(html).toContain("BLERËSI");
    expect(html).toContain("TRANSPORTUESI");
    expect(html).toContain("TOTALI NË ALL");
    expect(html).toContain("Shitje pa TVSH");
  });

  it("thermal layout sets the correct page width", () => {
    const doc = invoiceToPrintable(invoice, company, products);
    expect(buildDocHtml(doc, company, "58")).toContain("size: 58mm auto");
    expect(buildDocHtml(doc, company, "80")).toContain("size: 80mm auto");
    expect(buildDocHtml(doc, company, "110")).toContain("size: 110mm auto");
  });

  it("injects the QR svg markup when provided", () => {
    const doc = { ...invoiceToPrintable(invoice, company, products), nivf: "INV-1" };
    const html = buildDocHtml(doc, company, "80", "<svg id='qr'></svg>");
    expect(html).toContain("<svg id='qr'></svg>");
    expect(html).toContain("NIVF");
  });

  it("transfer document omits payment/price sections", () => {
    const doc = transferToPrintable(transfer, company);
    const a4 = buildDocHtml(doc, company, "A4");
    expect(a4).toContain("Nga magazina");
    expect(a4).toContain("Te magazina");
    expect(a4).toContain("DORËZUESI");
    expect(a4).toContain("MARRËSI");
    expect(a4).not.toContain("Pagesa");
    const thermal = buildDocHtml(doc, company, "80");
    expect(thermal).toContain("FLETË TRANSFERTE");
    expect(thermal).not.toContain("TOTAL ALL");
  });
});

describe("warehouse Fletë Dalje layout", () => {
  const outboundDoc: OutboundDoc = {
    id: 1,
    no: "FD-2026-0001",
    date: "2026-06-25",
    warehouse: "Magazina kryesore",
    status: "saved",
    createdAt: "2026-06-25T10:00:00Z",
    sourceType: "SALE_INVOICE",
    sourceInvoiceNo: 17680,
    customerName: "Klient Test",
    destinationAddress: "Rruga e Durrësit, Tiranë",
    lines: [
      {
        productName: "Ujë Rugove 0.5L",
        unit: "Koli",
        qty: 11,
        coef: 12,
        baseQty: 132,
        price: 300,
        costPiece: 18,
        value: 3300,
      },
    ],
  };

  it("WAREHOUSE_DOC_COLUMNS lists the 8 warehouse columns", () => {
    expect(WAREHOUSE_DOC_COLUMNS).toEqual([
      "Nr",
      "Emërtimi i mallit",
      "Njësia",
      "Sasia",
      "Koef",
      "Sasia Copë",
      "Çmimi",
      "Vlefta",
    ]);
  });

  it("warehouseDocToPrintable carries warehouse flag and selected-unit price", () => {
    const doc = warehouseDocToPrintable(outboundDoc, "outbound", company);
    expect(doc.warehouse).toBe(true);
    expect(doc.warehouseKind).toBe("outbound");
    expect(doc.title).toBe("FLETË DALJE");
    expect(doc.lines[0].rate).toBe(300); // Çmimi = per selected unit (Koli)
    expect(doc.lines[0].total).toBe(3300); // Vlefta = 11 × 300
    expect(doc.lines[0].coef).toBe(12);
    expect(doc.lines[0].baseQty).toBe(132);
    expect(doc.serialNo).toBe("17680");
    expect(doc.destinationAddress).toBe("Rruga e Durrësit, Tiranë");
  });

  it("warehouse HTML uses the warehouse layout, NOT the fiscal invoice", () => {
    const doc = warehouseDocToPrintable(outboundDoc, "outbound", company);
    const html = buildDocHtml(doc, company, "A4", "<svg id='qr'></svg>");
    // Warehouse layout markers
    expect(html).toContain("FLETË DALJE");
    expect(html).toContain("Sasia Copë");
    expect(html).toContain("Magazinieri");
    expect(html).toContain("Marrësi në dorëzim");
    expect(html).toContain("Transportuesi");
    expect(html).toContain("Llogaritari");
    expect(html).toContain("3,300.00"); // Vlefta
    // Must NOT carry fiscal invoice / QR artifacts
    expect(html).not.toContain("<svg id='qr'></svg>");
    expect(html).not.toContain("NIVF");
    expect(html).not.toContain("NSLF");
    expect(html).not.toContain("TVSH");
  });
});

// ---------------------------------------------------------------------------
// PART 4 — Gift line in Fletë Dalje  &  PART 2 — Fletë Hyrje signatures
// ---------------------------------------------------------------------------
describe("warehouse gift line & Fletë Hyrje signatures (v1.0.18)", () => {
  const giftOutbound: OutboundDoc = {
    id: 2,
    no: "FD-2026-0002",
    date: "2026-06-25",
    warehouse: "Magazina kryesore",
    status: "saved",
    createdAt: "2026-06-25T10:00:00Z",
    sourceType: "SALE_INVOICE",
    customerName: "Klient Test",
    lines: [
      // SOLD line: 10 Koli @300 -> value 3000
      { productName: "UJË 0.5L", unit: "Koli", qty: 10, coef: 12, baseQty: 120, price: 300, costPiece: 18, value: 3000 },
      // GIFT line: 1 Koli @0 -> value 0, still moves 12 copë of stock
      { productName: "UJË 0.5L", unit: "Koli", qty: 1, coef: 12, baseQty: 12, price: 0, value: 0, isGift: true } as any,
    ],
  };

  it("renders the gift line as a separate '- DHURATË' row with price 0 and value 0", () => {
    const doc = warehouseDocToPrintable(giftOutbound, "outbound", company);
    expect(doc.lines.length).toBe(2);
    const sold = doc.lines[0];
    const gift = doc.lines[1];
    expect(sold.total).toBe(3000);
    expect(gift.isGift).toBe(true);
    expect(gift.name).toContain("DHURATË");
    expect(gift.rate).toBe(0);
    expect(gift.total).toBe(0);
    // gift still carries its base quantity so stock moves
    expect(gift.baseQty).toBe(12);
  });

  it("Fletë Dalje HTML total uses sold value 3000 (gift adds nothing) and physical 132 copë", () => {
    const doc = warehouseDocToPrintable(giftOutbound, "outbound", company);
    const html = buildDocHtml(doc, company, "A4", "");
    expect(html).toContain("DHURATË");
    expect(html).toContain("3,000.00"); // financial total = sold only
    expect(html).not.toContain("3,300.00"); // gift must NOT inflate the total
    expect(html).toContain("132"); // physical pieces 120 + 12
  });

  it("Fletë Hyrje includes the extra 'Dorëzuesi' signature (5 roles vs Dalje's 4)", () => {
    const inboundDoc = {
      id: 3,
      no: "FH-2026-0001",
      date: "2026-06-25",
      warehouse: "Magazina kryesore",
      status: "saved",
      createdAt: "2026-06-25T10:00:00Z",
      sourceType: "PURCHASE_INVOICE",
      supplierName: "Furnitor Test",
      lines: [
        { productName: "UJË 0.5L", unit: "Koli", qty: 5, coef: 12, baseQty: 60, price: 200, value: 1000 },
      ],
    } as any;
    const doc = warehouseDocToPrintable(inboundDoc, "inbound", company);
    expect(doc.title).toBe("FLETË HYRJE");
    const html = buildDocHtml(doc, company, "A4", "");
    expect(html).toContain("Dorëzuesi");
    expect(html).toContain("Magazinieri");
    expect(html).toContain("Marrësi në dorëzim");
    expect(html).toContain("Transportuesi");
    expect(html).toContain("Llogaritari");
    expect(html).toContain("Emri, mbiemri");
  });
});
