import { describe, it, expect } from "vitest";
import {
  fmt,
  migrateDB,
  createWarehouse,
  updateWarehouse,
  setWarehouseStatus,
  warehouseNames,
  activeWarehouses,
  getWarehouseStock,
  stockInStore,
  warehouseStockOf,
  stockByWarehouseRows,
  stockUnitBreakdown,
  applyLinesToStock,
  saleStockErrorsDetailed,
  insufficientStockMessage,
  createTransfer,
  makeTransferNo,
  type DB,
  type Product,
} from "../lib/store";

function makeProduct(): Product {
  return {
    id: 1,
    name: "UJE 0.5L",
    salePiece: 25,
    buyPiece: 18,
    stock: 300,
    stockByStore: { "Magazina kryesore": 300 },
    units: [
      { name: "Copë", coef: 1 },
      { name: "Koli", coef: 12 },
    ],
  };
}

function makeDB(): DB {
  const db: DB = {
    company: { name: "TEST", currency: "LEK" },
    stores: ["Magazina kryesore"],
    products: [makeProduct()],
    customers: [{ id: 1, name: "Klient" }],
    suppliers: [{ id: 1, name: "Furnitor" }],
    invoices: [],
    purchases: [],
    payments: [],
    priceHistory: [],
    stockAdjustments: [],
    expenses: [],
    expenseCategories: [],
    storeTransfers: [],
    settings: { favoriteReports: [] },
    nextInvoice: 1,
    nextPurchase: 1,
  };
  return migrateDB(db);
}

describe("warehouse migration", () => {
  it("builds a default warehouse from legacy stores", () => {
    const db = makeDB();
    expect((db.warehouses || []).length).toBe(1);
    expect(db.warehouses![0].name).toBe("Magazina kryesore");
    expect(db.warehouses![0].status).toBe("active");
    expect(db.stores).toContain("Magazina kryesore");
  });
});

describe("warehouse CRUD", () => {
  it("creates a second warehouse and syncs stores", () => {
    const db = createWarehouse(makeDB(), { name: "Furgoni Ylli", address: "Lushnje" });
    expect(warehouseNames(db)).toEqual(["Magazina kryesore", "Furgoni Ylli"]);
    expect(activeWarehouses(db).length).toBe(2);
  });

  it("rejects duplicate warehouse names", () => {
    const db = makeDB();
    expect(() => createWarehouse(db, { name: "Magazina kryesore" })).toThrow();
  });

  it("deactivating a warehouse removes it from active store list", () => {
    let db = createWarehouse(makeDB(), { name: "Furgoni Ylli" });
    const ylli = db.warehouses!.find((w) => w.name === "Furgoni Ylli")!;
    db = setWarehouseStatus(db, ylli.id, "inactive");
    expect(warehouseNames(db)).toEqual(["Magazina kryesore"]);
    expect(warehouseNames(db, false)).toContain("Furgoni Ylli");
  });

  it("renaming a warehouse migrates per-warehouse stock keys", () => {
    let db = makeDB();
    const main = db.warehouses![0];
    db = updateWarehouse(db, main.id, { name: "Depo Qendrore" });
    expect(getWarehouseStock(db, "UJE 0.5L", "Depo Qendrore")).toBe(300);
    expect(getWarehouseStock(db, "UJE 0.5L", "Magazina kryesore")).toBe(0);
  });
});

describe("per-warehouse stock", () => {
  it("tracks stock independently per warehouse", () => {
    let db = createWarehouse(makeDB(), { name: "Furgoni Ylli" });
    // Purchase 10 Koli (120 pieces) into Furgoni Ylli.
    db = {
      ...db,
      products: applyLinesToStock(
        db.products,
        [{ productName: "UJE 0.5L", qty: 10, freeQty: 0, unit: "Koli" }],
        "Furgoni Ylli",
        1,
      ),
    };
    expect(getWarehouseStock(db, "UJE 0.5L", "Magazina kryesore")).toBe(300);
    expect(getWarehouseStock(db, "UJE 0.5L", "Furgoni Ylli")).toBe(120);
  });

  it("a sale deducts qty+free from the SELECTED warehouse only", () => {
    let db = createWarehouse(makeDB(), { name: "Furgoni Ylli" });
    // Sell 2 Koli + 1 free Koli = 3 Koli = 36 pieces from Magazina kryesore.
    db = {
      ...db,
      products: applyLinesToStock(
        db.products,
        [{ productName: "UJE 0.5L", qty: 2, freeQty: 1, unit: "Koli" }],
        "Magazina kryesore",
        -1,
      ),
    };
    expect(getWarehouseStock(db, "UJE 0.5L", "Magazina kryesore")).toBe(300 - 36);
    expect(getWarehouseStock(db, "UJE 0.5L", "Furgoni Ylli")).toBe(0);
  });
});

describe("insufficient stock validation", () => {
  it("builds the exact Albanian message", () => {
    const msg = insufficientStockMessage("Furgoni Ylli", 12, 120);
    expect(msg).toBe(`Stoku i pamjaftueshëm në magazinë Furgoni Ylli. Disponibël: ${fmt(12)}, Kërkuar: ${fmt(120)}`);
  });

  it("blocks a sale exceeding warehouse stock", () => {
    const db = createWarehouse(makeDB(), { name: "Furgoni Ylli" });
    // Furgoni Ylli has 0 pieces; selling 1 Koli (12) must error.
    const errors = saleStockErrorsDetailed(
      db.products,
      [{ productName: "UJE 0.5L", qty: 1, freeQty: 0, unit: "Koli" }],
      "Furgoni Ylli",
    );
    expect(errors.length).toBe(1);
    expect(errors[0]).toContain("Stoku i pamjaftueshëm në magazinë Furgoni Ylli");
    expect(errors[0]).toContain(`Kërkuar: ${fmt(12)}`);
  });

  it("allows a sale within warehouse stock", () => {
    const db = makeDB();
    const errors = saleStockErrorsDetailed(
      db.products,
      [{ productName: "UJE 0.5L", qty: 5, freeQty: 0, unit: "Koli" }],
      "Magazina kryesore",
    );
    expect(errors.length).toBe(0);
  });
});

describe("warehouse transfers", () => {
  it("moves base-unit stock and assigns a TR number", () => {
    let db = createWarehouse(makeDB(), { name: "Furgoni Ylli" });
    const res = createTransfer(db, {
      date: "2026-06-15",
      fromWarehouse: "Magazina kryesore",
      toWarehouse: "Furgoni Ylli",
      product: "UJE 0.5L",
      unit: "Koli",
      qty: 10, // 10 Koli = 120 pieces
    });
    expect(res.error).toBeUndefined();
    expect(res.transfer!.transferNo).toBe("TR-20260615-001");
    expect(res.transfer!.pieces).toBe(120);
    db = res.db;
    expect(getWarehouseStock(db, "UJE 0.5L", "Magazina kryesore")).toBe(300 - 120);
    expect(getWarehouseStock(db, "UJE 0.5L", "Furgoni Ylli")).toBe(120);
  });

  it("increments the transfer sequence within the same day", () => {
    let db = createWarehouse(makeDB(), { name: "Furgoni Ylli" });
    const r1 = createTransfer(db, {
      date: "2026-06-15",
      fromWarehouse: "Magazina kryesore",
      toWarehouse: "Furgoni Ylli",
      product: "UJE 0.5L",
      unit: "Copë",
      qty: 10,
    });
    db = r1.db;
    const nextNo = makeTransferNo(db, "2026-06-15");
    expect(nextNo).toBe("TR-20260615-002");
  });

  it("rejects a transfer to the same warehouse", () => {
    const db = makeDB();
    const res = createTransfer(db, {
      date: "2026-06-15",
      fromWarehouse: "Magazina kryesore",
      toWarehouse: "Magazina kryesore",
      product: "UJE 0.5L",
      unit: "Copë",
      qty: 5,
    });
    expect(res.error).toBeTruthy();
  });

  it("rejects a transfer exceeding source stock", () => {
    const db = createWarehouse(makeDB(), { name: "Furgoni Ylli" });
    const res = createTransfer(db, {
      date: "2026-06-15",
      fromWarehouse: "Furgoni Ylli", // empty
      toWarehouse: "Magazina kryesore",
      product: "UJE 0.5L",
      unit: "Koli",
      qty: 1,
    });
    expect(res.error).toContain("Stoku i pamjaftueshëm");
  });
});

// ISSUE 2 — Items warehouse filter helpers (acceptance Test 2)
describe("per-warehouse stock helpers (Items filter + product detail)", () => {
  function twoWarehouseDB(): DB {
    let db = createWarehouse(makeDB(), { name: "Furgoni Ylli" });
    // 1368 pieces in main, 240 pieces in the van.
    db.products[0].stockByStore = { "Magazina kryesore": 1368, "Furgoni Ylli": 240 };
    db.products[0].stock = 1608;
    return db;
  }

  it("warehouseStockOf returns per-warehouse pieces", () => {
    const db = twoWarehouseDB();
    const p = db.products[0];
    expect(warehouseStockOf(p, "Magazina kryesore")).toBe(1368);
    expect(warehouseStockOf(p, "Furgoni Ylli")).toBe(240);
  });

  it("warehouseStockOf('all') returns the grand total", () => {
    const db = twoWarehouseDB();
    expect(warehouseStockOf(db.products[0], "all")).toBe(1608);
    expect(warehouseStockOf(db.products[0], undefined)).toBe(1608);
  });

  it("second-unit (Koli, coef 12) breakdown is correct per warehouse", () => {
    const db = twoWarehouseDB();
    const p = db.products[0];
    // 1368 / 12 = 114 Koli ; 240 / 12 = 20 Koli ; 1608 / 12 = 134 Koli
    expect(stockUnitBreakdown(p, 1368)[1].qty).toBe(114);
    expect(stockUnitBreakdown(p, 240)[1].qty).toBe(20);
    expect(stockUnitBreakdown(p, 1608)[1].qty).toBe(134);
  });

  it("stockByWarehouseRows lists every warehouse and sums to the total", () => {
    const db = twoWarehouseDB();
    const rows = stockByWarehouseRows(db, db.products[0]);
    expect(rows.length).toBeGreaterThanOrEqual(2);
    const total = rows.reduce((s, r) => s + r.pieces, 0);
    expect(total).toBe(1608);
    const main = rows.find((r) => r.warehouse === "Magazina kryesore");
    const van = rows.find((r) => r.warehouse === "Furgoni Ylli");
    expect(main!.pieces).toBe(1368);
    expect(van!.pieces).toBe(240);
    expect(main!.label.length).toBeGreaterThan(0);
  });

  it("warehouseStockOf is 0 for a warehouse with no stock (toggle hides these)", () => {
    const db = twoWarehouseDB();
    db.products[0].stockByStore = { "Magazina kryesore": 1368 };
    expect(warehouseStockOf(db.products[0], "Furgoni Ylli")).toBe(0);
  });
});
