import { describe, it, expect } from "vitest";
import {
  migrateDB,
  createInboundDoc,
  createOutboundDoc,
  createInventoryDoc,
  createTransfer,
  recordDocumentMovements,
  wrapAsMultiDB,
  migrateMultiDB,
  newCompanyDB,
  stockInStore,
  totalStock,
  type DB,
  type Product,
  type MultiDB,
} from "../lib/store";
import {
  buildMultiBackup,
  serializeMultiBackup,
  parseMultiBackup,
  isMultiBackup,
} from "../lib/backup";

// --- helpers ---------------------------------------------------------------

function makeProduct(over?: Partial<Product>): Product {
  return {
    id: 1,
    name: "UJE 0.5L",
    salePiece: 25,
    buyPiece: 18,
    stock: 0,
    stockByStore: { "Magazina Kryesore": 0, Furgon: 0 },
    units: [
      { name: "Copë", coef: 1 },
      { name: "Koli", coef: 12 },
    ],
    ...over,
  };
}

function makeDB(): DB {
  const db: DB = {
    company: { name: "TEST", currency: "LEK" },
    stores: ["Magazina Kryesore", "Furgon"],
    products: [makeProduct()],
    customers: [{ id: 1, name: "Klient Rastesor" }],
    suppliers: [{ id: 1, name: "Furnitor" }],
    invoices: [],
    purchases: [],
    payments: [],
    priceHistory: [],
    stockAdjustments: [],
    expenses: [],
    expenseCategories: [],
    storeTransfers: [],
    settings: { favoriteReports: [] },
    nextInvoice: 1,
    nextPurchase: 1,
  };
  return migrateDB(db);
}

// --- T3: Fletë Hyrje (inbound) ---------------------------------------------

describe("Phase 1 — Fletë Hyrje (inbound)", () => {
  it("10 Koli x 12 = +120 copë në magazinë", () => {
    const db = makeDB();
    const res = createInboundDoc(db, {
      date: "2026-06-23",
      warehouse: "Magazina Kryesore",
      lines: [{ productName: "UJE 0.5L", unit: "Koli", qty: 10 }],
    });
    expect(res.error).toBeUndefined();
    const p = res.db.products[0];
    expect(stockInStore(p, "Magazina Kryesore")).toBe(120);
    expect(res.db.inboundDocs?.length).toBe(1);
    expect(res.db.stockMovements?.[0].inBase).toBe(120);
  });
});

// --- T4: Fletë Dalje (outbound) --------------------------------------------

describe("Phase 1 — Fletë Dalje (outbound)", () => {
  it("5 Koli = -60 copë kur ka stok mjaftueshëm", () => {
    let db = makeDB();
    db = createInboundDoc(db, {
      date: "2026-06-23",
      warehouse: "Magazina Kryesore",
      lines: [{ productName: "UJE 0.5L", unit: "Koli", qty: 10 }],
    }).db;
    const res = createOutboundDoc(db, {
      date: "2026-06-23",
      warehouse: "Magazina Kryesore",
      lines: [{ productName: "UJE 0.5L", unit: "Koli", qty: 5 }],
    });
    expect(res.error).toBeUndefined();
    expect(stockInStore(res.db.products[0], "Magazina Kryesore")).toBe(60);
  });

  it("bllokon daljen kur stoku është i pamjaftueshëm (asgjë nuk ndryshon)", () => {
    const db = makeDB(); // stock 0
    const res = createOutboundDoc(db, {
      date: "2026-06-23",
      warehouse: "Magazina Kryesore",
      lines: [{ productName: "UJE 0.5L", unit: "Koli", qty: 5 }],
    });
    expect(res.error).toBeTruthy();
    expect(stockInStore(res.db.products[0], "Magazina Kryesore")).toBe(0);
    expect(res.db.outboundDocs?.length || 0).toBe(0);
  });
});

// --- T5: Transferim main -> van --------------------------------------------

describe("Phase 1 — Transferim", () => {
  it("transferon 5 Koli (60 copë) nga Magazina Kryesore -> Furgon", () => {
    let db = makeDB();
    db = createInboundDoc(db, {
      date: "2026-06-23",
      warehouse: "Magazina Kryesore",
      lines: [{ productName: "UJE 0.5L", unit: "Koli", qty: 10 }],
    }).db;
    const res = createTransfer(db, {
      date: "2026-06-23",
      fromWarehouse: "Magazina Kryesore",
      toWarehouse: "Furgon",
      product: "UJE 0.5L",
      unit: "Koli",
      qty: 5,
    });
    expect(res.error).toBeUndefined();
    const p = res.db.products[0];
    expect(stockInStore(p, "Magazina Kryesore")).toBe(60);
    expect(stockInStore(p, "Furgon")).toBe(60);
    // total unchanged
    expect(totalStock(p)).toBe(120);
  });
});

// --- T6: Inventar Fizik diff -20 -------------------------------------------

describe("Phase 1 — Inventar Fizik", () => {
  it("vendos stokun në sasinë e numëruar; diferenca -20", () => {
    let db = makeDB();
    db = createInboundDoc(db, {
      date: "2026-06-23",
      warehouse: "Magazina Kryesore",
      lines: [{ productName: "UJE 0.5L", unit: "Copë", qty: 100 }],
    }).db;
    const res = createInventoryDoc(db, {
      date: "2026-06-23",
      warehouse: "Magazina Kryesore",
      lines: [{ productName: "UJE 0.5L", unit: "Copë", countedQty: 80 }],
    });
    expect(res.error).toBeUndefined();
    expect(stockInStore(res.db.products[0], "Magazina Kryesore")).toBe(80);
    const line = res.db.inventoryDocs?.[0].lines[0];
    expect(line?.diff).toBe(-20);
  });
});

// --- recordDocumentMovements (sales/purchases ledger) ----------------------

describe("Phase 1 — recordDocumentMovements", () => {
  it("regjistron lëvizje OUT për shitje me sasi + dhuratë", () => {
    let db = makeDB();
    db = createInboundDoc(db, {
      date: "2026-06-23",
      warehouse: "Magazina Kryesore",
      lines: [{ productName: "UJE 0.5L", unit: "Copë", qty: 100 }],
    }).db;
    const moved = recordDocumentMovements(db, {
      kind: "sale",
      docNo: 1001,
      date: "2026-06-23",
      warehouse: "Magazina Kryesore",
      lines: [{ productName: "UJE 0.5L", qty: 5, freeQty: 1, unit: "Copë" }],
    });
    const sales = (moved.stockMovements || []).filter((m) => m.docType === "sale");
    expect(sales.length).toBeGreaterThanOrEqual(1);
  });
});

// --- T9/migration: multi-company isolation & wrap --------------------------

describe("Phase 1 — Multi-company isolimi", () => {
  it("wrapAsMultiDB krijon kompaninë c1 me të dhënat legacy", () => {
    const legacy = makeDB();
    const mdb = wrapAsMultiDB(legacy);
    expect(mdb.activeCompanyId).toBe("c1");
    expect(mdb.companies.length).toBe(1);
    expect(mdb.data["c1"].products.length).toBe(1);
  });

  it("dy kompani kanë stok plotësisht të ndarë", () => {
    const a = makeDB();
    let mdb = wrapAsMultiDB(a);
    // add a second clean company
    const bSlice = newCompanyDB({ name: "Kompania B" });
    mdb = {
      ...mdb,
      companies: [...mdb.companies, { ...mdb.companies[0], id: "c2", name: "Kompania B" }],
      data: { ...mdb.data, c2: bSlice },
    };
    // inbound into company A only
    mdb.data["c1"] = createInboundDoc(mdb.data["c1"], {
      date: "2026-06-23",
      warehouse: "Magazina Kryesore",
      lines: [{ productName: "UJE 0.5L", unit: "Koli", qty: 10 }],
    }).db;
    expect(stockInStore(mdb.data["c1"].products[0], "Magazina Kryesore")).toBe(120);
    // company B has no such product / stock
    expect(mdb.data["c2"].products.length).toBe(0);
  });
});

// --- T10: multi-backup roundtrip -------------------------------------------

describe("Phase 1 — Multi-backup roundtrip", () => {
  it("buildMultiBackup -> serialize -> parse rikthen të njëjtat të dhëna", () => {
    let mdb: MultiDB = wrapAsMultiDB(makeDB());
    mdb.data["c1"] = createInboundDoc(mdb.data["c1"], {
      date: "2026-06-23",
      warehouse: "Magazina Kryesore",
      lines: [{ productName: "UJE 0.5L", unit: "Koli", qty: 10 }],
    }).db;
    const json = serializeMultiBackup(mdb);
    expect(isMultiBackup(JSON.parse(json))).toBe(true);
    const res = parseMultiBackup(json);
    expect(res.ok).toBe(true);
    expect(res.mdb?.companies.length).toBe(1);
    expect(stockInStore(res.mdb!.data["c1"].products[0], "Magazina Kryesore")).toBe(120);
  });

  it("migrateMultiDB plotëson fushat që mungojnë pa humbur të dhëna", () => {
    const raw = {
      schema: 2,
      activeCompanyId: "c1",
      companies: [{ id: "c1", name: "X", currency: "LEK", status: "active" }],
      data: { c1: makeDB() },
    } as unknown as MultiDB;
    const m = migrateMultiDB(raw);
    expect(m.data["c1"].inboundDocs).toBeDefined();
    expect(m.data["c1"].stockMovements).toBeDefined();
  });
});
