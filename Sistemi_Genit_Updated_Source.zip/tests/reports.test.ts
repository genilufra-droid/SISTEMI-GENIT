import { describe, it, expect } from "vitest";
import { REPORT_CATALOG, buildReport, renderReportHtml, reportCatalogDuplicates, findReport, type ReportType } from "../lib/reports";
import type { DB } from "../lib/store";

const db: DB = {
  company: { name: "TEST", currency: "LEK" },
  stores: ["Magazina kryesore"],
  products: [
    { id: 1, name: "UJE 0.5L", salePiece: 25, buyPiece: 18, stock: 120, minStock: 20, prices: [25, 23, 22], units: [{ name: "Cope", coef: 1 }, { name: "Koli", coef: 12 }] },
    { id: 2, name: "BUKE", salePiece: 80, buyPiece: 50, stock: 5, minStock: 10, units: [{ name: "Cope", coef: 1 }] },
  ],
  customers: [
    { id: 1, name: "ACME", openingBalance: 0 },
    { id: 2, name: "Beta", openingBalance: 5000 },
  ],
  suppliers: [{ id: 1, name: "S1" }],
  invoices: [
    {
      no: 1,
      date: "2026-01-05",
      time: "10:00",
      customer: "ACME",
      mode: "Me detyrim",
      items: [
        { productName: "UJE 0.5L", qty: 2, freeQty: 0, unit: "Koli", rate: 264, buyRate: 216, total: 528, cost: 432 },
        { productName: "BUKE", qty: 2, freeQty: 0, unit: "Cope", rate: 80, buyRate: 50, total: 160, cost: 100 },
      ],
      subtotal: 285,
      roundOff: 0,
      total: 285,
      paid: 100,
      due: 185,
      paymentType: "Cash",
      totalCost: 190,
      profit: 95,
    },
  ],
  purchases: [
    {
      no: 1,
      date: "2026-01-02",
      time: "11:00",
      supplier: "S1",
      mode: "Me detyrim",
      items: [
        { productName: "UJE 0.5L", qty: 10, freeQty: 0, unit: "Cope", rate: 18, buyRate: 18, total: 180, cost: 180 },
      ],
      subtotal: 180,
      roundOff: 0,
      total: 180,
      paid: 100,
      due: 80,
      paymentType: "Cash",
    },
  ],
  payments: [
    { id: 1, partyType: "customer", party: "ACME", date: "2026-01-06", amount: 25, method: "Cash" },
  ],
  priceHistory: [],
  stockAdjustments: [],
  expenses: [],
  expenseCategories: [],
  storeTransfers: [],
  settings: { favoriteReports: [] },
  nextInvoice: 2,
  nextPurchase: 2,
};

describe("REPORT_CATALOG", () => {
  it("contains 38 report types matching the original module", () => {
    expect(REPORT_CATALOG.length).toBeGreaterThanOrEqual(38);
  });

  it("every catalog entry has a label and group", () => {
    for (const r of REPORT_CATALOG) {
      expect(r.label.length).toBeGreaterThan(0);
      expect(r.group.length).toBeGreaterThan(0);
    }
  });
});

describe("buildReport - smoke", () => {
  it("every report type returns a valid result shape", () => {
    for (const r of REPORT_CATALOG) {
      const out = buildReport(r.value, db, {});
      expect(out.title.length).toBeGreaterThan(0);
      expect(Array.isArray(out.columns)).toBe(true);
      expect(out.columns.length).toBeGreaterThan(0);
      expect(Array.isArray(out.rows)).toBe(true);
    }
  });
});

describe("buildReport - figures", () => {
  it("salesSummary totals one invoice with 285 LEK", () => {
    const out = buildReport("salesSummary", db, {});
    expect(out.summary?.some((s) => s.value.includes("285"))).toBe(true);
  });

  it("unpaidInvoices includes invoice #1 (due 185)", () => {
    const out = buildReport("unpaidInvoices", db, {});
    expect(out.rows.length).toBeGreaterThan(0);
  });

  it("supplyNeed lists products under min stock", () => {
    const out = buildReport("supplyNeed", db, {});
    const names = out.rows.map((r) => String(r["product"] || r["name"] || ""));
    expect(names.some((n) => n.toUpperCase().includes("BUKE"))).toBe(true);
  });

  it("clientLedger filtered by ACME shows transactions", () => {
    const out = buildReport("clientLedger", db, { client: "ACME" });
    expect(out.rows.length).toBeGreaterThan(0);
  });

  it("supplierLedger filtered by S1 shows the purchase", () => {
    const out = buildReport("supplierLedger", db, { supplier: "S1" });
    expect(out.rows.length).toBeGreaterThan(0);
  });

  it("date filter excludes out-of-range", () => {
    const out = buildReport("salesSummary", db, { from: "2027-01-01", to: "2027-12-31" });
    // 0 invoices in 2027
    expect(out.summary?.some((s) => s.value === "0" || s.value === "0.00")).toBeTruthy();
  });

  it("managerTopClients ranks ACME as top with 285", () => {
    const out = buildReport("managerTopClients", db, {});
    expect(out.rows[0]).toBeTruthy();
  });
});

describe("new filters & reports", () => {
  it("multi-select products filters salesByProduct to only chosen items", () => {
    const out = buildReport("salesByProduct", db, { products: ["BUKE"] });
    const names = out.rows.map((r) => String(r["product"] || ""));
    expect(names.every((n) => n.toUpperCase().includes("BUKE"))).toBe(true);
    expect(names.length).toBeGreaterThan(0);
  });

  it("unit filter restricts sales lines to that unit", () => {
    const onlyKoli = buildReport("salesAnalytic", db, { units: ["Koli"] });
    const onlyCope = buildReport("salesAnalytic", db, { units: ["Cope"] });
    expect(onlyKoli.rows.length).toBe(1); // only UJE sold in Koli
    expect(onlyCope.rows.length).toBe(1); // only BUKE sold in Cope
  });

  it("purchaseSuggestion converts sold quantity into largest unit (2 koli)", () => {
    const out = buildReport("purchaseSuggestion", db, {});
    const uje = out.rows.find((r) => String(r["product"]).includes("UJE"));
    expect(uje).toBeTruthy();
    // 2 koli sold = 24 base; largest unit = Koli (coef 12) -> suggest 2
    expect(Number(uje!["suggest"])).toBeCloseTo(2, 5);
    expect(String(uje!["unit"])).toBe("Koli");
  });

  it("client filter matches with extra spaces and different case (normalized)", () => {
    const exact = buildReport("salesSummary", db, { clients: ["ACME"] });
    const messy = buildReport("salesSummary", db, { clients: ["  acme "] });
    expect(exact.rows.length).toBe(1);
    expect(messy.rows.length).toBe(exact.rows.length);
  });

  it("product multi filter matches with messy case/spaces", () => {
    const messy = buildReport("salesByProduct", db, { products: [" buke "] });
    const names = messy.rows.map((r) => String(r["product"] || "").toUpperCase());
    expect(names.length).toBeGreaterThan(0);
    expect(names.every((n) => n.includes("BUKE"))).toBe(true);
  });

  it("faturaTeresot lists today's sale lines with sold/free/piece-price columns", () => {
    const today = new Date().toISOString().slice(0, 10);
    const dbToday: DB = {
      ...db,
      invoices: [
        {
          no: 7,
          date: today,
          time: "09:00",
          customer: "ACME",
          mode: "Me arke",
          items: [
            { productName: "UJE 0.5L", qty: 3, freeQty: 1, unit: "Koli", rate: 264, buyRate: 216, total: 792, cost: 648 },
          ],
          subtotal: 792,
          roundOff: 0,
          total: 792,
          paid: 792,
          due: 0,
          paymentType: "Cash",
          totalCost: 648,
          profit: 144,
        },
      ],
    };
    const out = buildReport("faturaTeresot", dbToday, {});
    const keys = out.columns.map((c) => c.key);
    expect(keys).toEqual(["no", "product", "unit", "qtySold", "qtyFree", "rate", "value", "piece"]);
    expect(out.rows.length).toBe(1);
    const r = out.rows[0];
    expect(Number(r["qtySold"])).toBe(3);
    expect(Number(r["qtyFree"])).toBe(1);
    // piece price = rate 264 / coef 12 = 22
    expect(Number(r["piece"])).toBeCloseTo(22, 5);
  });

  it("stockSummary shows base unit, second unit and a both-units balance", () => {
    const out = buildReport("stockSummary", db, {});
    const keys = out.columns.map((c) => c.key);
    // Fixed column order per requirement.
    expect(keys).toEqual(["nr", "product", "baseUnit", "secondUnit", "qty", "balance", "buyPiece", "value"]);
    const uje = out.rows.find((r) => String(r["product"]).includes("UJE"));
    // Stock is stored in base units (120 copë) and shown in both units.
    expect(String(uje!["baseUnit"])).toBe("Cope");
    expect(String(uje!["secondUnit"])).toBe("Koli");
    expect(Number(uje!["qty"])).toBe(120);
    // 120 base / 12 = exactly 10 Koli.
    expect(String(uje!["balance"])).toContain("120 Cope");
    expect(String(uje!["balance"])).toContain("10 Koli");
  });
});

// ---------------------------------------------------------------------------
// PART 5 — SHITJE SOT  &  PART 6 — KËRKESË FURNIZIMI  (v1.0.18 acceptance)
// ---------------------------------------------------------------------------
describe("PART 5 - Shitje Sot report", () => {
  const today = new Date().toISOString().slice(0, 10);
  // Two sales today of the SAME product at TWO different prices, one with a gift.
  const dbSot: DB = {
    ...db,
    invoices: [
      {
        no: 10, date: today, time: "08:00", customer: "ACME", mode: "Me arke",
        items: [
          // 10 koli sold @300 + 1 koli gift  -> value 3000, gift adds nothing
          { productName: "UJE 0.5L", qty: 10, freeQty: 1, unit: "Koli", rate: 300, buyRate: 216, total: 3000, cost: 2160 },
        ],
        subtotal: 3000, roundOff: 0, total: 3000, paid: 3000, due: 0, paymentType: "Cash", totalCost: 2160, profit: 840,
      },
      {
        no: 11, date: today, time: "09:00", customer: "Beta", mode: "Me arke",
        items: [
          // same product, DIFFERENT price 280 -> must be a separate row
          { productName: "UJE 0.5L", qty: 5, freeQty: 0, unit: "Koli", rate: 280, buyRate: 216, total: 1400, cost: 1080 },
        ],
        subtotal: 1400, roundOff: 0, total: 1400, paid: 1400, due: 0, paymentType: "Cash", totalCost: 1080, profit: 320,
      },
    ],
  };

  it("defaults to TODAY when no date range is supplied", () => {
    const out = buildReport("shitjeSot", dbSot, {});
    expect(out.title).toBe("Shitje Sot");
    expect(String(out.subtitle)).toContain(today);
    // 2 data rows + 1 green TOTAL row
    const dataRows = out.rows.filter((r) => !r["_total"]);
    expect(dataRows.length).toBe(2);
  });

  it("returns nothing for a past interval with no sales", () => {
    const out = buildReport("shitjeSot", dbSot, { from: "2020-01-01", to: "2020-01-31" });
    const dataRows = out.rows.filter((r) => !r["_total"]);
    expect(dataRows.length).toBe(0);
  });

  it("same product at different prices produces TWO separate rows", () => {
    const out = buildReport("shitjeSot", dbSot, {});
    const dataRows = out.rows.filter((r) => !r["_total"]);
    const rates = dataRows.map((r) => Number(r["rate"])).sort((a, b) => a - b);
    expect(rates).toEqual([280, 300]);
  });

  it("shows gift in the name only; Sasi = sold qty; Vlerë = sold × price (gift adds nothing)", () => {
    const out = buildReport("shitjeSot", dbSot, {});
    const giftRow = out.rows.find((r) => String(r["product"]).includes("+1"));
    expect(giftRow).toBeTruthy();
    // Name pattern "UJE 0.5L (10 shitur +1)"
    expect(String(giftRow!["product"])).toContain("10 shitur +1");
    // Sasi is the SOLD quantity (10), not 11
    expect(Number(giftRow!["qty"])).toBe(10);
    // Vlerë = 10 × 300 = 3000 (gift would have made 3300 — it must NOT)
    expect(Number(giftRow!["value"])).toBe(3000);
  });

  it("has a green TOTAL row summing only sold value (3000 + 1400 = 4400)", () => {
    const out = buildReport("shitjeSot", dbSot, {});
    const totalRow = out.rows.find((r) => r["_total"]);
    expect(totalRow).toBeTruthy();
    expect(Number(totalRow!["value"])).toBe(4400);
  });

  it("uses exactly the 5 required columns: Emërtimi, Sasi, Njësia, Çmimi, Vlerë", () => {
    const out = buildReport("shitjeSot", dbSot, {});
    expect(out.columns.map((c) => c.key)).toEqual(["product", "qty", "unit", "rate", "value"]);
  });
});

describe("PART 6 - Kërkesë Furnizimi report", () => {
  it("uses ONLY three columns: Emërtimi, Sasi, Njësia (no price/value/total)", () => {
    const out = buildReport("kerkeseFurnizimi", db, {});
    const keys = out.columns.map((c) => c.key);
    expect(keys).toEqual(["product", "qty", "unit"]);
    // None of the forbidden money columns appear
    expect(keys).not.toContain("rate");
    expect(keys).not.toContain("value");
    expect(keys).not.toContain("total");
  });

  it("lists items at or below minimum stock (BUKE: stock 5 <= min 10)", () => {
    const out = buildReport("kerkeseFurnizimi", db, {});
    const names = out.rows.map((r) => String(r["product"]).toUpperCase());
    expect(names.some((n) => n.includes("BUKE"))).toBe(true);
    // UJE has stock 120 > min 20 -> not listed
    expect(names.some((n) => n.includes("UJE"))).toBe(false);
  });

  it("expresses the needed quantity in the largest unit", () => {
    // BUKE only has Cope, need = 10 - 5 = 5 Cope
    const out = buildReport("kerkeseFurnizimi", db, {});
    const buke = out.rows.find((r) => String(r["product"]).toUpperCase().includes("BUKE"))!;
    expect(Number(buke["qty"])).toBe(5);
    expect(String(buke["unit"])).toBe("Cope");
  });
});

describe("renderReportHtml", () => {
  it("produces an HTML document containing the report title", () => {
    const out = buildReport("salesSummary", db, {});
    const html = renderReportHtml(out, { companyName: "TEST", currency: "LEK" });
    expect(html).toContain("<html");
    expect(html).toContain(out.title);
    expect(html).toContain("TEST");
  });

  it("HTML for every report compiles without throwing", () => {
    for (const r of REPORT_CATALOG) {
      const out = buildReport(r.value as ReportType, db, {});
      const html = renderReportHtml(out, { companyName: "TEST" });
      expect(html.length).toBeGreaterThan(100);
    }
  });
});

// ---------- Salesman / GPS / Location reports (Phase 2) ----------
const dbGeo: DB = {
  company: { name: "GEO", currency: "LEK" },
  stores: ["Magazina kryesore"],
  products: [
    { id: 1, name: "UJE 0.5L", salePiece: 25, buyPiece: 18, stock: 120, minStock: 20, category: "Pije", units: [{ name: "Cope", coef: 1 }] },
    { id: 2, name: "BUKE", salePiece: 80, buyPiece: 50, stock: 5, minStock: 10, category: "Ushqim", units: [{ name: "Cope", coef: 1 }] },
  ],
  customers: [{ id: 1, name: "ACME", openingBalance: 0 }, { id: 2, name: "Beta", openingBalance: 0 }],
  suppliers: [{ id: 1, name: "S1" }],
  invoices: [
    {
      no: 1, date: "2026-02-01", time: "10:00", customer: "ACME", mode: "Me arke",
      items: [{ productName: "UJE 0.5L", qty: 2, freeQty: 0, unit: "Cope", rate: 25, buyRate: 18, total: 50, cost: 36 }],
      subtotal: 50, roundOff: 0, total: 50, paid: 50, due: 0, paymentType: "Cash", totalCost: 36, profit: 14,
      salesman: "Agim", salesmanName: "Agim", latitude: 41.33, longitude: 19.82,
      mapsUrl: "https://maps.google.com/?q=41.33,19.82", geo: { status: "ok", lat: 41.33, lng: 19.82 },
    },
    {
      no: 2, date: "2026-02-02", time: "11:00", customer: "Beta", mode: "Me arke",
      items: [{ productName: "BUKE", qty: 1, freeQty: 0, unit: "Cope", rate: 80, buyRate: 50, total: 80, cost: 50 }],
      subtotal: 80, roundOff: 0, total: 80, paid: 80, due: 0, paymentType: "Cash", totalCost: 50, profit: 30,
      salesman: "Besa", salesmanName: "Besa",
    },
  ],
  purchases: [],
  payments: [],
  priceHistory: [],
  stockAdjustments: [],
  expenses: [],
  expenseCategories: [],
  storeTransfers: [],
  settings: { favoriteReports: [], gpsEnabled: true, salesmanName: "Agim" },
  salesmen: [{ name: "Agim", createdAt: "2026-01-01" }, { name: "Besa", createdAt: "2026-01-01" }],
  routeTracks: [
    {
      id: "rt1", salesman: "Agim", date: "2026-02-01", startedAt: "2026-02-01T08:00:00Z",
      endedAt: "2026-02-01T17:00:00Z", status: "ended",
      points: [{ lat: 41.33, lng: 19.82, capturedAt: "2026-02-01T10:00:00Z" }],
    },
  ],
  currentSalesman: "Agim",
  nextInvoice: 3,
  nextPurchase: 1,
};

describe("locationReport", () => {
  it("lists every sale with salesman, GPS status and map link", () => {
    const out = buildReport("locationReport", dbGeo, {});
    expect(out.rows.length).toBe(2);
    const r1 = out.rows.find((r) => r["no"] === 1)!;
    expect(String(r1["salesman"])).toBe("Agim");
    expect(String(r1["gps"])).toBe("Po");
    expect(String(r1["maps"])).toContain("41.33");
    const r2 = out.rows.find((r) => r["no"] === 2)!;
    expect(String(r2["gps"])).toBe("Jo");
    // Summary counts: 2 docs, 1 with GPS.
    expect(out.summary?.find((s) => s.label === "Me GPS")?.value).toBe("1");
  });

  it("respects the salesman filter", () => {
    const out = buildReport("locationReport", dbGeo, { salesmen: ["Agim"] });
    expect(out.rows.length).toBe(1);
    expect(String(out.rows[0]["salesman"])).toBe("Agim");
  });
});

describe("salesmanSummary", () => {
  it("aggregates sales per salesman", () => {
    const out = buildReport("salesmanSummary", dbGeo, {});
    expect(out.rows.length).toBe(2);
    const agim = out.rows.find((r) => r["salesman"] === "Agim")!;
    expect(Number(agim["sales"])).toBe(50);
    expect(Number(agim["invoices"])).toBe(1);
    expect(Number(agim["gps"])).toBe(1);
  });
});

describe("salesmanActivity", () => {
  it("lists route tracks with point counts", () => {
    const out = buildReport("salesmanActivity", dbGeo, {});
    expect(out.rows.length).toBe(1);
    expect(String(out.rows[0]["salesman"])).toBe("Agim");
    expect(Number(out.rows[0]["points"])).toBe(1);
    expect(String(out.rows[0]["status"])).toBe("Mbyllur");
  });
});

describe("category filter", () => {
  it("filters analytic sales lines by product category", () => {
    const all = buildReport("salesAnalytic", dbGeo, {});
    const onlyPije = buildReport("salesAnalytic", dbGeo, { categories: ["Pije"] });
    expect(all.rows.length).toBe(2);
    expect(onlyPije.rows.length).toBe(1);
    expect(String(onlyPije.rows[0]["product"])).toContain("UJE");
  });
});

// ---------------------------------------------------------------------------
// ACCEPTANCE TEST 6 — Real XLSX export (SheetJS / OOXML, NOT CSV)
// lib/excel.ts builds the workbook with the same SheetJS calls exercised here;
// the Expo FileSystem/Sharing wrapper cannot run under node, so we verify the
// underlying workbook bytes are a genuine .xlsx (ZIP/OOXML) file.
// ---------------------------------------------------------------------------
import * as XLSX from "xlsx";

describe("ACCEPTANCE 6 - XLSX export is a real Excel file", () => {
  it("produces a valid .xlsx workbook (ZIP/OOXML magic) readable back by SheetJS", () => {
    const result = buildReport("salesSummary", db, {});
    const aoa: (string | number)[][] = [result.columns.map((c) => c.label)];
    result.rows.forEach((r) =>
      aoa.push(result.columns.map((c) => (r[c.key] ?? "") as string | number))
    );

    const ws = XLSX.utils.aoa_to_sheet(aoa);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Raport");
    const b64 = XLSX.write(wb, { type: "base64", bookType: "xlsx" }) as string;

    // A real .xlsx is a ZIP archive: bytes start with "PK\x03\x04",
    // whose base64 representation begins with "UEsDB".
    expect(b64.startsWith("UEsDB")).toBe(true);

    // Round-trip: SheetJS can read it back and recover the header row.
    const back = XLSX.read(b64, { type: "base64" });
    expect(back.SheetNames).toContain("Raport");
    const json = XLSX.utils.sheet_to_json(back.Sheets["Raport"], { header: 1 }) as unknown[][];
    expect(json[0]).toEqual(result.columns.map((c) => c.label));
  });
});

// ISSUE 3 — Reports navigation must be value-based, not index-based.
describe("report navigation stability (ISSUE 3)", () => {
  it("has no duplicate report values in the catalog", () => {
    expect(reportCatalogDuplicates()).toEqual([]);
  });

  it("findReport resolves a stable entry by value (never by index)", () => {
    const samples: ReportType[] = [
      "salesByProduct",
      "salesByClient",
      "stockByWarehouse",
      "transferReport",
      "locationReport",
      "salesmanSummary",
    ];
    for (const v of samples) {
      const entry = findReport(v);
      expect(entry).toBeDefined();
      expect(entry!.value).toBe(v);
    }
  });

  it("the value selected always builds the SAME report (no wrong-report bug)", () => {
    for (const r of REPORT_CATALOG) {
      const entry = findReport(r.value);
      expect(entry!.value).toBe(r.value);
      const out = buildReport(r.value, db, {});
      expect(out.type).toBe(r.value);
      expect(out.title.length).toBeGreaterThan(0);
    }
  });

  it("findReport returns undefined for an unknown value", () => {
    expect(findReport("doesNotExist")).toBeUndefined();
    expect(findReport(undefined)).toBeUndefined();
  });
});
