import { describe, it, expect } from "vitest";
import {
  fmt,
  num,
  unitCoef,
  activePrice,
  partyDue,
  supplierDue,
  toBaseQty,
  applyLinesToStock,
  totalStock,
  withSalesman,
  allSalesmen,
  attachLocation,
  currentSalesmanName,
  activeRoute,
  type DB,
  type Product,
} from "../lib/store";

const sampleProduct: Product = {
  id: 1,
  name: "UJE 0.5L",
  salePiece: 25,
  buyPiece: 18,
  stock: 100,
  units: [
    { name: "Cope", coef: 1 },
    { name: "Koli", coef: 12 },
  ],
};

const baseDB: DB = {
  company: { name: "TEST", currency: "LEK" },
  stores: ["Magazina kryesore"],
  products: [sampleProduct],
  customers: [
    { id: 1, name: "ACME", openingBalance: 0 },
    { id: 2, name: "Beta", openingBalance: 5000 },
  ],
  suppliers: [{ id: 1, name: "S1" }],
  invoices: [
    {
      no: 1,
      date: "2026-01-01",
      time: "10:00",
      customer: "ACME",
      mode: "Me detyrim",
      items: [
        { productName: "UJE 0.5L", qty: 5, freeQty: 0, unit: "Cope", rate: 25, buyRate: 18, total: 125, cost: 90 },
      ],
      subtotal: 125,
      roundOff: 0,
      total: 125,
      paid: 50,
      due: 75,
      paymentType: "Cash",
      totalCost: 90,
      profit: 35,
    },
  ],
  purchases: [
    {
      no: 1,
      date: "2026-01-02",
      time: "11:00",
      supplier: "S1",
      mode: "Me detyrim",
      items: [
        { productName: "UJE 0.5L", qty: 10, freeQty: 0, unit: "Cope", rate: 18, buyRate: 18, total: 180, cost: 180 },
      ],
      subtotal: 180,
      roundOff: 0,
      total: 180,
      paid: 100,
      due: 80,
      paymentType: "Cash",
    },
  ],
  payments: [
    { id: 1, partyType: "customer", party: "ACME", date: "2026-01-03", amount: 25, method: "Cash" },
  ],
  priceHistory: [
    { product: "UJE 0.5L", fromDate: "1900-01-01", salePiece: 20, buyPiece: 15 },
    { product: "UJE 0.5L", fromDate: "2026-01-01", salePiece: 25, buyPiece: 18 },
  ],
  stockAdjustments: [],
  expenses: [],
  expenseCategories: [],
  storeTransfers: [],
  settings: { favoriteReports: [] },
  nextInvoice: 2,
  nextPurchase: 2,
};

describe("number helpers", () => {
  it("num parses strings, formatted numbers, and ignores non-numeric", () => {
    expect(num("123")).toBe(123);
    expect(num("1,234.5")).toBe(1234.5);
    expect(num("abc")).toBe(0);
    expect(num(undefined)).toBe(0);
  });

  it("fmt produces a number-with-separator string", () => {
    expect(typeof fmt(1234)).toBe("string");
    expect(fmt(0)).toBeTruthy();
  });
});

describe("unitCoef", () => {
  it("returns 1 for unknown units, correct coef otherwise", () => {
    expect(unitCoef(sampleProduct, "Cope")).toBe(1);
    expect(unitCoef(sampleProduct, "Koli")).toBe(12);
    expect(unitCoef(sampleProduct, "Unknown")).toBe(1);
    expect(unitCoef(undefined, "Cope")).toBe(1);
  });
});

describe("activePrice", () => {
  it("picks the most recent price <= date", () => {
    const old = activePrice(baseDB, "UJE 0.5L", "2025-01-01");
    expect(old.salePiece).toBe(20);
    const recent = activePrice(baseDB, "UJE 0.5L", "2026-06-01");
    expect(recent.salePiece).toBe(25);
  });

  it("falls back to product price when no history", () => {
    const db: DB = { ...baseDB, priceHistory: [] };
    const r = activePrice(db, "UJE 0.5L", "2026-01-01");
    expect(r.salePiece).toBe(25);
  });
});

describe("gift/free quantity stock deduction (base units)", () => {
  it("toBaseQty converts the SELECTED unit including free qty", () => {
    // 10 cases + 1 free case = 11 cases × 12 = 132 pieces.
    expect(toBaseQty(sampleProduct, 11, "Koli")).toBe(132);
  });

  it("applyLinesToStock deducts both sold AND free quantities in base units", () => {
    const products: Product[] = [
      { ...sampleProduct, stock: 1000, stockByStore: { "Magazina kryesore": 1000 } },
    ];
    // Sell 10 Koli + 1 free Koli => (10 + 1) × 12 = 132 pieces deducted.
    const after = applyLinesToStock(
      products,
      [{ productName: "UJE 0.5L", qty: 10, freeQty: 1, unit: "Koli" }],
      "Magazina kryesore",
      -1,
    );
    expect(totalStock(after[0])).toBe(1000 - 132);
  });
});

describe("cascading unit coefficients (Unit 3 based on Unit 2)", () => {
  it("a pallet of 114 cases × 12 pieces stores 1368 base pieces", () => {
    const withPallet: Product = {
      ...sampleProduct,
      units: [
        { name: "Cope", coef: 1 },
        { name: "Koli", coef: 12 },
        { name: "Palete", coef: 1368 }, // 114 cases × 12 pieces
      ],
    };
    expect(unitCoef(withPallet, "Palete")).toBe(1368);
    // 1 pallet + 1 free pallet => 2 × 1368 = 2736 base pieces.
    expect(toBaseQty(withPallet, 2, "Palete")).toBe(2736);
  });
});

describe("party balances", () => {
  it("calculates customer due as opening + invoice due - payments", () => {
    // ACME: opening 0, invoice due 75, payment 25 -> 50
    expect(partyDue(baseDB, "ACME")).toBe(50);
    // Beta: opening 5000, no transactions -> 5000
    expect(partyDue(baseDB, "Beta")).toBe(5000);
  });

  it("calculates supplier due", () => {
    expect(supplierDue(baseDB, "S1")).toBe(80);
  });
});

describe("salesman & location helpers", () => {
  const base: DB = {
    company: { name: "T", currency: "LEK" },
    stores: ["M1"],
    products: [],
    customers: [],
    suppliers: [],
    invoices: [],
    purchases: [],
    payments: [],
    priceHistory: [],
    stockAdjustments: [],
    expenses: [],
    expenseCategories: [],
    storeTransfers: [],
    settings: { favoriteReports: [] },
    salesmen: [],
    routeTracks: [],
    currentSalesman: "",
    nextInvoice: 1,
    nextPurchase: 1,
  };

  it("withSalesman sets current + registers name once", () => {
    let db = withSalesman(base, "Agim");
    expect(currentSalesmanName(db)).toBe("Agim");
    expect(db.salesmen?.length).toBe(1);
    // Re-adding same name (different case) does not duplicate.
    db = withSalesman(db, "agim");
    expect(db.salesmen?.length).toBe(1);
    expect(currentSalesmanName(db)).toBe("agim");
  });

  it("allSalesmen merges registered + names used on documents", () => {
    const db: DB = {
      ...base,
      salesmen: [{ name: "Agim", createdAt: "x" }],
      invoices: [{ ...({} as any), salesmanName: "Besa" }],
    };
    expect(allSalesmen(db)).toEqual(["Agim", "Besa"]);
  });

  it("attachLocation writes salesman + geo + maps url", () => {
    const doc = attachLocation({ no: 1 } as any, "Agim", { status: "ok", lat: 41.3, lng: 19.8, accuracy: 5 }, "rt1");
    expect(doc.salesmanName).toBe("Agim");
    expect(doc.latitude).toBe(41.3);
    expect(doc.longitude).toBe(19.8);
    expect(doc.routeTrackId).toBe("rt1");
    expect(doc.mapsUrl).toContain("41.3");
  });

  it("attachLocation records non-ok status without coordinates", () => {
    const doc = attachLocation({ no: 1 } as any, "Agim", { status: "denied" });
    expect(doc.latitude).toBeUndefined();
    expect(doc.locationStatus).toBe("denied");
  });

  it("activeRoute finds the open route", () => {
    const db: DB = {
      ...base,
      routeTracks: [
        { id: "a", salesman: "Agim", date: "2026-01-01", startedAt: "x", status: "ended", endedAt: "y", points: [] },
        { id: "b", salesman: "Agim", date: "2026-01-02", startedAt: "x", status: "active", points: [] },
      ],
    };
    expect(activeRoute(db)?.id).toBe("b");
  });
});

// ---------------------------------------------------------------------------
// Multi-unit stock display (Items module) — stock stored in base units only.
// ---------------------------------------------------------------------------
import {
  formatStockUnits,
  stockUnitBreakdown,
  invoicesForCustomer,
  latestInvoiceForCustomer,
  usualItemsForCustomer,
  copyLastCustomerInvoice,
  addUsualCustomerItems,
  purchasesForSupplier,
  latestPurchaseForSupplier,
  usualItemsForSupplier,
  copyLastSupplierPurchase,
  addUsualSupplierItems,
} from "../lib/store";

const waterProduct: Product = {
  id: 10,
  name: "Rugove Water 0.5L",
  salePiece: 30,
  buyPiece: 18,
  stock: 1368,
  units: [
    { name: "copë", coef: 1 },
    { name: "koli", coef: 12 },
    { name: "paletë", coef: 1368 },
  ],
};

describe("multi-unit stock display", () => {
  it("Items list label shows base + second unit (Test 7)", () => {
    // 1368 pieces, 1 case = 12 pieces => 114 cases. (fmt() keeps locale grouping.)
    expect(formatStockUnits(waterProduct, 1368)).toBe(`${fmt(1368)} copë / ${fmt(114)} koli`);
  });

  it("breakdown lists every configured unit (Test 8 & 9)", () => {
    const rows = stockUnitBreakdown(waterProduct, 1368);
    expect(rows.map((r) => r.name)).toEqual(["copë", "koli", "paletë"]);
    expect(rows.map((r) => r.qty)).toEqual([1368, 114, 1]);
    expect(rows[0].isBase).toBe(true);
  });

  it("shows decimals when stock is not exactly divisible", () => {
    // 1250 / 12 = 104.1666… → fmt rounds to 2 decimals.
    const label = formatStockUnits({ ...waterProduct, units: [{ name: "copë", coef: 1 }, { name: "koli", coef: 12 }] }, 1250);
    expect(label).toContain(`${fmt(1250)} copë`);
    expect(label).toContain(`${fmt(1250 / 12)} koli`);
    expect(label).toMatch(/104[.,]17 koli/);
  });

  it("stock after sale reflects new balance (Test 10)", () => {
    // Sell 10 koli + 1 free koli => 132 pieces off 1368 => 1236 pieces / 103 cases.
    const products: Product[] = [{ ...waterProduct, stockByStore: { "Magazina kryesore": 1368 } }];
    const after = applyLinesToStock(
      products,
      [{ productName: "Rugove Water 0.5L", qty: 10, freeQty: 1, unit: "koli" }],
      "Magazina kryesore",
      -1,
    );
    expect(totalStock(after[0])).toBe(1236);
    expect(formatStockUnits(after[0], totalStock(after[0]))).toBe(`${fmt(1236)} copë / ${fmt(103)} koli`);
  });

  it("falls back to base unit only when no second unit", () => {
    const single: Product = { ...waterProduct, units: [{ name: "copë", coef: 1 }] };
    expect(formatStockUnits(single, 50)).toBe("50 copë");
  });
});

// ---------------------------------------------------------------------------
// Smart Repeat — Sales & Purchases
// ---------------------------------------------------------------------------
function repeatDB(): DB {
  const item = (productName: string, unit: string, qty: number, freeQty: number, rate: number) => ({
    productName, qty, freeQty, unit, rate, buyRate: 18, total: qty * rate, cost: (qty + freeQty) * 12 * 18,
  });
  const inv = (no: number, date: string, customer: string, items: any[]) => ({
    no, date, time: "10:00", customer, mode: "Me detyrim" as const, items,
    subtotal: 0, roundOff: 0, total: 0, paid: 0, due: 0, paymentType: "Cash", totalCost: 0, profit: 0,
  });
  const pur = (no: number, date: string, supplier: string, items: any[]) => ({
    no, date, time: "10:00", supplier, mode: "Me detyrim" as const, items,
    subtotal: 0, roundOff: 0, total: 0, paid: 0, due: 0, paymentType: "Cash",
  });
  return {
    company: { name: "T", currency: "LEK" },
    stores: ["Magazina kryesore"],
    products: [waterProduct, { id: 11, name: "BUKE", salePiece: 80, buyPiece: 50, stock: 100, units: [{ name: "copë", coef: 1 }] }],
    customers: [{ id: 1, name: "Market A", openingBalance: 0 }],
    suppliers: [{ id: 1, name: "Supplier A" }],
    invoices: [
      // latest first after sort is #3 (2026-02-03)
      inv(1, "2026-02-01", "Market A", [item("Rugove Water 0.5L", "koli", 10, 1, 300), item("BUKE", "copë", 5, 0, 80)]),
      inv(2, "2026-02-02", "Market A", [item("Rugove Water 0.5L", "koli", 4, 0, 300)]),
      inv(3, "2026-02-03", "Market A", [item("Rugove Water 0.5L", "koli", 2, 0, 320)]),
    ] as any,
    purchases: [
      pur(1, "2026-02-01", "Supplier A", [item("Rugove Water 0.5L", "koli", 50, 0, 200)]),
    ] as any,
    payments: [],
    priceHistory: [],
    stockAdjustments: [],
    expenses: [],
    expenseCategories: [],
    storeTransfers: [],
    settings: { favoriteReports: [] },
    nextInvoice: 4,
    nextPurchase: 2,
  };
}

describe("Smart Repeat — sales", () => {
  it("invoicesForCustomer returns history newest-first (Test 1)", () => {
    const db = repeatDB();
    const list = invoicesForCustomer(db, "Market A");
    expect(list.length).toBe(3);
    expect(list[0].no).toBe(3);
    expect(latestInvoiceForCustomer(db, "Market A")?.no).toBe(3);
  });

  it("matches customer name case-insensitively", () => {
    expect(invoicesForCustomer(repeatDB(), "market a").length).toBe(3);
  });

  it("copyLastCustomerInvoice copies lines from the latest invoice (Test 2)", () => {
    const items = copyLastCustomerInvoice(repeatDB(), "Market A");
    expect(items.length).toBe(1);
    expect(items[0].productName).toBe("Rugove Water 0.5L");
    expect(items[0].unit).toBe("koli");
    expect(items[0].qty).toBe(2);
    expect(items[0].rate).toBe(320);
  });

  it("copied invoice #1 preserves qty, free, unit and price (Test 2 detail)", () => {
    const db = repeatDB();
    // Use invoice #1 explicitly via usual items / latest of a single-invoice customer.
    const inv1 = invoicesForCustomer(db, "Market A").find((i) => i.no === 1)!;
    const copy = inv1.items.map((it) => ({ ...it }));
    const water = copy.find((c) => c.productName === "Rugove Water 0.5L")!;
    expect(water.qty).toBe(10);
    expect(water.freeQty).toBe(1);
    expect(water.unit).toBe("koli");
    expect(water.rate).toBe(300);
  });

  it("usualItemsForCustomer ranks by frequency (Test 4)", () => {
    const db = repeatDB();
    const usual = usualItemsForCustomer(db, "Market A");
    // Water appears in all 3 invoices, BUKE only once → water first.
    expect(usual[0].productName).toBe("Rugove Water 0.5L");
    expect(usual.length).toBe(2);
  });

  it("addUsualCustomerItems skips items already in the cart (Test 4)", () => {
    const db = repeatDB();
    const current = [{ productName: "Rugove Water 0.5L", qty: 1, freeQty: 0, unit: "koli", rate: 300, buyRate: 18, total: 300, cost: 216 }];
    const add = addUsualCustomerItems(db, "Market A", current);
    expect(add.map((a) => a.productName)).toEqual(["BUKE"]);
  });

  it("returns empty history for unknown customer", () => {
    expect(invoicesForCustomer(repeatDB(), "Nobody").length).toBe(0);
    expect(copyLastCustomerInvoice(repeatDB(), "Nobody")).toEqual([]);
  });
});

describe("Smart Repeat — purchases", () => {
  it("purchasesForSupplier + latest (Test 5)", () => {
    const db = repeatDB();
    expect(purchasesForSupplier(db, "Supplier A").length).toBe(1);
    expect(latestPurchaseForSupplier(db, "Supplier A")?.no).toBe(1);
  });

  it("copyLastSupplierPurchase copies the lines (Test 6)", () => {
    const items = copyLastSupplierPurchase(repeatDB(), "Supplier A");
    expect(items.length).toBe(1);
    expect(items[0].productName).toBe("Rugove Water 0.5L");
    expect(items[0].qty).toBe(50);
    expect(items[0].rate).toBe(200);
  });

  it("usualItemsForSupplier + dedupe", () => {
    const db = repeatDB();
    expect(usualItemsForSupplier(db, "Supplier A").length).toBe(1);
    const add = addUsualSupplierItems(db, "Supplier A", [{ productName: "Rugove Water 0.5L", qty: 1, freeQty: 0, unit: "koli", rate: 200, buyRate: 200, total: 200, cost: 200 }]);
    expect(add.length).toBe(0);
  });
});
