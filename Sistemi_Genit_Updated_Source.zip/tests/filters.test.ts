import { describe, it, expect } from "vitest";
import { paymentStatusesOf, filterInvoicesByPaymentStatus } from "../lib/store";

// ISSUE 1 — Home payment-status filter (acceptance Test 1)
// paid invoice    : total 3000, paid 3000  -> ["paid"]
// unpaid invoice  : total 5000, paid 0     -> ["unpaid", "due"]
// partial invoice : total 10000, paid 4000 -> ["partial", "due"]

const paidInvoice = { no: 1, total: 3000, paid: 3000 };
const unpaidInvoice = { no: 2, total: 5000, paid: 0 };
const partialInvoice = { no: 3, total: 10000, paid: 4000 };
const all = [paidInvoice, unpaidInvoice, partialInvoice];

describe("paymentStatusesOf", () => {
  it("classifies a fully paid invoice as paid (and not due)", () => {
    const st = paymentStatusesOf(paidInvoice);
    expect(st).toContain("paid");
    expect(st).not.toContain("due");
    expect(st).not.toContain("unpaid");
    expect(st).not.toContain("partial");
  });

  it("classifies an unpaid invoice as unpaid + due", () => {
    const st = paymentStatusesOf(unpaidInvoice);
    expect(st).toContain("unpaid");
    expect(st).toContain("due");
    expect(st).not.toContain("paid");
    expect(st).not.toContain("partial");
  });

  it("classifies a partially paid invoice as partial + due", () => {
    const st = paymentStatusesOf(partialInvoice);
    expect(st).toContain("partial");
    expect(st).toContain("due");
    expect(st).not.toContain("paid");
    expect(st).not.toContain("unpaid");
  });

  it("treats a tiny rounding residue as fully paid", () => {
    const st = paymentStatusesOf({ total: 3000, paid: 2999.9995 });
    expect(st).toContain("paid");
    expect(st).not.toContain("due");
  });
});

describe("filterInvoicesByPaymentStatus", () => {
  it("returns everything for ['all'] or empty selection", () => {
    expect(filterInvoicesByPaymentStatus(all, ["all"]).length).toBe(3);
    expect(filterInvoicesByPaymentStatus(all, []).length).toBe(3);
    expect(filterInvoicesByPaymentStatus(all, undefined).length).toBe(3);
  });

  it("filters to a single status", () => {
    expect(filterInvoicesByPaymentStatus(all, ["paid"]).map((i) => i.no)).toEqual([1]);
    expect(filterInvoicesByPaymentStatus(all, ["unpaid"]).map((i) => i.no)).toEqual([2]);
    expect(filterInvoicesByPaymentStatus(all, ["partial"]).map((i) => i.no)).toEqual([3]);
  });

  it("'due' matches both unpaid and partial invoices", () => {
    expect(filterInvoicesByPaymentStatus(all, ["due"]).map((i) => i.no)).toEqual([2, 3]);
  });

  it("matches the union of multiple selected statuses", () => {
    expect(filterInvoicesByPaymentStatus(all, ["unpaid", "partial"]).map((i) => i.no)).toEqual([2, 3]);
    expect(filterInvoicesByPaymentStatus(all, ["paid", "partial"]).map((i) => i.no)).toEqual([1, 3]);
  });
});
