# Sistemi Genit — V4 Hardening Notes

Ky version vazhdon punën pas v3 dhe fokusohet te ato pjesë që prishin besueshmërinë e sistemit në përdorim real.

## Ndryshimet kryesore

1. **Build / TypeScript hardening për dokumentet e magazinës**
   - `InboundDoc` tani mban edhe fushat e printimit: `authorizedPerson`, `vehicle`, `serialNo`.
   - `InventoryDoc` tani ka metadata të njëjtë si FH/FD që print/export të mos thyehet.
   - `InventoryDocInput` pranon fushat opsionale të printimit/logjistikës.
   - Kjo rregullon rrezikun që build-i të dështojë nga object literal fields që ekzistonin në kod por mungonin në type.

2. **Blerje/editim blerjeje më i sigurt**
   - Pas ruajtjes së blerjes kontrollohet gjendja finale.
   - Nëse editimi i blerjes do krijonte stok negativ, ruajtja bllokohet dhe rikthehet DB origjinale.
   - Kjo mbron rastin kur një blerje e vjetër është konsumuar nga shitjet dhe dikush tenton ta zvogëlojë ose ta ndryshojë.

3. **Kërkesë furnizimi pa çmime/vlera**
   - `supplyNeed` nuk nxjerr më kolonat `Çmim blerje` dhe `Vlerë`.
   - Raporti jep vetëm: Artikulli, Gjendje, Minimum, Kërko, Njësia.
   - Sasitë shfaqen në njësinë më të përshtatshme sipas koeficientëve të artikullit.

4. **Kërkesë furnizimi inteligjente sipas shitjes**
   - `purchaseSuggestion` tani llogarit mesataren ditore nga shitjet e periudhës së zgjedhur.
   - Zbritet gjendja aktuale.
   - Sugjerimi jep vetëm sasinë që mungon për target mbulim 3 ditë.
   - Nuk ka më kolona çmimi/vlere.
   - U hoq kolona e dubluar `Artikulli`.

## Rregull biznesi

Stoku ruhet në njësi bazë. Raportet e furnizimit e kthejnë sasinë në njësinë më të përshtatshme për përdoruesin, p.sh. në `Koli` kur kërkesa nuk arrin një `Paletë`, ose në `Paletë` kur sasia është e madhe.
