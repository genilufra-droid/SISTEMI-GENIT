/**
 * Warehouse document (Fletë Dalje / Fletë Hyrje) — real styled .xlsx builder.
 *
 * Pure module: imports only `xlsx-js-style` and types. NO native modules
 * (react-native / expo), so it is fully unit-testable and reusable. The layout
 * mirrors the printed warehouse document exactly:
 *   title • company • header field block • goods table • TOTAL • signatures.
 */
import * as XLSXStyle from "xlsx-js-style";
import type { Company } from "./store";
import type { PrintableDoc } from "./print-templates";

const WH_BORDER_THIN = { style: "thin", color: { rgb: "000000" } } as const;
const WH_ALL_BORDERS = {
  top: WH_BORDER_THIN,
  bottom: WH_BORDER_THIN,
  left: WH_BORDER_THIN,
  right: WH_BORDER_THIN,
};

/** Build a styled cell object for xlsx-js-style. */
function wcell(v: string | number, style: any): any {
  const t = typeof v === "number" ? "n" : "s";
  return { v, t, s: style };
}

/** The 6 physical warehouse-document columns, in order. */
export const WAREHOUSE_XLSX_COLUMNS = [
  "Nr",
  "Emërtimi i mallit",
  "Njësia",
  "Sasia",
  "Çmimi",
  "Vlefta",
] as const;

/**
 * Pure builder — constructs the styled xlsx-js-style workbook for a warehouse
 * document. Returns the workbook object (caller writes/serializes it).
 */
export function buildWarehouseDocWorkbook(doc: PrintableDoc, company: Company): any {
  const NCOLS = 6; // Nr, Emërtimi, Njësia, Sasia, Çmimi, Vlefta
  const lastCol = NCOLS - 1;
  const ws: any = {};
  const merges: any[] = [];
  const rowHeights: { hpt: number }[] = [];
  let R = 0;

  const setRow = (cells: any[], height?: number) => {
    cells.forEach((cell, c) => {
      if (cell == null) return;
      ws[XLSXStyle.utils.encode_cell({ r: R, c })] = cell;
    });
    rowHeights[R] = { hpt: height ?? 16 };
    R++;
  };

  const titleStyle = { font: { bold: true, sz: 20 }, alignment: { horizontal: "center", vertical: "center" }, border: WH_ALL_BORDERS };
  const companyStyle = { font: { bold: true, sz: 11 }, alignment: { horizontal: "center", vertical: "center", wrapText: true }, border: WH_ALL_BORDERS };
  const labelStyle = { font: { bold: true, sz: 10 }, fill: { fgColor: { rgb: "F0F0F0" } }, border: WH_ALL_BORDERS, alignment: { vertical: "center", wrapText: true } };
  const valueStyle = { font: { sz: 10 }, border: WH_ALL_BORDERS, alignment: { vertical: "center", wrapText: true } };
  const thStyle = { font: { bold: true, sz: 10 }, fill: { fgColor: { rgb: "E8E8E8" } }, border: WH_ALL_BORDERS, alignment: { horizontal: "center", vertical: "center", wrapText: true } };
  const tdL = { font: { sz: 10 }, border: WH_ALL_BORDERS, alignment: { horizontal: "left", wrapText: true } };
  const tdC = { font: { sz: 10 }, border: WH_ALL_BORDERS, alignment: { horizontal: "center" } };
  const tdR = { font: { sz: 10 }, border: WH_ALL_BORDERS, alignment: { horizontal: "right" } };
  const tdRMoney = { ...tdR, numFmt: "#,##0.00" };
  const totStyle = { font: { bold: true, sz: 10 }, fill: { fgColor: { rgb: "F0F0F0" } }, border: WH_ALL_BORDERS, alignment: { horizontal: "right" } };
  const totMoneyStyle = { ...totStyle, numFmt: "#,##0.00" };
  const signStyle = { font: { bold: true, sz: 10 }, alignment: { horizontal: "center", vertical: "top" }, border: { top: WH_BORDER_THIN } };

  // Top physical header: company block | title/date/number | destination/serial.
  setRow([wcell(company.name || "", companyStyle), null, wcell(doc.title, titleStyle), null, wcell("Adresa ku shkon malli", labelStyle), wcell(doc.destinationAddress || doc.partyAddress || "", valueStyle)], 26);
  merges.push({ s: { r: R - 1, c: 0 }, e: { r: R - 1, c: 1 } });
  merges.push({ s: { r: R - 1, c: 2 }, e: { r: R - 1, c: 3 } });

  setRow([wcell(company.nipt ? `NIPT: ${company.nipt}` : (company.address || ""), companyStyle), null, wcell(`Nr. ${doc.number || ""}`, valueStyle), wcell(`Dt. ${doc.date || ""}`, valueStyle), wcell("Seria / Referenca", labelStyle), wcell(doc.serialNo || "", valueStyle)], 22);
  merges.push({ s: { r: R - 1, c: 0 }, e: { r: R - 1, c: 1 } });

  const headerFields: [string, string][] = [
    ["Emri, mbiemri pers. Autorizuar", doc.authorizedPerson || ""],
    ["Lloji e targa e Mjetit transp.", doc.vehicle || ""],
    [doc.warehouseKind === "inbound" ? "Furnitori" : "Marrësi në dorëzim", doc.receiver || doc.partyName || ""],
    ["Magazina", doc.warehouseName || doc.businessUnit || ""],
    ["Arsyeja / Shënim", doc.note || ""],
    ["Dokumenti", `${doc.title} ${doc.number || ""}`],
  ];
  for (let i = 0; i < headerFields.length; i += 2) {
    const a = headerFields[i];
    const b = headerFields[i + 1];
    setRow([wcell(a[0], labelStyle), wcell(a[1], valueStyle), null, wcell(b[0], labelStyle), wcell(b[1], valueStyle)], 22);
    merges.push({ s: { r: R - 1, c: 1 }, e: { r: R - 1, c: 2 } });
    merges.push({ s: { r: R - 1, c: 4 }, e: { r: R - 1, c: 5 } });
  }
  setRow([], 6);

  setRow((WAREHOUSE_XLSX_COLUMNS as readonly string[]).map((h) => wcell(h, thStyle)), 24);

  const visibleLines = [...doc.lines];
  while (visibleLines.length < 21) visibleLines.push({ name: "", qty: 0, unit: "", rate: 0, total: 0 });
  visibleLines.forEach((l, i) => {
    const has = !!String(l.name || "").trim();
    setRow([
      wcell(i + 1, tdC),
      wcell(has ? l.name : "", tdL),
      wcell(has ? l.unit : "", tdC),
      wcell(has ? Number(l.qty || 0) : "", has ? { ...tdR, numFmt: "#,##0.###" } : tdR),
      wcell(has && Number(l.rate || 0) ? Number(l.rate || 0) : "", has ? tdRMoney : tdR),
      wcell(has && Number(l.total || 0) ? Number(l.total || 0) : "", has ? tdRMoney : tdR),
    ], 18);
  });

  const totalQty = doc.lines.reduce((s, l) => s + Number(l.qty || 0), 0);
  setRow([wcell("TOTALI", totStyle), null, null, wcell(totalQty, { ...totStyle, numFmt: "#,##0.###" }), wcell("", totStyle), wcell(Number(doc.total || 0), totMoneyStyle)], 20);
  merges.push({ s: { r: R - 1, c: 0 }, e: { r: R - 1, c: 2 } });

  setRow([], 26);
  setRow([], 24);

  const sigRoles = doc.warehouseKind === "inbound"
    ? ["Magazinieri", "Dorëzuesi", "Marrësi në dorëzim", "Transportuesi", "Llogaritari"]
    : ["Magazinieri", "Marrësi në dorëzim", "Transportuesi", "Llogaritari"];
  const sigCells: any[] = new Array(NCOLS).fill(null);
  const spans = doc.warehouseKind === "inbound" ? [1, 1, 1, 1, 2] : [1, 2, 1, 2];
  let cstart = 0;
  sigRoles.forEach((role, i) => {
    sigCells[cstart] = wcell(role, signStyle);
    if (spans[i] > 1) merges.push({ s: { r: R, c: cstart }, e: { r: R, c: cstart + spans[i] - 1 } });
    cstart += spans[i];
  });
  setRow(sigCells, 24);

  ws["!ref"] = XLSXStyle.utils.encode_range({ s: { r: 0, c: 0 }, e: { r: R - 1, c: lastCol } });
  ws["!cols"] = [{ wch: 6 }, { wch: 38 }, { wch: 12 }, { wch: 12 }, { wch: 14 }, { wch: 14 }];
  ws["!rows"] = rowHeights;
  ws["!merges"] = merges;

  const wb = XLSXStyle.utils.book_new();
  XLSXStyle.utils.book_append_sheet(wb, ws, (doc.title || "Fletë").slice(0, 28));
  return wb;
}
