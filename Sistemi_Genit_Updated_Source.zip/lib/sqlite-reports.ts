import { REPORT_CATALOG, type ReportFilter, type ReportResult, type ReportType, type Column, type Row } from "./reports";
import { fmt, saveMultiDB, getMultiDB } from "./store";
import { sqliteActiveCompanyId, sqliteAll, sqliteFirst } from "./sqlite-storage";

type SqlReport = ReportResult & { source?: "sqlite" };
type SqlParts = { where: string[]; params: any[] };

function norm(s?: string): string { return String(s || "").trim().toLowerCase().replace(/\s+/g, " "); }

function periodLabel(f: ReportFilter): string {
  if (f.from && f.to) return `${f.from} → ${f.to}`;
  if (f.from) return `Nga ${f.from}`;
  if (f.to) return `Deri ${f.to}`;
  return "Të gjitha datat";
}

function addDate(parts: SqlParts, col: string, f: ReportFilter) {
  if (f.from) { parts.where.push(`${col} >= ?`); parts.params.push(f.from); }
  if (f.to) { parts.where.push(`${col} <= ?`); parts.params.push(f.to); }
}

function addText(parts: SqlParts, col: string, list?: string[], single?: string) {
  if (list && list.length) {
    const cleaned = list.map(norm).filter(Boolean);
    if (cleaned.length) {
      parts.where.push(`LOWER(TRIM(${col})) IN (${cleaned.map(() => "?").join(",")})`);
      parts.params.push(...cleaned);
    }
  } else if (single && single.trim()) {
    parts.where.push(`LOWER(${col}) LIKE ?`);
    parts.params.push(`%${norm(single)}%`);
  }
}

function addTxn(parts: SqlParts, col: string, f: ReportFilter) {
  if (!f.txnType || f.txnType === "all") return;
  if (f.txnType === "cash") parts.where.push(`${col} = 'Me arke'`);
  else parts.where.push(`${col} <> 'Me arke'`);
}

function addPayStatus(parts: SqlParts, totalCol: string, paidCol: string, f: ReportFilter) {
  if (!f.payStatus || f.payStatus === "all") return;
  if (f.payStatus === "paid") parts.where.push(`${paidCol} >= ${totalCol} - 0.001`);
  else if (f.payStatus === "unpaid") parts.where.push(`${paidCol} <= 0.001`);
  else parts.where.push(`${paidCol} > 0.001 AND ${paidCol} < ${totalCol} - 0.001`);
}

function addPriceFilter(parts: SqlParts, rateCol: string, f: ReportFilter) {
  if (!f.price || !f.price.trim()) return;
  const prices = f.price.split(/[;,]/).map(x => Number(x.trim().replace(",", "."))).filter(n => !isNaN(n));
  if (!prices.length) return;
  parts.where.push(`ROUND(${rateCol}, 2) IN (${prices.map(() => "?").join(",")})`);
  parts.params.push(...prices.map(p => Math.round(p * 100) / 100));
}

function docInvoiceWhere(companyId: string, f: ReportFilter): SqlParts {
  const p: SqlParts = { where: ["i.company_id = ?"], params: [companyId] };
  addDate(p, "i.date", f);
  addText(p, "i.customer", f.clients, f.client);
  addText(p, "i.store", f.stores, f.store);
  addText(p, "i.salesman", f.salesmen, f.salesman);
  addTxn(p, "i.mode", f);
  addPayStatus(p, "i.total", "i.paid", f);
  return p;
}

function addLineFilters(parts: SqlParts, productCol: string, unitCol: string, categoryCol: string, f: ReportFilter, rateCol?: string) {
  addText(parts, productCol, f.products, f.product);
  addText(parts, unitCol, f.units, f.unit);
  addText(parts, categoryCol, f.categories, f.category);
  if (rateCol) addPriceFilter(parts, rateCol, f);
}

function withSource(result: ReportResult): SqlReport {
  return { ...result, source: "sqlite" };
}

const money = (n: number) => fmt(Number(n || 0));

export async function buildSqliteReport(type: ReportType, f: ReportFilter): Promise<SqlReport | null> {
  const companyId = await sqliteActiveCompanyId();
  if (!companyId) return null;

  // Force sync before report
  try { await saveMultiDB(getMultiDB()); } catch (_) {}

  const sub = periodLabel(f);

  if (type === "salesSummary" || type === "faturaTeresot" || type === "unpaidInvoices") {
    const p = docInvoiceWhere(companyId, f);
    if (type === "unpaidInvoices") {
      p.where.push("i.paid < i.total - 0.001");
    }
    const rows = await sqliteAll<Row>(
      `SELECT i.invoice_no AS no, i.date, i.customer AS party, i.total, i.paid, i.due, i.mode, i.profit 
       FROM invoices i 
       WHERE ${p.where.join(" AND ")} 
       ORDER BY i.date DESC, i.invoice_no DESC`,
      p.params
    );
    return withSource({
      type,
      title: REPORT_CATALOG.find(r => r.value === type)?.label || "Raport",
      subtitle: sub,
      columns: [
        { key: "party", label: "Klienti" },
        { key: "no", label: "Nr. Faturës" },
        { key: "date", label: "Data" },
        { key: "total", label: "Vlera", align: "right", format: "money" },
        { key: "due", label: "Detyrim", align: "right", format: "money" }
      ],
      rows,
      summary: [
        { label: "Fatura", value: String(rows.length) },
        { label: "Vlera Totale", value: money(rows.reduce((s, r) => s + Number(r.total || 0), 0)) },
        { label: "Detyrim Total", value: money(rows.reduce((s, r) => s + Number(r.due || 0), 0)) }
      ]
    });
  }

  if (type === "shitjeSot" || type === "salesByProduct") {
    const p = docInvoiceWhere(companyId, f);
    addLineFilters(p, "ii.product_name", "ii.unit", "COALESCE(pr.category,'')", f, "ii.rate");
    
    const lines = await sqliteAll<any>(
      `SELECT ii.product_name AS name, SUM(ii.qty) AS sasi, ii.unit AS njesi, ii.rate AS cmimi, SUM(ii.total) AS vlere
       FROM invoice_items ii
       JOIN invoices i ON i.company_id = ii.company_id AND i.invoice_no = ii.invoice_no
       LEFT JOIN products pr ON pr.company_id = ii.company_id AND LOWER(TRIM(pr.name)) = LOWER(TRIM(ii.product_name))
       WHERE ${p.where.join(" AND ")}
       GROUP BY ii.product_name, ii.unit, ii.rate
       ORDER BY ii.product_name ASC`,
      p.params
    );

    const totalVlere = lines.reduce((s, l) => s + Number(l.vlere || 0), 0);
    const rows: Row[] = [...lines];

    // Add Total row
    rows.push({
      name: "Total",
      sasi: "",
      njesi: "",
      cmimi: "",
      vlere: totalVlere,
      _total: true,
      _green: true
    });

    if (type === "shitjeSot") {
      // Special rows for Shitje Sot as per Excel screenshot
      // BORXHI PIT STOPIT (dummy or calculated from payments/due if needed, but here we match the style)
      const totalDue = await sqliteFirst<{val: number}>(
        `SELECT SUM(due) as val FROM invoices i WHERE ${p.where.join(" AND ")}`,
        p.params
      );
      const totalPaid = await sqliteFirst<{val: number}>(
        `SELECT SUM(paid) as val FROM invoices i WHERE ${p.where.join(" AND ")}`,
        p.params
      );

      rows.push({
        name: "BORXHI",
        sasi: "",
        njesi: "",
        cmimi: "",
        vlere: totalDue?.val || 0,
        _yellow: true
      });

      rows.push({
        name: "Arketuar",
        sasi: "",
        njesi: "",
        cmimi: "",
        vlere: totalPaid?.val || 0,
        _green: true
      });
    }

    return withSource({
      type,
      title: type === "shitjeSot" ? "Shitje Sot" : "Shitje sipas artikullit",
      subtitle: sub,
      columns: [
        { key: "name", label: "Item Name" },
        { key: "sasi", label: "Sasi", align: "right", format: "qty" },
        { key: "njesi", label: "Njesi" },
        { key: "cmimi", label: "Cmimi", align: "right", format: "money" },
        { key: "vlere", label: "Vlere", align: "right", format: "money" }
      ],
      rows
    });
  }

  // Fallback for other reports
  const entry = REPORT_CATALOG.find(r => r.value === type) || REPORT_CATALOG[0];
  return withSource({
    type,
    title: entry.label,
    subtitle: sub,
    columns: [{ key: "info", label: "Informacion" }],
    rows: [{ info: "Ky raport do të implementohet së shpejti në versionin e ri." }],
    emptyMessage: "Raporti është në proces implementimi."
  });
}
