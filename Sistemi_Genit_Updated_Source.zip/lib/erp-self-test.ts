import {
  DB,
  Invoice,
  InvoiceItem,
  Purchase,
  Product,
  commitPurchaseInvoice,
  commitSaleInvoice,
  deleteSaleInvoice,
  newCompanyDB,
  stockInStore,
  saveMultiDB,
  wrapAsMultiDB,
} from "./store";
import { buildReport, renderReportHtml, ReportType, type ReportFilter } from "./reports";
import { buildSqliteReport } from "./sqlite-reports";
import { resetSqliteMirror, setSqliteActiveCompanyIdForTests, sqliteActiveCompanyId, sqliteAll, sqliteFirst } from "./sqlite-storage";

export type SelfTestStatus = "PASS" | "FAIL";
export type SelfTestRow = {
  name: string;
  status: SelfTestStatus;
  details: string;
};

function ok(name: string, details: string): SelfTestRow {
  return { name, status: "PASS", details };
}
function fail(name: string, details: string): SelfTestRow {
  return { name, status: "FAIL", details };
}
function assertTest(name: string, condition: boolean, details: string): SelfTestRow {
  return condition ? ok(name, details) : fail(name, details);
}

async function persistIsolatedDemoDbForSqlite(db: DB): Promise<void> {
  // The strict SQLite filter tests must never depend on the user's current data.
  // Every test run wipes the SQLite mirror and saves one deterministic company
  // with known products, invoices, units and prices.
  await resetSqliteMirror();
  const mdb = wrapAsMultiDB(db);
  await saveMultiDB(mdb);
  // The strict tests must use the deterministic test company even if the app
  // context or a previous install has another active company in storage.
  setSqliteActiveCompanyIdForTests(mdb.activeCompanyId);
}

function sampleProduct(): Product {
  return {
    id: 1,
    code: "RUG-05",
    barcode: "100000000001",
    name: "Ujë Rugove 0.5L",
    category: "Ujë",
    store: "Magazina Kryesore",
    salePiece: 25,
    buyPiece: 20,
    prices: [300, 290, 280, 270, 260, 250, 240, 230, 220, 210],
    stock: 0,
    stockByStore: { "Magazina Kryesore": 0 },
    minStock: 24,
    units: [
      { name: "Copë", coef: 1 },
      { name: "Koli", coef: 12 },
      { name: "Paletë", coef: 1368 },
    ],
  };
}

function sampleProduct2(): Product {
  return {
    id: 2,
    code: "PER-033",
    barcode: "100000000002",
    name: "PERONI SHISHE 0.33L",
    category: "Birra",
    store: "Magazina Kryesore",
    salePiece: 50,
    buyPiece: 35,
    prices: [1200, 1100, 1000, 950, 900],
    stock: 0,
    stockByStore: { "Magazina Kryesore": 0 },
    minStock: 24,
    units: [
      { name: "Copë", coef: 1 },
      { name: "Koli", coef: 24 },
      { name: "Paletë", coef: 960 },
    ],
  };
}

function sampleProduct3(): Product {
  return {
    id: 3,
    code: "ELB-033",
    barcode: "100000000003",
    name: "ELBAR KANAÇE 0.33L",
    category: "Birra",
    store: "Magazina Kryesore",
    salePiece: 40,
    buyPiece: 30,
    prices: [960, 900, 850, 800],
    stock: 0,
    stockByStore: { "Magazina Kryesore": 0 },
    minStock: 24,
    units: [
      { name: "Copë", coef: 1 },
      { name: "Koli", coef: 24 },
      { name: "Paletë", coef: 960 },
    ],
  };
}

function line(productName: string, qty: number, freeQty: number, unit: string, rate: number, buyRate: number): InvoiceItem {
  return {
    productName,
    qty,
    freeQty,
    unit,
    rate,
    buyRate,
    total: qty * rate,
    cost: (qty + freeQty) * buyRate,
    priceList: 0,
  };
}

function baseDb(): DB {
  const db = newCompanyDB({ name: "TEST ERP" });
  return {
    ...db,
    stores: ["Magazina Kryesore"],
    warehouses: [
      {
        id: 1,
        name: "Magazina Kryesore",
        type: "main",
        status: "active",
        createdAt: "2026-06-28T00:00:00.000Z",
        updatedAt: "2026-06-28T00:00:00.000Z",
      },
    ],
    products: [sampleProduct(), sampleProduct2(), sampleProduct3()],
    customers: [{ id: 1, name: "Market Test", defaultPriceList: 0 }],
    suppliers: [{ id: 1, name: "Furnitor Test" }],
    invoices: [],
    purchases: [],
    payments: [],
    stockMovements: [],
    inboundDocs: [],
    outboundDocs: [],
    auditLogs: [],
    nextInvoice: 1,
    nextPurchase: 1,
  };
}

export function buildVerifiedDemoDb(): { db: DB; tests: SelfTestRow[] } {
  const tests: SelfTestRow[] = [];
  let db = baseDb();
  const product = "Ujë Rugove 0.5L";
  const wh = "Magazina Kryesore";

  const purchase: Purchase = {
    no: 1,
    date: "2026-06-28",
    time: "08:00",
    supplier: "Furnitor Test",
    store: wh,
    mode: "Me arke",
    items: [line(product, 10, 1, "Koli", 240, 20)],
    subtotal: 2400,
    roundOff: 0,
    total: 2400,
    paid: 2400,
    due: 0,
    paymentType: "Cash",
    note: "Test blerje 10+1 koli",
  };
  const pr = commitPurchaseInvoice(db, purchase, { autoInbound: true });
  tests.push(assertTest("Blerje + Fletë Hyrje", !pr.error && !!pr.purchase.linkedInboundDocId, pr.error || "U krijua blerja dhe fletë hyrja automatike."));
  db = pr.db;
  const afterPurchase = stockInStore(db.products.find((p) => p.name === product), wh);
  tests.push(assertTest("Stok pas blerjes 10+1 koli", afterPurchase === 132, `Pritet 132 copë, doli ${afterPurchase}.`));

  const sale: Invoice = {
    no: 1,
    date: "2026-06-28",
    time: "09:00",
    customer: "Market Test",
    store: wh,
    mode: "Me arke",
    items: [line(product, 3, 1, "Koli", 300, 20)],
    subtotal: 900,
    roundOff: 0,
    total: 900,
    paid: 900,
    due: 0,
    paymentType: "Cash",
    totalCost: 960,
    profit: -60,
    note: "Test shitje 3+1 koli",
  };
  const sr = commitSaleInvoice(db, sale, { autoOutbound: true });
  tests.push(assertTest("Shitje + Fletë Dalje", !sr.error && !!sr.invoice.linkedOutboundDocId, sr.error || "U krijua shitja dhe fletë dalja automatike."));
  db = sr.db;
  const afterSale = stockInStore(db.products.find((p) => p.name === product), wh);
  tests.push(assertTest("Stok pas shitjes 3+1 koli", afterSale === 84, `Pritet 84 copë, doli ${afterSale}.`));

  const blocked = commitSaleInvoice(
    db,
    { ...sale, no: 2, items: [line(product, 999, 0, "Koli", 300, 20)], subtotal: 299700, total: 299700, paid: 0, due: 299700 },
    { autoOutbound: true },
  );
  tests.push(assertTest("Bllokim shitje pa stok", !!blocked.error, blocked.error || "Duhej të bllokohej, por nuk u bllokua."));

  const del = deleteSaleInvoice(db, 1);
  tests.push(assertTest("Fshirje fature rikthen stok", !del.error, del.error || "Fatura u fshi dhe lëvizja u kthye."));
  db = del.db;
  const afterDelete = stockInStore(db.products.find((p) => p.name === product), wh);
  tests.push(assertTest("Stok pas fshirjes së shitjes", afterDelete === 132, `Pritet 132 copë, doli ${afterDelete}.`));

  // Keep final sales in the demo database so the SQLite report tests can
  // verify real filters with multiple products, different units and prices.
  const filterPurchase: Purchase = {
    no: 2,
    date: "2026-06-28",
    time: "10:00",
    supplier: "Furnitor Test",
    store: wh,
    mode: "Me arke",
    items: [
      line(product, 5, 0, "Koli", 240, 20),
      line("PERONI SHISHE 0.33L", 3, 0, "Koli", 840, 35),
      line("ELBAR KANAÇE 0.33L", 3, 0, "Koli", 720, 30),
    ],
    subtotal: 5880,
    roundOff: 0,
    total: 5880,
    paid: 5880,
    due: 0,
    paymentType: "Cash",
    note: "Seed për teste filtrash SQLite",
  };
  const fpr = commitPurchaseInvoice(db, filterPurchase, { autoInbound: true });
  tests.push(assertTest("Seed filtra: blerje shumë artikuj", !fpr.error, fpr.error || "U shtua stok për teste filtrash."));
  db = fpr.db;

  const filterSale1: Invoice = {
    no: 3,
    date: "2026-06-28",
    time: "11:00",
    customer: "Market Test",
    store: wh,
    mode: "Me arke",
    items: [
      line(product, 2, 0, "Koli", 300, 20),
      line("PERONI SHISHE 0.33L", 1, 0, "Koli", 1200, 35),
    ],
    subtotal: 1800,
    roundOff: 0,
    total: 1800,
    paid: 1800,
    due: 0,
    paymentType: "Cash",
    totalCost: 1320,
    profit: 480,
    note: "Seed shitje Koli",
  };
  const fsr1 = commitSaleInvoice(db, filterSale1, { autoOutbound: true });
  tests.push(assertTest("Seed filtra: shitje shumë artikuj", !fsr1.error, fsr1.error || "U krijua shitje me dy artikuj."));
  db = fsr1.db;

  const filterSale2: Invoice = {
    no: 4,
    date: "2026-06-28",
    time: "11:30",
    customer: "Market Test",
    store: wh,
    mode: "Me arke",
    items: [
      line(product, 6, 0, "Copë", 25, 20),
      line("ELBAR KANAÇE 0.33L", 1, 0, "Koli", 960, 30),
    ],
    subtotal: 1110,
    roundOff: 0,
    total: 1110,
    paid: 1110,
    due: 0,
    paymentType: "Cash",
    totalCost: 840,
    profit: 270,
    note: "Seed shitje Copë + Koli",
  };
  const fsr2 = commitSaleInvoice(db, filterSale2, { autoOutbound: true });
  tests.push(assertTest("Seed filtra: shitje njësi/çmime", !fsr2.error, fsr2.error || "U krijua shitje me njësi dhe çmime të ndryshme."));
  db = fsr2.db;

  const filterSale3: Invoice = {
    no: 5,
    date: "2026-06-28",
    time: "12:00",
    customer: "Market Test",
    store: wh,
    mode: "Me arke",
    items: [
      // Qëllimisht i njëjti çmim në dy njësi për të provuar reportUnit = Koli
      // dhe shfaqjen e përzier: 3 Koli + 6 Copë.
      line(product, 1, 0, "Koli", 300, 20),
      line(product, 6, 0, "Copë", 300, 20),
    ],
    subtotal: 2100,
    roundOff: 0,
    total: 2100,
    paid: 2100,
    due: 0,
    paymentType: "Cash",
    totalCost: 360,
    profit: 1740,
    note: "Seed reportUnit Koli + Copë",
  };
  const fsr3 = commitSaleInvoice(db, filterSale3, { autoOutbound: true });
  tests.push(assertTest("Seed filtra: reportUnit Koli + Copë", !fsr3.error, fsr3.error || "U krijua shitje e përzier për test njësie raporti."));
  db = fsr3.db;

  const history = db.clientPriceHistory?.["market test|ujë rugove 0.5l"] || [];
  tests.push(assertTest("5 çmimet e fundit të klientit", history.length >= 2 && history.some((h) => h.price === 300) && history.some((h) => h.price === 25), `Regjistrime: ${history.length}.`));

  const reports: ReportType[] = ["salesSummary", "purchaseAnalytic", "stockSummary", "stockMovement", "outboundDocsReport", "supplyNeed"];
  for (const r of reports) {
    try {
      const res = buildReport(r, db, { from: "2026-06-01", to: "2026-06-30" });
      const html = renderReportHtml(res, { companyName: db.company.name, filters: { from: "2026-06-01", to: "2026-06-30" } });
      const headersOk = res.columns.every((c) => html.includes(c.label));
      tests.push(assertTest(`Raport i kontrolluar: ${r}`, res.columns.length > 0 && headersOk, `${res.rows.length} rreshta, ${res.columns.length} kolona.`));
    } catch (e: any) {
      tests.push(fail(`Raport i kontrolluar: ${r}`, e?.message || String(e)));
    }
  }

  return { db, tests };
}


type ExpectedAgg = { lines: number; totalValue: number };

function money2(n: any): number {
  return Math.round(Number(n || 0) * 100) / 100;
}
function normText(s?: any): string {
  return String(s || "").trim().toLowerCase().replace(/\s+/g, " ");
}
function rowValueSum(rows: any[], key = "value"): number {
  return money2(rows.reduce((sum, r) => sum + Number(r?.[key] || 0), 0));
}
function getRowString(row: any, key: string): string {
  return String(row?.[key] ?? "");
}
async function expectedInvoiceItemAgg(whereSql: string, params: any[]): Promise<ExpectedAgg> {
  const row = await sqliteFirst<{ lines: number; totalValue: number }>(
    `SELECT COUNT(*) AS lines, COALESCE(SUM(ii.total), 0) AS totalValue
     FROM invoices i
     JOIN invoice_items ii ON ii.company_id=i.company_id AND ii.invoice_no=i.invoice_no
     WHERE ${whereSql}`,
    params,
  );
  return { lines: Number(row?.lines || 0), totalValue: money2(row?.totalValue || 0) };
}

function failRow(name: string, details: string): SelfTestRow { return fail(name, details); }
function passRow(name: string, details: string): SelfTestRow { return ok(name, details); }

async function assertSqliteSeedSynced(companyId: string): Promise<SelfTestRow> {
  const name = "SQLite fixture e izoluar u sinkronizua";
  const row = await sqliteFirst<{ invoices: number; invoiceItems: number; products: number; joinedLines: number }>(
    `SELECT
       (SELECT COUNT(*) FROM invoices WHERE company_id = ?) AS invoices,
       (SELECT COUNT(*) FROM invoice_items WHERE company_id = ?) AS invoiceItems,
       (SELECT COUNT(*) FROM products WHERE company_id = ?) AS products,
       (SELECT COUNT(*)
          FROM invoice_items ii
          JOIN invoices i ON i.company_id = ii.company_id AND i.invoice_no = ii.invoice_no
         WHERE ii.company_id = ?) AS joinedLines`,
    [companyId, companyId, companyId, companyId],
  );
  const invoices = Number(row?.invoices || 0);
  const invoiceItems = Number(row?.invoiceItems || 0);
  const products = Number(row?.products || 0);
  const joinedLines = Number(row?.joinedLines || 0);
  if (products < 3 || invoices < 2 || invoiceItems < 4 || joinedLines < 4) {
    return failRow(name, `Fixture jo e plotë: products=${products}, invoices=${invoices}, invoice_items=${invoiceItems}, joinedLines=${joinedLines}.`);
  }
  return passRow(name, `OK: products=${products}, invoices=${invoices}, invoice_items=${invoiceItems}, joinedLines=${joinedLines}.`);
}

async function assertSqliteRawExactFilterData(companyId: string): Promise<SelfTestRow> {
  const name = "SQLite raw exact filter data";
  const rows = await sqliteAll<any>(
    `SELECT i.invoice_no, i.date, i.customer, ii.product_name AS product, ii.unit, ii.rate, ii.total
       FROM invoices i
       JOIN invoice_items ii ON ii.company_id = i.company_id AND ii.invoice_no = i.invoice_no
      WHERE i.company_id = ?
        AND i.date >= ? AND i.date <= ?
        AND LOWER(TRIM(i.customer)) IN (?)
        AND LOWER(TRIM(ii.product_name)) IN (?)
        AND LOWER(TRIM(ii.unit)) IN (?)
        AND ROUND(ii.rate, 2) IN (?)`,
    [companyId, "2026-06-28", "2026-06-28", "market test", "ujë rugove 0.5l", "koli", 300],
  );
  if (rows.length !== 2) return failRow(name, `Pritej 2 rreshta raw për Ujë Rugove/Koli/300, dolën ${rows.length}.`);
  const bad = rows.find((r) => normText(r.product) !== "ujë rugove 0.5l" || normText(r.unit) !== "koli" || Number(r.rate) !== 300);
  if (bad) return failRow(name, `Raw row jashtë pritshmërisë: ${String(bad.product)} / ${String(bad.unit)} / ${String(bad.rate)}.`);
  return passRow(name, "OK: të dhënat raw për filtrin exact ekzistojnë në SQLite.");
}

async function assertSqliteSalesAnalyticStrict(filter: ReportFilter, expected: { product: string; unit: string; rate: number; whereSql: string; params: any[] }): Promise<SelfTestRow> {
  const name = "SQLite salesAnalytic strict Produkt+Njësi+Çmim+Datë+Klient";
  const report = await buildSqliteReport("salesAnalytic", filter);
  if (!report) return failRow(name, "Raporti nuk u ndërtua nga SQLite.");
  const expectedAgg = await expectedInvoiceItemAgg(expected.whereSql, expected.params);
  if (expectedAgg.lines <= 0) return failRow(name, "Fixture SQLite nuk ka rreshta për filtrin exact; testi nuk është i vlefshëm.");
  const bad = report.rows.find((r: any) => normText(r.product) !== normText(expected.product) || normText(r.unit) !== normText(expected.unit) || Math.abs(Number(r.rate || 0) - expected.rate) > 0.001);
  if (bad) return failRow(name, `Rresht jashtë filtrit: ${getRowString(bad, "product")} / ${getRowString(bad, "unit")} / ${getRowString(bad, "rate")}.`);
  if (report.rows.length !== expectedAgg.lines) return failRow(name, `Numër rreshtash gabim. Pritej ${expectedAgg.lines}, doli ${report.rows.length}.`);
  const actualValue = rowValueSum(report.rows, "value");
  if (Math.abs(actualValue - expectedAgg.totalValue) > 0.01) return failRow(name, `Vlerë gabim. Pritej ${expectedAgg.totalValue}, doli ${actualValue}.`);
  return passRow(name, `OK: ${expected.product} / ${expected.unit} / ${expected.rate}; ${report.rows.length} rreshta, vlerë ${actualValue}.`);
}

async function assertSqliteSalesByProductStrict(filter: ReportFilter, expected: { product: string; unit: string; rate: number; whereSql: string; params: any[] }): Promise<SelfTestRow> {
  const name = "SQLite salesByProduct strict Produkt+Njësi+Çmim";
  const report = await buildSqliteReport("salesByProduct", filter);
  if (!report) return failRow(name, "Raporti nuk u ndërtua nga SQLite.");
  const expectedAgg = await expectedInvoiceItemAgg(expected.whereSql, expected.params);
  if (expectedAgg.lines <= 0) return failRow(name, "Fixture SQLite nuk ka rreshta për filtrin exact; testi nuk është i vlefshëm.");
  if (report.rows.length !== 1) return failRow(name, `Pritej 1 grup i vetëm Artikull+Njësi+Çmim, dolën ${report.rows.length}.`);
  const r: any = report.rows[0] || {};
  if (normText(r.product) !== normText(expected.product) || normText(r.unit) !== normText(expected.unit) || Math.abs(Number(r.rate || 0) - expected.rate) > 0.001) {
    return failRow(name, `Grup gabim. Pritej ${expected.product} / ${expected.unit} / ${expected.rate}; doli ${String(r.product)} / ${String(r.unit)} / ${String(r.rate)}.`);
  }
  if (Math.abs(Number(r.value || 0) - expectedAgg.totalValue) > 0.01) return failRow(name, `Vlera e grupit gabim. Pritej ${expectedAgg.totalValue}, doli ${money2(r.value)}.`);
  return passRow(name, `OK: grupim i vetëm ${expected.product} / ${expected.unit} / ${expected.rate}, vlerë ${expectedAgg.totalValue}.`);
}

async function assertSqliteNoRows(reportType: ReportType, filter: ReportFilter, name: string): Promise<SelfTestRow> {
  const report = await buildSqliteReport(reportType, filter);
  if (!report) return failRow(name, "Raporti nuk u ndërtua nga SQLite.");
  return report.rows.length === 0
    ? passRow(name, "OK: filtri negativ ktheu 0 rreshta.")
    : failRow(name, `Duhej 0 rreshta, por u kthyen ${report.rows.length}. Filtri mund të jetë fasadë.`);
}

async function assertSqliteReportUnitKoli(): Promise<SelfTestRow> {
  const name = "SQLite reportUnit Koli shfaq Koli + Copë";
  const filter: ReportFilter = {
    products: ["Ujë Rugove 0.5L"],
    price: "300",
    reportUnit: "Koli",
    from: "2026-06-28",
    to: "2026-06-28",
    clients: ["Market Test"],
  };
  const report = await buildSqliteReport("salesByProduct", filter);
  if (!report) return failRow(name, "Raporti nuk u ndërtua nga SQLite.");
  const row: any = report.rows.find((r: any) => normText(r.product) === normText("Ujë Rugove 0.5L") && Number(r.rate) === 300);
  if (!row) return failRow(name, "Mungon grupi Ujë Rugove 0.5L me çmim 300.");
  const qty = String(row.qty || "");
  if (!qty.includes("Koli") || !qty.includes("Cop")) return failRow(name, `Sasia nuk u shfaq si Koli + Copë. Doli: ${qty}.`);
  if (normText(row.unit) !== normText("Koli")) return failRow(name, `Njësia e raportit gabim. Pritej Koli, doli ${String(row.unit)}.`);
  return passRow(name, `OK: reportUnit=Koli shfaq sasinë e përzier: ${qty}.`);
}

async function assertSqliteReportUnitInvalidFallback(): Promise<SelfTestRow> {
  const name = "SQLite reportUnit invalid nuk lejohet si etiketë false";
  const report = await buildSqliteReport("salesByProduct", { products: ["Ujë Rugove 0.5L"], price: "300", reportUnit: "Arke-False", from: "2026-06-28", to: "2026-06-28" });
  if (!report) return failRow(name, "Raporti nuk u ndërtua nga SQLite.");
  const bad = report.rows.find((r: any) => normText(r.unit) === normText("Arke-False") || String(r.qty || "").includes("Arke-False"));
  return bad ? failRow(name, "Njësia e pavlefshme u përdor në raport; duhet fallback në njësi reale të artikullit.") : passRow(name, "OK: njësia e pavlefshme nuk shfaqet si njësi raporti.");
}

async function assertSqliteMultiProductExact(companyId: string): Promise<SelfTestRow> {
  const name = "SQLite multi-product filter exact";
  const products = ["Ujë Rugove 0.5L", "PERONI SHISHE 0.33L"];
  const report = await buildSqliteReport("salesAnalytic", { products, from: "2026-06-28", to: "2026-06-28" });
  if (!report) return failRow(name, "Raporti nuk u ndërtua nga SQLite.");
  const expectedNorm = products.map(normText);
  const outside = report.rows.find((r: any) => !expectedNorm.includes(normText(r.product)));
  if (outside) return failRow(name, `U kthye produkt jashtë filtrit: ${String((outside as any).product)}.`);
  const expectedAgg = await expectedInvoiceItemAgg(
    `i.company_id = ? AND i.date >= ? AND i.date <= ? AND LOWER(TRIM(ii.product_name)) IN (?,?)`,
    [companyId, "2026-06-28", "2026-06-28", ...products.map(normText)],
  );
  if (expectedAgg.lines <= 0) return failRow(name, "Fixture SQLite nuk ka rreshta për multi-product filter; testi nuk është i vlefshëm.");
  if (report.rows.length !== expectedAgg.lines) return failRow(name, `Numër rreshtash gabim. Pritej ${expectedAgg.lines}, doli ${report.rows.length}.`);
  const actualValue = rowValueSum(report.rows, "value");
  if (Math.abs(actualValue - expectedAgg.totalValue) > 0.01) return failRow(name, `Vlerë gabim. Pritej ${expectedAgg.totalValue}, doli ${actualValue}.`);
  return passRow(name, `OK: u kthyen vetëm artikujt e zgjedhur, ${report.rows.length} rreshta, vlerë ${actualValue}.`);
}

async function assertSqliteFilterPerformance(): Promise<SelfTestRow> {
  const name = "SQLite filter performance";
  const started = Date.now();
  for (let i = 0; i < 5; i++) {
    await buildSqliteReport("salesAnalytic", { products: ["Ujë Rugove 0.5L"], units: ["Koli"], price: "300", from: "2026-06-28", to: "2026-06-28", clients: ["Market Test"], reportUnit: "Koli" });
  }
  const elapsed = Date.now() - started;
  return elapsed <= 1500 ? passRow(name, `OK: 5 raporte filtri u ndërtuan për ${elapsed} ms.`) : failRow(name, `Shumë ngadalë: 5 raporte morën ${elapsed} ms.`);
}

async function runSqliteStrictFilterTests(): Promise<SelfTestRow[]> {
  const tests: SelfTestRow[] = [];
  const companyId = await sqliteActiveCompanyId();
  if (!companyId) return [failRow("SQLite active company", "Nuk u gjet kompani aktive pas sinkronizimit të demo DB.")];
  const seed = await assertSqliteSeedSynced(companyId);
  tests.push(seed);
  if (seed.status === "FAIL") return tests;
  const rawExact = await assertSqliteRawExactFilterData(companyId);
  tests.push(rawExact);
  if (rawExact.status === "FAIL") return tests;
  const exactFilter: ReportFilter = {
    products: ["Ujë Rugove 0.5L"],
    units: ["Koli"],
    price: "300",
    from: "2026-06-28",
    to: "2026-06-28",
    clients: ["Market Test"],
    reportUnit: "Koli",
  };
  const expected = {
    product: "Ujë Rugove 0.5L",
    unit: "Koli",
    rate: 300,
    whereSql: `i.company_id = ? AND i.date >= ? AND i.date <= ? AND LOWER(TRIM(i.customer)) IN (?) AND LOWER(TRIM(ii.product_name)) IN (?) AND LOWER(TRIM(ii.unit)) IN (?) AND ROUND(ii.rate, 2) IN (?)`,
    params: [companyId, "2026-06-28", "2026-06-28", "market test", "ujë rugove 0.5l", "koli", 300],
  };
  tests.push(await assertSqliteSalesAnalyticStrict(exactFilter, expected));
  tests.push(await assertSqliteSalesByProductStrict(exactFilter, expected));
  tests.push(await assertSqliteNoRows("salesAnalytic", { ...exactFilter, products: ["Produkt Qe Nuk Ekziston"] }, "SQLite negative product filter"));
  tests.push(await assertSqliteNoRows("salesAnalytic", { ...exactFilter, units: ["Paletë"] }, "SQLite negative unit filter"));
  tests.push(await assertSqliteNoRows("salesAnalytic", { ...exactFilter, price: "999999" }, "SQLite negative price filter"));
  tests.push(await assertSqliteNoRows("salesByProduct", { ...exactFilter, price: "999999" }, "SQLite salesByProduct negative price filter"));
  tests.push(await assertSqliteReportUnitKoli());
  tests.push(await assertSqliteReportUnitInvalidFallback());
  tests.push(await assertSqliteMultiProductExact(companyId));
  tests.push(await assertSqliteFilterPerformance());
  return tests;
}

export async function runErpSelfTests(_persistDemoForUi?: (db: DB) => Promise<void>): Promise<SelfTestRow[]> {
  try {
    const { db, tests } = buildVerifiedDemoDb();
    await persistIsolatedDemoDbForSqlite(db);
    const sqliteTests = await runSqliteStrictFilterTests();
    return [...tests, ...sqliteTests];
  } catch (e: any) {
    return [fail("Testimi i plotë ERP", e?.message || String(e))];
  }
}
