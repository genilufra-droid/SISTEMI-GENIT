# v14 Reports Rewrite

- Report date bar is always visible.
- Date changes auto-refresh the current report immediately.
- Switching any report clears report-specific filters and stale SQLite snapshots.
- The viewer enters a loading state instead of showing rows/columns from the previous report.
- Non-date filters remain draft-based and use Apliko filtrat.
- Export uses only the current report result.

Version: 1.0.54
