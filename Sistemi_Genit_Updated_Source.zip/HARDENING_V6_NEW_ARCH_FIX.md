# Sistemi Genit v6 - New Architecture Fix

This build fixes the GitHub Actions release APK failure:

```
Execution failed for task ':react-native-worklets:assertNewArchitectureEnabledTask'
[Worklets] Worklets require new architecture to be enabled.
```

Changes:

- `app.config.ts`: `newArchEnabled: true`
- Version bumped to `1.0.21`

Reason:

`react-native-worklets` is required by the current React Native/Reanimated stack and fails release builds when New Architecture is disabled.
