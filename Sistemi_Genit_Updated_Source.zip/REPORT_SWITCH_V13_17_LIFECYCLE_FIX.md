# v13.17 Report Lifecycle Fix

Ky hotfix e trajton ndërrimin e raportit si lifecycle global për të gjitha raportet.

- Pastron rreshta/kolona/kërkim/snapshot kur ndërrohet raporti.
- Ruajtje vetëm e filtrave universalë kur kalohet në grup raporti tjetër.
- Filtrat shumë specifikë nuk fshehin më raportin e ri.
- Çdo raport merr key unik me type + filters + refresh + transitionSeq.
- Version 1.0.52.
