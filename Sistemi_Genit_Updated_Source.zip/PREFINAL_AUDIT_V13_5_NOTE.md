# v13.5 Pre-final audit

Ky version shton kontroll të brendshëm për filtrat kritikë të shitjes:

- product + unit + price filter nga SQLite
- multi-product filter nga SQLite
- salesAnalytic dhe salesByProduct me filtra realë, jo fasadë UI
- pastrim minor i duplicate style në warehouse-doc-form
- version 1.0.40

Në Test ERP / SQLite, kutia SQLite duhet të tregojë edhe:

- salesAnalytic_filtered_product_unit_price
- salesByProduct_filtered_product_unit_price
- salesAnalytic_multi_product_filter (kur ka 2+ artikuj në shitje)
