# Si ta nxjerrësh APK-në e Sistemi Genit v1.0.8

Ky projekt është React Native / Expo. APK nuk del thjesht duke hapur ZIP-in; duhet build me dependencies + Android SDK.

## Opsioni më i lehtë: EAS Build

1. Hape terminalin në folderin e projektit.
2. Instalo varësitë:

```bash
npm install -g pnpm eas-cli
pnpm install
```

3. Hyr në Expo:

```bash
eas login
```

4. Ndërto APK:

```bash
eas build -p android --profile preview-apk
```

Kur build mbaron, Expo jep link për shkarkim APK.

## Opsioni me GitHub Actions

1. Krijo repository private në GitHub.
2. Ngarko këtë projekt.
3. Hape tab-in **Actions**.
4. Zgjidh workflow **Build Android Debug APK**.
5. Shtyp **Run workflow**.
6. Pasi mbaron, te **Artifacts** shkarko `Sistemi_Genit_v1.0.8_debug.apk`.

## Opsioni lokal në Android Studio

```bash
npm install -g pnpm
pnpm install
npx expo prebuild --platform android --clean
cd android
./gradlew assembleDebug
```

APK del këtu:

```text
android/app/build/outputs/apk/debug/app-debug.apk
```

## Shënim i rëndësishëm

Nëse do release APK të firmosur për shpërndarje, duhet keystore. Debug APK është për testim dhe instalohet normalisht me sideload në telefon.
