# v13.7 — Complete filter tests gate

Ky hotfix forcon testet e filtrave që të mos jenë më vetëm "a ktheu rreshta".

## Çfarë u ndryshua

- `runErpSelfTests()` tani është async dhe sinkronizon një demo të izoluar/deterministike në SQLite përpara testeve SQL.
- Testet e filtrave janë pjesë e listës kryesore PASS/FAIL në ekranin `Test ERP / SQLite`, jo vetëm tekst në kutinë SQLite.
- `salesAnalytic` testohet me Produkt + Njësi + Çmim + Datë + Klient.
- `salesByProduct` testohet me të njëjtën rreptësi: verifikim produkti, njësie, çmimi dhe vlere totale.
- U shtuan teste negative për produkt, njësi dhe çmim të gabuar.
- U shtua test i `reportUnit=Koli` që duhet të shfaqë sasi të përzier `Koli + Copë`.
- U shtua test që një njësi raporti e pavlefshme nuk shfaqet si etiketë false.
- U shtua test multi-product që kontrollon që nuk kthehet produkt jashtë filtrit dhe numri i rreshtave përputhet me SQL expected.
- U shtua test performance për filtrat kryesorë.
- `sqliteReportsHealthCheck()` u dokumentua si smoke check; porta finale tani është `runErpSelfTests()`.

## Porta finale

Nuk kalohet në fazë finale nëse këto teste nuk dalin PASS:

- SQLite salesAnalytic strict Produkt+Njësi+Çmim+Datë+Klient
- SQLite salesByProduct strict Produkt+Njësi+Çmim
- SQLite negative product filter
- SQLite negative unit filter
- SQLite negative price filter
- SQLite salesByProduct negative price filter
- SQLite reportUnit Koli shfaq Koli + Copë
- SQLite reportUnit invalid nuk lejohet si etiketë false
- SQLite multi-product filter exact
- SQLite filter performance
