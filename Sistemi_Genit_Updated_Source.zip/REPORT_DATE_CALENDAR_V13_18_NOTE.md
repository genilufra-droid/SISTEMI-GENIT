# v13.18 — Calendar Auto Refresh Reports

- Shtohet kalendar për periudhën te Raportet.
- Datat Nga/Deri nuk janë më TextInput kryesor; hapen në modal kalendar.
- Zgjedhja e datës rifreskon automatikisht raportin dhe SQLite, pa shtypur Apliko filtrat.
- Filtrat e tjerë mbeten ERP draft dhe aplikohen me Apliko filtrat.
- U shtuan preset: Sot, Dje, 7 ditë, Muaji, Viti.
- Version 1.0.53.
