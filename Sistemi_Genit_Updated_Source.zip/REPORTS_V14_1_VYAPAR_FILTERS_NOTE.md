# v14.1 Reports Vyapar Filters

- Raportet përdorin datë/kalendar gjithmonë të dukshëm.
- Data rifreskon raportin automatikisht.
- Filtrat kryesorë janë chips si Vyapar: Artikuj, Klientë, Furnitorë, Magazina, Njësi, Çmim.
- Filtrat aplikohen automatikisht me debounce të shkurtër, pa buton të detyrueshëm Apliko.
- Report switch pastron viewer-in dhe nuk mban rreshta/kolona nga raporti i mëparshëm.
- PDF/Excel/Print përdorin vetëm raportin dhe filtrat aktualë.
- Popup-i i 5 çmimeve dhe scroll-i i formës së artikullit mbeten nga versionet e mëparshme.
