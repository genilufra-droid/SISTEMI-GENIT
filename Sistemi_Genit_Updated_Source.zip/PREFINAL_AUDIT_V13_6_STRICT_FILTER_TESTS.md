# v13.6 — Strict SQLite Sales Filter Tests

Ky version korrigjon pre-final audit-in e dobët të v13.5.

## Çfarë ishte gabim
- Testet e filtrave kontrollonin vetëm `rows.length > 0`.
- Multi-product kontrollonte vetëm numrin minimal të rreshtave.
- Kontrollet nuk futeshin në PASS/FAIL kryesore.
- Çmimi i testit përdorte rounding jo të mjaftueshëm për verifikim negativ.

## Çfarë u rregullua
- `sqliteReportsHealthCheck()` tani kthen `assertions[]` me PASS/FAIL të qarta.
- `app/erp-test.tsx` i shton këto assertions te lista kryesore e testeve.
- Testi exact kontrollon çdo rresht: produkt, njësi, çmim.
- Testi exact kontrollon numrin e rreshtave kundrejt SQL expected.
- Testi exact kontrollon shumën e vlerës kundrejt SQL expected.
- Testi `salesByProduct` kontrollon grupim të vetëm `Artikull + Njësi + Çmim`.
- U shtuan teste negative:
  - produkt i gabuar duhet të kthejë 0 rreshta
  - njësi e gabuar duhet të kthejë 0 rreshta
  - çmim i gabuar duhet të kthejë 0 rreshta
- Multi-product tani kontrollon:
  - asnjë produkt jashtë filtrit
  - asnjë produkt i filtruar nuk mungon
  - numri i rreshtave përputhet me SQL expected
- Demo databaza tani krijon disa artikuj, njësi dhe çmime për testim të filtrave realë.

## Porta finale
Faza finale nuk duhet të nisë nëse `Test ERP / SQLite` ka FAIL në ndonjë kontroll `SQLite ... filter exact`.
