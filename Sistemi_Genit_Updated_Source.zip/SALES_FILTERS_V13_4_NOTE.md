# v13.4 — Filtra reale shitje + Njësi raporti

- Filtrat e artikujve, çmimit dhe njësisë së shitjes zbatohen mbi rreshtat realë të faturës, jo vetëm mbi kokën e faturës.
- U shtua “Njësia e raportit” për shfaqje sasie në Copë/Koli/Paletë.
- U nda “Filtro njësinë e shitjes” nga “Njësia e raportit”.
- Raportet kryesore të shitjes në SQLite shfaqin sasi, dhurata dhe total fizik me njësinë e raportimit.
- U shtuan SQL-native për Fatura Totale Sot dhe Shitje Sot, me filtra realë sipas artikullit, njësisë dhe çmimit.
