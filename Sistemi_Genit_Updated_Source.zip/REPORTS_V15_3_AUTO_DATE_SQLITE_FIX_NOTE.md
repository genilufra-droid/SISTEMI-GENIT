# v15.3 Auto Date + SQLite Fresh Snapshot Fix

- Raportet sinkronizojnë MultiDB -> SQLite para çdo query raporti.
- Rregullon rastin ku header-i i faturës shfaqej në salesSummary, por invoice_items mungonin te salesAnalytic/salesByProduct pas shitjes së sapo ruajtur.
- Data From/To hap kalendar dhe rifreskon raportin automatikisht.
- Pasi zgjidhet data `Deri`, kalendari mbyllet dhe raporti ngarkohet menjëherë.
- Periudha default është muaji aktual.
- Popup 5 çmimet e fundit, scroll i formës Shto Artikull, UI Vyapar dhe klikimi i kartës së raportit mbeten.
