# v15.4 — Shitje Sot / Shitje sipas artikullit table form

Rregullime:

- Shitje Sot nuk shfaqet më si karta Vyapar, por si tabelë pune ditore sipas formatit të dërguar nga përdoruesi.
- Shitje sipas artikullit përdor të njëjtën formë: Item Name, Sasi, Njesi, Cmimi, Vlere.
- Rreshti Total shfaqet në fund me sfond jeshil.
- Dhuratat futen në emërtim si `Artikulli (41shit+4)` kur ka freeQty.
- Export/print marrin kolonat e thjeshta të raportit.
- Filter bottom sheet u ul mbi navigation bar dhe butonat Reset/Apply janë sticky/dukshëm.
- Version: 1.0.64
