# Sistemi Genit v11 — Dokumente Magazine + Kërkesë Furnizimi sipas Daljeve

Ky version vazhdon mbi v10, ku SQLite dhe raportet kryesore kaluan testet bazë.

## Ndryshime kryesore

- Moduli **Dokumente Magazine** u kthye në modul kërkimi pune:
  - kërkim sipas nr. dokumenti, artikullit, palës, adresës, shënimit
  - filtra data nga/deri
  - filtër magazinë/furgon
  - filtër tipi: të gjitha, Fletë Hyrje, Fletë Dalje, Inventar, Transferim

- Për Fletë Hyrje / Fletë Dalje u shtuan eksportet masive:
  - **PDF të gjitha** dokumentet e filtrit, njëra pas tjetrës në A4
  - **Printo të gjitha** dokumentet e filtrit
  - **Excel të gjitha** me dy sheet-e: `Dokumente` dhe `Rreshtat`

- Raporti **Kërkesë Furnizimi** u ndryshua sipas logjikës së biznesit:
  - nuk bazohet vetëm te stoku minimal
  - bazohet te daljet/shitjet fizike të periudhës
  - është kundërparti e raportit **Shitje Sot / Fletë Dalje**
  - nuk përmban çmime ose vlera; vetëm artikull, magazinë/furgon, sasi dhe njësi

## Rregulli i kërkesës së furnizimit

Çfarë doli nga magazina/furgoni në periudhën e zgjedhur = çfarë duhet furnizuar.

Shembull:

- Doli Ujë 0.5L: 171 koli
- Doli Elbar 0.5L: 20 koli

Kërkesa e furnizimit nxjerr:

- Ujë 0.5L — 171 koli
- Elbar 0.5L — 20 koli

Pa çmim, pa vlerë.
