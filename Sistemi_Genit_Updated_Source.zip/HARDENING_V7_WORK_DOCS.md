# HARDENING V7 — Fletë Hyrje / Fletë Dalje Working Layout

Ky version fokusohet te Dokumente Magazine, sepse APK u hap në telefon por Fletë Dalje/Hyrje nuk kishte tabelën poshtë si formulari fizik.

## Ndryshime kryesore

- Fletë Dalje dhe Fletë Hyrje tani kanë pamje më afër formularit fizik:
  - Titull i madh FLETË DALJE / FLETË HYRJE
  - Nr. dokumenti preview
  - Data
  - Adresa ku shkon malli
  - Marrësi/Furnitori
  - Personi i autorizuar
  - Mjeti i transportit
- U shtua tabela fikse e artikujve edhe kur nuk ka artikuj:
  - Nr
  - Emërtimi i mallit
  - Njësia
  - Sasia
  - Çmimi
  - Vlefta
  - Fshi
- Rreshtat bosh shfaqen vetëm për pamje si formulari; ruhen vetëm artikujt realë.
- Njësia ndryshohet duke shtypur qelizën e njësisë.
- Sasia dhe çmimi janë të editueshme direkt në tabelë.
- Fletë Dalje sinjalizon rreshtin me sfond të kuq të lehtë kur stoku nuk mjafton.
- Ruajtja vazhdon të përdorë stock engine-in ekzistues: Fletë Dalje zbret stok, Fletë Hyrje shton stok.
- Print template për dokumente magazine tani merr edhe:
  - authorizedPerson
  - vehicle
  - serialNo
  - reason si shënim

## Version

App version: 1.0.22
