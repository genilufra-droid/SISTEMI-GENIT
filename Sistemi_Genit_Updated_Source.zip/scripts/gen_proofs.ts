// Visual proof generator for v1.0.18 — RN-free modules only.
import { writeFileSync } from "fs";
import {
  warehouseDocToPrintable,
  buildDocHtml,
} from "../lib/print-templates";
import { buildReport, renderReportHtml } from "../lib/reports";
import type { Company, OutboundDoc } from "../lib/store";
import type { DB } from "../lib/store";

const company: Company = {
  name: "RUGOVE LUSHNJE",
  address: "Rruga Kongresi i Lushnjes",
  city: "Lushnjë",
  nipt: "L12345678A",
  currency: "ALL",
  phone: "0691234567",
};

// ---- Fletë Dalje with a gift line (PART 1 + PART 4) ----
const outbound: OutboundDoc = {
  id: 1,
  no: "FD-2026-0001",
  date: "2026-06-28",
  warehouse: "Magazina kryesore",
  status: "saved",
  createdAt: "2026-06-28T10:00:00Z",
  sourceType: "SALE_INVOICE",
  customerName: "Klient Test SHPK",
  destinationAddress: "Rruga e Durrësit, Tiranë",
  lines: [
    { productName: "UJË 0.5L", unit: "Koli", qty: 10, coef: 12, baseQty: 120, price: 300, costPiece: 18, value: 3000 },
    { productName: "UJË 0.5L", unit: "Koli", qty: 1, coef: 12, baseQty: 12, price: 0, value: 0, isGift: true } as any,
    { productName: "BUKË", unit: "Copë", qty: 20, coef: 1, baseQty: 20, price: 80, costPiece: 50, value: 1600 },
  ],
};
const fdDoc = warehouseDocToPrintable(outbound, "outbound", company);
writeFileSync("/home/ubuntu/proof_flete_dalje.html", buildDocHtml(fdDoc, company, "A4", ""));

// ---- Fletë Hyrje (PART 2 — 5 signatures incl. Dorëzuesi) ----
const inbound = {
  id: 2,
  no: "FH-2026-0001",
  date: "2026-06-28",
  warehouse: "Magazina kryesore",
  status: "saved",
  createdAt: "2026-06-28T10:00:00Z",
  sourceType: "PURCHASE_INVOICE",
  supplierName: "Furnitor Test SHPK",
  lines: [
    { productName: "UJË 0.5L", unit: "Koli", qty: 50, coef: 12, baseQty: 600, price: 200, value: 10000 },
    { productName: "BUKË", unit: "Copë", qty: 100, coef: 1, baseQty: 100, price: 50, value: 5000 },
  ],
} as any;
const fhDoc = warehouseDocToPrintable(inbound, "inbound", company);
writeFileSync("/home/ubuntu/proof_flete_hyrje.html", buildDocHtml(fhDoc, company, "A4", ""));

// ---- Reports DB (PART 5 + PART 6) ----
const today = new Date().toISOString().slice(0, 10);
const db: DB = {
  company: { name: "RUGOVE LUSHNJE", currency: "LEK" },
  stores: ["Magazina kryesore"],
  products: [
    { id: 1, name: "UJË 0.5L", salePiece: 25, buyPiece: 18, stock: 120, minStock: 20, units: [{ name: "Copë", coef: 1 }, { name: "Koli", coef: 12 }] },
    { id: 2, name: "BUKË", salePiece: 80, buyPiece: 50, stock: 5, minStock: 10, units: [{ name: "Copë", coef: 1 }] },
    { id: 3, name: "VAJ 1L", salePiece: 250, buyPiece: 200, stock: 3, minStock: 12, units: [{ name: "Copë", coef: 1 }, { name: "Paketë", coef: 6 }] },
  ],
  customers: [{ id: 1, name: "ACME", openingBalance: 0 }, { id: 2, name: "Beta", openingBalance: 0 }],
  suppliers: [{ id: 1, name: "S1" }],
  invoices: [
    {
      no: 10, date: today, time: "08:00", customer: "ACME", mode: "Me arke",
      items: [{ productName: "UJË 0.5L", qty: 98, freeQty: 9, unit: "Copë", rate: 300, buyRate: 216, total: 29400, cost: 21168 }],
      subtotal: 29400, roundOff: 0, total: 29400, paid: 29400, due: 0, paymentType: "Cash", totalCost: 21168, profit: 8232,
    },
    {
      no: 11, date: today, time: "09:00", customer: "Beta", mode: "Me arke",
      items: [{ productName: "UJË 0.5L", qty: 20, freeQty: 0, unit: "Copë", rate: 280, buyRate: 216, total: 5600, cost: 4320 }],
      subtotal: 5600, roundOff: 0, total: 5600, paid: 5600, due: 0, paymentType: "Cash", totalCost: 4320, profit: 1280,
    },
    {
      no: 12, date: today, time: "10:00", customer: "ACME", mode: "Me arke",
      items: [{ productName: "BUKË", qty: 30, freeQty: 0, unit: "Copë", rate: 80, buyRate: 50, total: 2400, cost: 1500 }],
      subtotal: 2400, roundOff: 0, total: 2400, paid: 2400, due: 0, paymentType: "Cash", totalCost: 1500, profit: 900,
    },
  ],
  purchases: [],
  payments: [],
  priceHistory: [],
  stockAdjustments: [],
  expenses: [],
  expenseCategories: [],
  storeTransfers: [],
  settings: { favoriteReports: [] },
  nextInvoice: 13,
  nextPurchase: 1,
} as any;

const sot = buildReport("shitjeSot", db, {});
writeFileSync("/home/ubuntu/proof_shitje_sot.html", renderReportHtml(sot, { companyName: "RUGOVE LUSHNJE", currency: "LEK" }));

const kerkese = buildReport("kerkeseFurnizimi", db, {});
writeFileSync("/home/ubuntu/proof_kerkese_furnizimi.html", renderReportHtml(kerkese, { companyName: "RUGOVE LUSHNJE", currency: "LEK" }));

console.log("Shitje Sot rows:", JSON.stringify(sot.rows, null, 0));
console.log("Kërkesë Furnizimi rows:", JSON.stringify(kerkese.rows, null, 0));
console.log("DONE: wrote 4 HTML proofs to /home/ubuntu/");
