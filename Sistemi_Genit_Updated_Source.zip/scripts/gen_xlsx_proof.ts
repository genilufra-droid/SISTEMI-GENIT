import { writeFileSync } from "fs";
import * as XLSXStyle from "xlsx-js-style";
import { warehouseDocToPrintable } from "../lib/print-templates";
import { buildWarehouseDocWorkbook } from "../lib/warehouse-excel";
import type { Company, OutboundDoc } from "../lib/store";

const company: Company = {
  name: "RUGOVE LUSHNJE", address: "Rruga Kongresi i Lushnjes", city: "Lushnjë",
  nipt: "L12345678A", currency: "ALL", phone: "0691234567",
};
const outbound: OutboundDoc = {
  id: 1, no: "FD-2026-0001", date: "2026-06-28", warehouse: "Magazina kryesore",
  status: "saved", createdAt: "2026-06-28T10:00:00Z", sourceType: "SALE_INVOICE",
  customerName: "Klient Test SHPK", destinationAddress: "Rruga e Durrësit, Tiranë",
  lines: [
    { productName: "UJË 0.5L", unit: "Koli", qty: 10, coef: 12, baseQty: 120, price: 300, costPiece: 18, value: 3000 },
    { productName: "UJË 0.5L", unit: "Koli", qty: 1, coef: 12, baseQty: 12, price: 0, value: 0, isGift: true } as any,
    { productName: "BUKË", unit: "Copë", qty: 20, coef: 1, baseQty: 20, price: 80, costPiece: 50, value: 1600 },
  ],
};
const doc = warehouseDocToPrintable(outbound, "outbound", company);
const wb = buildWarehouseDocWorkbook(doc, company);
const buf = XLSXStyle.write(wb, { type: "buffer", bookType: "xlsx" });
writeFileSync("/home/ubuntu/proof_flete_dalje.xlsx", buf);
console.log("Wrote /home/ubuntu/proof_flete_dalje.xlsx", buf.length, "bytes; magic:", buf.slice(0, 2).toString());
