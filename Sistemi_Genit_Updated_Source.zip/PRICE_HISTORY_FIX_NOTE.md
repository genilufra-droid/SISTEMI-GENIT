# Price history fix

This ZIP includes the missing write path for per-client last-5 price history.

Before: UI and helpers existed, but `recordClientPrice()` was never called when saving a sale invoice, so `clientPriceHistory` stayed empty.

Now: `commitSaleInvoice()` records each saved line into `clientPriceHistory`, keeping the last 5 prices per client + product.
