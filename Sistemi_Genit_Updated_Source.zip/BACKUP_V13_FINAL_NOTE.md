# Sistemi Genit v13 — Backup / Restore final

Ky version forcon fazën e backup/restore mbi v12.

## Përfshin

- Backup JSON për kompaninë aktive.
- Backup JSON për të gjitha kompanitë.
- Checksum për backup për të dalluar skedarë të ndryshuar/dëmtuar.
- Numër total regjistrimesh në envelope-in e backup-it.
- Kontroll SQLite para backup-it.
- Buton “Kontrollo SQLite + Backup të gjitha”.
- Shfaqje paralajmërimi në restore nëse checksum nuk përputhet.
- Backup sigurie automatik para reset/demo reset.

## Qëllimi

Të mos ketë më fshirje/rikthim të verbër. Çdo restore destruktiv krijon më parë një backup sigurie.
