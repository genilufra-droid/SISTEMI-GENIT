# v13.14 — Raporte ERP / Filtra profesionale + performance

Ky version trajton problemin që raportet SQLite vononin dhe filtrat ishin të rrëmujshëm.

## Ndryshime funksionale

- Filtrat tani janë **draft** deri sa përdoruesi shtyp `Apliko filtrat`.
- SQLite nuk rindërtohet më për çdo germë që shkruhet te data/çmimi/kërkimi.
- Kombinimet e filtrave zbatohen njëherësh si ERP: datë + klient + artikull + njësi + çmim + status + magazinë.
- U shtua panel kompakt `Filtra ERP të kombinuara` që hap/mbyll filtrat dhe ul rrëmujën në ekran.
- U shtua `Rifresko SQL` kur filtrat janë aktivë dhe përdoruesi do refresh manual kontrolli.
- Kur filtrat ndryshojnë, ekrani tregon qartë `Pa aplikuar` dhe kërkon `Apliko filtrat`.
- Print/PDF/Excel përdorin vetëm filtrat e aplikuar, që rezultatet të jenë identike me tabelën.

## Ndryshime performance SQLite

U shtuan indekse për raportet më të rënda:

- invoices(company_id, customer, date)
- invoices(company_id, store, date)
- invoice_items(company_id, product_name, unit, rate)
- invoice_items(company_id, invoice_no)
- purchase_items(company_id, product_name, unit, rate)
- stock_movements(company_id, date, warehouse)
- warehouse_docs(company_id, doc_kind, date, warehouse)
- products(company_id, category)

Këto indekse synojnë raportet me filtra të kombinuar si Artikull + Njësi + Çmim + Datë + Klient.

## Testim i rekomanduar

1. Hap Raporte.
2. Hap `Filtra ERP të kombinuara`.
3. Zgjidh 2-3 artikuj, një klient, njësi shitjeje dhe çmim.
4. Kontrollo që tabela nuk rifreskohet derisa të shtypësh `Apliko filtrat`.
5. Shtyp `Apliko filtrat` dhe kontrollo që tabela/PDF/Excel kanë të njëjtat rreshta.
