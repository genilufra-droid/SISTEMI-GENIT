# v15.6 — Video Report Loading Fix

Fix based on XRecorder_20260701_04 video.

Issues observed:
- Regjistri Përmbledhës i Shitjeve shows data.
- Several reports remained stuck/empty: Regjistri Analitik i Shitjeve, Faturë përmbledhëse shitje, Shitje sipas artikullit, Shitje ditore, Fatura shitje të renditura, Fatura Totale Sot, Shitje Sot, Kërkesë Furnizimi, Kartela e Artikullit.
- Root cause: reports screen was forcing full MultiDB → SQLite shadow sync before every report query/switch. This made report transitions slow and caused repeated loading states.

Fix:
- Warm up SQLite mirror once when Reports opens.
- Report switching now queries SQLite directly with strict key ownership.
- Removed full saveMultiDB(getMultiDB()) from every report query.
- Kept Vyapar UI, filter sheet, card navigation, physical tables, popup price history and item scroll.

Version: 1.0.66
