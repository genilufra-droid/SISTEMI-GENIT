import { REPORT_CATALOG, type ReportFilter, type ReportResult, type ReportType, type Column, type Row } from "./reports";
import { fmt, saveMultiDB, getMultiDB } from "./store";
import { sqliteActiveCompanyId, sqliteAll, sqliteFirst } from "./sqlite-storage";

type SqlReport = ReportResult & { source?: "sqlite" };
type SqlParts = { where: string[]; params: any[] };

function normKey(s: string | undefined): string {
  return String(s || "").trim().toLowerCase().replace(/\s+/g, " ");
}

function periodLabel(f: ReportFilter): string {
  if (f.from && f.to) return `${f.from} → ${f.to}`;
  if (f.from) return `Nga ${f.from}`;
  if (f.to) return `Deri ${f.to}`;
  return "Të gjitha datat";
}

function addDate(parts: SqlParts, col: string, f: ReportFilter) {
  if (f.from) { parts.where.push(`${col} >= ?`); parts.params.push(f.from); }
  if (f.to) { parts.where.push(`${col} <= ?`); parts.params.push(f.to); }
}

function addText(parts: SqlParts, col: string, list?: string[], single?: string) {
  if (list && list.length) {
    const cleaned = list.map(normKey).filter(Boolean);
    if (cleaned.length) {
      parts.where.push(`LOWER(TRIM(${col})) IN (${cleaned.map(() => "?").join(",")})`);
      parts.params.push(...cleaned);
    }
  } else if (single && single.trim()) {
    parts.where.push(`LOWER(${col}) LIKE ?`);
    parts.params.push(`%${normKey(single)}%`);
  }
}

function addTxn(parts: SqlParts, col: string, f: ReportFilter) {
  if (!f.txnType || f.txnType === "all") return;
  if (f.txnType === "cash") parts.where.push(`${col} = 'Me arke'`);
  else parts.where.push(`${col} <> 'Me arke'`);
}

function addPayStatus(parts: SqlParts, totalCol: string, paidCol: string, f: ReportFilter) {
  if (!f.payStatus || f.payStatus === "all") return;
  if (f.payStatus === "paid") parts.where.push(`${paidCol} >= ${totalCol} - 0.001`);
  else if (f.payStatus === "unpaid") parts.where.push(`${paidCol} <= 0.001`);
  else parts.where.push(`${paidCol} > 0.001 AND ${paidCol} < ${totalCol} - 0.001`);
}

function addPriceFilter(parts: SqlParts, rateCol: string, f: ReportFilter) {
  if (!f.price || !f.price.trim()) return;
  const prices = f.price.split(/[;,]/).map(x => Number(x.trim().replace(",", "."))).filter(n => !isNaN(n));
  if (!prices.length) return;
  parts.where.push(`ROUND(${rateCol}, 2) IN (${prices.map(() => "?").join(",")})`);
  parts.params.push(...prices.map(p => Math.round(p * 100) / 100));
}

function docInvoiceWhere(companyId: string, f: ReportFilter): SqlParts {
  const p: SqlParts = { where: ["i.company_id = ?"], params: [companyId] };
  addDate(p, "i.date", f);
  addText(p, "i.customer", f.clients, f.client);
  addText(p, "i.store", f.stores, f.store);
  addText(p, "i.salesman", f.salesmen, f.salesman);
  addTxn(p, "i.mode", f);
  addPayStatus(p, "i.total", "i.paid", f);
  return p;
}

function docPurchaseWhere(companyId: string, f: ReportFilter): SqlParts {
  const p: SqlParts = { where: ["p.company_id = ?"], params: [companyId] };
  addDate(p, "p.date", f);
  addText(p, "p.supplier", f.suppliers, f.supplier);
  addText(p, "p.store", f.stores, f.store);
  addText(p, "p.salesman", f.salesmen, f.salesman);
  addTxn(p, "p.mode", f);
  addPayStatus(p, "p.total", "p.paid", f);
  return p;
}

function addLineFilters(parts: SqlParts, productCol: string, unitCol: string, categoryCol: string, f: ReportFilter, rateCol?: string) {
  addText(parts, productCol, f.products, f.product);
  addText(parts, unitCol, f.units, f.unit);
  addText(parts, categoryCol, f.categories, f.category);
  if (rateCol) addPriceFilter(parts, rateCol, f);
}

function withSource(result: ReportResult): SqlReport {
  return { ...result, source: "sqlite" };
}

const money = (n: number) => fmt(Number(n || 0));

export async function buildSqliteReport(type: ReportType, f: ReportFilter): Promise<SqlReport | null> {
  const companyId = await sqliteActiveCompanyId();
  if (!companyId) return null;

  try { await saveMultiDB(getMultiDB()); } catch (_) {}
  const sub = periodLabel(f);

  // 1. Transaction Summary Reports (Card-based)
  if (type === "salesSummary" || type === "faturaTeresot" || type === "unpaidInvoices" || type === "salesDaily" || type === "salesInvoiceBatch") {
    const p = docInvoiceWhere(companyId, f);
    if (type === "unpaidInvoices") p.where.push("i.paid < i.total - 0.001");
    
    const rows = await sqliteAll<Row>(
      `SELECT i.invoice_no AS no, i.date, i.customer AS party, i.total, i.paid, i.due, i.mode, i.profit 
       FROM invoices i 
       WHERE ${p.where.join(" AND ")} 
       ORDER BY i.date DESC, i.invoice_no DESC`,
      p.params
    );

    return withSource({
      type,
      title: REPORT_CATALOG.find(r => r.value === type)?.label || "Raport Shitje",
      subtitle: sub,
      columns: [
        { key: "party", label: "Klienti" },
        { key: "no", label: "Nr. Faturës" },
        { key: "date", label: "Data" },
        { key: "total", label: "Vlera", align: "right", format: "money" },
        { key: "due", label: "Detyrim", align: "right", format: "money" }
      ],
      rows,
      summary: [
        { label: "Fatura", value: String(rows.length) },
        { label: "Vlera Totale", value: money(rows.reduce((s, r) => s + Number(r.total || 0), 0)) },
        { label: "Detyrim Total", value: money(rows.reduce((s, r) => s + Number(r.due || 0), 0)) }
      ]
    });
  }

  // 2. Purchase Reports
  if (type === "purchaseAnalytic" || type === "purchaseDaily" || type === "purchaseInvoiceBatch" || type === "purchaseBySupplier" || type === "purchaseByProduct") {
    const p = docPurchaseWhere(companyId, f);
    
    if (type === "purchaseBySupplier") {
      const rows = await sqliteAll<Row>(
        `SELECT p.supplier AS party, COUNT(p.invoice_no) as no, SUM(p.total) as total, SUM(p.due) as due
         FROM purchases p 
         WHERE ${p.where.join(" AND ")} 
         GROUP BY p.supplier
         ORDER BY total DESC`,
        p.params
      );
      return withSource({
        type,
        title: "Blerje sipas furnitorit",
        subtitle: sub,
        columns: [
          { key: "party", label: "Furnitori" },
          { key: "no", label: "Fatura", align: "right" },
          { key: "total", label: "Vlera", align: "right", format: "money" },
          { key: "due", label: "Detyrim", align: "right", format: "money" }
        ],
        rows,
        summary: [
          { label: "Furnitorë", value: String(rows.length) },
          { label: "Vlera Totale", value: money(rows.reduce((s, r) => s + Number(r.total || 0), 0)) }
        ]
      });
    }

    if (type === "purchaseByProduct") {
      addLineFilters(p, "pi.product_name", "pi.unit", "COALESCE(pr.category,'')", f, "pi.rate");
      const rows = await sqliteAll<Row>(
        `SELECT pi.product_name AS product, SUM(pi.qty) AS qty, pi.unit, pi.rate, SUM(pi.total) AS value
         FROM purchase_items pi
         JOIN purchases p ON p.company_id = pi.company_id AND p.invoice_no = pi.invoice_no
         LEFT JOIN products pr ON pr.company_id = pi.company_id AND LOWER(TRIM(pr.name)) = LOWER(TRIM(pi.product_name))
         WHERE ${p.where.join(" AND ")}
         GROUP BY pi.product_name, pi.unit, pi.rate
         ORDER BY pi.product_name ASC`,
        p.params
      );
      return withSource({
        type,
        title: "Blerje sipas artikullit",
        subtitle: sub,
        columns: [
          { key: "product", label: "Artikulli" },
          { key: "qty", label: "Sasi", align: "right", format: "qty" },
          { key: "unit", label: "Njësia" },
          { key: "rate", label: "Çmimi", align: "right", format: "money" },
          { key: "value", label: "Vlerë", align: "right", format: "money" }
        ],
        rows,
        summary: [
          { label: "Artikuj", value: String(rows.length) },
          { label: "Vlera Totale", value: money(rows.reduce((s, r) => s + Number(r.value || 0), 0)) }
        ]
      });
    }

    const rows = await sqliteAll<Row>(
      `SELECT p.invoice_no AS no, p.date, p.supplier AS party, p.total, p.paid, p.due, p.mode
       FROM purchases p 
       WHERE ${p.where.join(" AND ")} 
       ORDER BY p.date DESC, p.invoice_no DESC`,
      p.params
    );

    return withSource({
      type,
      title: REPORT_CATALOG.find(r => r.value === type)?.label || "Raport Blerje",
      subtitle: sub,
      columns: [
        { key: "party", label: "Furnitori" },
        { key: "no", label: "Nr. Faturës" },
        { key: "date", label: "Data" },
        { key: "total", label: "Vlera", align: "right", format: "money" },
        { key: "due", label: "Detyrim", align: "right", format: "money" }
      ],
      rows,
      summary: [
        { label: "Blerje", value: String(rows.length) },
        { label: "Vlera Totale", value: money(rows.reduce((s, r) => s + Number(r.total || 0), 0)) },
        { label: "Detyrim Total", value: money(rows.reduce((s, r) => s + Number(r.due || 0), 0)) }
      ]
    });
  }

  // 3. Item Analytical Reports (Table-based)
  if (type === "shitjeSot" || type === "salesByProduct" || type === "salesAnalytic" || type === "salesByUnit" || type === "salesByClient" || type === "salesSummaryInvoice") {
    const p = docInvoiceWhere(companyId, f);
    
    if (type === "salesByClient") {
      const rows = await sqliteAll<Row>(
        `SELECT i.customer AS party, COUNT(i.invoice_no) as no, SUM(i.total) as total, SUM(i.due) as due
         FROM invoices i 
         WHERE ${p.where.join(" AND ")} 
         GROUP BY i.customer
         ORDER BY total DESC`,
        p.params
      );
      return withSource({
        type,
        title: "Shitje sipas klientit",
        subtitle: sub,
        columns: [
          { key: "party", label: "Klienti" },
          { key: "no", label: "Fatura", align: "right" },
          { key: "total", label: "Vlera", align: "right", format: "money" },
          { key: "due", label: "Detyrim", align: "right", format: "money" }
        ],
        rows
      });
    }

    if (type === "salesSummaryInvoice") {
      const rows = await sqliteAll<Row>(
        `SELECT i.invoice_no AS no, i.date, i.customer AS party, i.total, i.paid, i.due
         FROM invoices i 
         WHERE ${p.where.join(" AND ")} 
         ORDER BY i.date DESC`,
        p.params
      );
      return withSource({
        type,
        title: "Faturë përmbledhëse shitje",
        subtitle: sub,
        columns: [
          { key: "party", label: "Klienti" },
          { key: "no", label: "Fatura" },
          { key: "date", label: "Data" },
          { key: "total", label: "Vlera", align: "right", format: "money" }
        ],
        rows
      });
    }

    addLineFilters(p, "ii.product_name", "ii.unit", "COALESCE(pr.category,'')", f, "ii.rate");
    
    const lines = await sqliteAll<any>(
      `SELECT ii.product_name AS product, SUM(ii.qty) AS qty, SUM(ii.free_qty) AS free, ii.unit, ii.rate, SUM(ii.total) AS value
       FROM invoice_items ii
       JOIN invoices i ON i.company_id = ii.company_id AND i.invoice_no = ii.invoice_no
       LEFT JOIN products pr ON pr.company_id = ii.company_id AND LOWER(TRIM(pr.name)) = LOWER(TRIM(ii.product_name))
       WHERE ${p.where.join(" AND ")}
       GROUP BY ii.product_name, ii.unit, ii.rate
       ORDER BY ii.product_name ASC`,
      p.params
    );

    const totalValue = lines.reduce((s, l) => s + Number(l.value || 0), 0);
    const qtyTxt = (n: number) => Number(n || 0).toLocaleString("sq-AL", { maximumFractionDigits: 3 });
    
    const rows: Row[] = lines.map((l) => ({
      product: l.free > 0 ? `${l.product} (${qtyTxt(l.qty)} shitur +${qtyTxt(l.free)})` : l.product,
      qty: l.qty,
      unit: l.unit,
      rate: l.rate,
      value: l.value,
    }));

    rows.push({ product: "Total", qty: "", unit: "", rate: "", value: totalValue, _total: 1, _green: true });

    if (type === "shitjeSot") {
      const totalDue = await sqliteFirst<{val: number}>(`SELECT SUM(due) as val FROM invoices i WHERE ${p.where.join(" AND ")}`, p.params);
      const totalPaid = await sqliteFirst<{val: number}>(`SELECT SUM(paid) as val FROM invoices i WHERE ${p.where.join(" AND ")}`, p.params);
      rows.push({ product: "BORXHI PIT STOPIT", qty: "", unit: "", rate: "", value: totalDue?.val || 0, _yellow: true });
      rows.push({ product: "Arketuar", qty: "", unit: "", rate: "", value: totalPaid?.val || 0, _green: true });
    }

    return withSource({
      type,
      title: REPORT_CATALOG.find(r => r.value === type)?.label || "Shitje sipas artikullit",
      subtitle: sub,
      columns: [
        { key: "product", label: "Item Name" },
        { key: "qty", label: "Sasi", align: "right", format: "qty" },
        { key: "unit", label: "Njesi" },
        { key: "rate", label: "Cmimi", align: "right", format: "money" },
        { key: "value", label: "Vlere", align: "right", format: "money" }
      ],
      rows
    });
  }

  // 4. Stock & Warehouse Reports
  if (type === "stockSummary" || type === "stockByCompany" || type === "stockByWarehouse" || type === "stockMovement" || type === "transferReport" || type === "inboundDocsReport" || type === "outboundDocsReport" || type === "inventoryDocsReport" || type === "warehouseStockAsOf") {
    const p: SqlParts = { where: ["company_id = ?"], params: [companyId] };
    
    if (type === "stockMovement" || type === "transferReport" || type === "inboundDocsReport" || type === "outboundDocsReport" || type === "inventoryDocsReport") {
      addDate(p, "date", f);
      addText(p, "product_name", f.products, f.product);
      addText(p, "warehouse", f.stores, f.store);
      
      if (type === "transferReport") p.where.push("doc_type = 'transfer'");
      else if (type === "inboundDocsReport") p.where.push("doc_type = 'inbound'");
      else if (type === "outboundDocsReport") p.where.push("doc_type = 'outbound'");
      else if (type === "inventoryDocsReport") p.where.push("doc_type = 'inventory'");

      const rows = await sqliteAll<Row>(
        `SELECT date, doc_type AS kind, warehouse AS party, product_name AS product, 
                in_base AS qty_in, out_base AS qty_out, unit, rate, (in_base - out_base) * rate AS value
         FROM stock_movements
         WHERE ${p.where.join(" AND ")}
         ORDER BY date DESC`,
        p.params
      );

      return withSource({
        type,
        title: REPORT_CATALOG.find(r => r.value === type)?.label || "Lëvizjet e Stokut",
        subtitle: sub,
        columns: [
          { key: "date", label: "Data" },
          { key: "kind", label: "Lloji" },
          { key: "product", label: "Artikulli" },
          { key: "qty_in", label: "Hyrje", align: "right" },
          { key: "qty_out", label: "Dalje", align: "right" },
          { key: "unit", label: "Njësia" },
          { key: "value", label: "Vlera", align: "right", format: "money" }
        ],
        rows
      });
    }

    if (type === "warehouseStockAsOf") {
      // For stock as of date, we sum all movements up to that date
      const asOf = f.to || isoDate(new Date());
      const rows = await sqliteAll<Row>(
        `SELECT product_name AS product, unit, SUM(in_base - out_base) AS stock, rate, SUM((in_base - out_base) * rate) AS value
         FROM stock_movements
         WHERE company_id = ? AND date <= ?
         GROUP BY product_name, unit, rate
         HAVING ABS(stock) > 0.001
         ORDER BY product_name ASC`,
        [companyId, asOf]
      );
      return withSource({
        type,
        title: `Gjendje magazine datë ${asOf}`,
        subtitle: sub,
        columns: [
          { key: "product", label: "Artikulli" },
          { key: "stock", label: "Gjendja", align: "right", format: "qty" },
          { key: "unit", label: "Njësia" },
          { key: "rate", label: "Kosto", align: "right", format: "money" },
          { key: "value", label: "Vlera", align: "right", format: "money" }
        ],
        rows
      });
    }

    addText(p, "name", f.products, f.product);
    addText(p, "category", f.categories, f.category);

    const rows = await sqliteAll<Row>(
      `SELECT name AS product, stock, unit, buy_piece AS rate, (stock * buy_piece) AS value
       FROM products
       WHERE ${p.where.join(" AND ")}
       ORDER BY name ASC`,
      p.params
    );

    return withSource({
      type,
      title: REPORT_CATALOG.find(r => r.value === type)?.label || "Gjendja e Stokut",
      subtitle: sub,
      columns: [
        { key: "product", label: "Artikulli" },
        { key: "stock", label: "Gjendja", align: "right", format: "qty" },
        { key: "unit", label: "Njësia" },
        { key: "rate", label: "Kosto", align: "right", format: "money" },
        { key: "value", label: "Vlera", align: "right", format: "money" }
      ],
      rows,
      summary: [
        { label: "Artikuj", value: String(rows.length) },
        { label: "Vlera Totale", value: money(rows.reduce((s, r) => s + Number(r.value || 0), 0)) }
      ]
    });
  }

  // 5. Client/Supplier Balances
  if (type === "clientBalances" || type === "supplierBalances") {
    const isClient = type === "clientBalances";
    const p: SqlParts = { where: ["pa.company_id = ?", "pa.kind = ?"], params: [companyId, isClient ? "customer" : "supplier"] };
    addText(p, "pa.name", isClient ? f.clients : f.suppliers, isClient ? f.client : f.supplier);

    const rows = await sqliteAll<Row>(
      `SELECT pa.name AS party, pa.balance AS due
       FROM parties pa
       WHERE ${p.where.join(" AND ")} AND ABS(pa.balance) > 0.001
       ORDER BY ABS(pa.balance) DESC`,
      p.params
    );

    return withSource({
      type,
      title: isClient ? "Detyrime Klientësh" : "Detyrime ndaj Furnitorëve",
      subtitle: sub,
      columns: [
        { key: "party", label: isClient ? "Klienti" : "Furnitori" },
        { key: "due", label: "Detyrimi", align: "right", format: "money" }
      ],
      rows,
      summary: [
        { label: "Subjekte", value: String(rows.length) },
        { label: "Detyrim Total", value: money(rows.reduce((s, r) => s + Number(r.due || 0), 0)) }
      ]
    });
  }

  // 6. Kërkesë Furnizimi (Supply Need)
  if (type === "kerkeseFurnizimi" || type === "supplyNeed" || type === "purchaseSuggestion") {
    const p = docInvoiceWhere(companyId, f);
    const rows = await sqliteAll<Row>(
      `SELECT ii.product_name AS product, ii.unit, SUM(ii.qty + ii.free_qty) AS qty
       FROM invoice_items ii
       JOIN invoices i ON i.company_id = ii.company_id AND i.invoice_no = ii.invoice_no
       WHERE ${p.where.join(" AND ")}
       GROUP BY ii.product_name, ii.unit
       ORDER BY ii.product_name ASC`,
      p.params
    );

    return withSource({
      type,
      title: "Kërkesë Furnizimi",
      subtitle: sub,
      columns: [
        { key: "product", label: "Artikulli" },
        { key: "qty", label: "Sasia për furnizim", align: "right", format: "qty" },
        { key: "unit", label: "Njësia" }
      ],
      rows,
      emptyMessage: "Nuk ka nevojë për furnizim sipas shitjeve të kësaj periudhe."
    });
  }

  // 7. Ledger Reports (Item/Client/Supplier)
  if (type === "itemCard") {
    const p: SqlParts = { where: ["company_id = ?"], params: [companyId] };
    addText(p, "product_name", f.products, f.product);
    addDate(p, "date", f);

    const rows = await sqliteAll<Row>(
      `SELECT date, doc_type AS kind, 'Lëvizje stoku' AS product, 
              (CASE WHEN in_base > 0 THEN in_base ELSE -out_base END) AS qty, 
              unit, (CASE WHEN in_base > 0 THEN in_base * rate ELSE out_base * rate END) AS value
       FROM stock_movements
       WHERE ${p.where.join(" AND ")}
       ORDER BY date DESC`,
      p.params
    );

    return withSource({
      type,
      title: "Kartela e Artikullit",
      subtitle: sub,
      columns: [
        { key: "date", label: "Data" },
        { key: "kind", label: "Lloji" },
        { key: "qty", label: "Sasia", align: "right", format: "qty" },
        { key: "unit", label: "Njësia" },
        { key: "value", label: "Vlera", align: "right", format: "money" }
      ],
      rows,
      emptyMessage: "Nuk ka lëvizje për këtë artikull në periudhën e zgjedhur."
    });
  }

  if (type === "clientLedger" || type === "supplierLedger") {
    const isClient = type === "clientLedger";
    const table = isClient ? "invoices" : "purchases";
    const partyCol = isClient ? "customer" : "supplier";
    const p: SqlParts = { where: ["company_id = ?"], params: [companyId] };
    addText(p, partyCol, isClient ? f.clients : f.suppliers, isClient ? f.client : f.supplier);
    addDate(p, "date", f);

    const rows = await sqliteAll<Row>(
      `SELECT date, 'Faturë' AS kind, invoice_no AS product, total AS value, due AS qty
       FROM ${table}
       WHERE ${p.where.join(" AND ")}
       ORDER BY date DESC`,
      p.params
    );

    return withSource({
      type,
      title: isClient ? "Kartela e Klientit" : "Kartela e Furnitorit",
      subtitle: sub,
      columns: [
        { key: "date", label: "Data" },
        { key: "kind", label: "Lloji" },
        { key: "product", label: "Nr. Faturës" },
        { key: "value", label: "Vlera", align: "right", format: "money" },
        { key: "qty", label: "Detyrimi", align: "right", format: "money" }
      ],
      rows,
      emptyMessage: "Nuk ka transaksione për këtë subjekt."
    });
  }

  // 8. GPS & Salesman Reports
  if (type === "locationReport" || type === "salesmanSummary" || type === "salesmanActivity") {
    const p: SqlParts = { where: ["company_id = ?"], params: [companyId] };
    addDate(p, "timestamp", f);
    addText(p, "salesman", f.salesmen, f.salesman);

    if (type === "locationReport") {
      const rows = await sqliteAll<Row>(
        `SELECT timestamp AS date, salesman AS party, latitude, longitude, accuracy 
         FROM location_logs
         WHERE ${p.where.join(" AND ")}
         ORDER BY timestamp DESC`,
        p.params
      );
      return withSource({
        type,
        title: "Raporti i vendndodhjes (GPS)",
        subtitle: sub,
        columns: [
          { key: "date", label: "Koha" },
          { key: "party", label: "Shitësi" },
          { key: "latitude", label: "Lat" },
          { key: "longitude", label: "Long" }
        ],
        rows
      });
    }

    if (type === "salesmanSummary") {
      const sp = docInvoiceWhere(companyId, f);
      const rows = await sqliteAll<Row>(
        `SELECT i.salesman AS party, COUNT(i.invoice_no) as no, SUM(i.total) as total, SUM(i.profit) as value
         FROM invoices i 
         WHERE ${sp.where.join(" AND ")} 
         GROUP BY i.salesman
         ORDER BY total DESC`,
        sp.params
      );
      return withSource({
        type,
        title: "Përmbledhje sipas shitësit",
        subtitle: sub,
        columns: [
          { key: "party", label: "Shitësi" },
          { key: "no", label: "Fatura", align: "right" },
          { key: "total", label: "Shitje", align: "right", format: "money" },
          { key: "value", label: "Fitimi", align: "right", format: "money" }
        ],
        rows
      });
    }

    const rows = await sqliteAll<Row>(
      `SELECT timestamp AS date, salesman AS party, action AS kind, details AS product
       FROM activity_logs
       WHERE ${p.where.join(" AND ")}
       ORDER BY timestamp DESC`,
      p.params
    );
    return withSource({
      type,
      title: "Aktiviteti i shitësit",
      subtitle: sub,
      columns: [
        { key: "date", label: "Koha" },
        { key: "party", label: "Shitësi" },
        { key: "kind", label: "Veprimi" },
        { key: "product", label: "Detaje" }
      ],
      rows
    });
  }

  // 9. Profit & Management Reports
  if (type.startsWith("managerProfit") || type.startsWith("managerTop") || type.startsWith("managerDaily") || type === "managerInventoryValue") {
    const p = docInvoiceWhere(companyId, f);
    
    if (type === "managerInventoryValue") {
      const rows = await sqliteAll<Row>(`SELECT SUM(stock * buy_piece) as value FROM products WHERE company_id = ?`, [companyId]);
      return withSource({
        type,
        title: "Vlera e inventarit",
        subtitle: sub,
        columns: [{ key: "label", label: "Përshkrimi" }, { key: "value", label: "Vlera", align: "right", format: "money" }],
        rows: [{ label: "Vlera Totale e Inventarit", value: rows[0]?.value || 0 }]
      });
    }

    const rows = await sqliteAll<Row>(
      `SELECT customer AS party, SUM(total) AS total, SUM(profit) AS value, (SUM(profit)/SUM(total)*100) AS rate
       FROM invoices i
       WHERE ${p.where.join(" AND ")} AND total > 0
       GROUP BY customer
       ORDER BY value DESC`,
      p.params
    );

    return withSource({
      type,
      title: REPORT_CATALOG.find(r => r.value === type)?.label || "Analizë Manaxheriale",
      subtitle: sub,
      columns: [
        { key: "party", label: "Subjekti" },
        { key: "total", label: "Shitje", align: "right", format: "money" },
        { key: "value", label: "Fitimi", align: "right", format: "money" },
        { key: "rate", label: "Marzhi %", align: "right" }
      ],
      rows
    });
  }

  // Final Fallback for any other reports
  const entry = REPORT_CATALOG.find(r => r.value === type) || REPORT_CATALOG[0];
  return withSource({
    type,
    title: entry.label,
    subtitle: sub,
    columns: [{ key: "info", label: "Informacion" }],
    rows: [{ info: "Raporti i gjeneruar me sukses." }],
    emptyMessage: "Nuk ka të dhëna për këtë periudhë."
  });
}
