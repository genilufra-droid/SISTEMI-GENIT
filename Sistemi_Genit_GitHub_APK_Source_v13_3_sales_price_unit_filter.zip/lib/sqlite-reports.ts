import type { ReportFilter, ReportResult, ReportType, Column, Row } from "./reports";
import { fmt } from "./store";
import { sqliteActiveCompanyId, sqliteAll, sqliteFirst } from "./sqlite-storage";

type SqlReport = ReportResult & { source?: "sqlite" };

type SqlParts = { where: string[]; params: any[] };

function norm(s?: string): string { return String(s || "").trim().toLowerCase().replace(/\s+/g, " "); }
function periodLabel(f: ReportFilter): string {
  if (f.from && f.to) return `${f.from} → ${f.to}`;
  if (f.from) return `Nga ${f.from}`;
  if (f.to) return `Deri ${f.to}`;
  return "Të gjitha datat";
}
function addDate(parts: SqlParts, col: string, f: ReportFilter) {
  if (f.from) { parts.where.push(`${col} >= ?`); parts.params.push(f.from); }
  if (f.to) { parts.where.push(`${col} <= ?`); parts.params.push(f.to); }
}
function addText(parts: SqlParts, col: string, list?: string[], single?: string) {
  if (list && list.length) {
    const cleaned = list.map(norm).filter(Boolean);
    if (cleaned.length) {
      parts.where.push(`LOWER(TRIM(${col})) IN (${cleaned.map(() => "?").join(",")})`);
      parts.params.push(...cleaned);
    }
  } else if (single && single.trim()) {
    parts.where.push(`LOWER(${col}) LIKE ?`);
    parts.params.push(`%${norm(single)}%`);
  }
}
function addTxn(parts: SqlParts, col: string, f: ReportFilter) {
  if (!f.txnType || f.txnType === "all") return;
  if (f.txnType === "cash") parts.where.push(`${col} = 'Me arke'`);
  else parts.where.push(`${col} <> 'Me arke'`);
}
function addPayStatus(parts: SqlParts, totalCol: string, paidCol: string, f: ReportFilter) {
  if (!f.payStatus || f.payStatus === "all") return;
  if (f.payStatus === "paid") parts.where.push(`${paidCol} >= ${totalCol} - 0.001`);
  else if (f.payStatus === "unpaid") parts.where.push(`${paidCol} <= 0.001`);
  else parts.where.push(`${paidCol} > 0.001 AND ${paidCol} < ${totalCol} - 0.001`);
}
function parsePriceFilter(price?: string): number[] {
  return String(price || "")
    .split(/[;,]/)
    .map((x) => Number(String(x).trim().replace(",", ".")))
    .filter((n) => Number.isFinite(n) && n >= 0);
}
function addPriceFilter(parts: SqlParts, rateCol: string, f: ReportFilter) {
  const prices = parsePriceFilter(f.price);
  if (!prices.length) return;
  parts.where.push(`ROUND(${rateCol}, 2) IN (${prices.map(() => "?").join(",")})`);
  parts.params.push(...prices.map((p) => Math.round(p * 100) / 100));
}
function docInvoiceWhere(companyId: string, f: ReportFilter): SqlParts {
  const p: SqlParts = { where: ["i.company_id = ?"], params: [companyId] };
  addDate(p, "i.date", f);
  addText(p, "i.customer", f.clients, f.client);
  addText(p, "i.store", f.stores, f.store);
  addText(p, "i.salesman", f.salesmen, f.salesman);
  addTxn(p, "i.mode", f);
  addPayStatus(p, "i.total", "i.paid", f);
  return p;
}
function docPurchaseWhere(companyId: string, f: ReportFilter): SqlParts {
  const p: SqlParts = { where: ["p.company_id = ?"], params: [companyId] };
  addDate(p, "p.date", f);
  addText(p, "p.supplier", f.suppliers, f.supplier);
  addText(p, "p.store", f.stores, f.store);
  addText(p, "p.salesman", f.salesmen, f.salesman);
  addTxn(p, "p.mode", f);
  addPayStatus(p, "p.total", "p.paid", f);
  return p;
}
function addLineFilters(parts: SqlParts, productCol: string, unitCol: string, categoryCol: string, f: ReportFilter, rateCol?: string) {
  addText(parts, productCol, f.products, f.product);
  addText(parts, unitCol, f.units, f.unit);
  addText(parts, categoryCol, f.categories, f.category);
  if (rateCol) addPriceFilter(parts, rateCol, f);
}
function hasSaleLineFilter(f: ReportFilter): boolean {
  return Boolean(
    (f.products && f.products.length) ||
    (f.product && f.product.trim()) ||
    (f.units && f.units.length) ||
    (f.unit && f.unit.trim()) ||
    (f.categories && f.categories.length) ||
    (f.category && f.category.trim()) ||
    (f.price && f.price.trim())
  );
}
function withSource(result: ReportResult): SqlReport {
  return { ...result, subtitle: result.subtitle ? `${result.subtitle} • Burimi: SQLite` : "Burimi: SQLite", source: "sqlite" };
}
async function companyIdOrNull(): Promise<string | null> {
  return await sqliteActiveCompanyId();
}
function sum(rows: Row[], key: string): number { return rows.reduce((s, r) => s + Number((r as any)[key] || 0), 0); }
const money = (n: number) => fmt(Number(n || 0));

// Unit-display helpers for reports whose quantities are stored in BASE units (copë).
// The unit chips in the UI are DISPLAY units, not only line filters.
type ProductUnit = { name: string; coef: number };
function parseUnitsJson(raw: any): ProductUnit[] {
  try {
    const arr = JSON.parse(String(raw || "[]"));
    if (!Array.isArray(arr)) return [{ name: "Copë", coef: 1 }];
    const units = arr
      .map((u: any) => ({ name: String(u?.name || "").trim() || "Copë", coef: Math.max(1, Number(u?.coef || 1)) }))
      .filter((u: ProductUnit) => u.name);
    return units.length ? units : [{ name: "Copë", coef: 1 }];
  } catch {
    return [{ name: "Copë", coef: 1 }];
  }
}
function pickDisplayUnit(units: ProductUnit[], preferred?: string[]): ProductUnit {
  const prefs = (preferred || []).map(norm).filter(Boolean);
  for (const p of prefs) {
    const found = units.find((u) => norm(u.name) === p);
    if (found) return found;
  }
  return units.slice().sort((a, b) => b.coef - a.coef)[0] || { name: "Copë", coef: 1 };
}
function formatBaseQty(baseQty: number, unitsRaw: any, preferred?: string[]): string {
  const units = parseUnitsJson(unitsRaw).sort((a, b) => a.coef - b.coef);
  const baseUnit = units[0] || { name: "Copë", coef: 1 };
  const wanted = pickDisplayUnit(units, preferred);
  const base = Number(baseQty || 0);
  if (!wanted || wanted.coef <= 1) return `${fmt(base)} ${baseUnit.name}`;
  const sign = base < 0 ? -1 : 1;
  const abs = Math.abs(base);
  const whole = Math.floor(abs / wanted.coef);
  const rest = Number((abs - whole * wanted.coef).toFixed(6));
  const signedWhole = whole * sign;
  if (rest <= 0.000001) return `${fmt(signedWhole)} ${wanted.name}`;
  if (whole === 0) return `${fmt(rest * sign)} ${baseUnit.name}`;
  // Exact mixed-unit display: 45 Koli + 6 Copë, not rounded to 46 Koli.
  return `${fmt(signedWhole)} ${wanted.name} + ${fmt(rest)} ${baseUnit.name}`;
}

export async function buildSqliteReport(type: ReportType, f: ReportFilter): Promise<SqlReport | null> {
  const companyId = await companyIdOrNull();
  if (!companyId) return null;
  const sub = periodLabel(f);

  if (type === "salesSummary") {
    const p = docInvoiceWhere(companyId, f);
    if (hasSaleLineFilter(f)) {
      addLineFilters(p, "ii.product_name", "ii.unit", "COALESCE(pr.category,'')", f, "ii.rate");
      const rows = await sqliteAll<Row>(
        `SELECT i.invoice_no AS no, i.date, i.customer, COUNT(*) AS rows, SUM(ii.total) AS total, SUM(ii.total - ii.cost) AS profit
         FROM invoices i
         JOIN invoice_items ii ON ii.company_id=i.company_id AND ii.invoice_no=i.invoice_no
         LEFT JOIN products pr ON pr.company_id=i.company_id AND LOWER(pr.name)=LOWER(ii.product_name)
         WHERE ${p.where.join(" AND ")}
         GROUP BY i.invoice_no, i.date, i.customer
         ORDER BY i.date, i.invoice_no`,
        p.params,
      );
      return withSource({ type, title: "Regjistri Përmbledhës i Shitjeve", subtitle: `${sub} • Filtër sipas rreshtave: Artikull + Njësi + Çmim`, columns: [
        { key: "no", label: "Nr." }, { key: "date", label: "Data" }, { key: "customer", label: "Klienti" }, { key: "rows", label: "Rreshta", align: "right", format: "qty" },
        { key: "total", label: "Vlera e filtruar", align: "right", format: "money" }, { key: "profit", label: "Fitim", align: "right", format: "money" }],
        rows, summary: [{ label: "Fatura", value: String(rows.length) }, { label: "Vlerë e filtruar", value: money(sum(rows, "total")) }, { label: "Fitim", value: money(sum(rows, "profit")) }] });
    }
    const rows = await sqliteAll<Row>(`SELECT invoice_no AS no, date, customer, total, paid, due, profit FROM invoices i WHERE ${p.where.join(" AND ")} ORDER BY date, invoice_no`, p.params);
    return withSource({ type, title: "Regjistri Përmbledhës i Shitjeve", subtitle: sub, columns: [
      { key: "no", label: "Nr." }, { key: "date", label: "Data" }, { key: "customer", label: "Klienti" },
      { key: "total", label: "Totali", align: "right", format: "money" }, { key: "paid", label: "Paguar", align: "right", format: "money" }, { key: "due", label: "Detyrim", align: "right", format: "money" }, { key: "profit", label: "Fitim", align: "right", format: "money" }],
      rows, summary: [{ label: "Fatura", value: String(rows.length) }, { label: "Vlerë shitje", value: money(sum(rows, "total")) }, { label: "Paguar", value: money(sum(rows, "paid")) }, { label: "Detyrim", value: money(sum(rows, "due")) }, { label: "Fitim", value: money(sum(rows, "profit")) }] });
  }

  if (type === "salesAnalytic") {
    const p = docInvoiceWhere(companyId, f); addLineFilters(p, "ii.product_name", "ii.unit", "COALESCE(pr.category,'')", f, "ii.rate");
    const rows = await sqliteAll<Row>(`SELECT i.date, i.invoice_no AS no, i.customer AS party, ii.product_name AS product, ii.unit, ii.qty, ii.free_qty AS freeQty, (ii.qty + ii.free_qty) AS physicalQty, ii.rate, ii.total AS value, ii.cost, (ii.total - ii.cost) AS profit FROM invoices i JOIN invoice_items ii ON ii.company_id=i.company_id AND ii.invoice_no=i.invoice_no LEFT JOIN products pr ON pr.company_id=i.company_id AND LOWER(pr.name)=LOWER(ii.product_name) WHERE ${p.where.join(" AND ")} ORDER BY i.date, i.invoice_no, ii.line_no`, p.params);
    return withSource({ type, title: "Regjistri Analitik i Shitjeve", subtitle: sub, columns: [
      { key: "date", label: "Data" }, { key: "no", label: "Nr." }, { key: "party", label: "Klienti" }, { key: "product", label: "Artikulli" }, { key: "unit", label: "Njësia" }, { key: "qty", label: "Sasia", align: "right", format: "qty" }, { key: "freeQty", label: "Dhuratë", align: "right", format: "qty" }, { key: "physicalQty", label: "Tot. fizik", align: "right", format: "qty" }, { key: "rate", label: "Çmimi", align: "right", format: "money" }, { key: "value", label: "Vlera", align: "right", format: "money" }, { key: "profit", label: "Fitim", align: "right", format: "money" }],
      rows, summary: [{ label: "Rreshta", value: String(rows.length) }, { label: "Sasi", value: String(sum(rows, "qty")) }, { label: "Dhuratë", value: String(sum(rows, "freeQty")) }, { label: "Vlerë", value: money(sum(rows, "value")) }, { label: "Fitim", value: money(sum(rows, "profit")) }] });
  }

  if (type === "salesByProduct") {
    const p = docInvoiceWhere(companyId, f); addLineFilters(p, "ii.product_name", "ii.unit", "COALESCE(pr.category,'')", f, "ii.rate");
    const rows = await sqliteAll<Row>(`SELECT ii.product_name AS product, ii.unit, ii.rate, SUM(ii.qty) AS qty, SUM(ii.free_qty) AS freeQty, SUM(ii.qty + ii.free_qty) AS physicalQty, SUM(ii.total) AS value, SUM(ii.cost) AS cost, SUM(ii.total - ii.cost) AS profit FROM invoices i JOIN invoice_items ii ON ii.company_id=i.company_id AND ii.invoice_no=i.invoice_no LEFT JOIN products pr ON pr.company_id=i.company_id AND LOWER(pr.name)=LOWER(ii.product_name) WHERE ${p.where.join(" AND ")} GROUP BY ii.product_name, ii.unit, ROUND(ii.rate,2) ORDER BY ii.product_name, ii.unit, ii.rate DESC`, p.params);
    return withSource({ type, title: "Shitje sipas artikullit / njësisë / çmimit", subtitle: sub, columns: [
      { key: "product", label: "Artikulli" }, { key: "unit", label: "Njësia" }, { key: "rate", label: "Çmimi", align: "right", format: "money" }, { key: "qty", label: "Sasia", align: "right", format: "qty" }, { key: "freeQty", label: "Dhuratë", align: "right", format: "qty" }, { key: "physicalQty", label: "Tot. fizik", align: "right", format: "qty" }, { key: "value", label: "Vlerë", align: "right", format: "money" }, { key: "cost", label: "Kosto", align: "right", format: "money" }, { key: "profit", label: "Fitim", align: "right", format: "money" }],
      rows, summary: [{ label: "Vlerë", value: money(sum(rows, "value")) }, { label: "Dhuratë", value: String(sum(rows, "freeQty")) }, { label: "Fitim", value: money(sum(rows, "profit")) }] });
  }

  if (type === "salesByClient") {
    const p = docInvoiceWhere(companyId, f);
    const rows = await sqliteAll<Row>(`SELECT customer AS party, COUNT(*) AS count, SUM(total) AS total, SUM(profit) AS profit, SUM(due) AS due FROM invoices i WHERE ${p.where.join(" AND ")} GROUP BY customer ORDER BY total DESC`, p.params);
    return withSource({ type, title: "Shitje sipas klientit", subtitle: sub, columns: [{ key: "party", label: "Klienti" }, { key: "count", label: "Fatura", align: "right", format: "qty" }, { key: "total", label: "Totali", align: "right", format: "money" }, { key: "profit", label: "Fitim", align: "right", format: "money" }, { key: "due", label: "Detyrim", align: "right", format: "money" }], rows, summary: [{ label: "Total", value: money(sum(rows, "total")) }] });
  }

  if (type === "salesDaily") {
    const p = docInvoiceWhere(companyId, f);
    const rows = await sqliteAll<Row>(`SELECT date, COUNT(*) AS count, SUM(total) AS total, SUM(profit) AS profit FROM invoices i WHERE ${p.where.join(" AND ")} GROUP BY date ORDER BY date`, p.params);
    return withSource({ type, title: "Shitje ditore", subtitle: sub, columns: [{ key: "date", label: "Data" }, { key: "count", label: "Fatura", align: "right", format: "qty" }, { key: "total", label: "Totali", align: "right", format: "money" }, { key: "profit", label: "Fitim", align: "right", format: "money" }], rows });
  }


  if (type === "salesByClient") {
    const p = docInvoiceWhere(companyId, f);
    if (hasSaleLineFilter(f)) {
      addLineFilters(p, "ii.product_name", "ii.unit", "COALESCE(pr.category,'')", f, "ii.rate");
      const rows = await sqliteAll<Row>(
        `SELECT i.customer AS party, COUNT(DISTINCT i.invoice_no) AS count, SUM(ii.total) AS total, SUM(ii.total - ii.cost) AS profit
         FROM invoices i
         JOIN invoice_items ii ON ii.company_id=i.company_id AND ii.invoice_no=i.invoice_no
         LEFT JOIN products pr ON pr.company_id=i.company_id AND LOWER(pr.name)=LOWER(ii.product_name)
         WHERE ${p.where.join(" AND ")}
         GROUP BY i.customer
         ORDER BY total DESC`,
        p.params,
      );
      return withSource({ type, title: "Shitje sipas klientit", subtitle: `${sub} • Totalet janë sipas rreshtave të filtruar`, columns: [
        { key: "party", label: "Klienti" }, { key: "count", label: "Fatura", align: "right", format: "qty" }, { key: "total", label: "Vlera e filtruar", align: "right", format: "money" }, { key: "profit", label: "Fitim", align: "right", format: "money" }],
        rows, summary: [{ label: "Total", value: money(sum(rows, "total")) }] });
    }
    const rows = await sqliteAll<Row>(`SELECT customer AS party, COUNT(*) AS count, SUM(total) AS total, SUM(profit) AS profit, SUM(due) AS due FROM invoices i WHERE ${p.where.join(" AND ")} GROUP BY customer ORDER BY total DESC`, p.params);
    return withSource({ type, title: "Shitje sipas klientit", subtitle: sub, columns: [
      { key: "party", label: "Klienti" }, { key: "count", label: "Fatura", align: "right", format: "qty" }, { key: "total", label: "Totali", align: "right", format: "money" }, { key: "profit", label: "Fitim", align: "right", format: "money" }, { key: "due", label: "Detyrim", align: "right", format: "money" }],
      rows, summary: [{ label: "Total", value: money(sum(rows, "total")) }] });
  }

  if (type === "salesDaily") {
    const p = docInvoiceWhere(companyId, f);
    if (hasSaleLineFilter(f)) {
      addLineFilters(p, "ii.product_name", "ii.unit", "COALESCE(pr.category,'')", f, "ii.rate");
      const rows = await sqliteAll<Row>(
        `SELECT i.date, COUNT(DISTINCT i.invoice_no) AS count, SUM(ii.total) AS total, SUM(ii.total - ii.cost) AS profit
         FROM invoices i
         JOIN invoice_items ii ON ii.company_id=i.company_id AND ii.invoice_no=i.invoice_no
         LEFT JOIN products pr ON pr.company_id=i.company_id AND LOWER(pr.name)=LOWER(ii.product_name)
         WHERE ${p.where.join(" AND ")}
         GROUP BY i.date
         ORDER BY i.date`,
        p.params,
      );
      return withSource({ type, title: "Shitje ditore", subtitle: `${sub} • Totalet janë sipas rreshtave të filtruar`, columns: [
        { key: "date", label: "Data" }, { key: "count", label: "Fatura", align: "right", format: "qty" }, { key: "total", label: "Vlera e filtruar", align: "right", format: "money" }, { key: "profit", label: "Fitim", align: "right", format: "money" }],
        rows, summary: [{ label: "Total", value: money(sum(rows, "total")) }] });
    }
    const rows = await sqliteAll<Row>(`SELECT date, COUNT(*) AS count, SUM(total) AS total, SUM(profit) AS profit FROM invoices i WHERE ${p.where.join(" AND ")} GROUP BY date ORDER BY date`, p.params);
    return withSource({ type, title: "Shitje ditore", subtitle: sub, columns: [
      { key: "date", label: "Data" }, { key: "count", label: "Fatura", align: "right", format: "qty" }, { key: "total", label: "Totali", align: "right", format: "money" }, { key: "profit", label: "Fitim", align: "right", format: "money" }], rows });
  }

  if (type === "salesSummaryInvoice") {
    const p = docInvoiceWhere(companyId, f);
    if (hasSaleLineFilter(f)) {
      addLineFilters(p, "ii.product_name", "ii.unit", "COALESCE(pr.category,'')", f, "ii.rate");
      const rows = await sqliteAll<Row>(
        `SELECT i.date, i.customer AS party, SUM(ii.total) AS total, SUM(ii.total - ii.cost) AS profit
         FROM invoices i
         JOIN invoice_items ii ON ii.company_id=i.company_id AND ii.invoice_no=i.invoice_no
         LEFT JOIN products pr ON pr.company_id=i.company_id AND LOWER(pr.name)=LOWER(ii.product_name)
         WHERE ${p.where.join(" AND ")}
         GROUP BY i.date, i.customer
         ORDER BY i.date, i.customer`,
        p.params,
      );
      return withSource({ type, title: "Faturë përmbledhëse shitje", subtitle: `${sub} • Totalet janë sipas rreshtave të filtruar`, columns: [
        { key: "date", label: "Data" }, { key: "party", label: "Klienti" }, { key: "total", label: "Vlera e filtruar", align: "right", format: "money" }, { key: "profit", label: "Fitim", align: "right", format: "money" }], rows, summary: [{ label: "Vlerë", value: money(sum(rows, "total")) }] });
    }
    const rows = await sqliteAll<Row>(`SELECT date, customer AS party, SUM(total) AS total, SUM(profit) AS profit FROM invoices i WHERE ${p.where.join(" AND ")} GROUP BY date, customer ORDER BY date, customer`, p.params);
    return withSource({ type, title: "Faturë përmbledhëse shitje", subtitle: sub, columns: [
      { key: "date", label: "Data" }, { key: "party", label: "Klienti" }, { key: "total", label: "Totali", align: "right", format: "money" }, { key: "profit", label: "Fitim", align: "right", format: "money" }], rows, summary: [{ label: "Vlerë", value: money(sum(rows, "total")) }] });
  }

  if (type === "purchaseAnalytic") {
    const p = docPurchaseWhere(companyId, f); addLineFilters(p, "pi.product_name", "pi.unit", "COALESCE(pr.category,'')", f);
    const rows = await sqliteAll<Row>(`SELECT p.date, p.purchase_no AS no, p.supplier AS party, pi.product_name AS product, pi.unit, pi.qty, pi.free_qty AS freeQty, (pi.qty + pi.free_qty) AS physicalQty, pi.rate, pi.total AS value, pi.cost FROM purchases p JOIN purchase_items pi ON pi.company_id=p.company_id AND pi.purchase_no=p.purchase_no LEFT JOIN products pr ON pr.company_id=p.company_id AND LOWER(pr.name)=LOWER(pi.product_name) WHERE ${p.where.join(" AND ")} ORDER BY p.date, p.purchase_no, pi.line_no`, p.params);
    return withSource({ type, title: "Regjistri Analitik i Blerjeve", subtitle: sub, columns: [{ key: "date", label: "Data" }, { key: "no", label: "Nr." }, { key: "party", label: "Furnitori" }, { key: "product", label: "Artikulli" }, { key: "unit", label: "Njësia" }, { key: "qty", label: "Sasia", align: "right", format: "qty" }, { key: "freeQty", label: "Dhuratë", align: "right", format: "qty" }, { key: "physicalQty", label: "Tot. fizik", align: "right", format: "qty" }, { key: "rate", label: "Çmimi", align: "right", format: "money" }, { key: "value", label: "Vlera", align: "right", format: "money" }], rows, summary: [{ label: "Rreshta", value: String(rows.length) }, { label: "Vlerë", value: money(sum(rows, "value")) }] });
  }

  if (type === "purchaseBySupplier") {
    const p = docPurchaseWhere(companyId, f);
    const rows = await sqliteAll<Row>(`SELECT supplier AS party, COUNT(*) AS count, SUM(total) AS total, SUM(paid) AS paid, SUM(due) AS due FROM purchases p WHERE ${p.where.join(" AND ")} GROUP BY supplier ORDER BY total DESC`, p.params);
    return withSource({ type, title: "Blerje sipas furnitorit", subtitle: sub, columns: [{ key: "party", label: "Furnitori" }, { key: "count", label: "Fatura", align: "right", format: "qty" }, { key: "total", label: "Totali", align: "right", format: "money" }, { key: "paid", label: "Paguar", align: "right", format: "money" }, { key: "due", label: "Detyrim", align: "right", format: "money" }], rows, summary: [{ label: "Total", value: money(sum(rows, "total")) }] });
  }

  if (type === "purchaseByProduct") {
    const p = docPurchaseWhere(companyId, f); addLineFilters(p, "pi.product_name", "pi.unit", "COALESCE(pr.category,'')", f);
    const rows = await sqliteAll<Row>(`SELECT pi.product_name AS product, pi.unit, SUM(pi.qty) AS qty, SUM(pi.free_qty) AS freeQty, SUM(pi.qty + pi.free_qty) AS physicalQty, SUM(pi.total) AS value, SUM(pi.cost) AS cost FROM purchases p JOIN purchase_items pi ON pi.company_id=p.company_id AND pi.purchase_no=p.purchase_no LEFT JOIN products pr ON pr.company_id=p.company_id AND LOWER(pr.name)=LOWER(pi.product_name) WHERE ${p.where.join(" AND ")} GROUP BY pi.product_name, pi.unit ORDER BY value DESC`, p.params);
    return withSource({ type, title: "Blerje sipas artikullit", subtitle: sub, columns: [{ key: "product", label: "Artikulli" }, { key: "unit", label: "Njësia" }, { key: "qty", label: "Sasia", align: "right", format: "qty" }, { key: "freeQty", label: "Dhuratë", align: "right", format: "qty" }, { key: "physicalQty", label: "Tot. fizik", align: "right", format: "qty" }, { key: "value", label: "Vlerë", align: "right", format: "money" }, { key: "cost", label: "Kosto", align: "right", format: "money" }], rows, summary: [{ label: "Vlerë", value: money(sum(rows, "value")) }] });
  }

  if (type === "stockSummary") {
    const p: SqlParts = { where: ["company_id = ?"], params: [companyId] };
    addText(p, "name", f.products, f.product); addText(p, "default_store", f.stores, f.store); addText(p, "category", f.categories, f.category);
    const rows = await sqliteAll<Row>(`SELECT name AS product, category, default_store AS store, stock_base AS stock, min_stock AS minStock, sale_piece AS salePiece, buy_piece AS buyPiece, (stock_base * buy_piece) AS stockValue FROM products WHERE ${p.where.join(" AND ")} ORDER BY name`, p.params);
    return withSource({ type, title: "Gjendja aktuale e stokut", subtitle: sub, columns: [{ key: "product", label: "Artikulli" }, { key: "category", label: "Kategori" }, { key: "store", label: "Magazina" }, { key: "stock", label: "Gjendje copë", align: "right", format: "qty" }, { key: "minStock", label: "Min." , align: "right", format: "qty"}, { key: "buyPiece", label: "Kosto/copë", align: "right", format: "money" }, { key: "stockValue", label: "Vlerë stoku", align: "right", format: "money" }], rows, summary: [{ label: "Artikuj", value: String(rows.length) }, { label: "Vlerë stoku", value: money(sum(rows, "stockValue")) }] });
  }

  if (type === "stockMovement") {
    const p: SqlParts = { where: ["company_id = ?"], params: [companyId] };
    addDate(p, "date", f); addText(p, "warehouse", f.stores, f.store); addText(p, "product_name", f.products, f.product);
    const rows = await sqliteAll<Row>(`SELECT date, doc_no AS no, warehouse AS store, product_name AS product, doc_type AS type, in_base AS inBase, out_base AS outBase, balance_after AS balance, note FROM stock_movements WHERE ${p.where.join(" AND ")} ORDER BY date, movement_id`, p.params);
    return withSource({ type, title: "Lëvizjet e magazinës", subtitle: sub, columns: [{ key: "date", label: "Data" }, { key: "no", label: "Dok." }, { key: "store", label: "Magazina" }, { key: "product", label: "Artikulli" }, { key: "type", label: "Lloji" }, { key: "inBase", label: "Hyrje", align: "right", format: "qty" }, { key: "outBase", label: "Dalje", align: "right", format: "qty" }, { key: "balance", label: "Gjendje", align: "right", format: "qty" }, { key: "note", label: "Shënim" }], rows });
  }

  if (type === "inboundDocsReport" || type === "outboundDocsReport" || type === "inventoryDocsReport") {
    const kind = type === "inboundDocsReport" ? "inbound" : type === "outboundDocsReport" ? "outbound" : "inventory";
    const title = kind === "inbound" ? "Raporti Fletë Hyrje" : kind === "outbound" ? "Raporti Fletë Dalje" : "Raporti Inventar Fizik";
    const p: SqlParts = { where: ["company_id = ?", "doc_kind = ?"], params: [companyId, kind] };
    addDate(p, "date", f); addText(p, "warehouse", f.stores, f.store);
    const rows = await sqliteAll<Row>(`SELECT doc_no AS no, date, warehouse AS store, party, destination_address AS destination, total_qty AS qty, total_value AS value, status FROM warehouse_docs WHERE ${p.where.join(" AND ")} ORDER BY date, doc_id`, p.params);
    return withSource({ type, title, subtitle: sub, columns: [{ key: "no", label: "Nr." }, { key: "date", label: "Data" }, { key: "store", label: "Magazina" }, { key: "party", label: "Palë" }, { key: "destination", label: "Destinacion" }, { key: "qty", label: "Sasi" , align: "right", format: "qty"}, { key: "value", label: "Vlerë" , align: "right", format: "money"}, { key: "status", label: "Status" }], rows, summary: [{ label: "Dokumente", value: String(rows.length) }] });
  }

  if (type === "supplyNeed" || type === "kerkeseFurnizimi") {
    // V11: Kërkesë Furnizimi is the counterpart of Shitje Sot / Dalje:
    // whatever physically left the warehouse in the selected period becomes the
    // quantity requested for replenishment. No price/value columns here.
    const p: SqlParts = { where: ["company_id = ?", "out_base > 0"], params: [companyId] };
    addDate(p, "date", f);
    addText(p, "warehouse", f.stores, f.store);
    addText(p, "product_name", f.products, f.product);
    const rawRows = await sqliteAll<Row>(
      `SELECT sm.product_name AS product,
              sm.warehouse AS store,
              SUM(sm.out_base) AS needBase,
              pr.units_json AS unitsJson,
              GROUP_CONCAT(DISTINCT sm.doc_no) AS docs
       FROM stock_movements sm
       LEFT JOIN products pr ON pr.company_id=sm.company_id AND LOWER(pr.name)=LOWER(sm.product_name)
       WHERE ${p.where.join(" AND ").replace(/\bcompany_id\b/g, "sm.company_id").replace(/\bdate\b/g, "sm.date").replace(/\bwarehouse\b/g, "sm.warehouse").replace(/\bproduct_name\b/g, "sm.product_name")}
         AND sm.doc_type IN ('sale','gift','outbound','transfer-out')
       GROUP BY sm.product_name, sm.warehouse, pr.units_json
       HAVING SUM(sm.out_base) > 0
       ORDER BY sm.product_name, sm.warehouse`,
      p.params,
    );
    const rows = rawRows.map((r: any) => ({
      product: r.product,
      store: r.store,
      need: formatBaseQty(Number(r.needBase || 0), r.unitsJson, f.units || (f.unit ? [f.unit] : [])),
      baseQty: Number(r.needBase || 0),
      docs: r.docs || "",
    }));
    return withSource({
      type,
      title: "Kërkesë Furnizimi sipas Daljeve",
      subtitle: `${sub} • Çfarë doli/shit = çfarë furnizohet • Pa çmime/vlera • Njësia sipas filtrit`,
      columns: [
        { key: "product", label: "Artikulli" },
        { key: "store", label: "Magazina/Furgoni" },
        { key: "need", label: "Sasia për furnizim" },
        { key: "docs", label: "Dokumente dalje" },
      ],
      rows,
      summary: [
        { label: "Artikuj për furnizim", value: String(rows.length) },
        { label: "Sasi totale bazë", value: `${fmt(rows.reduce((a: number, r: any) => a + Number(r.baseQty || 0), 0))} Copë` },
      ],
    });
  }

  if (type === "clientBalances" || type === "supplierBalances") {
    const partyType = type === "clientBalances" ? "customer" : "supplier";
    const partyLabel = type === "clientBalances" ? "Klienti" : "Furnitori";
    const docTable = type === "clientBalances" ? "invoices" : "purchases";
    const partyCol = type === "clientBalances" ? "customer" : "supplier";
    const title = type === "clientBalances" ? "Detyrime sipas klientëve" : "Detyrime sipas furnitorëve";
    const p: SqlParts = { where: ["pt.company_id = ?", "pt.party_type = ?"], params: [companyId, partyType] };
    if (partyType === "customer") addText(p, "pt.name", f.clients, f.client); else addText(p, "pt.name", f.suppliers, f.supplier);
    const rows = await sqliteAll<Row>(`SELECT pt.name AS party, COALESCE(pt.opening_balance,0) AS opening, COALESCE(d.total,0) AS billed, COALESCE(d.due,0) AS due, COALESCE(pay.paid,0) AS paidExtra, COALESCE(pt.opening_balance,0) + COALESCE(d.due,0) - COALESCE(pay.paid,0) AS balance FROM parties pt LEFT JOIN (SELECT company_id, ${partyCol} AS party, SUM(total) AS total, SUM(due) AS due FROM ${docTable} GROUP BY company_id, ${partyCol}) d ON d.company_id=pt.company_id AND LOWER(d.party)=LOWER(pt.name) LEFT JOIN (SELECT company_id, party, SUM(amount) AS paid FROM payments WHERE party_type='${partyType}' GROUP BY company_id, party) pay ON pay.company_id=pt.company_id AND LOWER(pay.party)=LOWER(pt.name) WHERE ${p.where.join(" AND ")} ORDER BY balance DESC, pt.name`, p.params);
    return withSource({ type, title, subtitle: sub, columns: [{ key: "party", label: partyLabel }, { key: "opening", label: "Hapje", align: "right", format: "money" }, { key: "billed", label: "Faturuar", align: "right", format: "money" }, { key: "due", label: "Detyrim fature", align: "right", format: "money" }, { key: "paidExtra", label: "Pagesa", align: "right", format: "money" }, { key: "balance", label: "Balancë", align: "right", format: "money" }], rows, summary: [{ label: "Balancë totale", value: money(sum(rows, "balance")) }] });
  }

  return null;
}

export async function sqliteReportsHealthCheck(): Promise<{ ok: boolean; message: string; reportCounts: Record<string, number> }> {
  const checks: ReportType[] = ["salesSummary", "salesAnalytic", "salesByProduct", "purchaseAnalytic", "purchaseByProduct", "stockSummary", "stockMovement", "inboundDocsReport", "outboundDocsReport", "supplyNeed", "clientBalances", "supplierBalances"];
  const reportCounts: Record<string, number> = {};
  try {
    for (const t of checks) {
      const r = await buildSqliteReport(t, {});
      reportCounts[t] = r ? r.rows.length : -1;
    }
    return { ok: true, message: "Raportet kryesore lexohen direkt nga SQLite.", reportCounts };
  } catch (e: any) {
    return { ok: false, message: String(e?.message || e), reportCounts };
  }
}
